import svgPaths from "./svg-wbv5xshn00";

function Checkbox1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Checkbox">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Checkbox">
          <rect fill="var(--fill-0, #3482FF)" height="24" rx="7" width="24" />
          <path d={svgPaths.p28bd7700} fill="var(--fill-0, white)" id="Path 94" />
        </g>
      </svg>
    </div>
  );
}

function Checkbox() {
  return (
    <div className="absolute bg-[#3482ff] content-stretch flex items-center left-[23px] rounded-[7px] top-[31px]" data-name="Checkbox">
      <Checkbox1 />
    </div>
  );
}

export default function Hover() {
  return (
    <div className="bg-[#212121] border border-[#e3e3e3] border-solid overflow-clip relative rounded-[12px] size-full" data-name="Hover">
      <p className="absolute font-['Poppins:SemiBold',sans-serif] leading-[35px] left-[23px] not-italic text-[20px] text-white top-[85px]">Sell Side</p>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[23px] not-italic text-[#a4a4a4] text-[14px] top-[128px] w-[382px] whitespace-pre-wrap">Empresas que buscam captar recursos e estruturar operações financeiras.</p>
      <Checkbox />
    </div>
  );
}