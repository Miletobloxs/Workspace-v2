import svgPaths from "./svg-7jshp6ntt2";
import imgImage from "figma:asset/a147ff8dce0ec5dab07efd8a0c0b6bdb328c3f1c.png";
import imgImage1 from "figma:asset/9fd896954628b3d7537af055fd9d7856d30759a4.png";
import imgImage2 from "figma:asset/ea67d7bea44d680ca654a4fae82ab3c999378f5b.png";
import imgImage3 from "figma:asset/9a8e3295558857dc96c9e60a2ae4f30d3cab6c73.png";

function InterfaceEssentialHomeHouse() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/Home, House">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.pd3c4230} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function BreadcrumbItem() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Breadcrumb Item">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Operações</p>
    </div>
  );
}

function BreadcrumbGroup() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Breadcrumb Group">
      <InterfaceEssentialHomeHouse />
      <ArrowsDiagramsArrow />
      <BreadcrumbItem />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <path d={svgPaths.p21e79c40} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2bbfc300} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p1f5ccf80} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p15583a00} id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p3bdcf300} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path clipRule="evenodd" d={svgPaths.p25e4c80} fillRule="evenodd" id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function SeoSearchLoapFast() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="SEO/search-loap-fast">
      <Group />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Consulta de viabilidade</p>
    </div>
  );
}

function Tab() {
  return (
    <div className="bg-white content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative shrink-0" data-name="Tab">
      <SeoSearchLoapFast />
      <Content />
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Ofertas públicas</p>
    </div>
  );
}

function Tab1() {
  return (
    <div className="bg-white content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative shrink-0" data-name="Tab">
      <Content1 />
    </div>
  );
}

function NavigationLinks() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center relative rounded-[8px] shrink-0" data-name="Navigation Links">
      <Tab />
      <Tab1 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-5%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.5 16.5">
          <g id="Group">
            <path d="M11.5833 0.75H15.75V4.91667" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M9.91667 6.58333L15.75 0.75" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2352106f} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <Group2 />
    </div>
  );
}

function NewOperationIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="New Operation Icon">
      <Group1 />
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Listar nova operação</p>
    </div>
  );
}

function TextLink() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center overflow-clip relative rounded-[8px] shrink-0" data-name="Text Link">
      <NewOperationIcon />
      <Content2 />
    </div>
  );
}

function NavigationContainer() {
  return (
    <div className="content-stretch flex items-center justify-between pb-[16px] relative shrink-0 w-full" data-name="Navigation Container">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <NavigationLinks />
      <TextLink />
      <div className="absolute bottom-0 flex h-[3px] items-center justify-center left-0 w-[225px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[#2e61ff] h-[225px] rounded-br-[4px] rounded-tr-[4px] w-[3px]" data-name="state" />
        </div>
      </div>
    </div>
  );
}

function HeaderContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Header Container">
      <BreadcrumbGroup />
      <NavigationContainer />
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9f0712] text-[12px]">3 deals</p>
    </div>
  );
}

function StatusBadge() {
  return (
    <div className="bg-[#ffe2e2] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Status Badge">
      <Content3 />
    </div>
  );
}

function TitleIndicator() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="Title+Indicator">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        R$ 1.2M
      </p>
      <StatusBadge />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[14px]">Em consulta de viabilidade</p>
      <TitleIndicator />
    </div>
  );
}

function InformationCircleSolid() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g clipPath="url(#clip0_8_21391)" id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.p191d3280} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_8_21391">
            <rect fill="white" height="15" width="15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex items-start justify-between overflow-clip relative shrink-0 w-full">
      <Frame13 />
      <InformationCircleSolid />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex items-center justify-between leading-[1.4] not-italic relative shrink-0 text-[14px] w-full">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">R$ 300K para o objetivo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#475569]">62%</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col h-[8px] items-start relative rounded-[4px] shrink-0 w-full">
      <div className="bg-[#00bc7d] h-[8px] rounded-[5px] shrink-0 w-[146.118px]" />
    </div>
  );
}

function Line() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start overflow-clip relative shrink-0 w-full" data-name="Line">
      <Frame10 />
      <Frame />
    </div>
  );
}

function Frame1() {
  return (
    <div className="bg-white flex-[1_0_0] h-[200px] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start justify-between p-[20px] relative size-full">
          <Frame11 />
          <Line />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Head() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start not-italic relative shrink-0" data-name="Head">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] relative shrink-0 text-[#64748b] text-[14px]">Buy Sides engajados</p>
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        24
      </p>
    </div>
  );
}

function InformationCircleSolid1() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g clipPath="url(#clip0_1_7245)" id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.p191d3280} fill="var(--fill-0, #94A3B8)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_7245">
            <rect fill="white" height="15" width="15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Head />
      <InformationCircleSolid1 />
    </div>
  );
}

function Avatar() {
  return (
    <div className="bg-[#3482ff] mr-[-10px] relative rounded-[90px] shrink-0 size-[36px]" data-name="Avatar">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[9.9px] py-[10.8px] relative rounded-[inherit] size-full">
        <p className="font-['Poppins:SemiBold',sans-serif] leading-[10.8px] not-italic relative shrink-0 text-[10.8px] text-center text-white">A</p>
      </div>
      <div aria-hidden="true" className="absolute border-2 border-solid border-white inset-0 pointer-events-none rounded-[90px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Avatar1() {
  return (
    <div className="mr-[-10px] relative rounded-[90px] shrink-0 size-[36px]" data-name="Avatar">
      <div aria-hidden="true" className="absolute border-2 border-solid border-white inset-0 pointer-events-none rounded-[90px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="absolute inset-0 rounded-[90px]" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[90px] size-full" src={imgImage} />
      </div>
    </div>
  );
}

function Avatar2() {
  return (
    <div className="bg-[#f9f9f9] mr-[-10px] relative rounded-[90px] shrink-0 size-[36px]" data-name="Avatar">
      <div aria-hidden="true" className="absolute border-2 border-solid border-white inset-0 pointer-events-none rounded-[90px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="absolute inset-0 rounded-[90px]" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[90px] size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Avatar3() {
  return (
    <div className="mr-[-10px] relative rounded-[90px] shrink-0 size-[36px]" data-name="Avatar">
      <div aria-hidden="true" className="absolute border-2 border-solid border-white inset-0 pointer-events-none rounded-[90px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="absolute inset-0 rounded-[90px]" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[90px] size-full" src={imgImage2} />
      </div>
    </div>
  );
}

function Avatar4() {
  return (
    <div className="bg-[#d63384] mr-[-10px] relative rounded-[90px] shrink-0 size-[36px]" data-name="Avatar">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[9.9px] py-[10.8px] relative rounded-[inherit] size-full">
        <p className="font-['Poppins:SemiBold',sans-serif] leading-[10.8px] not-italic relative shrink-0 text-[#f8f5ff] text-[10.8px] text-center">P</p>
      </div>
      <div aria-hidden="true" className="absolute border-2 border-solid border-white inset-0 pointer-events-none rounded-[90px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Avatar5() {
  return (
    <div className="bg-[#f1f5f9] mr-[-10px] relative rounded-[90px] shrink-0 size-[36px]" data-name="Avatar">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[9.9px] py-[10.8px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#64748b] text-[10px] text-center uppercase">+18</p>
      </div>
      <div aria-hidden="true" className="absolute border-2 border-solid border-white inset-0 pointer-events-none rounded-[90px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function AvatarGroup() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex items-end overflow-clip pl-[4px] pr-[14px] py-[4px] relative rounded-[9999px] shrink-0" data-name="Avatar Group">
      <Avatar />
      <Avatar1 />
      <Avatar2 />
      <Avatar3 />
      <Avatar4 />
      <Avatar5 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="bg-white flex-[1_0_0] h-[200px] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start justify-between p-[20px] relative size-full">
          <Frame8 />
          <AvatarGroup />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">5 deals</p>
    </div>
  );
}

function StatusBadge1() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Status Badge">
      <Content4 />
    </div>
  );
}

function Indicator1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Indicator">
      <StatusBadge1 />
    </div>
  );
}

function Indicator() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Indicator">
      <Indicator1 />
    </div>
  );
}

function TitleIndicator1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="Title+Indicator">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        R$ 10M
      </p>
      <Indicator />
    </div>
  );
}

function TitleSubtitle() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="Title+Subtitle">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[14px]">Concluídos</p>
      <TitleIndicator1 />
    </div>
  );
}

function InformationCircleSolid2() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g clipPath="url(#clip0_1_7245)" id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.p191d3280} fill="var(--fill-0, #94A3B8)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_7245">
            <rect fill="white" height="15" width="15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <TitleSubtitle />
      <InformationCircleSolid2 />
    </div>
  );
}

function Color() {
  return (
    <div className="bg-[#00bc7d] h-[12px] relative rounded-[4px] shrink-0 w-[130px]" data-name="Color 1">
      <div aria-hidden="true" className="absolute border border-[rgba(15,23,42,0.12)] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Color1() {
  return (
    <div className="bg-[#fd7e14] flex-[1_0_0] h-[12px] min-h-px min-w-px relative rounded-[4px]" data-name="Color 2">
      <div aria-hidden="true" className="absolute border border-[rgba(15,23,42,0.12)] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Color2() {
  return (
    <div className="bg-[#f1f5f9] h-[12px] relative rounded-[4px] shrink-0 w-[24px]" data-name="Color 3">
      <div aria-hidden="true" className="absolute border border-[rgba(15,23,42,0.12)] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function StackedProgressBar() {
  return (
    <div className="content-stretch flex gap-[5px] items-start relative shrink-0 w-full" data-name="Stacked Progress Bar">
      <Color />
      <Color1 />
      <Color2 />
    </div>
  );
}

function SquareGreenSolid() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="square-green-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#00bc7d] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[2px] size-[8px] top-1/2" />
    </div>
  );
}

function It1() {
  return (
    <div className="content-stretch flex gap-[4px] items-center overflow-clip relative shrink-0" data-name="It">
      <SquareGreenSolid />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Imobiliário</p>
    </div>
  );
}

function SquareRedSolid() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="square-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#fd7e14] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[2px] size-[8px] top-1/2" />
    </div>
  );
}

function Text() {
  return (
    <div className="content-stretch flex gap-[4px] items-center overflow-clip relative shrink-0" data-name="Text">
      <SquareRedSolid />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Agronegócio</p>
    </div>
  );
}

function SquareGreySolid() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="square-grey-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#f1f5f9] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[2px] size-[8px] top-1/2" />
    </div>
  );
}

function It2() {
  return (
    <div className="content-stretch flex gap-[4px] items-center overflow-clip relative shrink-0" data-name="It">
      <SquareGreySolid />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Outros</p>
    </div>
  );
}

function It() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full" data-name="It">
      <It1 />
      <Text />
      <It2 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <StackedProgressBar />
      <It />
    </div>
  );
}

function Frame3() {
  return (
    <div className="bg-white flex-[1_0_0] h-[200px] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start justify-between p-[20px] relative size-full">
          <Frame6 />
          <Frame15 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function TitleSubtitle1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0" data-name="Title+Subtitle">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] relative shrink-0 text-[#64748b] text-[14px]">Tempo médio das operações</p>
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        12 dias
      </p>
    </div>
  );
}

function InformationCircleSolid3() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g clipPath="url(#clip0_1_7245)" id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.p191d3280} fill="var(--fill-0, #94A3B8)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_7245">
            <rect fill="white" height="15" width="15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <TitleSubtitle1 />
      <InformationCircleSolid3 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="h-[77px] relative shrink-0 w-full">
      <div className="absolute bg-[#f1f5f9] h-[46px] left-0 rounded-[6px] top-[31px] w-[30px]" data-name="Rectangle" />
      <div className="absolute bg-[#f1f5f9] h-[77px] left-[40px] rounded-[6px] top-0 w-[29px]" data-name="Rectangle" />
      <div className="absolute bg-[#2e61ff] h-[39px] left-[40px] rounded-[6px] top-[38px] w-[29px]" data-name="Rectangle" />
      <div className="absolute bg-[#f1f5f9] h-[50px] left-[79px] rounded-[6px] top-[27px] w-[30px]" data-name="Rectangle" />
      <div className="absolute bg-[#f1f5f9] h-[77px] left-[119px] rounded-[6px] top-0 w-[29px]" data-name="Rectangle" />
      <div className="absolute bg-[#f1f5f9] h-[63px] left-[158px] rounded-[6px] top-[14px] w-[30px]" data-name="Rectangle" />
      <div className="absolute bg-[#2e61ff] h-[27px] left-[158px] rounded-[6px] top-[50px] w-[30px]" data-name="Rectangle" />
      <div className="absolute bg-[#f1f5f9] h-[77px] left-[198px] rounded-[6px] top-0 w-[29px]" data-name="Rectangle" />
      <div className="absolute bg-[#f1f5f9] h-[32px] left-[237px] rounded-[6px] top-[45px] w-[30px]" data-name="Rectangle" />
    </div>
  );
}

function Frame4() {
  return (
    <div className="bg-white flex-[1_0_0] h-[200px] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start justify-between p-[20px] relative size-full">
          <Frame7 />
          <Frame5 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
      <Frame1 />
      <Frame2 />
      <Frame3 />
      <Frame4 />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[12px] whitespace-pre-wrap" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#f1f5f9] w-full">Em consulta de viabilidade</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#cbd5e1] w-full">Valor das operações em fase inicial de avaliação.</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p2a1f0000} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3a6fd2e0} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDeleteDisabled() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/Delete, Disabled">
      <Group3 />
    </div>
  );
}

function Tooltip1() {
  return (
    <div className="bg-[#0f172a] relative rounded-[12px] shrink-0 w-full" data-name="Tooltip">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-start pl-[16px] pr-[12px] py-[12px] relative w-full">
          <Container />
          <InterfaceEssentialDeleteDisabled />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-[-1px] pointer-events-none rounded-[13px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Tail1() {
  return (
    <div className="h-[6px] relative w-[12px]" data-name="Tail">
      <div className="absolute inset-[-33.33%_-25%_-6.31%_-25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 8.37868">
          <g id="Tail">
            <path d={svgPaths.pa581200} fill="var(--fill-0, #0F172A)" id="Tail_2" stroke="var(--stroke-0, #334155)" />
            <rect fill="var(--fill-0, #0F172A)" height="2" id="Safe" rx="1" width="18" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative w-full" data-name="Tail">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Tail1 />
        </div>
      </div>
    </div>
  );
}

function Tooltip() {
  return (
    <div className="absolute content-stretch flex flex-col items-center left-[157px] top-[-26px] w-[245px]" data-name="Tooltip">
      <Tooltip1 />
      <div className="flex items-center justify-center relative shrink-0 w-full">
        <div className="-scale-y-100 flex-none w-full">
          <Tail />
        </div>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#020617] text-[18px]">Overview</p>
      <Frame12 />
      <div className="absolute left-[287px] size-[16px] top-[94px]" data-name="Vector">
        <div className="absolute inset-[-18.75%_-25%_-31.25%_-25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0001 24.0001">
            <g filter="url(#filter0_d_8_21424)" id="Vector">
              <path d={svgPaths.p17bb8880} fill="var(--fill-0, #475569)" />
              <path d={svgPaths.p265c6800} stroke="var(--stroke-0, white)" strokeWidth="2" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="24.0001" id="filter0_d_8_21424" width="24.0001" x="-2.38419e-07" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                <feOffset dy="1" />
                <feGaussianBlur stdDeviation="1" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.05 0" />
                <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_8_21424" />
                <feBlend in="SourceGraphic" in2="effect1_dropShadow_8_21424" mode="normal" result="shape" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <Tooltip />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p2a1f0000} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3a6fd2e0} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function AccessIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Access Icon">
      <Group4 />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">BS2#003</p>
    </div>
  );
}

function TextLink1() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex gap-[4px] items-center justify-center overflow-clip pl-[6px] pr-[8px] py-[4px] relative rounded-[8px] shrink-0" data-name="Text Link">
      <AccessIcon />
      <Content5 />
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px]">Operações</p>
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p52c2700} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-white h-[32px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[12px] py-[6px] relative rounded-[inherit]">
        <Content6 />
        <ArrowsDiagramsArrow1 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function AccessHeader() {
  return (
    <div className="content-stretch flex gap-[24px] items-center justify-center relative shrink-0 w-full" data-name="Access Header">
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[18px] whitespace-pre-wrap">Acesso nos últimos 30 dias</p>
      <TextLink1 />
      <div className="flex h-[16px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[16px]" data-name="line">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 1">
                <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="16" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Button />
    </div>
  );
}

function TableRow() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Table Row">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[12px] w-[40px] whitespace-pre-wrap">10.000</p>
      <div className="flex-[1_0_0] h-0 min-h-px min-w-px relative" data-name="Layer">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 1">
            <line id="Layer" stroke="var(--stroke-0, #E2E8F0)" strokeDasharray="2 2" x2="1172" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function TableRow1() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Table Row">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[12px] w-[40px] whitespace-pre-wrap">1000</p>
      <div className="flex-[1_0_0] h-0 min-h-px min-w-px relative" data-name="Layer">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 1">
            <line id="Layer" stroke="var(--stroke-0, #E2E8F0)" strokeDasharray="2 2" x2="1172" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function TableRow2() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Table Row">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[12px] w-[40px] whitespace-pre-wrap">100</p>
      <div className="flex-[1_0_0] h-0 min-h-px min-w-px relative" data-name="Layer">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 1">
            <line id="Layer" stroke="var(--stroke-0, #E2E8F0)" strokeDasharray="2 2" x2="1172" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function TableRow3() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Table Row">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[12px] w-[40px] whitespace-pre-wrap">10</p>
      <div className="flex-[1_0_0] h-0 min-h-px min-w-px relative" data-name="Layer">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 1">
            <line id="Layer" stroke="var(--stroke-0, #E2E8F0)" strokeDasharray="2 2" x2="1172" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function TableRow4() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Table Row">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[12px] w-[40px] whitespace-pre-wrap">0</p>
      <div className="flex-[1_0_0] h-0 min-h-px min-w-px relative" data-name="Layer">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 1">
            <line id="Layer" stroke="var(--stroke-0, #E2E8F0)" strokeDasharray="2 2" x2="1172" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function XAsis() {
  return (
    <div className="relative shrink-0 w-full" data-name="#xAsis">
      <div className="flex flex-row items-end size-full">
        <div className="content-stretch flex font-['Inter:Regular',sans-serif] font-normal items-end justify-between leading-[1.4] not-italic px-[30px] relative text-[#64748b] text-[12px] text-center w-full">
          <p className="relative shrink-0">10 Dez</p>
          <p className="relative shrink-0">11 Dez</p>
          <p className="relative shrink-0">12 Dez</p>
          <p className="relative shrink-0">13 Dez</p>
          <p className="relative shrink-0">14 Dez</p>
          <p className="relative shrink-0">15 Dez</p>
          <p className="relative shrink-0">16 Dez</p>
          <p className="relative shrink-0">17 Dez</p>
          <p className="relative shrink-0">18 Dez</p>
          <p className="relative shrink-0">19 Dez</p>
        </div>
      </div>
    </div>
  );
}

function Dot() {
  return (
    <div className="absolute left-[767px] size-[14px] top-[115px]" data-name="Dot">
      <div className="absolute inset-[-42.86%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 26">
          <g data-figma-bg-blur-radius="24" filter="url(#filter0_d_8_21386)" id="Dot">
            <rect fill="var(--fill-0, white)" height="14" rx="7" width="14" x="6" y="6" />
            <rect height="16" rx="8" stroke="var(--stroke-0, #2E61FF)" strokeWidth="2" width="16" x="5" y="5" />
            <circle cx="13" cy="13" fill="var(--fill-0, #335CFF)" id="Dot_2" r="3" />
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="66" id="filter0_d_8_21386" width="66" x="-20" y="-20">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="4" result="effect1_dropShadow_8_21386" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.180392 0 0 0 0 0.380392 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_8_21386" />
              <feBlend in="SourceGraphic" in2="effect1_dropShadow_8_21386" mode="normal" result="shape" />
            </filter>
            <clipPath id="bgblur_0_8_21386_clip_path" transform="translate(20 20)">
              <rect height="14" rx="7" width="14" x="6" y="6" />
            </clipPath>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[12px] whitespace-pre-wrap" data-name="Container">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#f1f5f9] w-full">Seg 15 Dez</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#cbd5e1] w-full">12 Buy Sides acessaram.</p>
    </div>
  );
}

function Tooltip3() {
  return (
    <div className="bg-[#0f172a] relative rounded-[12px] shrink-0 w-full" data-name="Tooltip">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-start pl-[16px] pr-[12px] py-[12px] relative w-full">
          <Container1 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-[-1px] pointer-events-none rounded-[13px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Tail3() {
  return (
    <div className="h-[6px] relative w-[12px]" data-name="Tail">
      <div className="absolute inset-[-33.33%_-25%_-6.31%_-25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 8.37868">
          <g id="Tail">
            <path d={svgPaths.pa581200} fill="var(--fill-0, #0F172A)" id="Tail_2" stroke="var(--stroke-0, #334155)" />
            <rect fill="var(--fill-0, #0F172A)" height="2" id="Safe" rx="1" width="18" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail2() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative w-full" data-name="Tail">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Tail3 />
        </div>
      </div>
    </div>
  );
}

function Tooltip2() {
  return (
    <div className="absolute content-stretch flex flex-col items-center left-[683px] top-[31px] w-[183px]" data-name="Tooltip">
      <Tooltip3 />
      <div className="flex items-center justify-center relative shrink-0 w-full">
        <div className="-scale-y-100 flex-none w-full">
          <Tail2 />
        </div>
      </div>
    </div>
  );
}

function FullTable() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-full" data-name="Full Table">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[32px] items-start p-[24px] relative w-full">
          <TableRow />
          <TableRow1 />
          <TableRow2 />
          <TableRow3 />
          <TableRow4 />
          <XAsis />
          <div className="-translate-y-1/2 absolute h-[196px] left-[80px] top-[calc(50%-24px)] w-[1172px]" data-name="Active">
            <div className="absolute inset-[0.25%_0_-0.41%_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 196.315">
                <path d={svgPaths.pf5c1680} id="Active" stroke="var(--stroke-0, #2E61FF)" strokeWidth="1.6" />
              </svg>
            </div>
          </div>
          <div className="-translate-y-1/2 absolute h-[196px] left-[80px] top-[calc(50%-24px)] w-[1172px]" data-name="Active">
            <div className="absolute inset-[0.66%_0_0_4.68%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1117.16 194.715">
                <path d={svgPaths.p8014f0} fill="url(#paint0_linear_8_21384)" id="Active" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_8_21384" x1="531.162" x2="531.162" y1="-1.28477" y2="194.715">
                    <stop stopColor="#2E61FF" stopOpacity="0.1" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="absolute left-[780px] size-[16px] top-[147px]" data-name="Vector">
            <div className="absolute inset-[-18.75%_-25%_-31.25%_-25%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0001 24.0001">
                <g filter="url(#filter0_d_8_21424)" id="Vector">
                  <path d={svgPaths.p17bb8880} fill="var(--fill-0, #475569)" />
                  <path d={svgPaths.p265c6800} stroke="var(--stroke-0, white)" strokeWidth="2" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="24.0001" id="filter0_d_8_21424" width="24.0001" x="-2.38419e-07" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                    <feOffset dy="1" />
                    <feGaussianBlur stdDeviation="1" />
                    <feComposite in2="hardAlpha" operator="out" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.05 0" />
                    <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_8_21424" />
                    <feBlend in="SourceGraphic" in2="effect1_dropShadow_8_21424" mode="normal" result="shape" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
          <div className="absolute flex h-[229px] items-center justify-center left-[774px] top-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
            <div className="flex-none rotate-90">
              <div className="h-0 relative w-[229px]" data-name="Layer">
                <div className="absolute inset-[-1px_0_0_0]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 229 1">
                    <line id="Layer" stroke="var(--stroke-0, #E2E8F0)" strokeDasharray="2 2" x2="229" y1="0.5" y2="0.5" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <Dot />
          <Tooltip2 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function AccessContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Access Container">
      <AccessHeader />
      <FullTable />
    </div>
  );
}

function InterfaceEssentialLoadingRotateArrow() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/loading-rotate-arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d="M12.5926 6.20381V3.33034" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M15.4661 3.33034H12.5926" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2e9cf2c0} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p27a2f700} id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p18a5e00} id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p248486c0} id="Path_6" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Em andamento</p>
    </div>
  );
}

function Tab2() {
  return (
    <div className="bg-white content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative shrink-0" data-name="Tab">
      <InterfaceEssentialLoadingRotateArrow />
      <Content7 />
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Encerradas</p>
    </div>
  );
}

function Tab3() {
  return (
    <div className="bg-white content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative shrink-0" data-name="Tab">
      <Content8 />
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Rascunhos</p>
    </div>
  );
}

function Tab4() {
  return (
    <div className="bg-white content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative shrink-0" data-name="Tab">
      <Content9 />
    </div>
  );
}

function TableNavigation() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center relative rounded-[8px] shrink-0" data-name="Table Navigation">
      <Tab2 />
      <Tab3 />
      <Tab4 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p396e8020} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M19 19L15.71 15.71" id="Path_3" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialSearchLoupe() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Search, Loupe">
      <Group5 />
    </div>
  );
}

function Search() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0 w-[250px]" data-name="Search">
      <div className="content-stretch flex gap-[8px] items-center overflow-clip px-[12px] relative rounded-[inherit] size-full">
        <InterfaceEssentialSearchLoupe />
        <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#64748b] text-[14px] whitespace-pre-wrap">Pesquisar</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function TableHeader() {
  return (
    <div className="content-stretch flex items-center justify-between pb-[16px] relative shrink-0 w-[840px]" data-name="Table Header">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <TableNavigation />
      <Search />
      <div className="absolute bottom-0 flex h-[3px] items-center justify-center left-0 w-[169px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="bg-[#2e61ff] h-[169px] rounded-br-[4px] rounded-tr-[4px] w-[3px]" data-name="state" />
        </div>
      </div>
    </div>
  );
}

function SortingIcons() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[16px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Operação</p>
      <SortingIcons />
    </div>
  );
}

function SortingIcons1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label1() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[199.25px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Volume</p>
      <SortingIcons1 />
    </div>
  );
}

function SortingIcons2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label2() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[340px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Setor</p>
      <SortingIcons2 />
    </div>
  );
}

function SortingIcons3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label3() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[479.75px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Status</p>
      <SortingIcons3 />
    </div>
  );
}

function SortingIcons4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label4() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[612px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Data de publicação</p>
      <SortingIcons4 />
    </div>
  );
}

function Header() {
  return (
    <div className="h-[48px] overflow-clip relative rounded-[16px] shrink-0 w-full" data-name="header">
      <Label />
      <Label1 />
      <Label2 />
      <Label3 />
      <Label4 />
    </div>
  );
}

function InterfaceEssentialLock() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Lock">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p38c19d00} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p175e80c0} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center p-[12px] relative shrink-0 w-[48px]" data-name="Table Row Cell">
      <InterfaceEssentialLock />
    </div>
  );
}

function Content10() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">BS2#001</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">Nataly Lana</p>
    </div>
  );
}

function TableRowCell1() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content10 />
    </div>
  );
}

function Content11() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">R$ 100.000.000,00</p>
    </div>
  );
}

function TableRowCell2() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content11 />
    </div>
  );
}

function Content12() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Infraestrutura</p>
    </div>
  );
}

function TableRowCell3() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content12 />
    </div>
  );
}

function Content13() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Concluído</p>
    </div>
  );
}

function Badge() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content13 />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge />
    </div>
  );
}

function TableRowCell4() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start justify-center p-[12px] relative shrink-0 w-[120px]" data-name="Table Row Cell">
      <Container3 />
    </div>
  );
}

function Content14() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">17/10/2025 - 10:00</p>
    </div>
  );
}

function TableRowCell5() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content14 />
        </div>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p1fd72d00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2ae1f820} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3577e000} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/dots">
      <Group6 />
    </div>
  );
}

function TableRowCell6() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center p-[12px] relative shrink-0" data-name="Table Row Cell">
      <InterfaceEssentialDots />
    </div>
  );
}

function TableRow5() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Table Row">
      <TableRowCell />
      <TableRowCell1 />
      <TableRowCell2 />
      <TableRowCell3 />
      <TableRowCell4 />
      <TableRowCell5 />
      <TableRowCell6 />
    </div>
  );
}

function Divider() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 832 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="832" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function TableRowCell7() {
  return <div className="bg-white h-full shrink-0 w-[48px]" data-name="Table Row Cell" />;
}

function Content15() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">BS2#002</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">Caio Paixão</p>
    </div>
  );
}

function TableRowCell8() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content15 />
    </div>
  );
}

function Content16() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">R$ 100.000.000,00</p>
    </div>
  );
}

function TableRowCell9() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content16 />
    </div>
  );
}

function Content17() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Infraestrutura</p>
    </div>
  );
}

function TableRowCell10() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content17 />
    </div>
  );
}

function Content18() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Em revisão</p>
    </div>
  );
}

function Badge1() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content18 />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge1 />
    </div>
  );
}

function TableRowCell11() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start justify-center p-[12px] relative shrink-0 w-[120px]" data-name="Table Row Cell">
      <Container4 />
    </div>
  );
}

function Content19() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">17/10/2025 - 10:00</p>
    </div>
  );
}

function TableRowCell12() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content19 />
        </div>
      </div>
    </div>
  );
}

function TableRow6() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Table Row">
      <TableRowCell7 />
      <TableRowCell8 />
      <TableRowCell9 />
      <TableRowCell10 />
      <TableRowCell11 />
      <TableRowCell12 />
    </div>
  );
}

function Divider1() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 832 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="832" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function InterfaceEssentialLock1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Lock">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p38c19d00} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p175e80c0} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell13() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center p-[12px] relative shrink-0 w-[48px]" data-name="Table Row Cell">
      <InterfaceEssentialLock1 />
    </div>
  );
}

function Content20() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">BS2#003</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">Lucas Ayres</p>
    </div>
  );
}

function TableRowCell14() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content20 />
    </div>
  );
}

function Content21() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">R$ 10.000.000,00</p>
    </div>
  );
}

function TableRowCell15() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content21 />
    </div>
  );
}

function Content22() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Infraestrutura</p>
    </div>
  );
}

function TableRowCell16() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content22 />
    </div>
  );
}

function Content23() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Concluído</p>
    </div>
  );
}

function Badge2() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content23 />
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge2 />
    </div>
  );
}

function TableRowCell17() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start justify-center p-[12px] relative shrink-0 w-[120px]" data-name="Table Row Cell">
      <Container5 />
    </div>
  );
}

function Content24() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">17/10/2025 - 10:00</p>
    </div>
  );
}

function TableRowCell18() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content24 />
        </div>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p1fd72d00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2ae1f820} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3577e000} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/dots">
      <Group7 />
    </div>
  );
}

function TableRowCell19() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center p-[12px] relative shrink-0" data-name="Table Row Cell">
      <InterfaceEssentialDots1 />
    </div>
  );
}

function TableRow7() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Table Row">
      <TableRowCell13 />
      <TableRowCell14 />
      <TableRowCell15 />
      <TableRowCell16 />
      <TableRowCell17 />
      <TableRowCell18 />
      <TableRowCell19 />
    </div>
  );
}

function Divider2() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 832 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="832" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function TableRowCell20() {
  return <div className="bg-white h-full shrink-0 w-[48px]" data-name="Table Row Cell" />;
}

function Content25() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">BS2#004</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">Filipe Goes</p>
    </div>
  );
}

function TableRowCell21() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content25 />
    </div>
  );
}

function Content26() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">R$ 80.000.000,00</p>
    </div>
  );
}

function TableRowCell22() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content26 />
    </div>
  );
}

function Content27() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Infraestrutura</p>
    </div>
  );
}

function TableRowCell23() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content27 />
    </div>
  );
}

function Content28() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Em revisão</p>
    </div>
  );
}

function Badge3() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content28 />
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge3 />
    </div>
  );
}

function TableRowCell24() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start justify-center p-[12px] relative shrink-0 w-[120px]" data-name="Table Row Cell">
      <Container6 />
    </div>
  );
}

function Content29() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">17/10/2025 - 10:00</p>
    </div>
  );
}

function TableRowCell25() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content29 />
        </div>
      </div>
    </div>
  );
}

function TableRow8() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Table Row">
      <TableRowCell20 />
      <TableRowCell21 />
      <TableRowCell22 />
      <TableRowCell23 />
      <TableRowCell24 />
      <TableRowCell25 />
    </div>
  );
}

function Divider3() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 832 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="832" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function InterfaceEssentialLock2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Lock">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p38c19d00} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p175e80c0} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell26() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center p-[12px] relative shrink-0 w-[48px]" data-name="Table Row Cell">
      <InterfaceEssentialLock2 />
    </div>
  );
}

function Content30() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">BS2#005</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">Lucas Heaouet</p>
    </div>
  );
}

function TableRowCell27() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content30 />
    </div>
  );
}

function Content31() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">R$ 1.000.000.000,00</p>
    </div>
  );
}

function TableRowCell28() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content31 />
    </div>
  );
}

function Content32() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Infraestrutura</p>
    </div>
  );
}

function TableRowCell29() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content32 />
    </div>
  );
}

function Content33() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Concluído</p>
    </div>
  );
}

function Badge4() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content33 />
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge4 />
    </div>
  );
}

function TableRowCell30() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start justify-center p-[12px] relative shrink-0 w-[120px]" data-name="Table Row Cell">
      <Container7 />
    </div>
  );
}

function Content34() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">17/10/2025 - 10:00</p>
    </div>
  );
}

function TableRowCell31() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content34 />
        </div>
      </div>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p1fd72d00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2ae1f820} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3577e000} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/dots">
      <Group8 />
    </div>
  );
}

function TableRowCell32() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center p-[12px] relative shrink-0" data-name="Table Row Cell">
      <InterfaceEssentialDots2 />
    </div>
  );
}

function TableRow9() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Table Row">
      <TableRowCell26 />
      <TableRowCell27 />
      <TableRowCell28 />
      <TableRowCell29 />
      <TableRowCell30 />
      <TableRowCell31 />
      <TableRowCell32 />
    </div>
  );
}

function Divider4() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 832 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="832" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function TableRowCell33() {
  return <div className="bg-white h-full shrink-0 w-[48px]" data-name="Table Row Cell" />;
}

function Content35() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">BS2#006</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">Filipe Goes</p>
    </div>
  );
}

function TableRowCell34() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content35 />
    </div>
  );
}

function Content36() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">R$ 80.000.000,00</p>
    </div>
  );
}

function TableRowCell35() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content36 />
    </div>
  );
}

function Content37() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Infraestrutura</p>
    </div>
  );
}

function TableRowCell36() {
  return (
    <div className="bg-white content-stretch flex gap-[12px] h-full items-center p-[12px] relative shrink-0 w-[140px]" data-name="Table Row Cell">
      <Content37 />
    </div>
  );
}

function Content38() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Em revisão</p>
    </div>
  );
}

function Badge5() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content38 />
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge5 />
    </div>
  );
}

function TableRowCell37() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-start justify-center p-[12px] relative shrink-0 w-[120px]" data-name="Table Row Cell">
      <Container8 />
    </div>
  );
}

function Content39() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">17/10/2025 - 10:00</p>
    </div>
  );
}

function TableRowCell38() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content39 />
        </div>
      </div>
    </div>
  );
}

function TableRow10() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Table Row">
      <TableRowCell33 />
      <TableRowCell34 />
      <TableRowCell35 />
      <TableRowCell36 />
      <TableRowCell37 />
      <TableRowCell38 />
    </div>
  );
}

function ArrowsDiagramsArrow2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p7773800} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function PaginationItem() {
  return (
    <div className="bg-[#f8fafc] content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">1</p>
      </div>
    </div>
  );
}

function PaginationItem1() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">2</p>
      </div>
    </div>
  );
}

function PaginationItem2() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">3</p>
      </div>
    </div>
  );
}

function PaginationItem3() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">...</p>
      </div>
    </div>
  );
}

function PaginationItem4() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">4</p>
      </div>
    </div>
  );
}

function PaginationItem5() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">5</p>
      </div>
    </div>
  );
}

function ArrowsDiagramsArrow3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0" data-name="container">
      <Button1 />
      <PaginationItem />
      <PaginationItem1 />
      <PaginationItem2 />
      <PaginationItem3 />
      <PaginationItem4 />
      <PaginationItem5 />
      <Button2 />
    </div>
  );
}

function PaginationGroup() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Pagination Group">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">1 de 6</p>
      <Container9 />
    </div>
  );
}

function PaginationContainer() {
  return (
    <div className="absolute bg-white bottom-0 h-[72px] left-0 w-[832px]" data-name="Pagination Container">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[24px] relative rounded-[inherit] size-full">
        <PaginationGroup />
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-solid border-t inset-0 pointer-events-none" />
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[16px] w-full" data-name="container">
      <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <TableRow5 />
        <Divider />
        <TableRow6 />
        <Divider1 />
        <TableRow7 />
        <Divider2 />
        <TableRow8 />
        <Divider3 />
        <TableRow9 />
        <Divider4 />
        <TableRow10 />
        <PaginationContainer />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Card() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px p-[4px] relative rounded-[16px] w-[840px]" data-name="card">
      <Header />
      <Container2 />
    </div>
  );
}

function TableContent() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative self-stretch shrink-0" data-name="Table Content">
      <TableHeader />
      <Card />
    </div>
  );
}

function RecentActivityIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p2e7081f0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1fc41e00} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pf2da870} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1c12f500} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p393a8a80} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p345e6fc0} id="Path_6" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <RecentActivityIcon />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[16px] whitespace-pre-wrap">Histórico recente</p>
    </div>
  );
}

function Header1() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start px-[16px] py-[12px] relative w-full">
          <Container10 />
        </div>
      </div>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p2bdd5560} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1e553080} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p20482380} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function RecentActivityIcon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <Group9 />
    </div>
  );
}

function Item1() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon1 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item2() {
  return <div className="bg-[#e2e8f0] flex-[1_0_0] min-h-px min-w-px w-px" data-name="item" />;
}

function Item() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-center min-h-px min-w-px relative w-full" data-name="item">
      <Item1 />
      <Item2 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Rectangle" />
          <path d={svgPaths.p3ad96100} id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="10.0041" cy="10.004" id="Oval" r="7.50312" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p31d9d100} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.0012 5.83562V11.2545" id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function RecentActivityIcon2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <Group10 />
    </div>
  );
}

function Item4() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon2 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item5() {
  return <div className="bg-[#e2e8f0] flex-[1_0_0] min-h-px min-w-px w-px" data-name="item" />;
}

function Item3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-center min-h-px min-w-px relative w-full" data-name="item">
      <Item4 />
      <Item5 />
    </div>
  );
}

function RecentActivityIcon3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p27124100} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3755fa80} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3e7b85f0} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M6.66667 14.1667H9.16667" id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_5" />
        </g>
      </svg>
    </div>
  );
}

function Item7() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon3 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item8() {
  return <div className="bg-[#e2e8f0] flex-[1_0_0] min-h-px min-w-px w-px" data-name="item" />;
}

function Item6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-center min-h-px min-w-px relative w-full" data-name="item">
      <Item7 />
      <Item8 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.pd451280} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3f1b2c80} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function RecentActivityIcon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <Group11 />
    </div>
  );
}

function Item10() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon4 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item11() {
  return <div className="bg-[#e2e8f0] flex-[1_0_0] min-h-px min-w-px w-px" data-name="item" />;
}

function Item9() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-center min-h-px min-w-px relative w-full" data-name="item">
      <Item10 />
      <Item11 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Rectangle" />
          <path d={svgPaths.p3ad96100} id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="10.0041" cy="10.004" id="Oval" r="7.50312" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p31d9d100} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.0012 5.83562V11.2545" id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function RecentActivityIcon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <Group12 />
    </div>
  );
}

function Item13() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon5 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item14() {
  return <div className="bg-[#e2e8f0] flex-[1_0_0] min-h-px min-w-px w-px" data-name="item" />;
}

function Item12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-center min-h-px min-w-px relative w-full" data-name="item">
      <Item13 />
      <Item14 />
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p2bdd5560} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1e553080} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p20482380} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function RecentActivityIcon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <Group13 />
    </div>
  );
}

function Item16() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon6 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item17() {
  return <div className="bg-[#e2e8f0] flex-[1_0_0] min-h-px min-w-px w-px" data-name="item" />;
}

function Item15() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-center min-h-px min-w-px relative w-full" data-name="item">
      <Item16 />
      <Item17 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.pd451280} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3f1b2c80} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function RecentActivityIcon7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Recent Activity Icon">
      <Group14 />
    </div>
  );
}

function Item19() {
  return (
    <div className="bg-white relative rounded-[9999px] shrink-0 size-[36px]" data-name="item">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <RecentActivityIcon7 />
      </div>
      <div className="absolute inset-[-1px] pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[10000px] shadow-[0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)]" />
    </div>
  );
}

function Item20() {
  return <div className="bg-[#e2e8f0] h-[21.083px] shrink-0 w-px" data-name="item" />;
}

function Item18() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center relative shrink-0 w-full" data-name="item">
      <Item19 />
      <Item20 />
    </div>
  );
}

function RecentActivityContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative self-stretch shrink-0" data-name="Recent Activity Container">
      <Item />
      <Item3 />
      <Item6 />
      <Item9 />
      <Item12 />
      <Item15 />
      <Item18 />
    </div>
  );
}

function Item21() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center leading-[1.4] relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium min-w-full relative shrink-0 text-[#020617] text-[14px] w-[min-content] whitespace-pre-wrap">XP Asset solicitou acesso à operação</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 12:13</p>
    </div>
  );
}

function Item22() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center leading-[1.4] relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium min-w-full relative shrink-0 text-[#020617] text-[14px] w-[min-content] whitespace-pre-wrap">BTG Pactual baixou o investment deck</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 10:30</p>
    </div>
  );
}

function Item23() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center leading-[1.4] relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium min-w-full relative shrink-0 text-[#020617] text-[14px] w-[min-content] whitespace-pre-wrap">XP Asset baixou documentos do Data Room</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 12:13</p>
    </div>
  );
}

function Item24() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center leading-[1.4] relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium min-w-full relative shrink-0 text-[#020617] text-[14px] w-[min-content] whitespace-pre-wrap">BTG Pactual demonstrou interesse indicativo na operação</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 10:30</p>
    </div>
  );
}

function Item25() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center leading-[1.4] relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium min-w-full relative shrink-0 text-[#020617] text-[14px] w-[min-content] whitespace-pre-wrap">XP Asset baixou documentos do Data Room</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 10:30</p>
    </div>
  );
}

function Item26() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center leading-[1.4] relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium min-w-full relative shrink-0 text-[#020617] text-[14px] w-[min-content] whitespace-pre-wrap">XP Asset baixou documentos do Data Room</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 10:30</p>
    </div>
  );
}

function Item27() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start justify-center relative shrink-0 w-full" data-name="item">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[0] min-w-full relative shrink-0 text-[#020617] text-[0px] text-[14px] w-[min-content] whitespace-pre-wrap">
        <span className="leading-[1.4]">{`XP Asset solicitou acesso à operação BS2#001. `}</span>
        <span className="leading-[1.4] text-[#2e61ff]">Acessar solicitação</span>
      </p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#475569] text-[12px]">10/02/2024 - 12:13</p>
    </div>
  );
}

function RecentActivityContainer1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[32px] items-start min-h-px min-w-px not-italic relative self-stretch" data-name="Recent Activity Container">
      <Item21 />
      <Item22 />
      <Item23 />
      <Item24 />
      <Item25 />
      <Item26 />
      <Item27 />
    </div>
  );
}

function Container11() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="content-stretch flex gap-[24px] items-start px-[16px] py-[24px] relative w-full">
        <RecentActivityContainer />
        <RecentActivityContainer1 />
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col items-start p-[4px] relative rounded-[16px] shrink-0 w-[412px]" data-name="card">
      <Header1 />
      <Container11 />
    </div>
  );
}

function TableContainer() {
  return (
    <div className="content-stretch flex gap-[24px] items-start relative shrink-0 w-full" data-name="Table Container">
      <TableContent />
      <Card1 />
    </div>
  );
}

function MainContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[32px] items-start relative shrink-0 w-full" data-name="Main Container">
      <HeaderContainer />
      <Frame14 />
      <AccessContainer />
      <TableContainer />
    </div>
  );
}

function WorkArea() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col items-start left-[100px] overflow-clip px-[32px] py-[24px] top-[78px] w-[1340px]" data-name="Work Area">
      <MainContainer />
    </div>
  );
}

function Component() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Component 11">
      <div className="absolute inset-[-29.17%_-47.06%_-147.06%_-47.06%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
          <g id="Component 11">
            <circle cx="23.2941" cy="19" id="Ellipse 516" opacity="0.1" r="14.5" stroke="url(#paint0_linear_1_5947)" />
            <g filter="url(#filter0_dddddddi_1_5947)" id="Ellipse 515">
              <circle cx="23.2941" cy="19" fill="var(--fill-0, #2E61FF)" r="11.2941" />
              <circle cx="23.2941" cy="19" fill="url(#paint1_linear_1_5947)" fillOpacity="0.1" r="11.2941" />
            </g>
            <g id="Frame 427321015">
              <circle cx="18.8312" cy="1.9707" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1434" opacity="0.3" r="0.75" />
              <circle cx="10.0441" cy="3.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1435" r="0.75" />
              <circle cx="33.0441" cy="4.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1446" r="0.75" />
              <circle cx="40.0441" cy="9.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1451" opacity="0.3" r="0.75" />
              <circle cx="9.04412" cy="10.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1449" opacity="0.3" r="0.75" />
            </g>
            <g id="IA">
              <path d={svgPaths.p1063c100} fill="var(--fill-0, white)" />
              <path d={svgPaths.p17307780} fill="var(--fill-0, white)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" id="filter0_dddddddi_1_5947" width="46.5882" x="2.98023e-07" y="6.70588">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="12" result="effect1_dropShadow_1_5947" />
              <feOffset dy="24" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="6" result="effect2_dropShadow_1_5947" />
              <feOffset dy="12" />
              <feGaussianBlur stdDeviation="6" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_5947" mode="normal" result="effect2_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="3" result="effect3_dropShadow_1_5947" />
              <feOffset dy="6" />
              <feGaussianBlur stdDeviation="3" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect2_dropShadow_1_5947" mode="normal" result="effect3_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.5" result="effect4_dropShadow_1_5947" />
              <feOffset dy="3" />
              <feGaussianBlur stdDeviation="1.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.02 0" />
              <feBlend in2="effect3_dropShadow_1_5947" mode="normal" result="effect4_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.5" result="effect5_dropShadow_1_5947" />
              <feOffset dy="1" />
              <feGaussianBlur stdDeviation="0.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect4_dropShadow_1_5947" mode="normal" result="effect5_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect6_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect5_dropShadow_1_5947" mode="normal" result="effect6_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect7_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0" />
              <feBlend in2="effect6_dropShadow_1_5947" mode="normal" result="effect7_dropShadow_1_5947" />
              <feBlend in="SourceGraphic" in2="effect7_dropShadow_1_5947" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="shape" mode="normal" result="effect8_innerShadow_1_5947" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_5947" x1="23.2941" x2="23.2941" y1="4" y2="34">
              <stop stopColor="#2E61FF" stopOpacity="0" />
              <stop offset="1" stopColor="#2E61FF" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_5947" x1="23.2941" x2="23.2941" y1="30.2941" y2="7.70588">
              <stop stopColor="white" stopOpacity="0" />
              <stop offset="1" stopColor="white" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Component />
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p39ce2c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.5 21H13.5" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MusicAudioBellNotifications() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Music, Audio/Bell, Notifications">
      <Group15 />
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <MusicAudioBellNotifications />
    </div>
  );
}

function CircleRedSolid() {
  return (
    <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]" data-name="circle-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#fb2c36] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="container">
      <Button3 />
      <Button4 />
      <CircleRedSolid />
    </div>
  );
}

function Logotype() {
  return (
    <div className="absolute inset-[42.65%_22.8%_42.65%_22.5%]" data-name="logotype">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.8804 5.87683">
        <g id="logotype">
          <path d={svgPaths.p1fa77d80} fill="var(--fill-0, white)" id="Vector" />
          <g id="Group">
            <path d={svgPaths.pe40ba00} fill="var(--fill-0, white)" id="Vector_2" />
            <path d={svgPaths.p1b629600} fill="var(--fill-0, white)" id="Vector_3" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Person() {
  return (
    <div className="absolute bg-[#e2e8f0] bottom-0 right-0 rounded-[9999px] size-[16px]" data-name="person">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="absolute h-[64px] left-[-12px] top-[-6px] w-[35px]" data-name="image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
        </div>
        <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-gradient-to-b from-[86.008%] from-[rgba(42,56,73,0)] left-1/2 rounded-[9999px] size-[16px] to-[rgba(42,56,73,0.3)] top-1/2" data-name="filter" />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-[-1px] pointer-events-none rounded-[10000px]" />
    </div>
  );
}

function Avatar6() {
  return (
    <div className="bg-[#2e61ff] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Logotype />
      <Person />
    </div>
  );
}

function Content40() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Bloxs Capital Partners LTDA</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#64748b] text-[12px]">41.847.533/0001-90</p>
    </div>
  );
}

function ArrowsDiagramsArrow4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0" data-name="container">
      <Avatar6 />
      <Content40 />
      <ArrowsDiagramsArrow4 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
      <Container12 />
      <div className="bg-[#e2e8f0] h-[24px] rounded-[9999px] shrink-0 w-[2px]" data-name="divider" />
      <Container13 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="absolute h-[80px] left-[100px] top-0 w-[1340px]" data-name="Navbar">
      <div className="content-stretch flex items-center justify-between overflow-clip px-[32px] py-[16px] relative rounded-[inherit] size-full">
        <Frame9 />
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Camada() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0002 24">
        <g id="Camada_1-2">
          <path d={svgPaths.p8744780} fill="var(--fill-0, #020617)" id="Vector" />
          <path d={svgPaths.p2e0a3600} fill="var(--fill-0, #2E61FF)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute content-stretch flex flex-col h-[80px] items-center justify-center left-0 px-[24px] py-[16px] top-0 w-[100px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <Camada />
    </div>
  );
}

function InterfaceEssentialHomeClassic() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/home-classic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Rectangle" />
          <path clipRule="evenodd" d={svgPaths.pf024880} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p32312200} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <InterfaceEssentialHomeClassic />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Home</p>
    </div>
  );
}

function SeoSearchGraph() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="SEO/Search, Graph">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d="M16 12.157V9H12.843" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p1ecf540} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M19 5L20 4" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M20 8H21" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M16 4V3" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p3b77e00} id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
          </g>
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <SeoSearchGraph />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px] text-center">Operações</p>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p1b647048} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p29968a80} fillRule="evenodd" id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p129ae5c0} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p7859880} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MoneyWalletMoney() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Money/Wallet, Money">
      <Group16 />
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <MoneyWalletMoney />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Carteira</p>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.pcf2900} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1e3f0a80} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1bc35740} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p3ed71a00} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function TechnologySpaceSpaceRocket() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Technology, Space/space-rocket">
      <Group17 />
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <TechnologySpaceSpaceRocket />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Soluções</p>
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-4.17%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.4993 19.4993">
          <g id="Group">
            <path clipRule="evenodd" d={svgPaths.p2d1c8c80} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ConstructionToolsToolsWench() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Construction, Tools/tools-wench">
      <Group18 />
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <ConstructionToolsToolsWench />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Tools</p>
    </div>
  );
}

function UserUsers() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="User/Users">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d={svgPaths.p2c68bbc0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="9" cy="7" id="Oval" r="4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe930c00} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p8cf1c80} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <UserUsers />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Comunidade</p>
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <circle cx="12.005" cy="12.005" id="Oval" r="9.00375" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2756080} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22612800} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p116d3c00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialQuestionCircle() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/question-circle">
      <Group19 />
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-[84px]" data-name="Button">
      <InterfaceEssentialQuestionCircle />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Ajuda</p>
    </div>
  );
}

function Main() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[14px] items-start left-[8px] top-[96px] w-[84px]" data-name="main">
      <Button6 />
      <Button7 />
      <Button8 />
      <Button9 />
      <Button10 />
      <Button11 />
      <Button12 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="bg-white border-[#e2e8f0] border-r border-solid h-[1568px] overflow-clip pointer-events-auto sticky top-0 w-[100px]" data-name="Sidebar">
      <Button5 />
      <div className="absolute bg-[#2e61ff] h-[75px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[185px] w-[3px]" data-name="state" />
      <Main />
    </div>
  );
}

export default function Component6GerenciarLightMode() {
  return (
    <div className="bg-white overflow-clip relative rounded-[24px] size-full" data-name="6. Gerenciar [Light Mode]">
      <WorkArea />
      <Navbar />
      <div className="absolute bottom-0 h-[1568px] left-0 pointer-events-none top-0">
        <Sidebar />
      </div>
    </div>
  );
}