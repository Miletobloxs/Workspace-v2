import { createBrowserRouter, Navigate } from "react-router";
import { DocumentUpload } from "./pages/DocumentUpload";
import { WorkspacePersonalization } from "./pages/WorkspacePersonalization";
import { Dealmatch } from "./pages/Dealmatch";
import { OperationsList } from "./pages/OperationsList";
import { OperationDetails } from "./pages/OperationDetails";
import { OperationsManagement } from "./pages/OperationsManagement";
import { WorkspaceSettings } from "./pages/WorkspaceSettings";
import { QuickRegister } from "./pages/QuickRegister";
import { Login } from "./pages/Login";
import { Home } from "./pages/Home";
import { QuotationStep1 } from "./pages/QuotationStep1";
import { QuotationStep2Estruturacao } from "./pages/QuotationStep2Estruturacao";
import { QuotationStep3 } from "./pages/QuotationStep3";
import { QuotationSuccess } from "./pages/QuotationSuccess";
import { OnboardingSellSide } from "./pages/OnboardingSellSide";
import { OnboardingBuySide } from "./pages/OnboardingBuySide";
import { WorkspaceDashboard } from "./pages/WorkspaceDashboard";
import { OperationsListV2 } from "./pages/OperationsListV2";
import { OperationDetailsV2 } from "./pages/OperationDetailsV2";
import { Carteira } from "./pages/Carteira";
import { Solucoes } from "./pages/Solucoes";
import { Tools } from "./pages/Tools";
import { Comunidade } from "./pages/Comunidade";
import { PersonaSelection } from "./pages/PersonaSelection";
import { OnboardingSuccess } from "./pages/OnboardingSuccess";

export const router = createBrowserRouter([
  // ==========================================
  // 🔐 AUTENTICAÇÃO (Público)
  // ==========================================
  {
    path: "/",
    Component: QuickRegister,
  },
  {
    path: "/registro",
    Component: QuickRegister,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/home",
    Component: Home,
  },
  
  // ==========================================
  // 🎭 ONBOARDING (Pós-cadastro)
  // ==========================================
  {
    path: "/onboarding/persona",
    Component: PersonaSelection,
  },
  {
    path: "/onboarding/sell-side",
    Component: OnboardingSellSide,
  },
  {
    path: "/onboarding/buy-side",
    Component: OnboardingBuySide,
  },
  {
    path: "/onboarding/documentos",
    Component: DocumentUpload,
  },
  {
    path: "/onboarding/personalizar",
    Component: WorkspacePersonalization,
  },
  {
    path: "/onboarding/sucesso",
    Component: OnboardingSuccess,
  },
  
  // ==========================================
  // 👔 SELL-SIDE WORKSPACE
  // ==========================================
  {
    path: "/workspace/dashboard",
    Component: WorkspaceDashboard,
  },
  {
    path: "/workspace/operacoes",
    Component: OperationsListV2, // Minhas operações (Sell-Side)
  },
  {
    path: "/workspace/operacoes/:id",
    Component: OperationDetailsV2,
  },
  {
    path: "/workspace/dealmatch",
    Component: Dealmatch,
  },
  {
    path: "/workspace/configuracoes",
    Component: WorkspaceSettings,
  },
  {
    path: "/workspace/personalizar",
    Component: WorkspacePersonalization,
  },
  
  // ==========================================
  // 📋 COTAÇÃO (Sell-Side)
  // ==========================================
  {
    path: "/cotacao/etapa-1",
    Component: QuotationStep1,
  },
  {
    path: "/cotacao/etapa-2-estruturacao",
    Component: QuotationStep2Estruturacao,
  },
  {
    path: "/cotacao/etapa-3",
    Component: QuotationStep3,
  },
  {
    path: "/cotacao/sucesso",
    Component: QuotationSuccess,
  },
  
  // ==========================================
  // 💼 BUY-SIDE MARKETPLACE
  // ==========================================
  {
    path: "/marketplace",
    Component: OperationsList, // Descobrir oportunidades (Buy-Side)
  },
  {
    path: "/marketplace/:id",
    Component: OperationDetails,
  },
  {
    path: "/marketplace/gerenciar",
    Component: OperationsManagement,
  },
  
  // ==========================================
  // 💼 BUY-SIDE NAVEGAÇÃO PRINCIPAL
  // ==========================================
  {
    path: "/carteira",
    Component: Carteira,
  },
  {
    path: "/solucoes",
    Component: Solucoes,
  },
  {
    path: "/tools",
    Component: Tools,
  },
  {
    path: "/comunidade",
    Component: Comunidade,
  },
  
  // ==========================================
  // 🔄 ROTAS COMPARTILHADAS
  // ==========================================
  {
    path: "/ajuda",
    Component: Home,
  },
  
  // ==========================================
  // 🔀 REDIRECTS (Rotas Antigas → Novas)
  // ==========================================
  {
    path: "/operacoes-v2",
    loader: () => {
      window.location.replace("/workspace/operacoes");
      return null;
    }
  },
  {
    path: "/operacoes-v2/:id",
    loader: ({ params }) => {
      window.location.replace(`/workspace/operacoes/${params.id}`);
      return null;
    }
  },
]);