import { useState, useRef, DragEvent } from "react";
import { Upload, X, FileText, File, CheckCircle, Loader2 } from "lucide-react";

interface UploadedFile {
  id: string;
  file: File;
  progress: number;
  status: "uploading" | "success" | "error";
  preview?: string;
}

interface MultiFileUploaderProps {
  onUploadComplete?: (files: UploadedFile[]) => void;
  maxFiles?: number;
  maxSizePerFile?: number; // em MB
  acceptedTypes?: string[];
}

export function MultiFileUploader({
  onUploadComplete,
  maxFiles = 10,
  maxSizePerFile = 10,
  acceptedTypes = [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".zip"],
}: MultiFileUploaderProps) {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    processFiles(droppedFiles);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    processFiles(selectedFiles);
  };

  const processFiles = (newFiles: File[]) => {
    // Validar número máximo de arquivos
    if (files.length + newFiles.length > maxFiles) {
      alert(`Você pode enviar no máximo ${maxFiles} arquivos por vez.`);
      return;
    }

    const validFiles = newFiles.filter((file) => {
      // Validar tamanho
      if (file.size > maxSizePerFile * 1024 * 1024) {
        alert(`${file.name} excede o tamanho máximo de ${maxSizePerFile}MB.`);
        return false;
      }

      // Validar tipo
      const extension = `.${file.name.split(".").pop()?.toLowerCase()}`;
      if (!acceptedTypes.includes(extension)) {
        alert(`${file.name} não é um tipo de arquivo aceito.`);
        return false;
      }

      return true;
    });

    // Criar objetos de arquivo com progresso
    const uploadedFiles: UploadedFile[] = validFiles.map((file) => ({
      id: `${file.name}-${Date.now()}-${Math.random()}`,
      file,
      progress: 0,
      status: "uploading" as const,
    }));

    setFiles((prev) => [...prev, ...uploadedFiles]);

    // Simular upload de cada arquivo
    uploadedFiles.forEach((uploadedFile) => {
      simulateUpload(uploadedFile);
    });
  };

  const simulateUpload = async (uploadedFile: UploadedFile) => {
    // Simular progresso de upload
    const duration = 2000 + Math.random() * 2000; // 2-4 segundos
    const steps = 20;
    const increment = 100 / steps;
    const stepDuration = duration / steps;

    for (let i = 0; i <= steps; i++) {
      await new Promise((resolve) => setTimeout(resolve, stepDuration));

      setFiles((prev) =>
        prev.map((f) =>
          f.id === uploadedFile.id
            ? { ...f, progress: Math.min(i * increment, 100) }
            : f
        )
      );
    }

    // Marcar como sucesso
    setFiles((prev) =>
      prev.map((f) =>
        f.id === uploadedFile.id ? { ...f, status: "success" as const, progress: 100 } : f
      )
    );

    // Em produção: fazer upload real para o backend
    /*
    const formData = new FormData();
    formData.append('file', uploadedFile.file);
    
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) {
        const percentComplete = (e.loaded / e.total) * 100;
        setFiles((prev) =>
          prev.map((f) =>
            f.id === uploadedFile.id ? { ...f, progress: percentComplete } : f
          )
        );
      }
    });
    
    xhr.addEventListener('load', () => {
      if (xhr.status === 200) {
        setFiles((prev) =>
          prev.map((f) =>
            f.id === uploadedFile.id ? { ...f, status: 'success', progress: 100 } : f
          )
        );
      } else {
        setFiles((prev) =>
          prev.map((f) =>
            f.id === uploadedFile.id ? { ...f, status: 'error' } : f
          )
        );
      }
    });
    
    xhr.open('POST', '/api/upload');
    xhr.send(formData);
    */
  };

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split(".").pop()?.toLowerCase();
    if (["pdf"].includes(extension || "")) return <FileText className="size-5 text-red-500" />;
    if (["doc", "docx"].includes(extension || "")) return <FileText className="size-5 text-blue-500" />;
    if (["xls", "xlsx"].includes(extension || "")) return <FileText className="size-5 text-emerald-500" />;
    if (["ppt", "pptx"].includes(extension || "")) return <FileText className="size-5 text-orange-500" />;
    return <File className="size-5 text-slate-500" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      {/* Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-[16px] p-8 text-center transition-all ${
          isDragging
            ? "border-[#2e61ff] bg-[#2e61ff]/5 dark:bg-[#2e61ff]/10"
            : "border-slate-300 dark:border-slate-600 hover:border-[#2e61ff] dark:hover:border-[#2e61ff]"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileSelect}
          accept={acceptedTypes.join(",")}
          className="hidden"
        />

        <div className="flex flex-col items-center gap-4">
          <div className="size-16 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center">
            <Upload className="size-8 text-slate-600 dark:text-slate-400" />
          </div>

          <div>
            <p className="text-[16px] font-semibold text-slate-900 dark:text-white mb-1">
              Arraste arquivos aqui ou{" "}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-[#2e61ff] hover:underline"
              >
                clique para selecionar
              </button>
            </p>
            <p className="text-[14px] text-slate-600 dark:text-slate-400">
              Até {maxFiles} arquivos • Máximo {maxSizePerFile}MB cada
            </p>
            <p className="text-[12px] text-slate-500 dark:text-slate-500 mt-1">
              Formatos aceitos: {acceptedTypes.join(", ")}
            </p>
          </div>
        </div>
      </div>

      {/* Lista de arquivos */}
      {files.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-[14px] font-semibold text-slate-900 dark:text-white">
              Arquivos ({files.length}/{maxFiles})
            </h4>
            {files.some((f) => f.status === "uploading") && (
              <span className="text-[12px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Loader2 className="size-3 animate-spin" />
                Enviando...
              </span>
            )}
          </div>

          <div className="space-y-2">
            {files.map((uploadedFile) => (
              <div
                key={uploadedFile.id}
                className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] p-4"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex-shrink-0">{getFileIcon(uploadedFile.file.name)}</div>

                  <div className="flex-1 min-w-0">
                    <p className="text-[14px] font-medium text-slate-900 dark:text-white truncate">
                      {uploadedFile.file.name}
                    </p>
                    <p className="text-[12px] text-slate-500">
                      {formatFileSize(uploadedFile.file.size)}
                    </p>
                  </div>

                  {uploadedFile.status === "uploading" && (
                    <Loader2 className="size-5 text-[#2e61ff] animate-spin flex-shrink-0" />
                  )}

                  {uploadedFile.status === "success" && (
                    <CheckCircle className="size-5 text-emerald-500 flex-shrink-0" />
                  )}

                  <button
                    type="button"
                    onClick={() => removeFile(uploadedFile.id)}
                    className="size-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center transition-colors flex-shrink-0"
                  >
                    <X className="size-4 text-slate-600 dark:text-slate-400" />
                  </button>
                </div>

                {/* Progress Bar */}
                {uploadedFile.status === "uploading" && (
                  <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#2e61ff] rounded-full transition-all duration-300"
                      style={{ width: `${uploadedFile.progress}%` }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Resumo */}
      {files.length > 0 && (
        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-[12px]">
          <div className="text-[14px]">
            <span className="font-semibold text-slate-900 dark:text-white">
              {files.filter((f) => f.status === "success").length}
            </span>
            <span className="text-slate-600 dark:text-slate-400"> de {files.length} concluídos</span>
          </div>
          {files.every((f) => f.status === "success") && (
            <div className="flex items-center gap-2 text-[14px] text-emerald-600 dark:text-emerald-400 font-medium">
              <CheckCircle className="size-4" />
              Todos os arquivos enviados
            </div>
          )}
        </div>
      )}
    </div>
  );
}
