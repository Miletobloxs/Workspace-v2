import { useState } from "react";
import { Loader2 } from "lucide-react";

interface GoogleOAuthButtonProps {
  onSuccess?: (user: any) => void;
  onError?: (error: any) => void;
  mode?: "signin" | "signup";
}

export function GoogleOAuthButton({ onSuccess, onError, mode = "signin" }: GoogleOAuthButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleAuth = async () => {
    setIsLoading(true);

    try {
      // Simular autenticação do Google
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Mock de dados do usuário do Google
      const mockGoogleUser = {
        id: "google_123456789",
        email: "usuario@gmail.com",
        name: "Usuário da Silva",
        picture: "https://lh3.googleusercontent.com/a/default-user",
        given_name: "Usuário",
        family_name: "da Silva",
        locale: "pt-BR",
      };

      console.log("✅ Google Auth Success:", mockGoogleUser);
      onSuccess?.(mockGoogleUser);

      // Em produção, usar Firebase ou Google Identity Services:
      /*
      // Opção 1: Firebase Auth
      import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
      
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      // Opção 2: Google Identity Services (mais moderno)
      google.accounts.id.initialize({
        client_id: 'YOUR_GOOGLE_CLIENT_ID',
        callback: handleCredentialResponse,
      });
      
      google.accounts.id.prompt();
      */
    } catch (error) {
      console.error("❌ Google Auth Error:", error);
      onError?.(error);
    } finally {
      setIsLoading(false);
    }
  };

  const buttonText = mode === "signin" ? "Entrar com Google" : "Cadastrar com Google";

  return (
    <button
      onClick={handleGoogleAuth}
      disabled={isLoading}
      className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-white dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 rounded-[12px] font-semibold text-[14px] text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {isLoading ? (
        <>
          <Loader2 className="size-5 animate-spin" />
          Conectando...
        </>
      ) : (
        <>
          <GoogleIcon />
          {buttonText}
        </>
      )}
    </button>
  );
}

// Ícone oficial do Google
function GoogleIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M47.532 24.5528C47.532 22.9214 47.3997 21.2811 47.1175 19.6761H24.48V28.9181H37.4434C36.9055 31.8988 35.177 34.5356 32.6461 36.2111V42.2078H40.3801C44.9217 38.0278 47.532 31.8547 47.532 24.5528Z"
        fill="#4285F4"
      />
      <path
        d="M24.48 48.0016C30.9529 48.0016 36.4116 45.8764 40.3888 42.2078L32.6549 36.2111C30.5031 37.675 27.7252 38.5039 24.4888 38.5039C18.2275 38.5039 12.9187 34.2798 11.0139 28.6006H3.03296V34.7825C7.10718 42.8868 15.4056 48.0016 24.48 48.0016Z"
        fill="#34A853"
      />
      <path
        d="M11.0051 28.6006C9.99973 25.6199 9.99973 22.3922 11.0051 19.4115V13.2296H3.03298C-0.371021 20.0112 -0.371021 28.0009 3.03298 34.7825L11.0051 28.6006Z"
        fill="#FBBC04"
      />
      <path
        d="M24.48 9.49932C27.9016 9.44641 31.2086 10.7339 33.6866 13.0973L40.5387 6.24523C36.2 2.17101 30.4414 -0.068932 24.48 0.00161733C15.4055 0.00161733 7.10718 5.11644 3.03296 13.2296L11.005 19.4115C12.901 13.7235 18.2187 9.49932 24.48 9.49932Z"
        fill="#EA4335"
      />
    </svg>
  );
}
