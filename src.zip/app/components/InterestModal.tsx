import { useState } from "react";
import { X, Calendar, Upload, Loader2, Check } from "lucide-react";

interface InterestModalProps {
  isOpen: boolean;
  onClose: () => void;
  operationName: string;
  operationId: string;
}

export function InterestModal({ isOpen, onClose, operationName, operationId }: InterestModalProps) {
  const [step, setStep] = useState<"form" | "success">("form");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    volume: "",
    deadline: "",
    comment: "",
    documents: [] as File[],
  });

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Prevenir duplo clique (trava de submissão)
    if (isSubmitting) return;

    setIsSubmitting(true);

    try {
      // Simular envio
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Em produção: enviar para backend + Hubspot
      console.log("📤 Interesse enviado:", {
        operationId,
        ...formData,
      });

      setStep("success");
    } catch (error) {
      console.error("Erro ao enviar interesse:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setFormData((prev) => ({
      ...prev,
      documents: [...prev.documents, ...files],
    }));
  };

  const removeFile = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      documents: prev.documents.filter((_, i) => i !== index),
    }));
  };

  const handleScheduleCall = () => {
    // Em produção: abrir modal do Calendly/Hubspot
    window.open("https://calendly.com/bloxs-capital/especialista", "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-800 rounded-[24px] shadow-2xl max-w-[600px] w-full max-h-[90vh] overflow-y-auto">
        {step === "form" && (
          <>
            {/* Header */}
            <div className="sticky top-0 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 p-6 rounded-t-[24px] z-10">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-[24px] font-bold text-slate-950 dark:text-white mb-1">
                    Demonstrar interesse
                  </h2>
                  <p className="text-[14px] text-slate-600 dark:text-slate-400">
                    {operationName}
                  </p>
                </div>
                <button
                  onClick={onClose}
                  disabled={isSubmitting}
                  className="size-10 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center transition-colors disabled:opacity-50"
                >
                  <X className="size-5 text-slate-600 dark:text-slate-400" />
                </button>
              </div>
            </div>

            {/* Content */}
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Falar com Especialista - Destaque */}
              <div className="bg-gradient-to-r from-[#2e61ff]/10 to-[#1b41f5]/10 border-2 border-[#2e61ff]/20 rounded-[16px] p-6">
                <div className="flex items-start gap-4">
                  <div className="size-12 bg-[#2e61ff] rounded-full flex items-center justify-center flex-shrink-0">
                    <Calendar className="size-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white mb-2">
                      Quer tirar dúvidas antes de investir?
                    </h3>
                    <p className="text-[14px] text-slate-600 dark:text-slate-400 mb-4">
                      Agende uma conversa com nosso especialista. É rápido, gratuito e sem compromisso.
                    </p>
                    <button
                      type="button"
                      onClick={handleScheduleCall}
                      className="flex items-center gap-2 px-4 py-2 bg-[#2e61ff] text-white rounded-[8px] font-medium text-[14px] hover:bg-[#1b41f5] transition-colors"
                    >
                      <Calendar className="size-4" />
                      Agendar conversa
                    </button>
                  </div>
                </div>
              </div>

              {/* Separador */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200 dark:border-slate-700" />
                </div>
                <div className="relative flex justify-center text-[12px] uppercase">
                  <span className="bg-white dark:bg-slate-800 px-3 text-slate-500 dark:text-slate-400">
                    ou preencha o formulário
                  </span>
                </div>
              </div>

              {/* Volume de Interesse */}
              <div>
                <label className="block text-[14px] font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Volume de interesse <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">R$</span>
                  <input
                    type="text"
                    value={formData.volume}
                    onChange={(e) => {
                      // Formatar como moeda
                      const value = e.target.value.replace(/\D/g, "");
                      const formatted = new Intl.NumberFormat("pt-BR").format(Number(value));
                      setFormData((prev) => ({ ...prev, volume: formatted }));
                    }}
                    placeholder="1.000.000"
                    className="w-full pl-12 pr-4 py-3 rounded-[12px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-950 dark:text-white focus:border-[#2e61ff] focus:ring-2 focus:ring-[#2e61ff]/20 focus:outline-none transition-colors"
                    required
                  />
                </div>
              </div>

              {/* Prazo Desejado */}
              <div>
                <label className="block text-[14px] font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Prazo desejado <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={formData.deadline}
                    onChange={(e) => setFormData((prev) => ({ ...prev, deadline: e.target.value }))}
                    placeholder="24"
                    min="1"
                    className="w-full pr-20 pl-4 py-3 rounded-[12px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-950 dark:text-white focus:border-[#2e61ff] focus:ring-2 focus:ring-[#2e61ff]/20 focus:outline-none transition-colors"
                    required
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500">meses</span>
                </div>
              </div>

              {/* Comentário */}
              <div>
                <label className="block text-[14px] font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Comentário <span className="text-slate-400">(opcional)</span>
                </label>
                <textarea
                  value={formData.comment}
                  onChange={(e) => setFormData((prev) => ({ ...prev, comment: e.target.value }))}
                  placeholder="Adicione observações ou requisitos específicos..."
                  rows={4}
                  className="w-full px-4 py-3 rounded-[12px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-950 dark:text-white focus:border-[#2e61ff] focus:ring-2 focus:ring-[#2e61ff]/20 focus:outline-none transition-colors resize-none"
                />
              </div>

              {/* Upload de Documentos */}
              <div>
                <label className="block text-[14px] font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Anexar documentos <span className="text-slate-400">(opcional)</span>
                </label>
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-[12px] p-6 text-center hover:border-[#2e61ff] transition-colors">
                  <input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                    accept=".pdf,.doc,.docx,.xls,.xlsx"
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer flex flex-col items-center gap-2"
                  >
                    <Upload className="size-8 text-slate-400" />
                    <p className="text-[14px] font-medium text-slate-700 dark:text-slate-300">
                      Clique para selecionar ou arraste arquivos
                    </p>
                    <p className="text-[12px] text-slate-500">PDF, Word ou Excel até 10MB cada</p>
                  </label>
                </div>

                {/* Lista de arquivos */}
                {formData.documents.length > 0 && (
                  <div className="mt-4 space-y-2">
                    {formData.documents.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-[8px]"
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="size-8 bg-[#2e61ff]/10 rounded-[6px] flex items-center justify-center flex-shrink-0">
                            <Upload className="size-4 text-[#2e61ff]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[14px] font-medium text-slate-900 dark:text-white truncate">
                              {file.name}
                            </p>
                            <p className="text-[12px] text-slate-500">
                              {(file.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="size-8 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 flex items-center justify-center transition-colors"
                        >
                          <X className="size-4 text-slate-600 dark:text-slate-400" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Aviso */}
              <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-[12px] p-4">
                <p className="text-[12px] text-blue-900 dark:text-blue-100">
                  💡 <strong>Dica:</strong> Ao manifestar interesse, o Sell Side será notificado e entrará em contato para discutir os próximos passos.
                </p>
              </div>

              {/* Botões */}
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={isSubmitting}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-[12px] font-semibold text-[16px] hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#1b41f5] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="size-5 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    "Enviar interesse"
                  )}
                </button>
              </div>
            </form>
          </>
        )}

        {step === "success" && (
          <div className="p-8 text-center space-y-6">
            {/* Success Icon */}
            <div className="size-20 bg-emerald-100 dark:bg-emerald-950 rounded-full flex items-center justify-center mx-auto">
              <Check className="size-10 text-emerald-600 dark:text-emerald-400" />
            </div>

            <div>
              <h3 className="text-[24px] font-bold text-slate-950 dark:text-white mb-2">
                Interesse enviado com sucesso!
              </h3>
              <p className="text-[16px] text-slate-600 dark:text-slate-400">
                O Sell Side foi notificado e entrará em contato em breve.
              </p>
            </div>

            <div className="bg-slate-50 dark:bg-slate-900 rounded-[16px] p-6 text-left">
              <h4 className="text-[14px] font-semibold text-slate-900 dark:text-white mb-3">
                📋 Próximos passos:
              </h4>
              <ul className="space-y-2 text-[14px] text-slate-600 dark:text-slate-400">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 dark:text-emerald-400">✓</span>
                  <span>Seu interesse foi registrado no sistema</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 dark:text-emerald-400">✓</span>
                  <span>Notificação enviada ao Sell Side</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 dark:text-orange-400">⏳</span>
                  <span>Aguardando resposta (até 48h úteis)</span>
                </li>
              </ul>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleScheduleCall}
                className="flex-1 py-3 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-[12px] font-semibold text-[16px] hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
              >
                <Calendar className="size-5" />
                Agendar conversa
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#1b41f5] transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
