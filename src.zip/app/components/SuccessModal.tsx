import { X, Check } from "lucide-react";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
}

export function SuccessModal({ isOpen, onClose, title, message }: SuccessModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-[#161616] rounded-[8px] shadow-xl max-w-[540px] w-full mx-4">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-start justify-between mb-8">
            {/* Success Icon */}
            <div className="relative">
              <div className="absolute size-[54px] bg-[#215B20] rounded-full" />
              <div className="absolute size-[42px] top-[6px] left-[6px] bg-[#247223] rounded-full" />
              <div className="absolute size-[30px] top-[12px] left-[12px] bg-[#2A9128] rounded-full" />
              <div className="absolute top-[15px] left-[15px] size-[24px] bg-[#2A9128] rounded-full flex items-center justify-center">
                <Check className="size-4 text-white" />
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="text-white/60 hover:text-white transition-colors"
            >
              <X className="size-6" />
            </button>
          </div>

          {/* Content */}
          <div className="mb-8">
            <h2 className="text-[18px] font-semibold text-white mb-2">{title}</h2>
            <p className="text-[14px] text-white/80 leading-relaxed">{message}</p>
          </div>

          {/* Button */}
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="px-12 py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd] transition-colors"
            >
              OK
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
