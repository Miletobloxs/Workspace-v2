import { useState } from "react";
import { X, ChevronDown } from "lucide-react";

interface FiltersModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFilters: (filters: FilterState) => void;
}

export interface FilterState {
  operationType: "public" | "viability" | null;
  sellSide: string;
  modality: string[];
  sector: string[];
  priceRange: [number, number];
}

export function FiltersModal({ isOpen, onClose, onApplyFilters }: FiltersModalProps) {
  const [filters, setFilters] = useState<FilterState>({
    operationType: "public",
    sellSide: "",
    modality: ["Dívida"],
    sector: ["Imobiliário"],
    priceRange: [0, 900],
  });

  if (!isOpen) return null;

  const handleApply = () => {
    onApplyFilters(filters);
    onClose();
  };

  const handleClear = () => {
    setFilters({
      operationType: null,
      sellSide: "",
      modality: [],
      sector: [],
      priceRange: [0, 900],
    });
  };

  const toggleModality = (value: string) => {
    setFilters(prev => ({
      ...prev,
      modality: prev.modality.includes(value)
        ? prev.modality.filter(m => m !== value)
        : [...prev.modality, value],
    }));
  };

  const toggleSector = (value: string) => {
    setFilters(prev => ({
      ...prev,
      sector: prev.sector.includes(value)
        ? prev.sector.filter(s => s !== value)
        : [...prev.sector, value],
    }));
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
        onClick={onClose}
      />
      
      <div className="fixed right-0 top-0 bottom-0 w-[440px] bg-white dark:bg-slate-900 shadow-2xl z-50 overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <svg className="size-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              <h2 className="text-[20px] font-semibold text-slate-950 dark:text-white">Filtros</h2>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="size-5" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Tipo de Operação */}
            <div>
              <label className="block text-[12px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
                Tipo de Operação
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setFilters(prev => ({ ...prev, operationType: "public" }))}
                  className={`flex-1 py-2 px-4 rounded-[8px] text-[14px] font-medium transition-colors ${
                    filters.operationType === "public"
                      ? "bg-[#2e61ff] text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Oferta Pública
                </button>
                <button
                  onClick={() => setFilters(prev => ({ ...prev, operationType: "viability" }))}
                  className={`flex-1 py-2 px-4 rounded-[8px] text-[14px] font-medium transition-colors ${
                    filters.operationType === "viability"
                      ? "bg-[#2e61ff] text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Consulta de Viabilidade
                </button>
              </div>
            </div>

            {/* Sell Side */}
            <div>
              <label className="block text-[12px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
                Sell Side
              </label>
              <div className="relative">
                <select
                  value={filters.sellSide}
                  onChange={(e) => setFilters(prev => ({ ...prev, sellSide: e.target.value }))}
                  className="w-full h-[48px] px-3 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-950 dark:text-white text-[14px] appearance-none cursor-pointer"
                >
                  <option value="">Selecionar</option>
                  <option value="Sell Side">Sell Side</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-slate-400 pointer-events-none" />
              </div>
            </div>

            {/* Modalidade */}
            <div>
              <label className="block text-[12px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
                Modalidade
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleModality("Dívida")}
                  className={`flex-1 py-2 px-4 rounded-[8px] text-[14px] font-medium transition-colors ${
                    filters.modality.includes("Dívida")
                      ? "bg-[#2e61ff] text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Dívida
                </button>
                <button
                  onClick={() => toggleModality("Equity")}
                  className={`flex-1 py-2 px-4 rounded-[8px] text-[14px] font-medium transition-colors ${
                    filters.modality.includes("Equity")
                      ? "bg-[#2e61ff] text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Equity
                </button>
              </div>
            </div>

            {/* Setor */}
            <div>
              <label className="block text-[12px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
                Setor
              </label>
              <div className="flex flex-wrap gap-2">
                {["Imobiliário", "Ativos Judiciais", "Agronegócios", "Infraestrutura", "Negócios", "Startups"].map((sector) => (
                  <button
                    key={sector}
                    onClick={() => toggleSector(sector)}
                    className={`py-2 px-4 rounded-[8px] text-[14px] font-medium transition-colors ${
                      filters.sector.includes(sector)
                        ? "bg-[#2e61ff] text-white"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                    }`}
                  >
                    {sector}
                  </button>
                ))}
              </div>
            </div>

            {/* Prazo (Slider) */}
            <div>
              <label className="block text-[12px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
                Prazo (meses)
              </label>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-[14px] font-medium text-slate-950 dark:text-white">R$ 0</span>
                  <div className="flex-1 h-[4px] bg-slate-200 dark:bg-slate-700 rounded-full relative">
                    <div className="absolute left-0 h-full bg-[#2e61ff] rounded-full" style={{ width: `${(filters.priceRange[1] / 900) * 100}%` }} />
                  </div>
                  <span className="text-[14px] font-medium text-slate-950 dark:text-white">R$ 900</span>
                </div>
                
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={`R$ ${filters.priceRange[0].toFixed(2)}`}
                    readOnly
                    className="flex-1 h-[40px] px-3 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-950 dark:text-white text-[14px]"
                  />
                  <span className="flex items-center text-slate-400">-</span>
                  <input
                    type="text"
                    value={`R$ ${filters.priceRange[1].toFixed(2)}`}
                    readOnly
                    className="flex-1 h-[40px] px-3 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-950 dark:text-white text-[14px]"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mt-8">
            <button
              onClick={handleClear}
              className="flex-1 py-3 rounded-[8px] border border-slate-300 dark:border-slate-600 text-slate-950 dark:text-white font-medium text-[14px] hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              Limpar
            </button>
            <button
              onClick={handleApply}
              className="flex-1 bg-[#2e61ff] text-white py-3 rounded-[8px] font-medium text-[14px] hover:bg-[#1b41f5] transition-colors"
            >
              Aplicar filtros
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
