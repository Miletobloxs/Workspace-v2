import { useState } from "react";
import { useNavigate } from "react-router";
import { Eye, EyeOff, Loader2, ArrowLeft } from "lucide-react";
import { GoogleOAuthButton } from "../components/GoogleOAuthButton";

export function Login() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Simular login
      await new Promise((resolve) => setTimeout(resolve, 1500));

      console.log("✅ Login success:", formData.email);

      // Em produção: validar credenciais no backend
      // const response = await fetch('/api/auth/login', {
      //   method: 'POST',
      //   body: JSON.stringify(formData),
      // });

      // Redirecionar para home
      navigate("/home");
    } catch (error) {
      console.error("❌ Login error:", error);
      alert("Email ou senha incorretos");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSuccess = (user: any) => {
    console.log("✅ Google login success:", user);
    // Verificar se usuário já existe no backend
    // Se sim: redirecionar para /home
    // Se não: redirecionar para /onboarding/documentos
    navigate("/home");
  };

  const handleGoogleError = (error: any) => {
    console.error("❌ Google login error:", error);
    alert("Erro ao fazer login com Google. Tente novamente.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2e61ff] via-[#1b41f5] to-[#0033cc] flex items-center justify-center p-4">
      <div className="w-full max-w-[480px]">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-4">
            <div className="size-8 bg-white rounded-full flex items-center justify-center">
              <span className="text-[#2e61ff] font-bold text-sm">B</span>
            </div>
            <span className="text-white font-semibold text-lg">Bloxs</span>
          </div>
          <h1 className="text-white text-[32px] font-bold mb-2">Bem-vindo de volta!</h1>
          <p className="text-white/80 text-[16px]">Entre para acessar sua conta</p>
        </div>

        {/* Card Principal */}
        <div className="bg-white dark:bg-slate-800 rounded-[24px] shadow-2xl p-8">
          {/* Google OAuth */}
          <GoogleOAuthButton
            mode="signin"
            onSuccess={handleGoogleSuccess}
            onError={handleGoogleError}
          />

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-700" />
            </div>
            <div className="relative flex justify-center text-[12px] uppercase">
              <span className="bg-white dark:bg-slate-800 px-3 text-slate-500 dark:text-slate-400">
                ou continue com email
              </span>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[14px] font-medium text-slate-700 dark:text-slate-300 mb-2">
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="seu@email.com.br"
                className="w-full px-4 py-3 rounded-[12px] border-2 border-slate-200 dark:border-slate-600 focus:border-[#2e61ff] focus:outline-none text-[16px] bg-white dark:bg-slate-900 text-slate-950 dark:text-white transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-[14px] font-medium text-slate-700 dark:text-slate-300 mb-2">
                Senha
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-[12px] border-2 border-slate-200 dark:border-slate-600 focus:border-[#2e61ff] focus:outline-none text-[16px] bg-white dark:bg-slate-900 text-slate-950 dark:text-white transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="size-4 rounded border-slate-300 text-[#2e61ff] focus:ring-[#2e61ff]"
                />
                <span className="text-[14px] text-slate-600 dark:text-slate-400">Lembrar de mim</span>
              </label>
              <button
                type="button"
                onClick={() => navigate("/recuperar-senha")}
                className="text-[14px] text-[#2e61ff] hover:underline font-medium"
              >
                Esqueceu a senha?
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#1b41f5] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="size-5 animate-spin" />
                  Entrando...
                </>
              ) : (
                "Entrar"
              )}
            </button>
          </form>

          {/* Link para Registro */}
          <div className="mt-6 text-center">
            <p className="text-[14px] text-slate-600 dark:text-slate-400">
              Não tem uma conta?{" "}
              <button
                onClick={() => navigate("/registro")}
                className="text-[#2e61ff] font-semibold hover:underline"
              >
                Criar conta
              </button>
            </p>
          </div>
        </div>

        {/* Back to Home */}
        <button
          onClick={() => navigate("/")}
          className="mt-6 w-full flex items-center justify-center gap-2 text-white/80 hover:text-white transition-colors text-[14px]"
        >
          <ArrowLeft className="size-4" />
          Voltar para o início
        </button>

        {/* Footer */}
        <p className="text-white/60 text-[12px] text-center mt-6">
          Ao entrar, você concorda com nossos{" "}
          <button className="text-white underline hover:text-white/80">Termos de Uso</button> e{" "}
          <button className="text-white underline hover:text-white/80">
            Política de Privacidade
          </button>
        </p>
      </div>
    </div>
  );
}
