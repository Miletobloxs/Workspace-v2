import { useState } from "react";
import { useNavigate } from "react-router";
import { ChevronDown, Check, X } from "lucide-react";

export function Dealmatch() {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState<number>(1);
  const [formData, setFormData] = useState({
    // Seção 1: Interesses
    setores: [] as string[],
    tiposAtivo: [] as string[],
    ticketMinimo: "",
    ticketMaximo: "",
    
    // Seção 2: Perfil de Risco
    toleranciaRisco: "",
    retornoEsperado: "",
    prazoInvestimento: "",
    
    // Seção 3: Localização e Garantias
    regioes: [] as string[],
    tiposGarantia: [] as string[],
    
    // Seção 4: Exigências
    rating: "",
    liquidez: "",
    diversificacao: "",
  });

  const [completedSections, setCompletedSections] = useState({
    section1: false,
    section2: false,
    section3: false,
    section4: false,
  });

  const handleFinish = () => {
    const allCompleted = Object.values(completedSections).every(v => v);
    if (!allCompleted) {
      alert("Por favor, complete todas as seções antes de finalizar");
      return;
    }
    navigate("/workspace/dashboard");
  };

  const setores = [
    "Imobiliário",
    "Agronegócio",
    "Infraestrutura",
    "Tecnologia",
    "Energia",
    "Saúde",
    "Educação",
    "Varejo"
  ];

  const tiposAtivo = ["CRI", "CRA", "Debêntures", "FIDC", "FII"];
  const regioes = ["Sudeste", "Sul", "Centro-Oeste", "Nordeste", "Norte"];
  const tiposGarantia = ["Hipoteca", "Alienação Fiduciária", "Penhor", "Aval", "Sem Garantia Real"];

  const toggleArrayItem = (array: string[], item: string) => {
    return array.includes(item) ? array.filter(i => i !== item) : [...array, item];
  };

  const getSectionStatus = (section: keyof typeof completedSections) => {
    return completedSections[section] ? "Completo" : "Pendente";
  };

  const allSectionsCompleted = Object.values(completedSections).every(v => v);
  const completedCount = Object.values(completedSections).filter(v => v).length;

  return (
    <div className="min-h-screen bg-[#212121]">
      {/* Header */}
      <div className="border-b border-[#2e2e2e] px-8 py-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-[28px] font-bold text-white mb-2">
              Dealmatch
            </h1>
            <p className="text-[14px] text-[#a4a4a4]">
              Configure suas preferências de investimento para receber oportunidades personalizadas
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 bg-[#292929] border border-[#434343] rounded-[8px]">
              <span className="text-[14px] text-[#a4a4a4]">
                Progresso: <span className="font-semibold text-white">{completedCount} de 4</span>
              </span>
            </div>

            {allSectionsCompleted && (
              <button
                onClick={handleFinish}
                className="px-6 py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd]"
              >
                Finalizar Configuração
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="px-8 py-8">
        <div className="grid grid-cols-4 gap-6">
          {/* Section Cards */}
          {[
            { id: 1, title: "Interesses de Investimento", key: "section1" as const },
            { id: 2, title: "Perfil de Risco", key: "section2" as const },
            { id: 3, title: "Localização e Garantias", key: "section3" as const },
            { id: 4, title: "Exigências Adicionais", key: "section4" as const }
          ].map((section) => (
            <button
              key={section.id}
              onClick={() => setCurrentSection(section.id)}
              className={`p-6 rounded-[12px] border transition-all text-left ${
                currentSection === section.id
                  ? "bg-[#3482ff]/10 border-[#3482ff]"
                  : "bg-[#292929] border-[#434343] hover:border-[#3482ff]/50"
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[12px] font-semibold text-[#a4a4a4]">
                  Seção {section.id}
                </span>
                <span
                  className={`px-2 py-1 rounded-[4px] text-[10px] font-semibold ${
                    completedSections[section.key]
                      ? "bg-[#01bf73]/10 text-[#01bf73]"
                      : "bg-[#ffc709]/10 text-[#ffc709]"
                  }`}
                >
                  {getSectionStatus(section.key)}
                </span>
              </div>
              <h3 className="text-[16px] font-semibold text-white">
                {section.title}
              </h3>
            </button>
          ))}
        </div>

        {/* Section Content */}
        <div className="mt-8 bg-[#292929] border border-[#434343] rounded-[12px] p-8">
          {/* Section 1: Interesses */}
          {currentSection === 1 && (
            <div className="space-y-6 max-w-[800px]">
              <h2 className="text-[20px] font-semibold text-white mb-6">
                Interesses de Investimento
              </h2>

              <div>
                <label className="block text-[14px] text-white mb-3">Setores de interesse</label>
                <div className="grid grid-cols-4 gap-3">
                  {setores.map((setor) => (
                    <button
                      key={setor}
                      onClick={() =>
                        setFormData({
                          ...formData,
                          setores: toggleArrayItem(formData.setores, setor)
                        })
                      }
                      className={`h-[40px] px-4 rounded-[6px] border text-[14px] font-medium transition-all ${
                        formData.setores.includes(setor)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      {setor}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-3">Tipos de ativo</label>
                <div className="grid grid-cols-5 gap-3">
                  {tiposAtivo.map((tipo) => (
                    <button
                      key={tipo}
                      onClick={() =>
                        setFormData({
                          ...formData,
                          tiposAtivo: toggleArrayItem(formData.tiposAtivo, tipo)
                        })
                      }
                      className={`h-[40px] px-4 rounded-[6px] border text-[14px] font-medium transition-all ${
                        formData.tiposAtivo.includes(tipo)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      {tipo}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[14px] text-white mb-2">Ticket mínimo</label>
                  <input
                    type="text"
                    placeholder="Ex: R$ 100.000"
                    value={formData.ticketMinimo}
                    onChange={(e) =>
                      setFormData({ ...formData, ticketMinimo: e.target.value })
                    }
                    className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
                  />
                </div>

                <div>
                  <label className="block text-[14px] text-white mb-2">Ticket máximo</label>
                  <input
                    type="text"
                    placeholder="Ex: R$ 5.000.000"
                    value={formData.ticketMaximo}
                    onChange={(e) =>
                      setFormData({ ...formData, ticketMaximo: e.target.value })
                    }
                    className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
                  />
                </div>
              </div>

              <button
                onClick={() => {
                  setCompletedSections({ ...completedSections, section1: true });
                  setCurrentSection(2);
                }}
                className="w-full py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd]"
              >
                Salvar e Continuar
              </button>
            </div>
          )}

          {/* Section 2: Perfil de Risco */}
          {currentSection === 2 && (
            <div className="space-y-6 max-w-[800px]">
              <h2 className="text-[20px] font-semibold text-white mb-6">
                Perfil de Risco
              </h2>

              <div>
                <label className="block text-[14px] text-white mb-2">Tolerância a risco</label>
                <select
                  value={formData.toleranciaRisco}
                  onChange={(e) =>
                    setFormData({ ...formData, toleranciaRisco: e.target.value })
                  }
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="conservador">Conservador</option>
                  <option value="moderado">Moderado</option>
                  <option value="agressivo">Agressivo</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Retorno esperado (% a.a.)</label>
                <input
                  type="text"
                  placeholder="Ex: 12%"
                  value={formData.retornoEsperado}
                  onChange={(e) =>
                    setFormData({ ...formData, retornoEsperado: e.target.value })
                  }
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
                />
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Prazo de investimento</label>
                <select
                  value={formData.prazoInvestimento}
                  onChange={(e) =>
                    setFormData({ ...formData, prazoInvestimento: e.target.value })
                  }
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="curto">Curto prazo (até 2 anos)</option>
                  <option value="medio">Médio prazo (2-5 anos)</option>
                  <option value="longo">Longo prazo (5+ anos)</option>
                </select>
              </div>

              <button
                onClick={() => {
                  setCompletedSections({ ...completedSections, section2: true });
                  setCurrentSection(3);
                }}
                className="w-full py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd]"
              >
                Salvar e Continuar
              </button>
            </div>
          )}

          {/* Section 3: Localização */}
          {currentSection === 3 && (
            <div className="space-y-6 max-w-[800px]">
              <h2 className="text-[20px] font-semibold text-white mb-6">
                Localização e Garantias
              </h2>

              <div>
                <label className="block text-[14px] text-white mb-3">Regiões de interesse</label>
                <div className="grid grid-cols-5 gap-3">
                  {regioes.map((regiao) => (
                    <button
                      key={regiao}
                      onClick={() =>
                        setFormData({
                          ...formData,
                          regioes: toggleArrayItem(formData.regioes, regiao)
                        })
                      }
                      className={`h-[40px] px-4 rounded-[6px] border text-[14px] font-medium transition-all ${
                        formData.regioes.includes(regiao)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      {regiao}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-3">Tipos de garantia aceitáveis</label>
                <div className="grid grid-cols-3 gap-3">
                  {tiposGarantia.map((tipo) => (
                    <button
                      key={tipo}
                      onClick={() =>
                        setFormData({
                          ...formData,
                          tiposGarantia: toggleArrayItem(formData.tiposGarantia, tipo)
                        })
                      }
                      className={`h-[40px] px-4 rounded-[6px] border text-[14px] font-medium transition-all ${
                        formData.tiposGarantia.includes(tipo)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      {tipo}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  setCompletedSections({ ...completedSections, section3: true });
                  setCurrentSection(4);
                }}
                className="w-full py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd]"
              >
                Salvar e Continuar
              </button>
            </div>
          )}

          {/* Section 4: Exigências */}
          {currentSection === 4 && (
            <div className="space-y-6 max-w-[800px]">
              <h2 className="text-[20px] font-semibold text-white mb-6">
                Exigências Adicionais
              </h2>

              <div>
                <label className="block text-[14px] text-white mb-2">Rating mínimo</label>
                <select
                  value={formData.rating}
                  onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="AAA">AAA</option>
                  <option value="AA">AA</option>
                  <option value="A">A</option>
                  <option value="BBB">BBB</option>
                  <option value="BB">BB ou inferior</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Liquidez desejada</label>
                <select
                  value={formData.liquidez}
                  onChange={(e) => setFormData({ ...formData, liquidez: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="alta">Alta liquidez (mercado secundário ativo)</option>
                  <option value="media">Média liquidez</option>
                  <option value="baixa">Baixa liquidez (buy and hold)</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Estratégia de diversificação</label>
                <select
                  value={formData.diversificacao}
                  onChange={(e) =>
                    setFormData({ ...formData, diversificacao: e.target.value })
                  }
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="concentrado">Concentrado (1-3 ativos)</option>
                  <option value="moderado">Moderado (4-8 ativos)</option>
                  <option value="diversificado">Diversificado (9+ ativos)</option>
                </select>
              </div>

              <button
                onClick={() => {
                  setCompletedSections({ ...completedSections, section4: true });
                }}
                className="w-full py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd]"
              >
                Salvar Configurações
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
