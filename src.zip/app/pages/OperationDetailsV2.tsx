import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import {
  ArrowLeft,
  Building2,
  Calendar,
  TrendingUp,
  Users,
  FileText,
  Download,
  Upload,
  CheckCircle2,
  Clock,
  AlertCircle,
  Eye
} from "lucide-react";

export function OperationDetailsV2() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState<"geral" | "documentos" | "investidores" | "timeline">("geral");

  // Mock data
  const operation = {
    id: id || "1",
    code: "CRI-2024-001",
    type: "CRI",
    status: "ativa",
    issuer: {
      name: "Construtora ABC S.A.",
      cnpj: "12.345.678/0001-90",
      address: "São Paulo, SP"
    },
    financial: {
      volume: "R$ 50.000.000,00",
      rate: "IPCA + 8,5% a.a.",
      maturity: "36 meses",
      issueDate: "15/01/2024",
      paymentFrequency: "Mensal",
      guarantee: "Hipoteca"
    },
    liquidation: {
      status: "em-dia",
      nextPayment: "15/03/2024",
      paidInstallments: 2,
      totalInstallments: 36,
      paidAmount: "R$ 2.850.000,00",
      remainingAmount: "R$ 47.150.000,00"
    },
    investors: [
      { name: "Fundo XYZ", amount: "R$ 10.000.000", percentage: "20%" },
      { name: "Investor ABC", amount: "R$ 8.000.000", percentage: "16%" },
      { name: "Capital Partners", amount: "R$ 7.500.000", percentage: "15%" }
    ],
    documents: [
      { name: "Escritura de Emissão", type: "PDF", size: "2.4 MB", date: "15/01/2024", status: "aprovado" },
      { name: "Termo de Securitização", type: "PDF", size: "1.8 MB", date: "15/01/2024", status: "aprovado" },
      { name: "Parecer Jurídico", type: "PDF", size: "856 KB", date: "12/01/2024", status: "aprovado" },
      { name: "Rating CVM", type: "PDF", size: "1.2 MB", date: "10/01/2024", status: "pendente" }
    ],
    timeline: [
      { date: "15/02/2024", event: "Pagamento realizado", type: "payment", status: "success" },
      { date: "15/01/2024", event: "Pagamento realizado", type: "payment", status: "success" },
      { date: "15/01/2024", event: "Operação iniciada", type: "milestone", status: "success" },
      { date: "10/01/2024", event: "Documentação aprovada", type: "document", status: "success" }
    ]
  };

  const getStatusConfig = (status: string) => {
    const configs = {
      ativa: { label: "Ativa", color: "#01bf73", icon: CheckCircle2 },
      liquidando: { label: "Liquidando", color: "#ffc709", icon: Clock },
      liquidada: { label: "Liquidada", color: "#818181", icon: CheckCircle2 },
      pendente: { label: "Pendente", color: "#3482ff", icon: AlertCircle }
    };
    return configs[status as keyof typeof configs] || configs.ativa;
  };

  const statusConfig = getStatusConfig(operation.status);
  const StatusIcon = statusConfig.icon;

  return (
    <div className="min-h-screen bg-[#212121]">
      {/* Header */}
      <div className="border-b border-[#2e2e2e] px-8 py-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate("/workspace/operacoes")}
            className="size-10 flex items-center justify-center bg-[#292929] border border-[#434343] rounded-[8px] text-white hover:border-[#3482ff]"
          >
            <ArrowLeft className="size-5" />
          </button>

          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h1 className="text-[24px] font-bold text-white">
                {operation.code}
              </h1>
              <span
                className="px-3 py-1 rounded-[6px] text-[12px] font-semibold"
                style={{
                  backgroundColor: `${statusConfig.color}15`,
                  color: statusConfig.color
                }}
              >
                {statusConfig.label}
              </span>
            </div>
            <p className="text-[14px] text-[#a4a4a4]">
              {operation.issuer.name} • Emitido em {operation.financial.issueDate}
            </p>
          </div>

          <button className="px-4 py-2 bg-[#292929] border border-[#434343] rounded-[8px] text-[14px] font-semibold text-white hover:border-[#3482ff] flex items-center gap-2">
            <Download className="size-4" />
            Exportar Relatório
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-[#434343]">
          {[
            { id: "geral", label: "Visão Geral" },
            { id: "documentos", label: "Documentos" },
            { id: "investidores", label: "Investidores" },
            { id: "timeline", label: "Timeline" }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 text-[14px] font-semibold border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "text-[#3482ff] border-[#3482ff]"
                  : "text-[#a4a4a4] border-transparent hover:text-white"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="px-8 py-8">
        {/* Tab: Geral */}
        {activeTab === "geral" && (
          <div className="grid grid-cols-3 gap-6">
            {/* Left Column - Main Info */}
            <div className="col-span-2 space-y-6">
              {/* Informações Financeiras */}
              <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
                <h2 className="text-[18px] font-semibold text-white mb-6">
                  Informações Financeiras
                </h2>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Volume Total</p>
                    <p className="text-[20px] font-bold text-white">{operation.financial.volume}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Taxa de Remuneração</p>
                    <p className="text-[20px] font-bold text-white">{operation.financial.rate}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Prazo</p>
                    <p className="text-[16px] font-semibold text-white">{operation.financial.maturity}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Periodicidade</p>
                    <p className="text-[16px] font-semibold text-white">{operation.financial.paymentFrequency}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Garantia</p>
                    <p className="text-[16px] font-semibold text-white">{operation.financial.guarantee}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Data de Emissão</p>
                    <p className="text-[16px] font-semibold text-white">{operation.financial.issueDate}</p>
                  </div>
                </div>
              </div>

              {/* Status de Liquidação */}
              <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-[18px] font-semibold text-white">
                    Status de Liquidação
                  </h2>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-[#01bf73]/10 rounded-[6px]">
                    <CheckCircle2 className="size-4 text-[#01bf73]" />
                    <span className="text-[12px] font-semibold text-[#01bf73]">Em dia</span>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[14px] text-[#a4a4a4]">Progresso de Pagamento</span>
                      <span className="text-[14px] font-semibold text-white">
                        {operation.liquidation.paidInstallments}/{operation.liquidation.totalInstallments} parcelas
                      </span>
                    </div>
                    <div className="h-2 bg-[#212121] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#3482ff] rounded-full"
                        style={{ width: `${(operation.liquidation.paidInstallments / operation.liquidation.totalInstallments) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-[#212121] border border-[#434343] rounded-[8px]">
                      <p className="text-[12px] text-[#a4a4a4] mb-1">Valor Pago</p>
                      <p className="text-[16px] font-bold text-[#01bf73]">{operation.liquidation.paidAmount}</p>
                    </div>
                    <div className="p-4 bg-[#212121] border border-[#434343] rounded-[8px]">
                      <p className="text-[12px] text-[#a4a4a4] mb-1">Valor Restante</p>
                      <p className="text-[16px] font-bold text-white">{operation.liquidation.remainingAmount}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 p-4 bg-[#3482ff]/10 border border-[#3482ff]/20 rounded-[8px]">
                  <Calendar className="size-5 text-[#3482ff]" />
                  <div>
                    <p className="text-[12px] text-[#a4a4a4]">Próximo Pagamento</p>
                    <p className="text-[14px] font-semibold text-white">{operation.liquidation.nextPayment}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Sidebar */}
            <div className="space-y-6">
              {/* Emissor */}
              <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="size-10 bg-[#3482ff]/10 rounded-[8px] flex items-center justify-center">
                    <Building2 className="size-5 text-[#3482ff]" />
                  </div>
                  <h3 className="text-[16px] font-semibold text-white">Emissor</h3>
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Nome</p>
                    <p className="text-[14px] font-medium text-white">{operation.issuer.name}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">CNPJ</p>
                    <p className="text-[14px] font-medium text-white">{operation.issuer.cnpj}</p>
                  </div>
                  <div>
                    <p className="text-[12px] text-[#a4a4a4] mb-1">Localização</p>
                    <p className="text-[14px] font-medium text-white">{operation.issuer.address}</p>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
                <h3 className="text-[16px] font-semibold text-white mb-4">Resumo</h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="size-4 text-[#a4a4a4]" />
                      <span className="text-[14px] text-[#a4a4a4]">Investidores</span>
                    </div>
                    <span className="text-[14px] font-semibold text-white">{operation.investors.length}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="size-4 text-[#a4a4a4]" />
                      <span className="text-[14px] text-[#a4a4a4]">Documentos</span>
                    </div>
                    <span className="text-[14px] font-semibold text-white">{operation.documents.length}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="size-4 text-[#a4a4a4]" />
                      <span className="text-[14px] text-[#a4a4a4]">Tipo</span>
                    </div>
                    <span className="text-[14px] font-semibold text-white">{operation.type}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab: Documentos */}
        {activeTab === "documentos" && (
          <div className="max-w-[900px]">
            <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-[18px] font-semibold text-white">
                  Documentos da Operação
                </h2>
                <button className="px-4 py-2 bg-[#3482ff] text-white rounded-[8px] text-[14px] font-semibold hover:bg-[#2668dd] flex items-center gap-2">
                  <Upload className="size-4" />
                  Upload Documento
                </button>
              </div>

              <div className="space-y-3">
                {operation.documents.map((doc, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-[#212121] border border-[#434343] rounded-[8px] hover:border-[#3482ff]/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="size-10 bg-[#3482ff]/10 rounded-[8px] flex items-center justify-center">
                        <FileText className="size-5 text-[#3482ff]" />
                      </div>
                      <div>
                        <p className="text-[14px] font-semibold text-white mb-1">{doc.name}</p>
                        <p className="text-[12px] text-[#a4a4a4]">
                          {doc.type} • {doc.size} • {doc.date}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span
                        className={`px-3 py-1 rounded-[4px] text-[12px] font-semibold ${
                          doc.status === "aprovado"
                            ? "bg-[#01bf73]/10 text-[#01bf73]"
                            : "bg-[#ffc709]/10 text-[#ffc709]"
                        }`}
                      >
                        {doc.status === "aprovado" ? "Aprovado" : "Pendente"}
                      </span>

                      <button className="size-8 flex items-center justify-center bg-[#292929] border border-[#434343] rounded-[6px] text-white hover:border-[#3482ff]">
                        <Eye className="size-4" />
                      </button>
                      <button className="size-8 flex items-center justify-center bg-[#292929] border border-[#434343] rounded-[6px] text-white hover:border-[#3482ff]">
                        <Download className="size-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab: Investidores */}
        {activeTab === "investidores" && (
          <div className="max-w-[900px]">
            <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
              <h2 className="text-[18px] font-semibold text-white mb-6">
                Lista de Investidores
              </h2>

              <div className="space-y-3">
                {operation.investors.map((investor, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-[#212121] border border-[#434343] rounded-[8px]"
                  >
                    <div className="flex items-center gap-4">
                      <div className="size-10 bg-[#3482ff]/10 rounded-[8px] flex items-center justify-center">
                        <Users className="size-5 text-[#3482ff]" />
                      </div>
                      <div>
                        <p className="text-[14px] font-semibold text-white">{investor.name}</p>
                        <p className="text-[12px] text-[#a4a4a4]">Investidor Qualificado</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-[16px] font-bold text-white mb-1">{investor.amount}</p>
                      <p className="text-[12px] text-[#a4a4a4]">{investor.percentage} do total</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab: Timeline */}
        {activeTab === "timeline" && (
          <div className="max-w-[900px]">
            <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
              <h2 className="text-[18px] font-semibold text-white mb-6">
                Histórico da Operação
              </h2>

              <div className="space-y-4">
                {operation.timeline.map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="size-8 bg-[#01bf73]/10 rounded-full flex items-center justify-center">
                        <CheckCircle2 className="size-4 text-[#01bf73]" />
                      </div>
                      {index < operation.timeline.length - 1 && (
                        <div className="w-0.5 h-12 bg-[#434343]" />
                      )}
                    </div>

                    <div className="flex-1 pb-4">
                      <p className="text-[14px] font-semibold text-white mb-1">{item.event}</p>
                      <p className="text-[12px] text-[#a4a4a4]">{item.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}