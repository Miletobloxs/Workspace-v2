import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Upload, User } from "lucide-react";
import { Navbar } from "../components/Navbar";

export function WorkspacePersonalization() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    workspaceName: "",
    description: "",
    coverImage: null as File | null,
    profileImage: null as File | null,
  });

  const handleBack = () => {
    navigate('/');
  };

  const handleContinue = () => {
    // Salvar configurações do workspace
    localStorage.setItem("workspacePersonalization", JSON.stringify(formData));
    localStorage.setItem("onboardingStep", "workspace-personalized");
    
    // Redirecionar para página de boas-vindas
    navigate('/onboarding/sucesso');
  };

  const workspaceInitials = formData.workspaceName
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) || 'NW';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      <Navbar />

      {/* Header with Progress */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-[1440px] mx-auto px-[72px] pt-8 pb-8">
          <div className="flex items-end justify-between mb-8">
            <div className="flex-1">
              <h1 className="text-[32px] font-medium tracking-[-0.16px] text-slate-950 dark:text-white mb-3">
                Bem-vindo à Bloxs!
              </h1>
              <p className="text-[14px] leading-[1.4] text-slate-600 dark:text-slate-400">
                <span className="font-semibold">Antes de começar</span>, complete as etapas abaixo para liberar o acesso total à plataforma.
              </p>
            </div>

            <div className="flex gap-6 items-center bg-blue-50 dark:bg-blue-950 px-6 py-3 rounded-[12px]">
              <div className="bg-white dark:bg-slate-800 p-2 rounded-full border-2 border-white">
                <span className="font-semibold text-[#2e61ff] text-[14px]">01</span>
              </div>
              <div>
                <p className="font-semibold text-[14px] text-slate-950 dark:text-white">Personalize o espaço</p>
                <p className="text-[12px] text-slate-600 dark:text-slate-400">Adicione logo, capa e descrição da empresa</p>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="bg-slate-200 dark:bg-slate-700 h-[4px] rounded-full overflow-hidden">
            <div className="bg-[#2e61ff] h-full rounded-full" style={{ width: '33.33%' }} />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex max-w-[1440px] mx-auto w-full">
        {/* Form Section */}
        <div className="flex-1 px-[72px] py-12">
          <div className="max-w-[624px]">
            <div className="flex items-center gap-3 mb-6">
              <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 3H3m6 4H3m6 4H3m18-8v16a2 2 0 01-2 2H9a2 2 0 01-2-2V5a2 2 0 012-2h10a2 2 0 012 2z" className="text-slate-600 dark:text-slate-400" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 3H3M9 7H3M9 11H3" className="text-[#2e61ff]" />
              </svg>
              <h2 className="text-[24px] font-medium tracking-[-0.12px] text-slate-950 dark:text-white">
                Dê a cara do seu workspace
              </h2>
            </div>
            <p className="text-[14px] leading-[1.4] text-slate-600 dark:text-slate-400 mb-8">
              Adicione o logo, a imagem de capa e uma breve descrição para deixar<br />
              seu espaço com a cara da sua empresa.
            </p>

            <div className="space-y-6">
              {/* Workspace Name */}
              <div>
                <label className="flex gap-1 items-center text-[14px] font-medium text-slate-950 dark:text-white mb-2">
                  Nome do workspace
                  <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Digite o nome do workspace"
                  value={formData.workspaceName}
                  onChange={(e) => setFormData({ ...formData, workspaceName: e.target.value })}
                  className="w-full h-[48px] px-3 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-950 dark:text-white placeholder-slate-500 text-[14px] focus:outline-none focus:ring-2 focus:ring-[#2e61ff]"
                />
              </div>

              {/* Description */}
              <div>
                <label className="flex gap-1 items-center text-[14px] font-medium text-slate-950 dark:text-white mb-2">
                  Descrição da empresa
                  <span className="text-red-600">*</span>
                </label>
                <div className="relative">
                  <textarea
                    placeholder="Digite uma descrição da empresa"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    maxLength={200}
                    className="w-full h-[112px] px-3 py-3 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-950 dark:text-white placeholder-slate-500 text-[14px] resize-none focus:outline-none focus:ring-2 focus:ring-[#2e61ff]"
                  />
                  <div className="absolute bottom-3 right-3 text-[12px] text-slate-400">
                    {formData.description.length}/200
                  </div>
                </div>
              </div>

              {/* Cover Image */}
              <div>
                <label className="flex gap-1 items-center text-[14px] font-medium text-slate-950 dark:text-white mb-2">
                  Foto de capa
                  <span className="text-red-600">*</span>
                </label>
                <label className="w-full border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-[12px] bg-white dark:bg-slate-800 p-8 flex flex-col items-center justify-center cursor-pointer hover:border-[#2e61ff] transition-colors">
                  <Upload className="size-6 text-slate-950 dark:text-white mb-4" />
                  <p className="text-[14px] font-medium text-slate-950 dark:text-white text-center mb-1">
                    Escolha um arquivo ou arraste e solte-o aqui.
                  </p>
                  <p className="text-[12px] text-slate-600 dark:text-slate-400 text-center">
                    Formatos JPEG ou PNG, até 50 MB.
                  </p>
                  <input
                    type="file"
                    accept="image/jpeg,image/png"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setFormData({ ...formData, coverImage: e.target.files[0] });
                      }
                    }}
                  />
                </label>
              </div>

              {/* Profile Image */}
              <div>
                <label className="flex gap-1 items-center text-[14px] font-medium text-slate-950 dark:text-white mb-2">
                  Foto de perfil
                  <span className="text-red-600">*</span>
                </label>
                <div className="flex items-center gap-4">
                  <div className="size-[80px] rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                    <User className="size-8 text-slate-400" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[14px] font-medium text-slate-950 dark:text-white mb-1">
                      Carregue seu avatar
                    </p>
                    <p className="text-[12px] text-slate-600 dark:text-slate-400 mb-2">
                      JPEG ou PNG, até 128×128px
                    </p>
                    <label className="inline-block bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 px-4 py-2 rounded-[8px] text-[12px] font-medium text-slate-950 dark:text-white cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                      Carregar
                      <input
                        type="file"
                        accept="image/jpeg,image/png"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setFormData({ ...formData, profileImage: e.target.files[0] });
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Preview Section */}
        <div className="w-[480px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 p-12 flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 mb-2 text-[#2e61ff]">
            <div className="size-2 bg-[#2e61ff] rounded-full" />
            <span className="text-[12px] font-semibold">Preview real</span>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800 rounded-[16px] p-8 w-full max-w-[400px] mt-6">
            <div className="flex items-start gap-4">
              <div className="size-[64px] rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-[20px] font-semibold text-slate-600 dark:text-slate-300">
                {workspaceInitials}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white">
                    {formData.workspaceName || 'Nome do workspace'}
                  </h3>
                  {formData.workspaceName && (
                    <svg className="size-4 text-[#2e61ff]" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  )}
                </div>
                <p className="text-[12px] text-slate-600 dark:text-slate-400 mt-1">
                  {formData.description || 'Breve descrição do seu negócio.'}
                </p>
              </div>
            </div>

            <div className="mt-6 bg-white dark:bg-slate-900 rounded-[12px] p-4">
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 mb-3">
                <svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="text-[12px] font-medium">Atualização em tempo real</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Esta prévia mostra como o seu workspace aparecerá para os membros da equipe.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-slate-100 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 px-[72px] py-6">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between">
          <button
            onClick={handleBack}
            className="flex items-center gap-2 px-4 py-2 rounded-[8px] text-[14px] font-medium text-slate-950 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="size-4" />
            Voltar
          </button>

          <p className="text-[12px] text-slate-500">[ PASSO 1 DE 3 ]</p>

          <button
            onClick={handleContinue}
            className="bg-[#2e61ff] text-white px-6 py-2 rounded-[8px] text-[14px] font-medium hover:bg-[#1b41f5] transition-colors flex items-center gap-2"
          >
            Avançar
            <ArrowLeft className="size-4 rotate-180" />
          </button>
        </div>
      </div>
    </div>
  );
}