import { useNavigate } from "react-router";
import {
  Calculator,
  FileText,
  TrendingUp,
  Calendar,
  PieChart,
  Database,
  BarChart3,
  Target,
  ArrowRight,
  Download,
  Upload,
  Zap,
  Bell
} from "lucide-react";
import { Sidebar } from "../components/Sidebar";

export function Tools() {
  const navigate = useNavigate();

  const tools = [
    {
      id: "1",
      icon: Calculator,
      title: "Calculadora de Rentabilidade",
      description: "Simule a rentabilidade de diferentes tipos de investimentos estruturados",
      features: ["Cálculo de CDI", "Cálculo de IPCA", "Comparativo de taxas"],
      color: "#3482ff",
      status: "available",
      badge: "Popular"
    },
    {
      id: "2",
      icon: FileText,
      title: "Gerador de Documentos",
      description: "Gere modelos de documentos essenciais para operações estruturadas",
      features: ["Termo de Compromisso", "Contrato Padrão", "Declarações"],
      color: "#01bf73",
      status: "available",
      badge: null
    },
    {
      id: "3",
      icon: TrendingUp,
      title: "Análise de Viabilidade",
      description: "Avalie a viabilidade econômico-financeira de sua operação",
      features: ["Fluxo de Caixa", "VPL", "TIR", "Payback"],
      color: "#ffc709",
      status: "available",
      badge: "Novo"
    },
    {
      id: "4",
      icon: Calendar,
      title: "Calendário de Pagamentos",
      description: "Organize e acompanhe todos os pagamentos de suas operações",
      features: ["Alertas automáticos", "Exportar agenda", "Sincronização"],
      color: "#9333ea",
      status: "available",
      badge: null
    },
    {
      id: "5",
      icon: PieChart,
      title: "Dashboard de Performance",
      description: "Visualize a performance consolidada de seu portfólio",
      features: ["Gráficos interativos", "Métricas em tempo real", "Relatórios"],
      color: "#3482ff",
      status: "available",
      badge: null
    },
    {
      id: "6",
      icon: Database,
      title: "Base de Dados CVM",
      description: "Acesse informações públicas de operações registradas na CVM",
      features: ["Busca avançada", "Histórico de taxas", "Estatísticas"],
      color: "#01bf73",
      status: "available",
      badge: null
    },
    {
      id: "7",
      icon: BarChart3,
      title: "Comparador de Taxas",
      description: "Compare taxas e condições de diferentes operações do mercado",
      features: ["Benchmark", "Gráficos comparativos", "Exportação"],
      color: "#ffc709",
      status: "available",
      badge: null
    },
    {
      id: "8",
      icon: Target,
      title: "Simulador de Estruturação",
      description: "Simule diferentes estruturas para sua captação",
      features: ["Múltiplos cenários", "Custos estimados", "Timeline"],
      color: "#9333ea",
      status: "available",
      badge: null
    },
    {
      id: "9",
      icon: Download,
      title: "Central de Downloads",
      description: "Acesse modelos, templates e documentos importantes",
      features: ["Modelos CVM", "Contratos-padrão", "Checklists"],
      color: "#818181",
      status: "available",
      badge: null
    }
  ];

  const quickActions = [
    {
      icon: Zap,
      title: "Início Rápido",
      description: "Guias e tutoriais para começar",
      color: "#ffc709",
      action: () => {}
    },
    {
      icon: Upload,
      title: "Upload de Documentos",
      description: "Envie documentos para análise",
      color: "#3482ff",
      action: () => {}
    },
    {
      icon: FileText,
      title: "Meus Relatórios",
      description: "Acesse relatórios gerados",
      color: "#01bf73",
      action: () => {}
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[28px] font-bold text-slate-950 dark:text-white mb-2">
                Ferramentas
              </h1>
              <p className="text-[14px] text-slate-500 dark:text-slate-400">
                Utilize ferramentas especializadas para otimizar suas operações
              </p>
            </div>

            <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
              <Bell className="size-5 text-slate-600 dark:text-slate-400" />
              <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-6">
          <div className="grid grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={action.action}
                className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] hover:border-blue-500 transition-all text-left"
              >
                <div
                  className="size-12 rounded-[10px] flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${action.color}15` }}
                >
                  <action.icon className="size-6" style={{ color: action.color }} />
                </div>

                <div>
                  <h3 className="text-[14px] font-semibold text-slate-950 dark:text-white mb-1">
                    {action.title}
                  </h3>
                  <p className="text-[12px] text-slate-500 dark:text-slate-400">
                    {action.description}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 px-8 py-8">
          {/* Tools Grid */}
          <div className="grid grid-cols-3 gap-6 mb-12">
            {tools.map((tool) => (
              <div
                key={tool.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] p-6 hover:border-blue-500 transition-all"
              >
                {/* Icon and Badge */}
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="size-14 rounded-[10px] flex items-center justify-center"
                    style={{ backgroundColor: `${tool.color}15` }}
                  >
                    <tool.icon className="size-7" style={{ color: tool.color }} />
                  </div>

                  {tool.badge && (
                    <span
                      className="px-3 py-1 rounded-[6px] text-[11px] font-semibold"
                      style={{
                        backgroundColor: tool.badge === "Popular" ? "#ffc70915" : "#01bf7315",
                        color: tool.badge === "Popular" ? "#ffc709" : "#01bf73"
                      }}
                    >
                      {tool.badge}
                    </span>
                  )}
                </div>

                {/* Title and Description */}
                <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white mb-2">
                  {tool.title}
                </h3>
                <p className="text-[13px] text-slate-500 dark:text-slate-400 mb-4 leading-relaxed">
                  {tool.description}
                </p>

                {/* Features */}
                <div className="mb-6">
                  <ul className="space-y-2">
                    {tool.features.map((feature, index) => (
                      <li
                        key={index}
                        className="flex items-center gap-2 text-[13px] text-slate-500 dark:text-slate-400"
                      >
                        <div className="size-1 rounded-full bg-blue-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA */}
                {tool.status === "available" ? (
                  <button
                    onClick={() => {}}
                    className="w-full py-2.5 bg-blue-500 text-white rounded-[8px] font-semibold text-[14px] hover:bg-blue-600 flex items-center justify-center gap-2"
                  >
                    Acessar Ferramenta
                    <ArrowRight className="size-4" />
                  </button>
                ) : (
                  <button
                    disabled
                    className="w-full py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded-[8px] font-semibold text-[14px] cursor-not-allowed"
                  >
                    Em breve
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Bottom Banner */}
          <div className="bg-gradient-to-r from-blue-500/10 to-blue-500/5 border border-blue-500/20 rounded-[12px] p-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="size-16 bg-blue-500 rounded-[12px] flex items-center justify-center">
                  <Zap className="size-8 text-white" />
                </div>

                <div>
                  <h3 className="text-[20px] font-semibold text-slate-950 dark:text-white mb-2">
                    Precisa de uma ferramenta específica?
                  </h3>
                  <p className="text-[14px] text-slate-500 dark:text-slate-400">
                    Envie sua sugestão e ajude a construir a plataforma perfeita para você
                  </p>
                </div>
              </div>

              <button className="px-6 py-3 bg-blue-500 text-white rounded-[8px] font-semibold text-[14px] hover:bg-blue-600 flex items-center gap-2 whitespace-nowrap">
                Enviar Sugestão
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
