import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Search,
  Filter,
  Building2,
  TrendingUp,
  Shield,
  Clock,
  ArrowRight,
  Star,
  Check,
  Bell
} from "lucide-react";
import { Sidebar } from "../components/Sidebar";

export function Solucoes() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("todas");
  const [filterSector, setFilterSector] = useState("todos");

  const solutions = [
    {
      id: "1",
      title: "Estruturação de CRI",
      category: "Estruturação",
      description: "Estruturação completa de Certificados de Recebíveis Imobiliários para seu empreendimento",
      sectors: ["Imobiliário"],
      minTicket: "R$ 1.000.000",
      timeline: "45-60 dias",
      rating: 4.8,
      providers: 12,
      features: ["Due Diligence", "Documentação CVM", "Rating de Crédito", "Registro na B3"],
      color: "#3482ff"
    },
    {
      id: "2",
      title: "Emissão de Debêntures",
      category: "Emissão",
      description: "Assessoria completa para emissão de debêntures incentivadas e não incentivadas",
      sectors: ["Infraestrutura", "Energia"],
      minTicket: "R$ 5.000.000",
      timeline: "60-90 dias",
      rating: 4.9,
      providers: 8,
      features: ["Estruturação Jurídica", "Bookbuilding", "Agente Fiduciário", "Registro CVM"],
      color: "#ffc709"
    },
    {
      id: "3",
      title: "CRA do Agronegócio",
      category: "Estruturação",
      description: "Securitização de recebíveis do agronegócio com benefícios fiscais",
      sectors: ["Agronegócio"],
      minTicket: "R$ 500.000",
      timeline: "30-45 dias",
      rating: 4.7,
      providers: 10,
      features: ["Isenção Fiscal", "Garantias Reais", "Due Diligence", "Registro CVM"],
      color: "#01bf73"
    },
    {
      id: "4",
      title: "Distribuição no Mercado",
      category: "Distribuição",
      description: "Coloque sua operação no mercado com suporte de distribuidores especializados",
      sectors: ["Todos"],
      minTicket: "R$ 2.000.000",
      timeline: "15-30 dias",
      rating: 4.6,
      providers: 15,
      features: ["Roadshow", "Análise de Investidores", "Bookbuilding", "Pós-Venda"],
      color: "#9333ea"
    },
    {
      id: "5",
      title: "FIDC - Fundo de Recebíveis",
      category: "Estruturação",
      description: "Constituição e gestão de Fundos de Investimento em Direitos Creditórios",
      sectors: ["Financeiro", "Varejo"],
      minTicket: "R$ 10.000.000",
      timeline: "90-120 dias",
      rating: 4.9,
      providers: 6,
      features: ["Estruturação Completa", "Gestão de Carteira", "Administração", "Custódia"],
      color: "#9333ea"
    },
    {
      id: "6",
      title: "Assessoria Jurídica",
      category: "Serviços",
      description: "Suporte jurídico especializado em operações estruturadas de mercado de capitais",
      sectors: ["Todos"],
      minTicket: "R$ 50.000",
      timeline: "Variável",
      rating: 4.8,
      providers: 20,
      features: ["Documentação", "Compliance", "Contratos", "Pareceres"],
      color: "#818181"
    }
  ];

  const categories = [
    { id: "todas", label: "Todas" },
    { id: "estruturacao", label: "Estruturação" },
    { id: "emissao", label: "Emissão" },
    { id: "distribuicao", label: "Distribuição" },
    { id: "servicos", label: "Serviços" }
  ];

  const filteredSolutions = solutions.filter(solution => {
    const matchesSearch = solution.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         solution.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "todas" || 
                           solution.category.toLowerCase() === filterCategory;
    const matchesSector = filterSector === "todos" ||
                         solution.sectors.includes(filterSector);
    
    return matchesSearch && matchesCategory && matchesSector;
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[28px] font-bold text-slate-950 dark:text-white mb-2">
                Soluções Disponíveis
              </h1>
              <p className="text-[14px] text-slate-500 dark:text-slate-400">
                Encontre as melhores soluções para estruturar, emitir e distribuir suas operações
              </p>
            </div>

            <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
              <Bell className="size-5 text-slate-600 dark:text-slate-400" />
              <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setFilterCategory(category.id)}
                className={`px-6 py-3 rounded-[8px] text-[14px] font-semibold transition-all ${
                  filterCategory === category.id
                    ? "bg-blue-500 text-white"
                    : "bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-950 dark:text-white hover:border-blue-500"
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 px-8 py-8">
          {/* Filters */}
          <div className="flex items-center gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar soluções..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-[48px] pl-11 pr-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] text-slate-950 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400 pointer-events-none" />
              <select
                value={filterSector}
                onChange={(e) => setFilterSector(e.target.value)}
                className="h-[48px] pl-11 pr-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] text-slate-950 dark:text-white focus:outline-none focus:border-blue-500 appearance-none cursor-pointer min-w-[200px]"
              >
                <option value="todos">Todos os setores</option>
                <option value="Imobiliário">Imobiliário</option>
                <option value="Agronegócio">Agronegócio</option>
                <option value="Infraestrutura">Infraestrutura</option>
                <option value="Energia">Energia</option>
                <option value="Financeiro">Financeiro</option>
                <option value="Varejo">Varejo</option>
              </select>
            </div>
          </div>

          {/* Solutions Grid */}
          <div className="grid grid-cols-2 gap-6">
            {filteredSolutions.map((solution) => (
              <div
                key={solution.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] p-6 hover:border-blue-500 transition-all cursor-pointer"
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-4">
                    <div
                      className="size-14 rounded-[10px] flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${solution.color}15` }}
                    >
                      <Building2 className="size-7" style={{ color: solution.color }} />
                    </div>

                    <div>
                      <h3 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-1">
                        {solution.title}
                      </h3>
                      <span
                        className="inline-block px-3 py-1 rounded-[6px] text-[12px] font-semibold"
                        style={{
                          backgroundColor: `${solution.color}15`,
                          color: solution.color
                        }}
                      >
                        {solution.category}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <Star className="size-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-[14px] font-semibold text-slate-950 dark:text-white">
                      {solution.rating}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="text-[14px] text-slate-500 dark:text-slate-400 mb-4 leading-relaxed">
                  {solution.description}
                </p>

                {/* Info Grid */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px]">
                    <div className="flex items-center gap-2 mb-1">
                      <TrendingUp className="size-3.5 text-slate-500 dark:text-slate-400" />
                      <span className="text-[10px] text-slate-500 dark:text-slate-400">Ticket Mínimo</span>
                    </div>
                    <p className="text-[13px] font-semibold text-slate-950 dark:text-white">{solution.minTicket}</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px]">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="size-3.5 text-slate-500 dark:text-slate-400" />
                      <span className="text-[10px] text-slate-500 dark:text-slate-400">Prazo</span>
                    </div>
                    <p className="text-[13px] font-semibold text-slate-950 dark:text-white">{solution.timeline}</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px]">
                    <div className="flex items-center gap-2 mb-1">
                      <Shield className="size-3.5 text-slate-500 dark:text-slate-400" />
                      <span className="text-[10px] text-slate-500 dark:text-slate-400">Provedores</span>
                    </div>
                    <p className="text-[13px] font-semibold text-slate-950 dark:text-white">{solution.providers}</p>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {solution.features.map((feature, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[6px]"
                      >
                        <Check className="size-3 text-green-500" />
                        <span className="text-[12px] text-slate-950 dark:text-white">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sectors */}
                <div className="flex items-center gap-2 mb-4">
                  {solution.sectors.map((sector, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[4px] text-[11px] text-slate-500 dark:text-slate-400"
                    >
                      {sector}
                    </span>
                  ))}
                </div>

                {/* CTA */}
                <button
                  onClick={() => navigate("/cotacao/etapa-1")}
                  className="w-full py-3 bg-blue-500 text-white rounded-[8px] font-semibold text-[14px] hover:bg-blue-600 flex items-center justify-center gap-2"
                >
                  Solicitar Cotação
                  <ArrowRight className="size-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {filteredSolutions.length === 0 && (
            <div className="text-center py-16">
              <div className="size-16 mx-auto mb-4 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full flex items-center justify-center">
                <Search className="size-8 text-slate-400" />
              </div>
              <h3 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-2">
                Nenhuma solução encontrada
              </h3>
              <p className="text-[14px] text-slate-500 dark:text-slate-400">
                Tente ajustar os filtros ou termo de busca
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
