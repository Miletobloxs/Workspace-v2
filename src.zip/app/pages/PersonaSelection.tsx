import { useNavigate } from "react-router";
import { Building2, TrendingUp, Briefcase, Target, Users, Rocket } from "lucide-react";

export function PersonaSelection() {
  const navigate = useNavigate();

  const handlePersonaSelect = (persona: "sell-side" | "buy-side") => {
    // Salvar persona no localStorage
    localStorage.setItem("userPersona", persona);
    localStorage.setItem("onboardingStep", "persona-selected");
    
    // Navegar para onboarding específico
    if (persona === "sell-side") {
      navigate("/onboarding/sell-side");
    } else {
      navigate("/onboarding/buy-side");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#212121] via-[#2a2a2a] to-[#1a1a1a] flex items-center justify-center p-4">
      <div className="w-full max-w-[1200px]">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-white/5 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
            <div className="size-8 bg-[#3482ff] rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <span className="text-white font-semibold text-lg">Bloxs</span>
          </div>
          
          <h1 className="text-white text-[36px] font-bold mb-3">
            Bem-vindo à Bloxs! 👋
          </h1>
          <p className="text-[#a4a4a4] text-[18px] max-w-[600px] mx-auto">
            Para personalizar sua experiência, conte-nos qual é o seu perfil
          </p>
        </div>

        {/* Persona Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Sell-Side Card */}
          <button
            onClick={() => handlePersonaSelect("sell-side")}
            className="group relative bg-[#292929] border-2 border-[#434343] rounded-[24px] p-8 text-left hover:border-[#3482ff] hover:bg-[#2a2a2a] transition-all duration-300"
          >
            {/* Badge */}
            <div className="absolute top-6 right-6">
              <div className="px-3 py-1 bg-[#3482ff]/10 border border-[#3482ff] rounded-full">
                <span className="text-[12px] font-semibold text-[#3482ff]">
                  ORIGINADOR
                </span>
              </div>
            </div>

            {/* Icon */}
            <div className="size-16 bg-[#3482ff]/10 rounded-[16px] flex items-center justify-center mb-6 group-hover:bg-[#3482ff]/20 transition-colors">
              <Building2 className="size-8 text-[#3482ff]" />
            </div>

            {/* Content */}
            <h2 className="text-white text-[24px] font-bold mb-3">
              Sell-Side (Originador)
            </h2>
            <p className="text-[#a4a4a4] text-[16px] mb-6 leading-relaxed">
              Para empresas que desejam <strong className="text-white">estruturar e distribuir</strong> operações de crédito estruturado (CRI, CRA, Debêntures, FIDC)
            </p>

            {/* Features */}
            <div className="space-y-3 mb-6">
              <div className="flex items-start gap-3">
                <div className="size-6 bg-[#01bf73]/10 rounded-[6px] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Rocket className="size-4 text-[#01bf73]" />
                </div>
                <p className="text-[14px] text-[#e0e0e0]">
                  <strong className="text-white">Estruture operações</strong> com assistência de IA
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-6 bg-[#01bf73]/10 rounded-[6px] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Target className="size-4 text-[#01bf73]" />
                </div>
                <p className="text-[14px] text-[#e0e0e0]">
                  <strong className="text-white">Distribua para investidores</strong> qualificados
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-6 bg-[#01bf73]/10 rounded-[6px] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <TrendingUp className="size-4 text-[#01bf73]" />
                </div>
                <p className="text-[14px] text-[#e0e0e0]">
                  <strong className="text-white">Gerencie todo o ciclo</strong> da operação
                </p>
              </div>
            </div>

            {/* CTA */}
            <div className="flex items-center justify-between pt-6 border-t border-[#434343]">
              <span className="text-[14px] text-[#a4a4a4]">
                Ideal para: Securitizadoras, Fundos, Originadores
              </span>
              <div className="size-10 bg-[#3482ff] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-white text-[20px]">→</span>
              </div>
            </div>
          </button>

          {/* Buy-Side Card */}
          <button
            onClick={() => handlePersonaSelect("buy-side")}
            className="group relative bg-[#292929] border-2 border-[#434343] rounded-[24px] p-8 text-left hover:border-[#01bf73] hover:bg-[#2a2a2a] transition-all duration-300"
          >
            {/* Badge */}
            <div className="absolute top-6 right-6">
              <div className="px-3 py-1 bg-[#01bf73]/10 border border-[#01bf73] rounded-full">
                <span className="text-[12px] font-semibold text-[#01bf73]">
                  INVESTIDOR
                </span>
              </div>
            </div>

            {/* Icon */}
            <div className="size-16 bg-[#01bf73]/10 rounded-[16px] flex items-center justify-center mb-6 group-hover:bg-[#01bf73]/20 transition-colors">
              <Briefcase className="size-8 text-[#01bf73]" />
            </div>

            {/* Content */}
            <h2 className="text-white text-[24px] font-bold mb-3">
              Buy-Side (Investidor)
            </h2>
            <p className="text-[#a4a4a4] text-[16px] mb-6 leading-relaxed">
              Para investidores que buscam <strong className="text-white">descobrir e investir</strong> em oportunidades de crédito estruturado com retornos atrativos
            </p>

            {/* Features */}
            <div className="space-y-3 mb-6">
              <div className="flex items-start gap-3">
                <div className="size-6 bg-[#3482ff]/10 rounded-[6px] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Target className="size-4 text-[#3482ff]" />
                </div>
                <p className="text-[14px] text-[#e0e0e0]">
                  <strong className="text-white">Descubra oportunidades</strong> exclusivas de mercado
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-6 bg-[#3482ff]/10 rounded-[6px] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Users className="size-4 text-[#3482ff]" />
                </div>
                <p className="text-[14px] text-[#e0e0e0]">
                  <strong className="text-white">Analise e compare</strong> operações com dados completos
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-6 bg-[#3482ff]/10 rounded-[6px] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <TrendingUp className="size-4 text-[#3482ff]" />
                </div>
                <p className="text-[14px] text-[#e0e0e0]">
                  <strong className="text-white">Gerencie sua carteira</strong> em tempo real
                </p>
              </div>
            </div>

            {/* CTA */}
            <div className="flex items-center justify-between pt-6 border-t border-[#434343]">
              <span className="text-[14px] text-[#a4a4a4]">
                Ideal para: Family Offices, Fundos, Gestoras
              </span>
              <div className="size-10 bg-[#01bf73] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-white text-[20px]">→</span>
              </div>
            </div>
          </button>
        </div>

        {/* Help Text */}
        <div className="text-center">
          <p className="text-[#818181] text-[14px]">
            💡 Não se preocupe, você poderá alterar essa escolha depois nas configurações
          </p>
        </div>
      </div>
    </div>
  );
}
