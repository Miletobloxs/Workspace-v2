import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, FileText } from "lucide-react";
import { ProgressBar } from "../components/ProgressBar";
import imgTexture from "figma:asset/49b10b9ed2e210e5e2ae2f86906940de3b56018c.png";
import imgFrame from "figma:asset/4e47467b904f6cf80272c7ebc90bbc02b523e519.png";

export function DocumentUpload() {
  const navigate = useNavigate();
  const [files, setFiles] = useState({
    frente: null as File | null,
    verso: null as File | null,
    comprovante: null as File | null,
  });

  const handleFileUpload = (type: 'frente' | 'verso' | 'comprovante', file: File) => {
    setFiles(prev => ({ ...prev, [type]: file }));
  };

  const handleContinue = () => {
    // Salvar estado de documentos enviados
    localStorage.setItem("documentsUploaded", "true");
    localStorage.setItem("onboardingStep", "documents-uploaded");
    
    navigate('/onboarding/personalizar');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      {/* Left Side - Form */}
      <div className="flex-1 flex flex-col p-[72px]">
        <button className="flex items-center gap-2 mb-8 text-slate-950 dark:text-white hover:opacity-70">
          <ArrowLeft className="size-6" />
          <span className="font-medium text-[14px]">Voltar</span>
        </button>

        <ProgressBar currentStep={3} totalSteps={4} />

        <div className="mt-12">
          <h1 className="text-[32px] font-medium tracking-[-0.16px] text-slate-950 dark:text-white mb-4">
            Envie os documentos da sua empresa
          </h1>
          <p className="text-[14px] leading-[1.4] text-slate-600 dark:text-slate-400">
            Para validar seu cadastro, precisamos de alguns documentos oficiais. <br />
            <span className="font-semibold">Fique tranquilo:</span> seus dados são tratados com total sigilo e segurança.
          </p>
        </div>

        <div className="mt-8 space-y-6">
          <DocumentSection
            title="Frente"
            description="O arquivo deve mostrar frente do documento e com todas as informações visíveis."
            hint="Anexe o documento em PDF, com até X MB."
            file={files.frente}
            onFileSelect={(file) => handleFileUpload('frente', file)}
          />

          <DocumentSection
            title="Verso"
            description="O arquivo deve mostrar verso do documento e com todas as informações visíveis."
            hint="Anexe o documento em PDF, com até X MB."
            file={files.verso}
            onFileSelect={(file) => handleFileUpload('verso', file)}
          />

          <DocumentSection
            title="Comprovante de endereço"
            description="Anexe seu comprovante de endereço recente (até 30 dias)."
            hint="Arquivo no formato PDF e com no máximo X MB."
            file={files.comprovante}
            onFileSelect={(file) => handleFileUpload('comprovante', file)}
          />
        </div>

        <button
          onClick={handleContinue}
          className="mt-12 bg-[#2e61ff] text-white px-6 py-3 rounded-[8px] font-medium text-[14px] hover:bg-[#1b41f5] transition-colors flex items-center justify-center gap-2 w-full"
        >
          Avançar
          <ArrowLeft className="size-4 rotate-180" />
        </button>

        <p className="mt-8 text-[12px] text-slate-500 dark:text-slate-400">
          © 2025 Bloxs Tech Desenvolvedora de Programas. Todos os direitos reservados.
        </p>
      </div>

      {/* Right Side - Preview */}
      <div className="flex-1 bg-slate-100 dark:bg-slate-900 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `url(${imgTexture})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        
        <div className="relative z-10 flex items-center justify-center h-full p-12">
          <div className="bg-white dark:bg-slate-800 rounded-[24px] shadow-2xl p-8 max-w-[600px] w-full">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <div className="bg-slate-100 dark:bg-slate-700 p-2 rounded-lg">
                  <svg className="size-4" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="6" fill="#94A3B8" />
                  </svg>
                </div>
                <span className="text-[12px] text-slate-600 dark:text-slate-400">app.bloxs.com.br</span>
                <svg className="size-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
              </div>
              <div className="flex gap-2">
                <button className="bg-slate-100 dark:bg-slate-700 p-2 rounded-lg hover:bg-slate-200">
                  <svg className="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <circle cx="12" cy="12" r="10" strokeWidth={2} />
                    <path d="M12 8v8m4-4H8" strokeWidth={2} strokeLinecap="round" />
                  </svg>
                </button>
              </div>
            </div>

            <img 
              src={imgFrame} 
              alt="Preview da plataforma Bloxs" 
              className="w-full rounded-lg"
            />

            <div className="mt-6 text-center">
              <h3 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-2">
                Uma plataforma, múltiplas soluções
              </h3>
              <p className="text-[14px] text-slate-600 dark:text-slate-400">
                Transformando o Mercado de Capitais<br />em um ambiente 100% digital.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface DocumentSectionProps {
  title: string;
  description: string;
  hint: string;
  file: File | null;
  onFileSelect: (file: File) => void;
}

function DocumentSection({ title, description, hint, file, onFileSelect }: DocumentSectionProps) {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-[10px] items-center">
        <FileText className="size-5 text-slate-600 dark:text-slate-400" />
        <h3 className="font-semibold text-[16px] text-slate-950 dark:text-white">{title}</h3>
      </div>
      <p className="text-[14px] leading-[1.4] text-slate-600 dark:text-slate-400">{description}</p>
      
      <div className="bg-white dark:bg-slate-800 h-[48px] rounded-[8px] border border-slate-300 dark:border-slate-600 shadow-sm flex items-center px-4 gap-2">
        <p className="flex-1 text-[12px] leading-[1.4] text-slate-600 dark:text-slate-400">
          {file ? file.name : hint}
        </p>
        <label className="bg-[#2e61ff] text-white px-[10px] py-[6px] rounded-[8px] text-[12px] font-medium cursor-pointer hover:bg-[#1b41f5] transition-colors">
          Anexar
          <input
            type="file"
            accept=".pdf"
            className="hidden"
            onChange={handleFileChange}
          />
        </label>
      </div>
    </div>
  );
}