import { useState } from "react";
import { useNavigate } from "react-router";
import { X, Check } from "lucide-react";

type Solution = "estruturacao" | "emissao" | "distribuicao";

export function QuotationStep1() {
  const navigate = useNavigate();
  const [selectedSolutions, setSelectedSolutions] = useState<Solution[]>([]);

  const toggleSolution = (solution: Solution) => {
    setSelectedSolutions((prev) =>
      prev.includes(solution)
        ? prev.filter((s) => s !== solution)
        : [...prev, solution]
    );
  };

  const handleContinue = () => {
    if (selectedSolutions.length === 0) return;
    
    // Redireciona baseado na solução selecionada
    if (selectedSolutions.includes("distribuicao")) {
      navigate("/cotacao/etapa-2-distribuicao", { state: { solutions: selectedSolutions } });
    } else {
      navigate("/cotacao/etapa-2-estruturacao", { state: { solutions: selectedSolutions } });
    }
  };

  const solutions = [
    {
      id: "estruturacao" as Solution,
      title: "Estruturação de Operações",
      description: "Serviços especializados para estruturação jurídica, regulatória e financeira.",
    },
    {
      id: "emissao" as Solution,
      title: "Emissão e Registro de Ofertas",
      description: "Assessoria completa para registro e emissão de títulos no mercado.",
    },
    {
      id: "distribuicao" as Solution,
      title: "Coordenação e Distribuição",
      description: "Coordenação de ofertas e distribuição junto ao mercado investidor.",
    },
  ];

  return (
    <div className="min-h-screen bg-[#212121] flex">
      {/* Left Sidebar */}
      <div className="w-[463px] bg-[#292929] relative overflow-hidden">
        {/* Gradient Effects */}
        <div className="absolute top-[-74px] left-[-257px] w-[530px] h-[361px] pointer-events-none">
          <div className="w-full h-full opacity-30 blur-[94.5px]">
            <div className="w-full h-full bg-gradient-to-r from-[#3482ff] to-transparent rotate-[145deg]" />
          </div>
        </div>
        <div className="absolute bottom-0 right-0 w-[526px] h-[368px] pointer-events-none">
          <div className="w-full h-full opacity-30 blur-[94.5px]">
            <div className="w-full h-full bg-gradient-to-l from-[#3482ff] to-transparent rotate-[-145deg]" />
          </div>
        </div>

        {/* Logo */}
        <div className="absolute top-[104px] left-[32px] w-[104px] h-[24px]">
          <svg viewBox="0 0 104 24" fill="none">
            <text x="0" y="18" fill="white" fontSize="20" fontWeight="600" fontFamily="Poppins">
              bloxs
            </text>
          </svg>
        </div>

        {/* Content */}
        <div className="absolute top-[214px] left-1/2 -translate-x-1/2 w-[399px]">
          <h2 className="text-[32px] font-semibold text-white leading-normal tracking-[0.48px] mb-[100px]">
            Cote as soluções ideais para sua operação
          </h2>

          {/* Features */}
          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="size-[40px] bg-[#242320] border border-[rgba(52,130,255,0.2)] rounded-[8px] flex items-center justify-center flex-shrink-0">
                <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="#3482FF" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <p className="text-[16px] text-[#a4a4a4] leading-normal pt-2">
                Tudo que sua operação precisa, de ponta a ponta
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="size-[40px] bg-[#242320] border border-[rgba(52,130,255,0.2)] rounded-[8px] flex items-center justify-center flex-shrink-0">
                <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="#3482FF" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                </svg>
              </div>
              <p className="text-[16px] text-[#a4a4a4] leading-normal pt-2">
                Expertise regulatória para o Mercado de Capitais
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="size-[40px] bg-[#242320] border border-[rgba(52,130,255,0.2)] rounded-[8px] flex items-center justify-center flex-shrink-0">
                <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="#3482FF" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
                </svg>
              </div>
              <p className="text-[16px] text-[#a4a4a4] leading-normal pt-2">
                Tecnologia, eficiência e segurança em cada etapa
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative">
        {/* Close Button */}
        <button
          onClick={() => navigate("/home")}
          className="absolute top-6 right-6 size-6 text-white hover:text-white/80 transition-colors"
        >
          <X className="size-6" />
        </button>

        {/* Progress */}
        <div className="absolute top-[80px] left-[32px] w-[216px]">
          <p className="text-[12px] text-white mb-2">Etapa 1 de 3</p>
          <div className="h-2 bg-[#292929] rounded-[20px] overflow-hidden">
            <div className="h-full w-1/4 bg-[#3482ff] rounded-[20px]" />
          </div>
        </div>

        {/* Title */}
        <div className="absolute top-[138px] left-[32px] max-w-[900px]">
          <h1 className="text-[24px] font-bold text-white leading-[48px] mb-2">
            Quais soluções você deseja cotar com a Bloxs?
          </h1>
          <p className="text-[16px] text-white leading-normal">
            Selecione abaixo as soluções que você deseja cotar para sua operação.
          </p>
        </div>

        {/* Solutions */}
        <div className="absolute top-[266px] left-[32px] flex gap-4">
          {solutions.map((solution) => {
            const isSelected = selectedSolutions.includes(solution.id);
            return (
              <button
                key={solution.id}
                onClick={() => toggleSolution(solution.id)}
                className={`px-4 py-3 rounded-[8px] border transition-all flex items-center gap-4 ${
                  isSelected
                    ? "border-[#3482ff] bg-transparent"
                    : "border-[#515151] bg-transparent hover:border-[#3482ff]/50"
                }`}
              >
                {/* Checkbox */}
                <div
                  className={`size-4 rounded-[2px] border flex items-center justify-center ${
                    isSelected
                      ? "border-[#3482ff] bg-transparent"
                      : "border-[#515151] bg-[#292929]"
                  }`}
                >
                  {isSelected && <Check className="size-3 text-[#3482ff]" />}
                </div>
                <span className="text-[14px] font-semibold text-white whitespace-nowrap">
                  {solution.title}
                </span>
              </button>
            );
          })}
        </div>

        {/* Tooltip (show when hovering first solution) */}
        {selectedSolutions.includes("estruturacao") && (
          <div className="absolute top-[106px] right-[100px] w-[420px] bg-[#313131] rounded-[8px] shadow-[0px_4px_15px_0px_rgba(0,0,0,0.1)] p-6">
            <h3 className="text-[16px] font-semibold text-[#3482ff] mb-2">
              Estruturação de operações
            </h3>
            <p className="text-[14px] text-[#e3e3e3] leading-normal">
              Serviços especializados para estruturação jurídica, regulatória e financeira.
            </p>
          </div>
        )}

        {/* Divider */}
        <div className="absolute bottom-[81px] left-[32px] right-[32px] h-px bg-[#2e2e2e]" />

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          disabled={selectedSolutions.length === 0}
          className="absolute bottom-6 right-8 px-6 py-4 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[16px] leading-[16px] hover:bg-[#2668dd] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Continuar
        </button>
      </div>
    </div>
  );
}
