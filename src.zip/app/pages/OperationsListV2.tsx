import { useState } from "react";
import { useNavigate } from "react-router";
import { 
  Plus, 
  Search, 
  Filter, 
  Download,
  Eye,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle
} from "lucide-react";

type OperationStatus = "ativa" | "liquidando" | "liquidada" | "pendente";
type OperationType = "CRI" | "CRA" | "Debênture" | "FIDC";

interface Operation {
  id: string;
  code: string;
  type: OperationType;
  issuer: string;
  volume: string;
  rate: string;
  maturity: string;
  status: OperationStatus;
  createdAt: string;
  investors: number;
}

export function OperationsListV2() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("todas");
  const [filterType, setFilterType] = useState<string>("todos");

  const operations: Operation[] = [
    {
      id: "1",
      code: "CRI-2024-001",
      type: "CRI",
      issuer: "Construtora ABC S.A.",
      volume: "R$ 50.000.000,00",
      rate: "IPCA + 8,5% a.a.",
      maturity: "36 meses",
      status: "ativa",
      createdAt: "15/01/2024",
      investors: 12
    },
    {
      id: "2",
      code: "CRA-2024-002",
      type: "CRA",
      issuer: "Agro Invest Ltda",
      volume: "R$ 25.000.000,00",
      rate: "CDI + 3% a.a.",
      maturity: "24 meses",
      status: "liquidando",
      createdAt: "10/02/2024",
      investors: 8
    },
    {
      id: "3",
      code: "DEB-2024-003",
      type: "Debênture",
      issuer: "Tech Solutions S.A.",
      volume: "R$ 100.000.000,00",
      rate: "12% a.a. (pré)",
      maturity: "60 meses",
      status: "liquidada",
      createdAt: "05/12/2023",
      investors: 24
    },
    {
      id: "4",
      code: "CRI-2024-004",
      type: "CRI",
      issuer: "Imobiliária Premium",
      volume: "R$ 35.000.000,00",
      rate: "IPCA + 9% a.a.",
      maturity: "48 meses",
      status: "pendente",
      createdAt: "20/02/2024",
      investors: 0
    },
    {
      id: "5",
      code: "FIDC-2024-005",
      type: "FIDC",
      issuer: "Crédito Fácil S.A.",
      volume: "R$ 75.000.000,00",
      rate: "CDI + 4,5% a.a.",
      maturity: "36 meses",
      status: "ativa",
      createdAt: "18/01/2024",
      investors: 18
    }
  ];

  const getStatusConfig = (status: OperationStatus) => {
    const configs = {
      ativa: {
        label: "Ativa",
        color: "#01bf73",
        bg: "#01bf73",
        icon: CheckCircle2
      },
      liquidando: {
        label: "Liquidando",
        color: "#ffc709",
        bg: "#ffc709",
        icon: Clock
      },
      liquidada: {
        label: "Liquidada",
        color: "#818181",
        bg: "#818181",
        icon: CheckCircle2
      },
      pendente: {
        label: "Pendente",
        color: "#3482ff",
        bg: "#3482ff",
        icon: AlertCircle
      }
    };
    return configs[status];
  };

  const getTypeColor = (type: OperationType) => {
    const colors = {
      CRI: "#3482ff",
      CRA: "#01bf73",
      Debênture: "#ffc709",
      FIDC: "#9333ea"
    };
    return colors[type];
  };

  const filteredOperations = operations.filter(op => {
    const matchesSearch = op.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         op.issuer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "todas" || op.status === filterStatus;
    const matchesType = filterType === "todos" || op.type === filterType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const stats = [
    { label: "Total de Operações", value: operations.length.toString(), icon: TrendingUp, color: "#3482ff" },
    { label: "Volume Total", value: "R$ 285M", icon: TrendingUp, color: "#01bf73" },
    { label: "Operações Ativas", value: operations.filter(o => o.status === "ativa").length.toString(), icon: CheckCircle2, color: "#01bf73" },
    { label: "Em Liquidação", value: operations.filter(o => o.status === "liquidando").length.toString(), icon: Clock, color: "#ffc709" }
  ];

  return (
    <div className="min-h-screen bg-[#212121]">
      {/* Header */}
      <div className="border-b border-[#2e2e2e] px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-[28px] font-bold text-white mb-2">
              Operações
            </h1>
            <p className="text-[14px] text-[#a4a4a4]">
              Gerencie todas as operações do seu workspace
            </p>
          </div>

          <button
            onClick={() => navigate("/cotacao/etapa-1")}
            className="px-6 py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd] flex items-center gap-2"
          >
            <Plus className="size-5" />
            Nova Operação
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-[#292929] border border-[#434343] rounded-[8px] p-4"
            >
              <div className="flex items-center gap-3 mb-2">
                <div
                  className="size-8 rounded-[6px] flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}15` }}
                >
                  <stat.icon className="size-4" style={{ color: stat.color }} />
                </div>
                <span className="text-[12px] text-[#a4a4a4]">{stat.label}</span>
              </div>
              <p className="text-[20px] font-bold text-white">{stat.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="px-8 py-6 border-b border-[#2e2e2e]">
        <div className="flex items-center gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-[#818181]" />
            <input
              type="text"
              placeholder="Buscar por código ou emissor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-[48px] pl-11 pr-4 bg-[#292929] border border-[#434343] rounded-[8px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
            />
          </div>

          {/* Status Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="h-[48px] pl-11 pr-8 bg-[#292929] border border-[#434343] rounded-[8px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none cursor-pointer min-w-[180px]"
            >
              <option value="todas">Todos os status</option>
              <option value="ativa">Ativa</option>
              <option value="liquidando">Liquidando</option>
              <option value="liquidada">Liquidada</option>
              <option value="pendente">Pendente</option>
            </select>
          </div>

          {/* Type Filter */}
          <div className="relative">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="h-[48px] px-4 bg-[#292929] border border-[#434343] rounded-[8px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none cursor-pointer min-w-[150px]"
            >
              <option value="todos">Todos os tipos</option>
              <option value="CRI">CRI</option>
              <option value="CRA">CRA</option>
              <option value="Debênture">Debênture</option>
              <option value="FIDC">FIDC</option>
            </select>
          </div>

          {/* Export */}
          <button className="h-[48px] px-4 bg-[#292929] border border-[#434343] rounded-[8px] text-[14px] font-semibold text-white hover:border-[#3482ff] flex items-center gap-2">
            <Download className="size-5" />
            Exportar
          </button>
        </div>
      </div>

      {/* Operations Table */}
      <div className="px-8 py-6">
        <div className="bg-[#292929] border border-[#434343] rounded-[12px] overflow-hidden">
          {/* Table Header */}
          <div className="grid grid-cols-12 gap-4 px-6 py-4 border-b border-[#434343] bg-[#212121]">
            <div className="col-span-2">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Código</span>
            </div>
            <div className="col-span-1">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Tipo</span>
            </div>
            <div className="col-span-2">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Emissor</span>
            </div>
            <div className="col-span-2">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Volume</span>
            </div>
            <div className="col-span-2">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Taxa</span>
            </div>
            <div className="col-span-1">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Status</span>
            </div>
            <div className="col-span-2">
              <span className="text-[12px] font-semibold text-[#a4a4a4] uppercase">Ações</span>
            </div>
          </div>

          {/* Table Body */}
          <div className="divide-y divide-[#434343]">
            {filteredOperations.length === 0 ? (
              <div className="px-6 py-12 text-center">
                <p className="text-[14px] text-[#a4a4a4]">Nenhuma operação encontrada</p>
              </div>
            ) : (
              filteredOperations.map((operation) => {
                const statusConfig = getStatusConfig(operation.status);
                const typeColor = getTypeColor(operation.type);
                const StatusIcon = statusConfig.icon;

                return (
                  <div
                    key={operation.id}
                    className="grid grid-cols-12 gap-4 px-6 py-4 hover:bg-[#212121] transition-colors cursor-pointer"
                    onClick={() => navigate(`/workspace/operacoes/${operation.id}`)}
                  >
                    <div className="col-span-2 flex items-center">
                      <span className="text-[14px] font-semibold text-white">
                        {operation.code}
                      </span>
                    </div>

                    <div className="col-span-1 flex items-center">
                      <span
                        className="px-2 py-1 rounded-[4px] text-[12px] font-semibold"
                        style={{ 
                          backgroundColor: `${typeColor}15`,
                          color: typeColor
                        }}
                      >
                        {operation.type}
                      </span>
                    </div>

                    <div className="col-span-2 flex items-center">
                      <span className="text-[14px] text-white truncate">
                        {operation.issuer}
                      </span>
                    </div>

                    <div className="col-span-2 flex items-center">
                      <span className="text-[14px] font-medium text-white">
                        {operation.volume}
                      </span>
                    </div>

                    <div className="col-span-2 flex items-center">
                      <span className="text-[14px] text-[#a4a4a4]">
                        {operation.rate}
                      </span>
                    </div>

                    <div className="col-span-1 flex items-center">
                      <div
                        className="flex items-center gap-1 px-2 py-1 rounded-[4px]"
                        style={{ backgroundColor: `${statusConfig.bg}15` }}
                      >
                        <StatusIcon className="size-3" style={{ color: statusConfig.color }} />
                        <span
                          className="text-[12px] font-semibold"
                          style={{ color: statusConfig.color }}
                        >
                          {statusConfig.label}
                        </span>
                      </div>
                    </div>

                    <div className="col-span-2 flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/workspace/operacoes/${operation.id}`);
                        }}
                        className="px-3 py-1.5 bg-[#3482ff]/10 border border-[#3482ff] rounded-[6px] text-[12px] font-semibold text-[#3482ff] hover:bg-[#3482ff]/20 flex items-center gap-1"
                      >
                        <Eye className="size-3.5" />
                        Ver
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Pagination */}
        {filteredOperations.length > 0 && (
          <div className="flex items-center justify-between mt-6">
            <p className="text-[14px] text-[#a4a4a4]">
              Mostrando {filteredOperations.length} de {operations.length} operações
            </p>

            <div className="flex items-center gap-2">
              <button className="px-4 py-2 bg-[#292929] border border-[#434343] rounded-[6px] text-[14px] font-semibold text-white hover:border-[#3482ff]">
                Anterior
              </button>
              <button className="px-4 py-2 bg-[#3482ff] border border-[#3482ff] rounded-[6px] text-[14px] font-semibold text-white">
                1
              </button>
              <button className="px-4 py-2 bg-[#292929] border border-[#434343] rounded-[6px] text-[14px] font-semibold text-white hover:border-[#3482ff]">
                2
              </button>
              <button className="px-4 py-2 bg-[#292929] border border-[#434343] rounded-[6px] text-[14px] font-semibold text-white hover:border-[#3482ff]">
                Próximo
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}