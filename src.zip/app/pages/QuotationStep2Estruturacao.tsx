import { useState } from "react";
import { useNavigate, useLocation } from "react-router";
import { X, ChevronDown, Info, Lock } from "lucide-react";

export function QuotationStep2Estruturacao() {
  const navigate = useNavigate();
  const location = useLocation();
  const solutions = (location.state as any)?.solutions || [];

  const [formData, setFormData] = useState({
    cnpjEmissor: "",
    volumeTotal: "",
    tipoAtivo: "CRI",
    garantia: "Aval, Veículos, Imóvel Rural...",
    garantiaIndexador: "Sim",
    indexador: "IPCA + 14,5% a.a",
    taxaIndexador: "",
    taxaPreFixada: "",
    prazoMeses: "",
    periodicidadePagamento: "",
    periodicidadeJuros: "",
  });

  const handleContinue = () => {
    navigate("/cotacao/etapa-3", { state: { solutions, formData } });
  };

  return (
    <div className="min-h-screen bg-[#212121] flex">
      {/* Left Sidebar (same as Step 1) */}
      <div className="w-[463px] bg-[#292929] relative overflow-hidden">
        <div className="absolute top-[-74px] left-[-257px] w-[530px] h-[361px] pointer-events-none">
          <div className="w-full h-full opacity-30 blur-[94.5px]">
            <div className="w-full h-full bg-gradient-to-r from-[#3482ff] to-transparent rotate-[145deg]" />
          </div>
        </div>
        <div className="absolute bottom-0 right-0 w-[526px] h-[368px] pointer-events-none">
          <div className="w-full h-full opacity-30 blur-[94.5px]">
            <div className="w-full h-full bg-gradient-to-l from-[#3482ff] to-transparent rotate-[-145deg]" />
          </div>
        </div>

        <div className="absolute top-[104px] left-[32px] w-[104px] h-[24px]">
          <svg viewBox="0 0 104 24" fill="none">
            <text x="0" y="18" fill="white" fontSize="20" fontWeight="600" fontFamily="Poppins">
              bloxs
            </text>
          </svg>
        </div>

        <div className="absolute top-[214px] left-1/2 -translate-x-1/2 w-[399px]">
          <h2 className="text-[32px] font-semibold text-white leading-normal tracking-[0.48px] mb-[100px]">
            Cote as soluções ideais para sua operação
          </h2>

          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="size-[40px] bg-[#242320] border border-[rgba(52,130,255,0.2)] rounded-[8px] flex items-center justify-center flex-shrink-0">
                <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="#3482FF" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <p className="text-[16px] text-[#a4a4a4] leading-normal pt-2">
                Tudo que sua operação precisa, de ponta a ponta
              </p>
            </div>
            <div className="flex items-start gap-4">
              <div className="size-[40px] bg-[#242320] border border-[rgba(52,130,255,0.2)] rounded-[8px] flex items-center justify-center flex-shrink-0">
                <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="#3482FF" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                </svg>
              </div>
              <p className="text-[16px] text-[#a4a4a4] leading-normal pt-2">
                Expertise regulatória para o Mercado de Capitais
              </p>
            </div>
            <div className="flex items-start gap-4">
              <div className="size-[40px] bg-[#242320] border border-[rgba(52,130,255,0.2)] rounded-[8px] flex items-center justify-center flex-shrink-0">
                <svg className="size-6" fill="none" viewBox="0 0 24 24" stroke="#3482FF" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
                </svg>
              </div>
              <p className="text-[16px] text-[#a4a4a4] leading-normal pt-2">
                Tecnologia, eficiência e segurança em cada etapa
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative overflow-y-auto">
        <button
          onClick={() => navigate("/home")}
          className="absolute top-6 right-6 size-6 text-white hover:text-white/80 transition-colors z-10"
        >
          <X className="size-6" />
        </button>

        <div className="absolute top-[80px] left-[32px] w-[216px]">
          <p className="text-[12px] text-white mb-2">Etapa 2 de 3</p>
          <div className="h-2 bg-[#292929] rounded-[20px] overflow-hidden">
            <div className="h-full w-2/3 bg-[#3482ff] rounded-[20px]" />
          </div>
        </div>

        <div className="absolute top-[138px] left-[32px] max-w-[900px]">
          <h1 className="text-[24px] font-bold text-white leading-[48px]">
            Informe os dados da operação
          </h1>
        </div>

        {/* Form */}
        <div className="absolute top-[218px] left-[32px] right-[32px] space-y-6 pb-32">
          {/* Row 1: CNPJ, Volume, Tipo Ativo */}
          <div className="grid grid-cols-3 gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="CNPJ do emissor"
                value={formData.cnpjEmissor}
                onChange={(e) => setFormData({ ...formData, cnpjEmissor: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
              />
              <Info className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-[#818181]" />
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder="Volume total"
                value={formData.volumeTotal}
                onChange={(e) => setFormData({ ...formData, volumeTotal: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
              />
              <Info className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-[#818181]" />
            </div>

            <div className="relative">
              <select
                value={formData.tipoAtivo}
                onChange={(e) => setFormData({ ...formData, tipoAtivo: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white appearance-none focus:outline-none focus:border-[#3482ff]"
              >
                <option value="CRI">CRI</option>
                <option value="CRA">CRA</option>
                <option value="Debênture">Debênture</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
            </div>
          </div>

          {/* Row 2: Garantia, Indexador */}
          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <select
                value={formData.garantia}
                onChange={(e) => setFormData({ ...formData, garantia: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white appearance-none focus:outline-none focus:border-[#3482ff]"
              >
                <option value="Aval, Veículos, Imóvel Rural...">Aval, Veículos, Imóvel Rural...</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
            </div>

            <div className="relative">
              <select
                value={formData.garantiaIndexador}
                onChange={(e) => setFormData({ ...formData, garantiaIndexador: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white appearance-none focus:outline-none focus:border-[#3482ff]"
              >
                <option value="Sim">Sim</option>
                <option value="Não">Não</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
            </div>
          </div>

          {/* Section: Remuneração e Prazo */}
          <div className="pt-4">
            <h3 className="text-[16px] font-semibold text-white mb-4">Remuneração e Prazo</h3>

            <div className="grid grid-cols-3 gap-4">
              <div className="relative">
                <select
                  value={formData.indexador}
                  onChange={(e) => setFormData({ ...formData, indexador: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white appearance-none focus:outline-none focus:border-[#3482ff]"
                >
                  <option value="IPCA + 14,5% a.a">IPCA + 14,5% a.a</option>
                  <option value="CDI + 2% a.a">CDI + 2% a.a</option>
                  <option value="Pré-fixado">Pré-fixado</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
              </div>

              <input
                type="text"
                placeholder="Taxa sobre indexador"
                value={formData.taxaIndexador}
                onChange={(e) => setFormData({ ...formData, taxaIndexador: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
              />

              <input
                type="text"
                placeholder="Taxa pré-fixada"
                value={formData.taxaPreFixada}
                onChange={(e) => setFormData({ ...formData, taxaPreFixada: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
              />
            </div>

            <div className="relative mt-4 flex items-center gap-2">
              <Lock className="absolute left-4 size-3.5 text-[#818181]" />
              <input
                type="text"
                value={formData.indexador}
                disabled
                className="flex-1 h-[48px] pl-11 pr-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white opacity-60 cursor-not-allowed"
              />
              <Info className="size-4 text-[#818181]" />
            </div>

            <div className="mt-4">
              <input
                type="text"
                placeholder="Prazo em meses (opcional)"
                value={formData.prazoMeses}
                onChange={(e) => setFormData({ ...formData, prazoMeses: e.target.value })}
                className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
              />
            </div>
          </div>

          {/* Section: Fluxo de pagamento */}
          <div className="pt-4">
            <h3 className="text-[16px] font-semibold text-white mb-4">Fluxo de pagamento</h3>

            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <select
                  value={formData.periodicidadePagamento}
                  onChange={(e) => setFormData({ ...formData, periodicidadePagamento: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white appearance-none focus:outline-none focus:border-[#3482ff]"
                >
                  <option value="">Selecione a periodicidade</option>
                  <option value="Mensal">Mensal</option>
                  <option value="Trimestral">Trimestral</option>
                  <option value="Semestral">Semestral</option>
                  <option value="Anual">Anual</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
              </div>

              <div className="relative">
                <select
                  value={formData.periodicidadeJuros}
                  onChange={(e) => setFormData({ ...formData, periodicidadeJuros: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white appearance-none focus:outline-none focus:border-[#3482ff]"
                >
                  <option value="">Selecione a periodicidade</option>
                  <option value="Mensal">Mensal</option>
                  <option value="Trimestral">Trimestral</option>
                  <option value="Semestral">Semestral</option>
                  <option value="Anual">Anual</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 size-5 text-[#818181] pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="fixed bottom-0 right-0 left-[463px] h-[81px] border-t border-[#2e2e2e] bg-[#212121] flex items-center justify-between px-8">
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-4 bg-[#292929] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#3a3a3a] transition-colors"
          >
            Voltar
          </button>
          <button
            onClick={handleContinue}
            className="px-6 py-4 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#2668dd] transition-colors"
          >
            Continuar
          </button>
        </div>
      </div>
    </div>
  );
}
