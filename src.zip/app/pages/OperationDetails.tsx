import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { ChevronLeft, ChevronRight, Info, Download, ArrowRight, Bell, Calendar, FileText, Home, Building, Car, CheckCircle2, Users, Rocket } from "lucide-react";
import { Sidebar } from "../components/Sidebar";

export function OperationDetails() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState<"teaser" | "deck" | "dataroom">("teaser");

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-[14px] text-slate-500">
              <button onClick={() => navigate("/home")} className="hover:text-slate-950 dark:hover:text-white">
                <Home className="size-4" />
              </button>
              <ChevronRight className="size-4" />
              <button onClick={() => navigate("/operacoes")} className="hover:text-slate-950 dark:hover:text-white">
                Operações
              </button>
              <ChevronRight className="size-4" />
              <span className="text-slate-950 dark:text-white">Consulta de viabilidade</span>
              <ChevronRight className="size-4" />
              <span className="text-slate-950 dark:text-white font-medium">RB24001</span>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <svg className="size-5 text-slate-600 dark:text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <circle cx="12" cy="12" r="10" strokeWidth={2} />
                </svg>
              </button>

              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-400" />
                <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
              </button>

              <div className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-700">
                <div className="size-[40px] bg-[#2e61ff] rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-[14px]">BC</span>
                </div>
                <div>
                  <p className="text-[14px] font-semibold text-slate-950 dark:text-white">Bloxs Capital Partners LTDA</p>
                  <p className="text-[12px] text-slate-500">41.847.533/0001-90</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-[1400px] mx-auto p-8">
            {/* Informações Básicas */}
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 mb-6">
              <div className="flex items-center gap-2 mb-4">
                <Info className="size-5 text-slate-600 dark:text-slate-400" />
                <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white">Informações básicas</h2>
              </div>

              <button className="flex items-end gap-2 text-[12px] text-[#2e61ff] ml-auto">
                Ver perfil do Sell Side
                <ArrowRight className="size-3" />
              </button>

              <div className="flex items-start gap-4 mt-4">
                <div className="size-[64px] bg-slate-950 dark:bg-white rounded-full flex items-center justify-center">
                  <span className="text-white dark:text-slate-950 font-bold text-[24px]">A</span>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-[24px] font-semibold text-slate-950 dark:text-white">Insany Design</h3>
                    <span className="bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-[6px] text-[12px] font-medium text-slate-600 dark:text-slate-300">
                      Non-Deal Roadshow
                    </span>
                  </div>
                  <p className="text-[14px] text-slate-600 dark:text-slate-400 leading-relaxed max-w-3xl">
                    Somos um estúdio de design, tecnologia e inovação dedicado a potencializar a presença digital das marcas dos nossos clientes. 
                    Desenvolvemos soluções que alavancam e impulsionam métricas significativas.
                  </p>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 mb-6">
              <button
                onClick={() => setActiveTab("teaser")}
                className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors ${
                  activeTab === "teaser"
                    ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Teaser
              </button>
              <button
                onClick={() => setActiveTab("deck")}
                className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors ${
                  activeTab === "deck"
                    ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Investment Deck
              </button>
              <button
                onClick={() => setActiveTab("dataroom")}
                className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors ${
                  activeTab === "dataroom"
                    ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Data Room
              </button>

              <div className="flex-1" />

              <button className="flex items-center gap-2 px-4 py-2 bg-[#2e61ff] text-white rounded-[8px] text-[14px] font-medium hover:bg-[#1b41f5] transition-colors">
                Agendar conversa
              </button>
              <button className="px-4 py-2 bg-[#2e61ff] text-white rounded-[8px] text-[14px] font-medium hover:bg-[#1b41f5] transition-colors">
                Tenho interesse
              </button>
            </div>

            {/* Detalhes da operação */}
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 mb-6">
              <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-6">Detalhes da operação</h2>

              <div className="grid grid-cols-4 gap-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <svg className="size-4 text-[#2e61ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Volume</span>
                  </div>
                  <p className="text-[20px] font-semibold text-slate-950 dark:text-white">100 milhões</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="size-4 text-[#2e61ff]" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Prazo</span>
                  </div>
                  <p className="text-[20px] font-semibold text-slate-950 dark:text-white">320 meses</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <svg className="size-4 text-[#2e61ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Remuneração</span>
                  </div>
                  <p className="text-[20px] font-semibold text-slate-950 dark:text-white">IPCA + 18% a.a.</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="size-4 text-[#2e61ff]" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Perfil de Risco</span>
                  </div>
                  <p className="text-[20px] font-semibold text-slate-950 dark:text-white">High Yield</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="size-4 text-slate-500" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Setor</span>
                  </div>
                  <p className="text-[16px] font-medium text-slate-950 dark:text-white">Agronegócio</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="size-4 text-slate-500" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Segmento</span>
                  </div>
                  <p className="text-[16px] font-medium text-slate-950 dark:text-white">Produtor Rural</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="size-4 text-slate-500" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Finalidade</span>
                  </div>
                  <p className="text-[16px] font-medium text-slate-950 dark:text-white">Investimento na produção</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="size-4 text-slate-500" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Possui rating?</span>
                  </div>
                  <p className="text-[16px] font-medium text-slate-950 dark:text-white">Sim</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="size-4 text-slate-500" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Possíveis instrumentos</span>
                  </div>
                  <p className="text-[16px] font-medium text-slate-950 dark:text-white">CRA</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="size-4 text-slate-500" />
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Estágio</span>
                  </div>
                  <p className="text-[16px] font-medium text-slate-950 dark:text-white">SP, BA</p>
                </div>
              </div>
            </div>

            {/* Garantias */}
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 mb-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white">Garantias</h2>
                <span className="text-[12px] font-semibold text-orange-600 bg-orange-50 dark:bg-orange-950 px-3 py-1 rounded-[6px]">
                  145% de execução
                </span>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="bg-slate-50 dark:bg-slate-900 rounded-[12px] p-4 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 mb-3">
                    <FileText className="size-5 text-[#2e61ff]" />
                  </div>
                  <h3 className="text-[14px] font-semibold text-slate-950 dark:text-white mb-1">
                    Carteira de recebíveis
                  </h3>
                  <p className="text-[20px] font-bold text-slate-950 dark:text-white mb-1">R$ 30.000.000</p>
                  <span className="inline-block bg-[#2e61ff] text-white text-[10px] px-2 py-0.5 rounded-[4px]">
                    Imobilizado
                  </span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-900 rounded-[12px] p-4 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 mb-3">
                    <Home className="size-5 text-[#2e61ff]" />
                  </div>
                  <h3 className="text-[14px] font-semibold text-slate-950 dark:text-white mb-1">
                    Imóvel rural
                  </h3>
                  <p className="text-[20px] font-bold text-slate-950 dark:text-white mb-1">R$ 30.000.000</p>
                  <span className="inline-block bg-[#2e61ff] text-white text-[10px] px-2 py-0.5 rounded-[4px]">
                    Penhor
                  </span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-900 rounded-[12px] p-4 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 mb-3">
                    <Car className="size-5 text-[#2e61ff]" />
                  </div>
                  <h3 className="text-[14px] font-semibold text-slate-950 dark:text-white mb-1">
                    Veículos
                  </h3>
                  <p className="text-[20px] font-bold text-slate-950 dark:text-white mb-1">R$ 30.000.000</p>
                  <span className="text-[12px] text-slate-500">Não informado</span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-900 rounded-[12px] p-4 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 mb-3">
                    <Users className="size-5 text-[#2e61ff]" />
                  </div>
                  <h3 className="text-[14px] font-semibold text-slate-950 dark:text-white mb-1">
                    Aval dos sócios
                  </h3>
                  <p className="text-[20px] font-bold text-slate-950 dark:text-white mb-1">Não informado</p>
                </div>
              </div>
            </div>

            {/* Highlights */}
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 mb-6">
              <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-6">Highlights</h2>

              <div className="grid grid-cols-3 gap-6">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Building className="size-5 text-[#2e61ff]" />
                    <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white">Empresa</h3>
                  </div>
                  <p className="text-[14px] text-slate-600 dark:text-slate-400 leading-relaxed">
                    Um time de especialistas para guiar o seu negócio e chegar ao próximo nível.
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <svg className="size-5 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white">
                      Projeto
                      <span className="ml-2 text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-[4px]">
                        Projeção histórica auditada
                      </span>
                    </h3>
                  </div>
                  <p className="text-[14px] text-slate-600 dark:text-slate-400 leading-relaxed">
                    Sempre atualizados de temas útil e com foco total nos objetivos da negócio.
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Rocket className="size-5 text-[#2e61ff]" />
                    <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white">Operação</h3>
                  </div>
                  <p className="text-[14px] text-slate-600 dark:text-slate-400 leading-relaxed">
                    Tenha cases que se tornam os hábitos melhores em seus segmentos.
                  </p>
                </div>
              </div>
            </div>

            {/* Investment Deck */}
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 mb-6">
              <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-6">Investment deck</h2>

              <div className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-[16px] h-[480px] flex items-center justify-center">
                <div className="text-white text-[64px] font-bold tracking-wider">INSANY</div>

                <button className="absolute left-4 top-1/2 -translate-y-1/2 size-[40px] bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                  <ChevronLeft className="size-6 text-white" />
                </button>

                <button className="absolute right-4 top-1/2 -translate-y-1/2 size-[40px] bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                  <ChevronRight className="size-6 text-white" />
                </button>

                <button className="absolute top-4 right-4 size-[32px] bg-white/10 backdrop-blur-sm rounded-[8px] flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg className="size-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                  </svg>
                </button>

                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-4 text-white text-[12px]">
                  <span>01 / 40</span>
                  <div className="w-[200px] h-[2px] bg-white/30 rounded-full">
                    <div className="w-[10%] h-full bg-white rounded-full" />
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="hover:text-white/70">
                      <svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                      </svg>
                    </button>
                    <button className="hover:text-white/70">
                      <Download className="size-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Data Room */}
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white">Data room</h2>
                <button className="flex items-center gap-2 text-[14px] text-[#2e61ff] hover:text-[#1b41f5]">
                  Baixar tudo
                  <Download className="size-4" />
                </button>
              </div>

              <div className="grid grid-cols-4 gap-4">
                {[
                  "Cronograma físico-finace",
                  "CRM file",
                  "CV & Resume",
                  "Insany Deck Proposal",
                  "2005_Docs",
                  "2024_Docs",
                  "Monthly Report",
                  "Syllabus Sample",
                  "Download assets",
                  "Client Chain (2025)",
                  "Company list",
                  "Company list",
                ].map((fileName, index) => (
                  <button
                    key={index}
                    className="flex items-center gap-3 p-3 rounded-[12px] border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-left"
                  >
                    <div className="size-[32px] bg-blue-100 dark:bg-blue-950 rounded-[8px] flex items-center justify-center flex-shrink-0">
                      <FileText className="size-4 text-[#2e61ff]" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-medium text-slate-950 dark:text-white truncate">{fileName}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}