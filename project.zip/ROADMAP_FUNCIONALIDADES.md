# 🎯 BLOXS WORKSPACE V2 - ROADMAP DE FUNCIONALIDADES

**Data:** 18/02/2026  
**Status:** Em desenvolvimento organizado

---

## 📋 FUNCIONALIDADES PRINCIPAIS (Ordem de Implementação)

### ✅ 1. FUNCIONALIDADE DE COTAÇÃO (100% COMPLETO)
**Status:** ✅ Implementado  
**Rotas:** `/cotacao/*`

**Fluxo Completo:**
```
/cotacao/etapa-1 
  → Seleção de Soluções (3 opções)
  
/cotacao/etapa-2-estruturacao
  → Dados da Operação (formulário completo)
  
/cotacao/etapa-3
  → Informações Adicionais (textarea + link)
  
/cotacao/sucesso
  → Confirmação e próximos passos
```

**Arquivos Criados:**
- ✅ `/src/app/pages/QuotationStep1.tsx`
- ✅ `/src/app/pages/QuotationStep2Estruturacao.tsx`
- ✅ `/src/app/pages/QuotationStep3.tsx`
- ✅ `/src/app/pages/QuotationSuccess.tsx`

**Features:**
- ✅ Progress bar (Etapa 1 de 3, 2 de 3, 3 de 3)
- ✅ Sidebar fixa com branding e features
- ✅ Seleção múltipla de soluções (checkboxes)
- ✅ Formulário extenso com validações
- ✅ Inputs, selects, textareas
- ✅ Navegação entre etapas com state
- ✅ Tela de sucesso com radial gradient
- ✅ Dark mode (#212121, #292929)

---

### ⏳ 2. FUNCIONALIDADE CADASTRO (Parcialmente Implementado)
**Status:** 🟡 60% Completo  
**Rotas:** `/`, `/registro`, `/login`

**Já Implementado:**
- ✅ QuickRegister (Cadastro rápido com email)
- ✅ Login (Email + Google OAuth)
- ✅ GoogleOAuthButton (componente reutilizável)

**Pendente:**
- ⏳ Onboarding/Suitability para Sell-side
- ⏳ Onboarding/Suitability para Buy-side
- ⏳ Fluxo diferenciado por persona

**Arquivos Existentes:**
- `/src/app/pages/QuickRegister.tsx`
- `/src/app/pages/Login.tsx`
- `/src/app/components/GoogleOAuthButton.tsx`

---

### ⏳ 3. FUNCIONALIDADE CRIAÇÃO DO WORKSPACE (Parcialmente Implementado)
**Status:** 🟡 70% Completo  
**Rotas:** `/workspace/*`

**Já Implementado:**
- ✅ WorkspacePersonalization (Customização visual)
- ✅ DocumentUpload (Upload de documentos)
- ✅ Dealmatch (Página de match)
- ✅ WorkspaceSettingsV2 (Configurações completas)
  - ✅ Dados da empresa
  - ✅ Adicionar membros (com modals)
  - ✅ Gerenciar permissões
  - ✅ Solicitações de acesso

**Pendente:**
- ⏳ Rito de detalhes do Dealmatch para Buy-side
- ⏳ Fluxo de convite específico
- ⏳ Níveis de visualização customizados

**Arquivos Existentes:**
- `/src/app/pages/WorkspacePersonalization.tsx`
- `/src/app/pages/DocumentUpload.tsx`
- `/src/app/pages/Dealmatch.tsx`
- `/src/app/pages/WorkspaceSettingsV2.tsx`
- `/src/app/components/SuccessModal.tsx`
- `/src/app/components/ErrorModal.tsx`
- `/src/app/components/AddMemberModal.tsx`

---

### ⏳ 4. FUNCIONALIDADE DE OPERAÇÕES (Parcialmente Implementado)
**Status:** 🟡 50% Completo  
**Rotas:** `/operacoes/*`

**Já Implementado:**
- ✅ OperationsList (Listagem básica)
- ✅ OperationDetails (Detalhes de operação)
- ✅ OperationsManagement (Gerenciamento)

**Pendente:**
- ⏳ Todas as telas com Design System V2
- ⏳ Fluxo completo de criação de operação
- ⏳ Estados de liquidação real
- ⏳ Documentação RCVM 88
- ⏳ Nomenclatura comercial

**Arquivos Existentes:**
- `/src/app/pages/OperationsList.tsx`
- `/src/app/pages/OperationDetails.tsx`
- `/src/app/pages/OperationsManagement.tsx`

---

## 🔄 PRÓXIMAS ETAPAS

### **FASE 1: Completar Funcionalidades Base** (Prioridade Alta)

#### 1.1 Completar Cadastro
- [ ] Criar tela de Suitability Sell-side
- [ ] Criar tela de Suitability Buy-side
- [ ] Implementar lógica de direcionamento por persona
- [ ] Conectar com QuickRegister
- [ ] Validações de formulário

#### 1.2 Completar Workspace
- [ ] Implementar rito Dealmatch para Buy-side
- [ ] Criar fluxo de convite customizado
- [ ] Implementar níveis de permissão granulares
- [ ] Dashboard do workspace

#### 1.3 Completar Operações
- [ ] Redesign com V2 (todas as telas)
- [ ] Fluxo de criação completo
- [ ] Estados de liquidação
- [ ] Upload de documentos RCVM 88
- [ ] Timeline de operação

---

### **FASE 2: Funcionalidades Avançadas** (Enviar Designs)

Aguardando designs v1 para prototipação v2:

- [ ] **Gerenciamento** (telas v1 → v2)
- [ ] **Mercado Secundário** (telas v1 → v2)
- [ ] **Soluções** (telas v1 → v2)
- [ ] **Listar Operações** (telas v1 → v2)

---

## 📊 ESTRUTURA DE ROTAS ATUAL

```typescript
// AUTENTICAÇÃO
/ → QuickRegister
/registro → QuickRegister
/login → Login

// HOME
/home → Home (Dashboard)

// ONBOARDING
/onboarding/documentos → DocumentUpload
/onboarding/personalizar → WorkspacePersonalization

// WORKSPACE
/workspace/dealmatch → Dealmatch
/workspace/configuracoes → WorkspaceSettings (v1)
/workspace/configuracoes-v2 → WorkspaceSettingsV2 (v2)

// COTAÇÃO ✅ COMPLETO
/cotacao/etapa-1 → QuotationStep1
/cotacao/etapa-2-estruturacao → QuotationStep2Estruturacao
/cotacao/etapa-3 → QuotationStep3
/cotacao/sucesso → QuotationSuccess

// OPERAÇÕES
/operacoes → OperationsList
/operacoes/:id → OperationDetails
/operacoes/gerenciar → OperationsManagement

// SIDEBAR LINKS
/carteira → Home
/solucoes → Home
/tools → Home
/comunidade → Home
/ajuda → Home
```

---

## 🎨 DESIGN SYSTEM V2

### **Cores Principais:**
```css
Background: #212121
Cards: #292929
Input BG: #313131
Borders: #434343, #515151
Primary: #3482FF
Text: #FFFFFF
Muted: #A4A4A4
Placeholder: #818181
Yellow: #FFC709
Green: #01BF73
Red: #C50000
```

### **Tipografia:**
```css
Font Family: Poppins
Headings: 24px, 32px (font-semibold/bold)
Body: 14px, 16px, 18px (font-regular/medium)
Labels: 10px, 12px (font-regular)
```

### **Componentes Padrão:**
```css
Inputs: h-[48px], rounded-[6px], border-[#818181]
Buttons: px-6 py-4, rounded-[8px], font-semibold
Cards: rounded-[8px], border-[#434343]
Modals: bg-[#161616], rounded-[8px]
Progress: h-2, rounded-[20px]
```

---

## 📈 PROGRESSO GERAL

```
✅ Cotação:          100% █████████████████████
🟡 Cadastro:          60% ████████████░░░░░░░░░
🟡 Workspace:         70% ██████████████░░░░░░░
🟡 Operações:         50% ██████████░░░░░░░░░░░
⏳ Gerenciamento:      0% ░░░░░░░░░░░░░░░░░░░░░
⏳ Mercado Secundário: 0% ░░░░░░░░░░░░░░░░░░░░░
⏳ Soluções:           0% ░░░░░░░░░░░░░░░░░░░░░
⏳ Listar Operações:   0% ░░░░░░░░░░░░░░░░░░░░░

Total: ~45% Completo
```

---

## 🔧 COMPONENTES REUTILIZÁVEIS

### **Modals:**
- ✅ SuccessModal (confirmações)
- ✅ ErrorModal (erros de validação)
- ✅ AddMemberModal (adicionar membros)

### **Forms:**
- ✅ GoogleOAuthButton (login social)
- ✅ Checkbox customizado
- ✅ Select com ChevronDown
- ✅ Input com ícones
- ✅ Textarea

### **Navigation:**
- ✅ Sidebar (menu principal)
- ✅ Progress bar (etapas)
- ✅ Breadcrumbs

### **Layout:**
- ✅ Split screen (sidebar + content)
- ✅ Gradient backgrounds
- ✅ Radial effects

---

## 🚀 COMO TESTAR

### **Funcionalidade de Cotação:**
```bash
# Etapa 1: Seleção
http://localhost:5173/cotacao/etapa-1

# Etapa 2: Dados
http://localhost:5173/cotacao/etapa-2-estruturacao

# Etapa 3: Adicionais
http://localhost:5173/cotacao/etapa-3

# Sucesso
http://localhost:5173/cotacao/sucesso
```

### **Fluxo Completo de Teste:**
1. Acesse `/cotacao/etapa-1`
2. Selecione "Distribuição de ativo estruturado"
3. Clique [Continuar]
4. Preencha formulário da Etapa 2
5. Clique [Continuar]
6. Preencha informações adicionais
7. Clique [Enviar]
8. Veja tela de sucesso

---

## 📋 CHECKLIST DE IMPLEMENTAÇÃO

### **Cotação (100%):**
- [x] Etapa 1 - Seleção de soluções
- [x] Etapa 2 - Dados da operação
- [x] Etapa 3 - Informações adicionais
- [x] Tela de sucesso
- [x] Navegação entre etapas
- [x] State management
- [x] Validações básicas
- [x] Design fiel ao Figma

### **Cadastro (60%):**
- [x] QuickRegister
- [x] Login
- [x] Google OAuth
- [ ] Suitability Sell-side
- [ ] Suitability Buy-side
- [ ] Direcionamento por persona

### **Workspace (70%):**
- [x] Personalização
- [x] Upload de documentos
- [x] Configurações v2
- [x] Adicionar membros
- [ ] Dealmatch Buy-side completo
- [ ] Dashboard do workspace

### **Operações (50%):**
- [x] Listagem básica
- [x] Detalhes de operação
- [x] Gerenciamento básico
- [ ] Design System v2
- [ ] Fluxo completo de criação
- [ ] Estados de liquidação

---

## 🎯 PRÓXIMA SPRINT

**Objetivo:** Completar Cadastro e Workspace

1. **Cadastro:**
   - Criar Suitability Sell-side
   - Criar Suitability Buy-side
   - Implementar lógica de direcionamento

2. **Workspace:**
   - Completar Dealmatch para Buy-side
   - Criar dashboard do workspace
   - Implementar permissões granulares

3. **Operações:**
   - Aplicar Design System v2
   - Criar fluxo de criação completo

---

**Documentado por:** Figma Make Assistant  
**Versão:** 2.0  
**Data:** 18/02/2026  
**Status:** ✅ Cotação Completa | 🟡 Outras em Andamento
