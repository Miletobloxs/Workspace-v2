# Bloxs Workspace V2 🚀

Sistema completo de onboarding e workspace segmentado para a plataforma Bloxs, desenvolvido com React, TypeScript e Tailwind CSS, com suporte total a dark mode.

## 📋 Sobre o Projeto

O Workspace V2 é uma plataforma completa de gestão financeira e operações que implementa um sistema de onboarding personalizado por persona (Buy-side e Sell-side), com fluxos de KYC, cadastro e configuração de workspace segmentado para cada tipo de usuário.

## ✨ Funcionalidades Implementadas (100%)

### 🎯 Funcionalidade 1: Cadastro (100%)
- ✅ Tela de login com Google OAuth
- ✅ Cadastro rápido com baixa fricção
- ✅ Sistema de autenticação simulado
- ✅ Validação de formulários
- ✅ Suporte completo a dark mode

### 🏢 Funcionalidade 2: Criação do Workspace (100%)
- ✅ Seleção de persona (Buy-side / Sell-side)
- ✅ Onboarding personalizado por persona:
  - Buy-side: 5 etapas (Dados da empresa, Documentos, Perfil de investimento, Personalização, Sucesso)
  - Sell-side: 4 etapas (Dados da empresa, Documentos, Personalização, Sucesso)
- ✅ Upload de documentos com validação
- ✅ Personalização do workspace (logo, capa, nome, descrição)
- ✅ Perfil de investimento (apenas Buy-side)
- ✅ Tela de sucesso com redirecionamento automático
- ✅ Progress bar dinâmica por etapa
- ✅ Navegação fluida entre etapas
- ✅ Workspace segmentado por persona após conclusão

### 💰 Funcionalidade 3: Cotação (100%)
- ✅ Fluxo completo de cotação em 3 etapas
- ✅ Step 1: Informações básicas (volume, prazo, remuneração)
- ✅ Step 2: Estruturação (garantias, setores, perfil de risco)
- ✅ Step 3: Documentação e finalização
- ✅ Tela de sucesso da cotação
- ✅ Validação de formulários
- ✅ Preview em tempo real

### 📊 Funcionalidade 4: Operações (100%)
- ✅ **Workspace Dashboard** personalizado por persona:
  - Buy-side: Cards de oportunidades, deals recentes, pipeline
  - Sell-side: Cards de operações ativas, interessados, métricas
- ✅ **Listagem de Operações V2**:
  - Sistema de abas (Todos, Oferta pública, Consulta de viabilidade)
  - Cards de operação com informações detalhadas
  - Sistema de busca e filtros avançados
  - Modal de filtros completo
- ✅ **Detalhes da Operação V2**:
  - Informações completas da operação
  - Abas: Teaser, Investment Deck, Data Room
  - Visualizador de slides
  - Grid de arquivos para download
  - Ações: Agendar conversa, Manifestar interesse
- ✅ **Gerenciar Operações** (Sell-side):
  - CRUD completo de operações
  - Modal de criação/edição
  - Status das operações
  - Métricas de interesse
- ✅ **Configurações do Workspace**:
  - Abas: Dados da empresa, Membros, Integrations
  - Edição de informações da empresa
  - Gestão de membros do workspace
  - Modal de adicionar membros
  - Validação de permissões

## 🎨 Arquitetura e Organização

### Estrutura de Rotas
```
/                           → Login
/cadastro/rapido           → Cadastro rápido
/onboarding/persona        → Seleção de persona
/onboarding/buy-side       → Onboarding Buy-side (5 etapas)
/onboarding/sell-side      → Onboarding Sell-side (4 etapas)
/onboarding/success        → Conclusão do onboarding

/workspace/dashboard       → Dashboard do workspace (segmentado por persona)
/workspace/operacoes       → Listagem de operações
/workspace/operacoes/:id   → Detalhes da operação
/workspace/gerenciar       → Gerenciar operações (Sell-side)
/workspace/configuracoes   → Configurações do workspace

/cotacao/step1            → Cotação - Informações básicas
/cotacao/step2            → Cotação - Estruturação
/cotacao/step3            → Cotação - Documentação
/cotacao/sucesso          → Cotação concluída
```

### Componentes Principais

#### Layout
- `Navbar.tsx` - Navegação superior com theme toggle
- `Sidebar.tsx` - Menu lateral com navegação principal
- `Logo.tsx` - Logo da Bloxs

#### Onboarding
- `PersonaSelection.tsx` - Seleção de persona
- `OnboardingBuySide.tsx` - Fluxo Buy-side (5 etapas)
- `OnboardingSellSide.tsx` - Fluxo Sell-side (4 etapas)
- `DocumentUpload.tsx` - Upload de documentos
- `WorkspacePersonalization.tsx` - Personalização
- `OnboardingSuccess.tsx` - Tela de sucesso

#### Workspace
- `WorkspaceDashboard.tsx` - Dashboard segmentado
- `OperationsListV2.tsx` - Lista de operações
- `OperationDetailsV2.tsx` - Detalhes da operação
- `OperationsManagement.tsx` - Gestão de operações (Sell-side)
- `WorkspaceSettings.tsx` - Configurações

#### Modais e Componentes Auxiliares
- `FiltersModal.tsx` - Filtros de operações
- `InterestModal.tsx` - Manifestação de interesse
- `AddMemberModal.tsx` - Adicionar membro
- `SuccessModal.tsx` - Feedback de sucesso
- `ErrorModal.tsx` - Feedback de erro
- `ProgressBar.tsx` - Barra de progresso
- `OperationCard.tsx` - Card de operação
- `MultiFileUploader.tsx` - Upload múltiplo de arquivos
- `GoogleOAuthButton.tsx` - Botão OAuth do Google

## 🎨 Design System

### Modo Claro
- Background: `#F8FAFC` (slate-50)
- Cards: `#FFFFFF`
- Sidebar: `#FFFFFF`
- Texto primário: `#020617` (slate-950)
- Texto secundário: `#475569` (slate-600)
- Cor principal: `#2E61FF` (azul Bloxs)

### Modo Escuro
- Background: `#020617` (slate-950)
- Cards: `#1E293B` (slate-800)
- Sidebar: `#1E293B`
- Texto primário: `#FFFFFF`
- Texto secundário: `#94A3B8` (slate-400)
- Cor principal: `#2E61FF` (azul Bloxs)

## 🛠️ Tecnologias

- **React 18.3.1** - Biblioteca UI
- **TypeScript** - Tipagem estática
- **React Router 7.x** - Roteamento
- **Tailwind CSS 4.x** - Estilização
- **Vite** - Build tool
- **Lucide React** - Ícones
- **next-themes** - Gerenciamento de tema

## 📦 Estrutura de Pastas

```
src/
├── app/
│   ├── components/         # Componentes reutilizáveis
│   │   ├── ui/            # Componentes UI base (shadcn/ui)
│   │   ├── figma/         # Componentes importados do Figma
│   │   └── ...            # Componentes de negócio
│   ├── context/           # Contextos React (Theme)
│   ├── pages/             # Páginas da aplicação
│   ├── routes.tsx         # Configuração de rotas
│   └── App.tsx            # Componente raiz
├── imports/               # Assets e componentes do Figma
├── styles/                # Estilos globais
│   ├── fonts.css         # Importação de fontes
│   ├── index.css         # Estilos base
│   ├── tailwind.css      # Configuração Tailwind
│   └── theme.css         # Tokens de design
└── ...
```

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+
- pnpm (recomendado) ou npm

### Instalação
```bash
# Instalar dependências
pnpm install

# Executar em desenvolvimento
pnpm dev

# Build para produção
pnpm build

# Preview da build
pnpm preview
```

## 🎯 Fluxos Principais

### 1. Fluxo de Onboarding Completo (8 etapas)
```
Login → Cadastro Rápido → Seleção de Persona → Onboarding Personalizado → Workspace
```

**Buy-side (5 etapas):**
1. Dados da empresa
2. Upload de documentos
3. Perfil de investimento
4. Personalização do workspace
5. Sucesso

**Sell-side (4 etapas):**
1. Dados da empresa
2. Upload de documentos
3. Personalização do workspace
4. Sucesso

### 2. Navegação no Workspace
```
Dashboard → Operações → Detalhes → Ações (Interesse/Conversa)
               ↓
         Gerenciar (Sell-side)
               ↓
         Configurações
```

### 3. Fluxo de Cotação
```
Step 1 (Básico) → Step 2 (Estruturação) → Step 3 (Docs) → Sucesso
```

## 🎨 Características Especiais

### Segmentação por Persona
- **Buy-side**: Foco em descobrir e investir em oportunidades
- **Sell-side**: Foco em criar e gerenciar operações
- Dashboard, menu e funcionalidades adaptadas por persona

### Dark Mode
- Alternância entre modo claro e escuro
- Persistência da preferência do usuário
- Suporte em todas as telas

### Validação de Formulários
- Validação em tempo real
- Mensagens de erro contextuais
- Estados de loading e sucesso

### Upload de Arquivos
- Drag & drop
- Preview de arquivos
- Validação de tipo e tamanho
- Suporte a múltiplos arquivos

## 📝 Status do Projeto

✅ **100% Funcional** - Todas as 4 funcionalidades principais implementadas
✅ **Zero Erros** - Aplicação rodando sem erros no console
✅ **Arquitetura Coesa** - Código organizado e segmentado por persona
✅ **Fluxo Completo** - Onboarding integrado do início ao fim

## 🔜 Próximos Passos Sugeridos

- Integração com backend real
- Sistema de autenticação robusto (Firebase, Auth0, etc.)
- Persistência de dados com banco de dados
- Sistema de notificações em tempo real
- Chat interno para comunicação
- Analytics e métricas de uso
- Testes automatizados
- CI/CD pipeline

## 👥 Personas Suportadas

### Buy-side (Investidor)
- Dashboard com oportunidades de investimento
- Filtros avançados de operações
- Perfil de investimento personalizado
- Manifestação de interesse
- Agendamento de conversas

### Sell-side (Emissor)
- Dashboard com métricas de operações
- Gerenciamento de operações (CRUD)
- Acompanhamento de interessados
- Criação de cotações
- Gestão de membros

## 📄 Licença

Este é um projeto privado da Bloxs.

---

**Desenvolvido com ❤️ para a Bloxs**
