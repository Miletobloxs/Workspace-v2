# 🚀 Deploy Rápido - Workspace V2

## Comandos para copiar e colar no terminal:

### 1️⃣ Primeiro Deploy (Execute uma vez)

```bash
# Dar permissão ao script
chmod +x deploy.sh

# Executar o deploy
./deploy.sh
```

### 2️⃣ Ou faça manualmente:

```bash
# Inicializar Git (se necessário)
git init

# Adicionar remote
git remote add origin https://github.com/Miletobloxs/Workspace-v2.git

# Adicionar arquivos
git add .

# Fazer commit
git commit -m "feat: implementação completa do Workspace V2"

# Configurar branch
git branch -M main

# Push para GitHub
git push -u origin main
```

### 3️⃣ Próximos commits (após primeiro deploy):

```bash
git add .
git commit -m "feat: sua mensagem aqui"
git push
```

---

## 🔑 Autenticação

Quando solicitar credenciais:
- **Username:** Miletobloxs
- **Password:** Use seu Personal Access Token

**Criar token:** https://github.com/settings/tokens

---

## ✅ Verificar deploy

Acesse: **https://github.com/Miletobloxs/Workspace-v2**

---

## ⚡ Script Automático (Recomendado)

O arquivo `deploy.sh` faz tudo automaticamente:

```bash
chmod +x deploy.sh && ./deploy.sh
```

---

**📦 Arquivos preparados:**
- ✅ `.gitignore` - Ignora node_modules e arquivos desnecessários
- ✅ `README.md` - Documentação completa do projeto
- ✅ `deploy.sh` - Script de deploy automático
- ✅ `DEPLOY_GITHUB.md` - Guia detalhado em português
- ✅ `COMANDOS_RAPIDOS.md` - Este arquivo com comandos rápidos
