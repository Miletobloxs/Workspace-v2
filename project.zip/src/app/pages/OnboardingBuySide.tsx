import { useState } from "react";
import { useNavigate } from "react-router";
import { Check } from "lucide-react";

export function OnboardingBuySide() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    // Step 1: Perfil do Investidor
    tipoInvestidor: "",
    volumeInvestimento: "",
    experienciaMercado: "",
    certificacoes: [] as string[],
    
    // Step 2: Estratégia de Investimento
    objetivoInvestimento: "",
    prazoInvestimento: "",
    toleranciaRisco: "",
    setorPreferencia: [] as string[],
    
    // Step 3: Preferências
    tiposAtivo: [] as string[],
    ticketMinimo: "",
    ticketMaximo: "",
    diversificacao: "",
  });

  const handleContinue = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Salvar dados do onboarding
      localStorage.setItem("onboardingBuySideData", JSON.stringify(formData));
      localStorage.setItem("onboardingStep", "buy-side-completed");
      
      // Finalizar onboarding e ir para personalização do workspace
      navigate("/onboarding/personalizar");
    }
  };

  return (
    <div className="min-h-screen bg-[#212121] flex">
      {/* Left Sidebar */}
      <div className="w-[463px] bg-[#292929] relative overflow-hidden">
        <div className="absolute top-[-74px] left-[-257px] w-[530px] h-[361px] pointer-events-none">
          <div className="w-full h-full opacity-30 blur-[94.5px]">
            <div className="w-full h-full bg-gradient-to-r from-[#3482ff] to-transparent rotate-[145deg]" />
          </div>
        </div>

        <div className="absolute top-[104px] left-[32px]">
          <svg width="104" height="24" viewBox="0 0 104 24" fill="none">
            <text x="0" y="18" fill="white" fontSize="20" fontWeight="600" fontFamily="Poppins">
              bloxs
            </text>
          </svg>
        </div>

        <div className="absolute top-[214px] left-[32px] right-[32px]">
          <h2 className="text-[28px] font-semibold text-white leading-normal mb-6">
            Vamos conhecer seu perfil de investimento
          </h2>
          <p className="text-[16px] text-[#a4a4a4] leading-relaxed mb-12">
            Com base nas suas preferências, vamos conectar você com as melhores oportunidades do Mercado de Capitais.
          </p>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className={`size-[40px] rounded-[8px] flex items-center justify-center flex-shrink-0 ${
                step >= 1 ? "bg-[#3482ff]" : "bg-[#242320] border border-[rgba(52,130,255,0.2)]"
              }`}>
                {step > 1 ? <Check className="size-5 text-white" /> : <span className="text-white font-semibold">1</span>}
              </div>
              <div>
                <h3 className="text-[16px] font-semibold text-white mb-1">Perfil do investidor</h3>
                <p className="text-[14px] text-[#a4a4a4]">Tipo, volume e experiência no mercado</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className={`size-[40px] rounded-[8px] flex items-center justify-center flex-shrink-0 ${
                step >= 2 ? "bg-[#3482ff]" : "bg-[#242320] border border-[rgba(52,130,255,0.2)]"
              }`}>
                {step > 2 ? <Check className="size-5 text-white" /> : <span className="text-white font-semibold">2</span>}
              </div>
              <div>
                <h3 className="text-[16px] font-semibold text-white mb-1">Estratégia de investimento</h3>
                <p className="text-[14px] text-[#a4a4a4]">Objetivos, prazos e tolerância a risco</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className={`size-[40px] rounded-[8px] flex items-center justify-center flex-shrink-0 ${
                step >= 3 ? "bg-[#3482ff]" : "bg-[#242320] border border-[rgba(52,130,255,0.2)]"
              }`}>
                <span className="text-white font-semibold">3</span>
              </div>
              <div>
                <h3 className="text-[16px] font-semibold text-white mb-1">Preferências de alocação</h3>
                <p className="text-[14px] text-[#a4a4a4]">Tipos de ativos e tickets de investimento</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative overflow-y-auto">
        <div className="absolute top-[80px] left-[32px] w-[216px]">
          <p className="text-[12px] text-white mb-2">Etapa {step} de 3</p>
          <div className="h-2 bg-[#292929] rounded-[20px] overflow-hidden">
            <div 
              className="h-full bg-[#3482ff] rounded-[20px] transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1 */}
        {step === 1 && (
          <div className="absolute top-[138px] left-[32px] right-[32px]">
            <h1 className="text-[24px] font-bold text-white leading-[48px] mb-8">
              Qual o seu perfil como investidor?
            </h1>

            <div className="space-y-6 max-w-[600px]">
              <div>
                <label className="block text-[14px] text-white mb-2">Tipo de investidor</label>
                <select
                  value={formData.tipoInvestidor}
                  onChange={(e) => setFormData({ ...formData, tipoInvestidor: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="pessoa-fisica">Pessoa Física</option>
                  <option value="investidor-qualificado">Investidor Qualificado</option>
                  <option value="investidor-profissional">Investidor Profissional</option>
                  <option value="family-office">Family Office</option>
                  <option value="fundo-investimento">Fundo de Investimento</option>
                  <option value="instituicional">Institucional</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Volume aproximado para investimento</label>
                <select
                  value={formData.volumeInvestimento}
                  onChange={(e) => setFormData({ ...formData, volumeInvestimento: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="ate-1m">Até R$ 1 milhão</option>
                  <option value="1m-5m">R$ 1M - R$ 5M</option>
                  <option value="5m-10m">R$ 5M - R$ 10M</option>
                  <option value="10m-50m">R$ 10M - R$ 50M</option>
                  <option value="acima-50m">Acima de R$ 50M</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Experiência no Mercado de Capitais</label>
                <select
                  value={formData.experienciaMercado}
                  onChange={(e) => setFormData({ ...formData, experienciaMercado: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="iniciante">Iniciante (menos de 1 ano)</option>
                  <option value="intermediario">Intermediário (1-3 anos)</option>
                  <option value="experiente">Experiente (3-5 anos)</option>
                  <option value="avancado">Avançado (5+ anos)</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Certificações (opcional)</label>
                <div className="space-y-3">
                  {[
                    { id: "cga", label: "CGA - Certificação de Gestores ANBIMA" },
                    { id: "cfa", label: "CFA - Chartered Financial Analyst" },
                    { id: "cnpi", label: "CNPI - Certificado Nacional de Profissionais de Investimento" },
                  ].map((cert) => (
                    <button
                      key={cert.id}
                      onClick={() => {
                        const newCerts = formData.certificacoes.includes(cert.id)
                          ? formData.certificacoes.filter(c => c !== cert.id)
                          : [...formData.certificacoes, cert.id];
                        setFormData({ ...formData, certificacoes: newCerts });
                      }}
                      className={`w-full h-[48px] px-4 rounded-[6px] border text-left font-medium text-[14px] transition-all flex items-center gap-3 ${
                        formData.certificacoes.includes(cert.id)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      <div className={`size-5 rounded border-2 flex items-center justify-center ${
                        formData.certificacoes.includes(cert.id)
                          ? "border-[#3482ff] bg-[#3482ff]"
                          : "border-[#818181]"
                      }`}>
                        {formData.certificacoes.includes(cert.id) && <Check className="size-3 text-white" />}
                      </div>
                      {cert.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <div className="absolute top-[138px] left-[32px] right-[32px]">
            <h1 className="text-[24px] font-bold text-white leading-[48px] mb-8">
              Qual a sua estratégia de investimento?
            </h1>

            <div className="space-y-6 max-w-[600px]">
              <div>
                <label className="block text-[14px] text-white mb-2">Objetivo principal</label>
                <select
                  value={formData.objetivoInvestimento}
                  onChange={(e) => setFormData({ ...formData, objetivoInvestimento: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="renda-passiva">Geração de renda passiva</option>
                  <option value="valorizacao">Valorização do capital</option>
                  <option value="diversificacao">Diversificação de portfólio</option>
                  <option value="preservacao">Preservação de patrimônio</option>
                  <option value="crescimento">Crescimento agressivo</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Prazo de investimento</label>
                <select
                  value={formData.prazoInvestimento}
                  onChange={(e) => setFormData({ ...formData, prazoInvestimento: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="curto">Curto prazo (até 2 anos)</option>
                  <option value="medio">Médio prazo (2-5 anos)</option>
                  <option value="longo">Longo prazo (5-10 anos)</option>
                  <option value="muito-longo">Muito longo prazo (10+ anos)</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Tolerância a risco</label>
                <div className="space-y-3">
                  {[
                    { id: "conservador", label: "Conservador", desc: "Prioriza segurança e previsibilidade" },
                    { id: "moderado", label: "Moderado", desc: "Equilibra segurança e rentabilidade" },
                    { id: "agressivo", label: "Agressivo", desc: "Busca máxima rentabilidade" },
                  ].map((perfil) => (
                    <button
                      key={perfil.id}
                      onClick={() => setFormData({ ...formData, toleranciaRisco: perfil.id })}
                      className={`w-full min-h-[60px] px-4 py-3 rounded-[6px] border text-left transition-all ${
                        formData.toleranciaRisco === perfil.id
                          ? "border-[#3482ff] bg-[#3482ff]/10"
                          : "border-[#818181] hover:border-[#3482ff]/50"
                      }`}
                    >
                      <div className="font-semibold text-[14px] text-white mb-1">{perfil.label}</div>
                      <div className="text-[12px] text-[#a4a4a4]">{perfil.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Setores de preferência (opcional)</label>
                <div className="space-y-2">
                  {["Agronegócio", "Imobiliário", "Infraestrutura", "Tecnologia", "Varejo"].map((setor) => (
                    <button
                      key={setor}
                      onClick={() => {
                        const newSetores = formData.setorPreferencia.includes(setor)
                          ? formData.setorPreferencia.filter(s => s !== setor)
                          : [...formData.setorPreferencia, setor];
                        setFormData({ ...formData, setorPreferencia: newSetores });
                      }}
                      className={`w-full h-[40px] px-4 rounded-[6px] border text-left font-medium text-[14px] transition-all flex items-center gap-3 ${
                        formData.setorPreferencia.includes(setor)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      <div className={`size-4 rounded border-2 flex items-center justify-center ${
                        formData.setorPreferencia.includes(setor)
                          ? "border-[#3482ff] bg-[#3482ff]"
                          : "border-[#818181]"
                      }`}>
                        {formData.setorPreferencia.includes(setor) && <Check className="size-2.5 text-white" />}
                      </div>
                      {setor}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 3 */}
        {step === 3 && (
          <div className="absolute top-[138px] left-[32px] right-[32px]">
            <h1 className="text-[24px] font-bold text-white leading-[48px] mb-8">
              Preferências de alocação
            </h1>

            <div className="space-y-6 max-w-[600px]">
              <div>
                <label className="block text-[14px] text-white mb-2">Tipos de ativos de interesse</label>
                <div className="space-y-3">
                  {[
                    { id: "cri", label: "CRI - Certificado de Recebíveis Imobiliários" },
                    { id: "cra", label: "CRA - Certificado de Recebíveis do Agronegócio" },
                    { id: "debenture", label: "Debêntures" },
                    { id: "fidc", label: "FIDC - Fundo de Investimento em Direitos Creditórios" },
                    { id: "fii", label: "FII - Fundos Imobiliários" },
                  ].map((tipo) => (
                    <button
                      key={tipo.id}
                      onClick={() => {
                        const newTipos = formData.tiposAtivo.includes(tipo.id)
                          ? formData.tiposAtivo.filter(t => t !== tipo.id)
                          : [...formData.tiposAtivo, tipo.id];
                        setFormData({ ...formData, tiposAtivo: newTipos });
                      }}
                      className={`w-full h-[48px] px-4 rounded-[6px] border text-left font-medium text-[14px] transition-all flex items-center gap-3 ${
                        formData.tiposAtivo.includes(tipo.id)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      <div className={`size-5 rounded border-2 flex items-center justify-center ${
                        formData.tiposAtivo.includes(tipo.id)
                          ? "border-[#3482ff] bg-[#3482ff]"
                          : "border-[#818181]"
                      }`}>
                        {formData.tiposAtivo.includes(tipo.id) && <Check className="size-3 text-white" />}
                      </div>
                      {tipo.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[14px] text-white mb-2">Ticket mínimo</label>
                  <input
                    type="text"
                    placeholder="Ex: R$ 100.000"
                    value={formData.ticketMinimo}
                    onChange={(e) => setFormData({ ...formData, ticketMinimo: e.target.value })}
                    className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
                  />
                </div>

                <div>
                  <label className="block text-[14px] text-white mb-2">Ticket máximo</label>
                  <input
                    type="text"
                    placeholder="Ex: R$ 5.000.000"
                    value={formData.ticketMaximo}
                    onChange={(e) => setFormData({ ...formData, ticketMaximo: e.target.value })}
                    className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Interesse em diversificação</label>
                <select
                  value={formData.diversificacao}
                  onChange={(e) => setFormData({ ...formData, diversificacao: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="concentrado">Concentrado (1-3 ativos)</option>
                  <option value="moderado">Moderado (4-8 ativos)</option>
                  <option value="diversificado">Diversificado (9-15 ativos)</option>
                  <option value="muito-diversificado">Muito diversificado (15+ ativos)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="fixed bottom-0 right-0 left-[463px] h-[81px] border-t border-[#2e2e2e] bg-[#212121] flex items-center justify-between px-8">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="px-6 py-4 bg-[#292929] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#3a3a3a] transition-colors"
            >
              Voltar
            </button>
          )}
          <div className="ml-auto">
            <button
              onClick={handleContinue}
              className="px-6 py-4 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#2668dd] transition-colors"
            >
              {step === 3 ? "Finalizar" : "Continuar"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}