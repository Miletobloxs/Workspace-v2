import { useState } from "react";
import { useNavigate } from "react-router";
import { Check, Loader2, Building2, MapPin, Briefcase } from "lucide-react";
import { GoogleOAuthButton } from "../components/GoogleOAuthButton";

export function QuickRegister() {
  const navigate = useNavigate();
  const [step, setStep] = useState<"email" | "cnpj" | "loading" | "success">("email");
  const [email, setEmail] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [loading, setLoading] = useState(false);
  const [companyData, setCompanyData] = useState<any>(null);

  // Formatar CNPJ: 00.000.000/0000-00
  const formatCNPJ = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 14) {
      return numbers
        .replace(/^(\d{2})(\d)/, "$1.$2")
        .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
        .replace(/\.(\d{3})(\d)/, ".$1/$2")
        .replace(/(\d{4})(\d)/, "$1-$2");
    }
    return value;
  };

  // Consultar CNPJ na ReceitaWS (API pública gratuita)
  const consultarCNPJ = async (cnpjValue: string) => {
    setLoading(true);
    const cnpjNumbers = cnpjValue.replace(/\D/g, "");

    try {
      // Simular consulta (em produção, usar API real)
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Mock de dados da Receita Federal
      const mockData = {
        cnpj: cnpjNumbers,
        razao_social: "BLOXS CAPITAL PARTNERS LTDA",
        nome_fantasia: "Bloxs Capital",
        cnae_fiscal: "6499-9/99",
        cnae_fiscal_descricao: "Outras atividades de serviços financeiros",
        logradouro: "AV BRIGADEIRO FARIA LIMA",
        numero: "2277",
        complemento: "CONJUNTO 801",
        bairro: "JARDIM PAULISTANO",
        municipio: "SAO PAULO",
        uf: "SP",
        cep: "01452-000",
        situacao: "ATIVA",
        data_situacao: "01/10/2020",
      };

      setCompanyData(mockData);
      setStep("success");

      // Enviar para Hubspot (webhook)
      await sendToHubspot({
        email,
        cnpj: cnpjNumbers,
        company_name: mockData.razao_social,
        company_status: mockData.situacao,
      });
    } catch (error) {
      console.error("Erro ao consultar CNPJ:", error);
    } finally {
      setLoading(false);
    }
  };

  // Enviar lead para Hubspot
  const sendToHubspot = async (data: any) => {
    // Mock de integração com Hubspot
    console.log("📤 Enviando para Hubspot:", data);

    // Em produção:
    // await fetch('https://api.hubapi.com/crm/v3/objects/contacts', {
    //   method: 'POST',
    //   headers: {
    //     'Authorization': `Bearer ${HUBSPOT_API_KEY}`,
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({ properties: data }),
    // });

    return new Promise((resolve) => setTimeout(resolve, 500));
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setStep("cnpj");
    }
  };

  const handleCNPJSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cnpj.replace(/\D/g, "").length === 14) {
      setStep("loading");
      consultarCNPJ(cnpj);
    }
  };

  const handleContinue = async () => {
    // Salvar dados no localStorage
    localStorage.setItem("userEmail", email);
    localStorage.setItem("userCNPJ", cnpj.replace(/\D/g, ""));
    localStorage.setItem("companyData", JSON.stringify(companyData));
    localStorage.setItem("onboardingStep", "company-confirmed");
    
    // Redirecionar para seleção de persona
    navigate("/onboarding/persona");
  };

  const handleGoogleSuccess = (user: any) => {
    console.log("✅ Google signup success:", user);
    // Verificar se é novo usuário ou já existe
    // Se novo: ir para CNPJ
    // Se existe: ir direto para /home
    setEmail(user.email);
    setStep("cnpj");
  };

  const handleGoogleError = (error: any) => {
    console.error("❌ Google signup error:", error);
    alert("Erro ao cadastrar com Google. Tente novamente.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2e61ff] via-[#1b41f5] to-[#0033cc] flex items-center justify-center p-4">
      <div className="w-full max-w-[480px]">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-4">
            <div className="size-8 bg-white rounded-full flex items-center justify-center">
              <span className="text-[#2e61ff] font-bold text-sm">B</span>
            </div>
            <span className="text-white font-semibold text-lg">Bloxs</span>
          </div>
          <h1 className="text-white text-[32px] font-bold mb-2">
            Crie sua conta em 30 segundos
          </h1>
          <p className="text-white/80 text-[16px]">
            Comece agora e complete seu perfil depois
          </p>
        </div>

        {/* Card Principal */}
        <div className="bg-white rounded-[24px] shadow-2xl p-8">
          {/* Progress Steps */}
          <div className="flex items-center justify-center gap-2 mb-8">
            <div
              className={`size-2 rounded-full transition-all ${
                step === "email" ? "bg-[#2e61ff] w-8" : "bg-slate-200"
              }`}
            />
            <div
              className={`size-2 rounded-full transition-all ${
                step === "cnpj" || step === "loading" || step === "success"
                  ? "bg-[#2e61ff] w-8"
                  : "bg-slate-200"
              }`}
            />
            <div
              className={`size-2 rounded-full transition-all ${
                step === "success" ? "bg-[#2e61ff] w-8" : "bg-slate-200"
              }`}
            />
          </div>

          {/* Step 1: Email */}
          {step === "email" && (
            <>
              {/* Google OAuth */}
              <GoogleOAuthButton
                mode="signup"
                onSuccess={handleGoogleSuccess}
                onError={handleGoogleError}
              />

              {/* Divider */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200" />
                </div>
                <div className="relative flex justify-center text-[12px] uppercase">
                  <span className="bg-white px-3 text-slate-500">
                    ou continue com email
                  </span>
                </div>
              </div>

              <form onSubmit={handleEmailSubmit} className="space-y-6">
                <div>
                  <label className="block text-[14px] font-medium text-slate-700 mb-2">
                    Qual seu email profissional?
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu@email.com.br"
                    className="w-full px-4 py-3 rounded-[12px] border-2 border-slate-200 focus:border-[#2e61ff] focus:outline-none text-[16px] transition-colors"
                    autoFocus
                    required
                  />
                  <p className="text-[12px] text-slate-500 mt-2">
                    Usaremos para enviar atualizações importantes
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#1b41f5] transition-colors"
                >
                  Continuar
                </button>

                <p className="text-[12px] text-slate-500 text-center">
                  Já tem conta?{" "}
                  <button
                    type="button"
                    onClick={() => navigate("/login")}
                    className="text-[#2e61ff] font-semibold hover:underline"
                  >
                    Fazer login
                  </button>
                </p>
              </form>
            </>
          )}

          {/* Step 2: CNPJ */}
          {step === "cnpj" && (
            <form onSubmit={handleCNPJSubmit} className="space-y-6">
              <div>
                <label className="block text-[14px] font-medium text-slate-700 mb-2">
                  Qual o CNPJ da sua empresa?
                </label>
                <input
                  type="text"
                  value={cnpj}
                  onChange={(e) => setCnpj(formatCNPJ(e.target.value))}
                  placeholder="00.000.000/0000-00"
                  className="w-full px-4 py-3 rounded-[12px] border-2 border-slate-200 focus:border-[#2e61ff] focus:outline-none text-[16px] transition-colors"
                  autoFocus
                  maxLength={18}
                  required
                />
                <p className="text-[12px] text-slate-500 mt-2">
                  📋 Vamos preencher os dados automaticamente
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep("email")}
                  className="px-6 py-3 bg-slate-100 text-slate-700 rounded-[12px] font-semibold text-[16px] hover:bg-slate-200 transition-colors"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  disabled={cnpj.replace(/\D/g, "").length !== 14}
                  className="flex-1 py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#1b41f5] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Buscar dados
                </button>
              </div>
            </form>
          )}

          {/* Step 3: Loading */}
          {step === "loading" && (
            <div className="py-12 text-center space-y-6">
              <Loader2 className="size-16 text-[#2e61ff] animate-spin mx-auto" />
              <div>
                <h3 className="text-[20px] font-semibold text-slate-900 mb-2">
                  Buscando dados da empresa...
                </h3>
                <p className="text-[14px] text-slate-600">
                  Consultando base da Receita Federal
                </p>
              </div>
            </div>
          )}

          {/* Step 4: Success */}
          {step === "success" && companyData && (
            <div className="space-y-6">
              {/* Success Icon */}
              <div className="size-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
                <Check className="size-8 text-emerald-600" />
              </div>

              <div className="text-center">
                <h3 className="text-[20px] font-semibold text-slate-900 mb-2">
                  Dados encontrados!
                </h3>
                <p className="text-[14px] text-slate-600">
                  Confirme as informações abaixo
                </p>
              </div>

              {/* Company Info Cards */}
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-[12px]">
                  <div className="size-10 bg-[#2e61ff] rounded-[8px] flex items-center justify-center flex-shrink-0">
                    <Building2 className="size-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] text-slate-500 mb-1">Razão Social</p>
                    <p className="text-[14px] font-semibold text-slate-900">
                      {companyData.razao_social}
                    </p>
                    {companyData.nome_fantasia && (
                      <p className="text-[12px] text-slate-600 mt-1">
                        {companyData.nome_fantasia}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-[12px]">
                  <div className="size-10 bg-emerald-500 rounded-[8px] flex items-center justify-center flex-shrink-0">
                    <MapPin className="size-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] text-slate-500 mb-1">Endereço</p>
                    <p className="text-[14px] font-semibold text-slate-900">
                      {companyData.logradouro}, {companyData.numero}
                    </p>
                    <p className="text-[12px] text-slate-600 mt-1">
                      {companyData.bairro} - {companyData.municipio}/{companyData.uf}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-[12px]">
                  <div className="size-10 bg-orange-500 rounded-[8px] flex items-center justify-center flex-shrink-0">
                    <Briefcase className="size-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] text-slate-500 mb-1">CNAE Fiscal</p>
                    <p className="text-[14px] font-semibold text-slate-900">
                      {companyData.cnae_fiscal}
                    </p>
                    <p className="text-[12px] text-slate-600 mt-1">
                      {companyData.cnae_fiscal_descricao}
                    </p>
                  </div>
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center justify-center gap-2 p-3 bg-emerald-50 rounded-[12px]">
                <div className="size-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="text-[14px] font-semibold text-emerald-700">
                  Situação: {companyData.situacao}
                </span>
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <button
                  onClick={handleContinue}
                  className="w-full py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#1b41f5] transition-colors"
                >
                  Confirmar e continuar
                </button>
                <button
                  onClick={() => setStep("cnpj")}
                  className="w-full py-3 bg-slate-100 text-slate-700 rounded-[12px] font-semibold text-[16px] hover:bg-slate-200 transition-colors"
                >
                  Corrigir CNPJ
                </button>
              </div>

              <p className="text-[11px] text-slate-500 text-center">
                ✅ Seus dados foram enviados de forma segura. <br />
                Você receberá um email de confirmação em instantes.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-white/60 text-[12px] text-center mt-6">
          Ao continuar, você concorda com nossos{" "}
          <button className="text-white underline hover:text-white/80">
            Termos de Uso
          </button>{" "}
          e{" "}
          <button className="text-white underline hover:text-white/80">
            Política de Privacidade
          </button>
        </p>
      </div>
    </div>
  );
}