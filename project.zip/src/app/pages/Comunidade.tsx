import { useState } from "react";
import {
  Search,
  TrendingUp,
  MessageSquare,
  ThumbsUp,
  Eye,
  Plus,
  Filter,
  Users,
  Award,
  Calendar,
  BookOpen,
  Bell
} from "lucide-react";
import { Sidebar } from "../components/Sidebar";

export function Comunidade() {
  const [activeTab, setActiveTab] = useState<"discussoes" | "eventos" | "conteudo">("discussoes");
  const [searchTerm, setSearchTerm] = useState("");

  const discussions = [
    {
      id: "1",
      author: {
        name: "Lucas Ayres",
        avatar: "https://i.pravatar.cc/150?img=1",
        badge: "Expert"
      },
      title: "Melhores práticas para estruturação de CRI em 2024",
      category: "Estruturação",
      excerpt: "Gostaria de compartilhar algumas práticas que temos adotado para estruturação de CRI este ano...",
      likes: 45,
      comments: 12,
      views: 320,
      timeAgo: "2 horas atrás",
      tags: ["CRI", "Estruturação", "Boas Práticas"]
    },
    {
      id: "2",
      author: {
        name: "Jessica Mota",
        avatar: "https://i.pravatar.cc/150?img=2",
        badge: "Pro"
      },
      title: "Análise: Tendências do mercado de debêntures incentivadas",
      category: "Mercado",
      excerpt: "Dados recentes mostram um crescimento de 35% nas emissões de debêntures incentivadas...",
      likes: 38,
      comments: 8,
      views: 245,
      timeAgo: "5 horas atrás",
      tags: ["Debêntures", "Infraestrutura", "Análise"]
    },
    {
      id: "3",
      author: {
        name: "Caio Paixão",
        avatar: "https://i.pravatar.cc/150?img=3",
        badge: "Expert"
      },
      title: "Como avaliar o rating de crédito em operações estruturadas?",
      category: "Dúvidas",
      excerpt: "Alguém pode compartilhar experiências sobre os principais fatores considerados pelas agências...",
      likes: 52,
      comments: 15,
      views: 412,
      timeAgo: "1 dia atrás",
      tags: ["Rating", "Análise de Risco", "CVM"]
    },
    {
      id: "4",
      author: {
        name: "Nataly Lima",
        avatar: "https://i.pravatar.cc/150?img=4",
        badge: "Iniciante"
      },
      title: "Primeira emissão de CRA - Dicas e sugestões",
      category: "Dúvidas",
      excerpt: "Estou estruturando minha primeira operação de CRA e gostaria de orientações sobre...",
      likes: 28,
      comments: 19,
      views: 189,
      timeAgo: "2 dias atrás",
      tags: ["CRA", "Agronegócio", "Primeiro Projeto"]
    }
  ];

  const events = [
    {
      id: "1",
      title: "Webinar: Tendências do Mercado de Capitais 2024",
      date: "25/02/2024",
      time: "14:00",
      type: "Online",
      participants: 245,
      image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=200&fit=crop"
    },
    {
      id: "2",
      title: "Workshop: Estruturação de Operações Complexas",
      date: "05/03/2024",
      time: "09:00",
      type: "Presencial - SP",
      participants: 45,
      image: "https://images.unsplash.com/photo-1591115765373-5207764f72e7?w=400&h=200&fit=crop"
    },
    {
      id: "3",
      title: "Painel: O Futuro das Debêntures Incentivadas",
      date: "15/03/2024",
      time: "16:00",
      type: "Híbrido",
      participants: 180,
      image: "https://images.unsplash.com/photo-1559223607-a43f54e1f7d4?w=400&h=200&fit=crop"
    }
  ];

  const content = [
    {
      id: "1",
      title: "Guia Completo: Emissão de CRI do Zero",
      type: "Guia",
      author: "Equipe Bloxs",
      readTime: "15 min",
      likes: 156,
      image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400&h=200&fit=crop"
    },
    {
      id: "2",
      title: "Checklist: Documentação para CVM",
      type: "Checklist",
      author: "Lucas Ayres",
      readTime: "8 min",
      likes: 98,
      image: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400&h=200&fit=crop"
    },
    {
      id: "3",
      title: "Estudo de Caso: Emissão de R$ 500M em Debêntures",
      type: "Case",
      author: "Jessica Mota",
      readTime: "20 min",
      likes: 203,
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop"
    }
  ];

  const stats = [
    { icon: Users, label: "Membros Ativos", value: "2.450", color: "#3482ff" },
    { icon: MessageSquare, label: "Discussões", value: "1.234", color: "#01bf73" },
    { icon: Calendar, label: "Eventos este mês", value: "12", color: "#ffc709" },
    { icon: BookOpen, label: "Conteúdos", value: "486", color: "#9333ea" }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[28px] font-bold text-slate-950 dark:text-white mb-2">
                Comunidade
              </h1>
              <p className="text-[14px] text-slate-500 dark:text-slate-400">
                Conecte-se com profissionais do mercado de capitais
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-400" />
                <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
              </button>

              <button className="px-6 py-3 bg-blue-500 text-white rounded-[8px] font-semibold text-[14px] hover:bg-blue-600 flex items-center gap-2">
                <Plus className="size-5" />
                Nova Discussão
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-6">
          <div className="grid grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] p-4"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div
                    className="size-10 rounded-[8px] flex items-center justify-center"
                    style={{ backgroundColor: `${stat.color}15` }}
                  >
                    <stat.icon className="size-5" style={{ color: stat.color }} />
                  </div>
                  <div>
                    <p className="text-[12px] text-slate-500 dark:text-slate-400">{stat.label}</p>
                    <p className="text-[20px] font-bold text-slate-950 dark:text-white">{stat.value}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 px-8 py-8">
          {/* Tabs */}
          <div className="flex gap-2 mb-8">
            {[
              { id: "discussoes", label: "Discussões", icon: MessageSquare },
              { id: "eventos", label: "Eventos", icon: Calendar },
              { id: "conteudo", label: "Conteúdo", icon: BookOpen }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-3 rounded-[8px] text-[14px] font-semibold transition-all ${
                  activeTab === tab.id
                    ? "bg-blue-500 text-white"
                    : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-950 dark:text-white hover:border-blue-500"
                }`}
              >
                <tab.icon className="size-4" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Filters */}
          <div className="flex items-center gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
              <input
                type="text"
                placeholder={`Buscar ${activeTab}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-[48px] pl-11 pr-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] text-slate-950 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <button className="h-[48px] px-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] font-semibold text-slate-950 dark:text-white hover:border-blue-500 flex items-center gap-2">
              <Filter className="size-4" />
              Filtros
            </button>
          </div>

          {/* Content */}
          {activeTab === "discussoes" && (
            <div className="space-y-4">
              {discussions.map((discussion) => (
                <div
                  key={discussion.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] p-6 hover:border-blue-500 transition-all cursor-pointer"
                >
                  <div className="flex gap-4">
                    {/* Author Avatar */}
                    <img
                      src={discussion.author.avatar}
                      alt={discussion.author.name}
                      className="size-12 rounded-full flex-shrink-0"
                    />

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[14px] font-semibold text-slate-950 dark:text-white">
                            {discussion.author.name}
                          </span>
                          <span
                            className="px-2 py-0.5 rounded-[4px] text-[10px] font-semibold"
                            style={{
                              backgroundColor: discussion.author.badge === "Expert" ? "#ffc70915" : "#3482ff15",
                              color: discussion.author.badge === "Expert" ? "#ffc709" : "#3482ff"
                            }}
                          >
                            {discussion.author.badge}
                          </span>
                          <span className="text-[12px] text-slate-400">•</span>
                          <span className="text-[12px] text-slate-400">{discussion.timeAgo}</span>
                        </div>

                        <span className="px-3 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[6px] text-[12px] text-slate-950 dark:text-white">
                          {discussion.category}
                        </span>
                      </div>

                      <h3 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-2">
                        {discussion.title}
                      </h3>

                      <p className="text-[14px] text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
                        {discussion.excerpt}
                      </p>

                      <div className="flex items-center justify-between">
                        {/* Tags */}
                        <div className="flex gap-2">
                          {discussion.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[4px] text-[11px] text-slate-500 dark:text-slate-400"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>

                        {/* Stats */}
                        <div className="flex items-center gap-4 text-[13px] text-slate-500 dark:text-slate-400">
                          <div className="flex items-center gap-1.5">
                            <ThumbsUp className="size-4" />
                            <span>{discussion.likes}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <MessageSquare className="size-4" />
                            <span>{discussion.comments}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Eye className="size-4" />
                            <span>{discussion.views}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "eventos" && (
            <div className="grid grid-cols-3 gap-6">
              {events.map((event) => (
                <div
                  key={event.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] overflow-hidden hover:border-blue-500 transition-all cursor-pointer"
                >
                  <div className="h-[160px] bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="px-2 py-1 bg-blue-500/10 border border-blue-500 rounded-[4px]">
                        <span className="text-[11px] font-semibold text-blue-500">
                          {event.type}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-[12px] text-slate-500 dark:text-slate-400">
                        <Users className="size-3.5" />
                        <span>{event.participants}</span>
                      </div>
                    </div>

                    <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white mb-3">
                      {event.title}
                    </h3>

                    <div className="flex items-center gap-2 text-[13px] text-slate-500 dark:text-slate-400 mb-4">
                      <Calendar className="size-4" />
                      <span>{event.date} às {event.time}</span>
                    </div>

                    <button className="w-full py-2.5 bg-blue-500 text-white rounded-[8px] font-semibold text-[14px] hover:bg-blue-600">
                      Participar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "conteudo" && (
            <div className="grid grid-cols-3 gap-6">
              {content.map((item) => (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] overflow-hidden hover:border-blue-500 transition-all cursor-pointer"
                >
                  <div className="h-[160px] bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <span
                        className="px-2 py-1 rounded-[4px] text-[11px] font-semibold"
                        style={{
                          backgroundColor: item.type === "Guia" ? "#01bf7315" : item.type === "Checklist" ? "#ffc70915" : "#9333ea15",
                          color: item.type === "Guia" ? "#01bf73" : item.type === "Checklist" ? "#ffc709" : "#9333ea"
                        }}
                      >
                        {item.type}
                      </span>
                      <span className="text-[12px] text-slate-500 dark:text-slate-400">• {item.readTime}</span>
                    </div>

                    <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white mb-3">
                      {item.title}
                    </h3>

                    <div className="flex items-center justify-between">
                      <span className="text-[13px] text-slate-500 dark:text-slate-400">
                        Por {item.author}
                      </span>

                      <div className="flex items-center gap-1.5 text-[13px] text-slate-500 dark:text-slate-400">
                        <ThumbsUp className="size-4" />
                        <span>{item.likes}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
