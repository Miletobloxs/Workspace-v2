import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, SlidersHorizontal, ChevronRight, Bell, CheckCircle, Rocket } from "lucide-react";
import { Sidebar } from "../components/Sidebar";
import { OperationCard } from "../components/OperationCard";
import { FiltersModal, FilterState } from "../components/FiltersModal";
import { InterestModal } from "../components/InterestModal";

export function OperationsList() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"all" | "public" | "viability">("all");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [interestModalOpen, setInterestModalOpen] = useState(false);
  const [selectedOperation, setSelectedOperation] = useState<string>("");
  const [filters, setFilters] = useState<FilterState>({
    operationType: "public",
    sellSide: "",
    modality: ["Dívida"],
    sector: ["Imobiliário"],
    priceRange: [0, 900],
  });

  // Dados mockados com segmentação clara
  const operations = [
    // ===== OFERTAS PÚBLICAS (Prontas para investir) =====
    {
      id: "BS2#001",
      commercialName: "CRI Fictor I",
      sellSideName: "Banco BS2",
      sellSideLogo: "https://logo.clearbit.com/bs2.com.br",
      type: "Oferta Pública" as const,
      sector: "Imobiliário",
      volume: "R$ 12.900.000,00",
      deadline: "30 meses",
      remuneration: "IPCA + 18.80% a.a.",
      risk: "Médio" as const,
      instruments: ["CRI", "Debênture", "FIDC"],
      guarantees: [
        { type: "Alienação Fiduciária", value: "R$ 15.000.000,00", status: "Registrada" },
        { type: "Fiança Bancária", value: "R$ 0,00", status: "Não aplicável" },
      ],
      documents: {
        prospectus: "https://example.com/prospecto.pdf",
        factSheet: "https://example.com/lamina.pdf",
        announcement: "https://example.com/anuncio.pdf",
      },
      liquidationStatus: "received" as const,
      liquidationValue: "R$ 12.900.000,00",
      liquidationDate: "Recebido em 15/02/2026 às 14:32",
      badges: ["Disponível", "Alta Procura"],
      availableQuotas: 850,
      totalQuotas: 1000,
      minInvestment: "R$ 10.000,00",
      startDate: "15/02/2026",
      endDate: "30/03/2026",
    },
    {
      id: "BS2#003",
      commercialName: "FIDC Agro Brasil",
      sellSideName: "BTG Pactual",
      type: "Oferta Pública" as const,
      sector: "Agronegócio",
      volume: "R$ 80.000.000,00",
      deadline: "36 meses",
      remuneration: "CDI + 2.00% a.a.",
      risk: "Baixo" as const,
      instruments: ["FIDC", "CRA"],
      guarantees: [
        { type: "Penhor Rural", value: "R$ 90.000.000,00", status: "Registrado" },
      ],
      documents: {
        prospectus: "https://example.com/prospecto.pdf",
        factSheet: "https://example.com/lamina.pdf",
      },
      liquidationStatus: "processing" as const,
      badges: ["Agro", "Registro CVM"],
      isFavorite: true,
      availableQuotas: 1200,
      totalQuotas: 2000,
      minInvestment: "R$ 25.000,00",
      startDate: "10/02/2026",
      endDate: "25/03/2026",
    },
    {
      id: "XP#004",
      commercialName: "Debênture Infraestrutura BR",
      sellSideName: "XP Investimentos",
      type: "Oferta Pública" as const,
      sector: "Infraestrutura",
      volume: "R$ 150.000.000,00",
      deadline: "60 meses",
      remuneration: "IPCA + 9.50% a.a.",
      risk: "Baixo" as const,
      instruments: ["Debênture"],
      guarantees: [
        { type: "Garantia Real", value: "R$ 180.000.000,00", status: "Registrada" },
      ],
      documents: {
        prospectus: "https://example.com/prospecto.pdf",
        factSheet: "https://example.com/lamina.pdf",
        announcement: "https://example.com/anuncio.pdf",
      },
      badges: ["Incentivada", "ESG"],
      availableQuotas: 2500,
      totalQuotas: 3000,
      minInvestment: "R$ 50.000,00",
      startDate: "18/02/2026",
      endDate: "15/04/2026",
    },

    // ===== CONSULTA DE VIABILIDADE (Pré-aprovação, análise) =====
    {
      id: "BS2#002",
      commercialName: "Debênture Solar Tech",
      sellSideName: "XP Asset Management",
      type: "Consulta de Viabilidade" as const,
      sector: "Energia",
      volume: "R$ 50.000.000,00",
      deadline: "48 meses",
      remuneration: "CDI + 3.50% a.a.",
      risk: "Baixo" as const,
      instruments: ["Debênture", "CRA"],
      guarantees: [
        { type: "Aval", value: "R$ 0,00", status: "Confirmado" },
      ],
      documents: {},
      badges: ["ESG", "Em Análise"],
      viabilityStatus: "pre_approved" as const,
      estimatedLaunch: "Março 2026",
      analysisProgress: 75,
      interestedInvestors: 12,
    },
    {
      id: "ITU#005",
      commercialName: "CRA Exportação Grãos",
      sellSideName: "Itaú BBA",
      type: "Consulta de Viabilidade" as const,
      sector: "Agronegócio",
      volume: "R$ 35.000.000,00",
      deadline: "24 meses",
      remuneration: "CDI + 4.20% a.a.",
      risk: "Médio" as const,
      instruments: ["CRA"],
      guarantees: [
        { type: "Penhor Agrícola", value: "R$ 42.000.000,00", status: "Em Avaliação" },
      ],
      documents: {},
      badges: ["Exportação", "Viável"],
      viabilityStatus: "viable" as const,
      estimatedLaunch: "Abril 2026",
      analysisProgress: 90,
      interestedInvestors: 8,
    },
    {
      id: "SAN#006",
      commercialName: "FIDC Crédito Consignado",
      sellSideName: "Santander",
      type: "Consulta de Viabilidade" as const,
      sector: "Financeiro",
      volume: "R$ 100.000.000,00",
      deadline: "36 meses",
      remuneration: "CDI + 2.80% a.a.",
      risk: "Baixo" as const,
      instruments: ["FIDC"],
      guarantees: [
        { type: "Cessão de Créditos", value: "R$ 120.000.000,00", status: "Aprovado" },
      ],
      documents: {},
      badges: ["Baixo Risco", "Em Estruturação"],
      viabilityStatus: "structuring" as const,
      estimatedLaunch: "Maio 2026",
      analysisProgress: 60,
      interestedInvestors: 15,
    },
  ];

  // Lógica de filtragem baseada no tab ativo
  const filteredOperations = operations.filter(operation => {
    if (activeTab === "all") return true;
    if (activeTab === "public") return operation.type === "Oferta Pública";
    if (activeTab === "viability") return operation.type === "Consulta de Viabilidade";
    return true;
  });

  // Contadores para exibir nos tabs
  const counters = {
    all: operations.length,
    public: operations.filter(op => op.type === "Oferta Pública").length,
    viability: operations.filter(op => op.type === "Consulta de Viabilidade").length,
  };

  // Título dinâmico baseado no tab
  const getTitle = () => {
    if (activeTab === "public") return "Ofertas Públicas Disponíveis";
    if (activeTab === "viability") return "Consulta de Viabilidade";
    return "Todas as Oportunidades";
  };

  const getIcon = () => {
    if (activeTab === "public") return <Rocket className="size-5 text-slate-950 dark:text-white" />;
    if (activeTab === "viability") return <CheckCircle className="size-5 text-slate-950 dark:text-white" />;
    return <svg className="size-5 text-slate-950 dark:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
    </svg>;
  };

  const getDescription = () => {
    if (activeTab === "public") {
      return "Operações oficialmente lançadas no mercado, prontas para investimento imediato com cotas disponíveis.";
    }
    if (activeTab === "viability") {
      return "Operações em análise e pré-aprovadas, disponíveis para manifestação de interesse antecipado.";
    }
    return "Visualize todas as oportunidades de investimento disponíveis na plataforma.";
  };

  const handleLearnMore = (id: string) => {
    navigate(`/marketplace/${id}`);
  };

  const handleToggleFavorite = (id: string) => {
    console.log("Toggle favorite:", id);
    // Em produção: atualizar no backend
  };

  const handleInterest = (operationId: string, operationName: string) => {
    setSelectedOperation(operationName);
    setInterestModalOpen(true);
  };

  const handleApplyFilters = (newFilters: FilterState) => {
    setFilters(newFilters);
    console.log("Filters applied:", newFilters);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex-1" />
            
            <div className="flex items-center gap-4">
              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <svg className="size-5 text-slate-600 dark:text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <circle cx="12" cy="12" r="10" strokeWidth={2} />
                </svg>
              </button>

              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-400" />
                <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
              </button>

              <div className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-700">
                <div className="size-[40px] bg-[#2e61ff] rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-[14px]">BC</span>
                </div>
                <div>
                  <p className="text-[14px] font-semibold text-slate-950 dark:text-white">Bloxs Capital Partners LTDA</p>
                  <p className="text-[12px] text-slate-500">41.847.533/0001-90</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          {/* Hero Banner */}
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-[24px] p-8 mb-8 relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-3">
                <svg className="size-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h1 className="text-[32px] font-semibold text-white mb-2">
                Encontre oportunidades<br />
                exclusivas do Mercado de Capitais
              </h1>
            </div>

            <div className="absolute top-4 right-4 space-y-3">
              <div className="bg-white/10 backdrop-blur-sm rounded-[12px] p-4 border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[12px] text-white/80">Sell Side</span>
                </div>
                <p className="text-[16px] font-semibold text-white">123 Capital</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[12px] text-white/60">XPTO#001</span>
                  <span className="px-2 py-0.5 bg-white/20 rounded-[4px] text-[10px] text-white">Privado</span>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-[12px] p-4 border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[12px] text-white/80">Buy Side</span>
                </div>
                <p className="text-[16px] font-semibold text-white">123 Capital</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[12px] text-white/60">XPTO#001</span>
                  <button className="px-2 py-0.5 bg-blue-600 rounded-[4px] text-[10px] text-white hover:bg-blue-700">
                    Imobilizar
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs and Search */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex gap-2">
              <button
                onClick={() => setActiveTab("all")}
                className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors ${
                  activeTab === "all"
                    ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Todos
              </button>
              <button
                onClick={() => setActiveTab("public")}
                className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors ${
                  activeTab === "public"
                    ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Oferta pública
              </button>
              <button
                onClick={() => setActiveTab("viability")}
                className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors flex items-center gap-2 ${
                  activeTab === "viability"
                    ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                <svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Consulta de viabilidade
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="O que você está buscando?"
                  className="w-[320px] h-[40px] pl-10 pr-4 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-950 dark:text-white text-[14px] placeholder-slate-500"
                />
              </div>

              <button
                onClick={() => setIsFiltersOpen(true)}
                className="flex items-center gap-2 px-4 h-[40px] rounded-[8px] border border-slate-300 dark:border-slate-600 text-slate-950 dark:text-white text-[14px] font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <SlidersHorizontal className="size-4" />
                Filtros
              </button>
            </div>
          </div>

          {/* Section Title */}
          <div className="flex items-center gap-2 mb-6">
            {getIcon()}
            <h2 className="text-[20px] font-semibold text-slate-950 dark:text-white">{getTitle()}</h2>
          </div>

          {/* Description */}
          <p className="text-[14px] text-slate-500 dark:text-slate-400 mb-6">{getDescription()}</p>

          {/* Operations Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredOperations.map((operation) => (
              <OperationCard
                key={operation.id}
                operation={operation}
                onLearnMore={handleLearnMore}
                onToggleFavorite={handleToggleFavorite}
                onInterest={handleInterest}
              />
            ))}
          </div>
        </div>
      </div>

      <FiltersModal
        isOpen={isFiltersOpen}
        onClose={() => setIsFiltersOpen(false)}
        onApplyFilters={handleApplyFilters}
      />

      <InterestModal
        isOpen={interestModalOpen}
        onClose={() => setInterestModalOpen(false)}
        operationName={selectedOperation}
        operationId={operations.find(op => op.commercialName === selectedOperation)?.id || ""}
      />
    </div>
  );
}