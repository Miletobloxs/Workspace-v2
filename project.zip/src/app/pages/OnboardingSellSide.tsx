import { useState } from "react";
import { useNavigate } from "react-router";
import { Check } from "lucide-react";

export function OnboardingSellSide() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    // Step 1: Perfil da Empresa
    areaAtuacao: "",
    faturamentoAnual: "",
    qtdFuncionarios: "",
    tempoMercado: "",
    
    // Step 2: Objetivos
    objetivoPrincipal: "",
    valorDesejado: "",
    prazoDesejado: "",
    jaRealizouOperacao: "",
    
    // Step 3: Necessidades
    tipoAtivo: [] as string[],
    urgencia: "",
    documentacaoPreparada: "",
  });

  const handleContinue = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Salvar dados do onboarding
      localStorage.setItem("onboardingSellSideData", JSON.stringify(formData));
      localStorage.setItem("onboardingStep", "sell-side-completed");
      
      // Finalizar onboarding e ir para upload de documentos
      navigate("/onboarding/documentos");
    }
  };

  return (
    <div className="min-h-screen bg-[#212121] flex">
      {/* Left Sidebar */}
      <div className="w-[463px] bg-[#292929] relative overflow-hidden">
        {/* Gradient Effects */}
        <div className="absolute top-[-74px] left-[-257px] w-[530px] h-[361px] pointer-events-none">
          <div className="w-full h-full opacity-30 blur-[94.5px]">
            <div className="w-full h-full bg-gradient-to-r from-[#3482ff] to-transparent rotate-[145deg]" />
          </div>
        </div>

        {/* Logo */}
        <div className="absolute top-[104px] left-[32px]">
          <svg width="104" height="24" viewBox="0 0 104 24" fill="none">
            <text x="0" y="18" fill="white" fontSize="20" fontWeight="600" fontFamily="Poppins">
              bloxs
            </text>
          </svg>
        </div>

        {/* Content */}
        <div className="absolute top-[214px] left-[32px] right-[32px]">
          <h2 className="text-[28px] font-semibold text-white leading-normal mb-6">
            Vamos conhecer melhor sua empresa
          </h2>
          <p className="text-[16px] text-[#a4a4a4] leading-relaxed mb-12">
            Com essas informações, conseguiremos criar um workspace personalizado e conectar você com as melhores soluções do mercado.
          </p>

          {/* Steps */}
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className={`size-[40px] rounded-[8px] flex items-center justify-center flex-shrink-0 ${
                step >= 1 ? "bg-[#3482ff]" : "bg-[#242320] border border-[rgba(52,130,255,0.2)]"
              }`}>
                {step > 1 ? (
                  <Check className="size-5 text-white" />
                ) : (
                  <span className="text-white font-semibold">1</span>
                )}
              </div>
              <div>
                <h3 className="text-[16px] font-semibold text-white mb-1">Perfil da empresa</h3>
                <p className="text-[14px] text-[#a4a4a4]">Informações básicas sobre sua organização</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className={`size-[40px] rounded-[8px] flex items-center justify-center flex-shrink-0 ${
                step >= 2 ? "bg-[#3482ff]" : "bg-[#242320] border border-[rgba(52,130,255,0.2)]"
              }`}>
                {step > 2 ? (
                  <Check className="size-5 text-white" />
                ) : (
                  <span className="text-white font-semibold">2</span>
                )}
              </div>
              <div>
                <h3 className="text-[16px] font-semibold text-white mb-1">Objetivos financeiros</h3>
                <p className="text-[14px] text-[#a4a4a4]">O que você busca no Mercado de Capitais</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className={`size-[40px] rounded-[8px] flex items-center justify-center flex-shrink-0 ${
                step >= 3 ? "bg-[#3482ff]" : "bg-[#242320] border border-[rgba(52,130,255,0.2)]"
              }`}>
                <span className="text-white font-semibold">3</span>
              </div>
              <div>
                <h3 className="text-[16px] font-semibold text-white mb-1">Necessidades específicas</h3>
                <p className="text-[14px] text-[#a4a4a4]">Tipo de operação e timeline desejado</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative overflow-y-auto">
        {/* Progress */}
        <div className="absolute top-[80px] left-[32px] w-[216px]">
          <p className="text-[12px] text-white mb-2">Etapa {step} de 3</p>
          <div className="h-2 bg-[#292929] rounded-[20px] overflow-hidden">
            <div 
              className="h-full bg-[#3482ff] rounded-[20px] transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Perfil da Empresa */}
        {step === 1 && (
          <div className="absolute top-[138px] left-[32px] right-[32px]">
            <h1 className="text-[24px] font-bold text-white leading-[48px] mb-8">
              Conte-nos sobre sua empresa
            </h1>

            <div className="space-y-6 max-w-[600px]">
              <div>
                <label className="block text-[14px] text-white mb-2">Área de atuação principal</label>
                <select
                  value={formData.areaAtuacao}
                  onChange={(e) => setFormData({ ...formData, areaAtuacao: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="agronegocio">Agronegócio</option>
                  <option value="financeiro">Financeiro</option>
                  <option value="imobiliario">Imobiliário</option>
                  <option value="tecnologia">Tecnologia</option>
                  <option value="varejo">Varejo</option>
                  <option value="outro">Outro</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Faturamento anual aproximado</label>
                <select
                  value={formData.faturamentoAnual}
                  onChange={(e) => setFormData({ ...formData, faturamentoAnual: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="ate-10m">Até R$ 10 milhões</option>
                  <option value="10m-50m">R$ 10M - R$ 50M</option>
                  <option value="50m-200m">R$ 50M - R$ 200M</option>
                  <option value="200m-500m">R$ 200M - R$ 500M</option>
                  <option value="acima-500m">Acima de R$ 500M</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Quantidade de funcionários</label>
                <select
                  value={formData.qtdFuncionarios}
                  onChange={(e) => setFormData({ ...formData, qtdFuncionarios: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="1-10">1-10</option>
                  <option value="11-50">11-50</option>
                  <option value="51-200">51-200</option>
                  <option value="201-500">201-500</option>
                  <option value="acima-500">Acima de 500</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Há quanto tempo está no mercado?</label>
                <select
                  value={formData.tempoMercado}
                  onChange={(e) => setFormData({ ...formData, tempoMercado: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="menos-1ano">Menos de 1 ano</option>
                  <option value="1-3anos">1-3 anos</option>
                  <option value="3-5anos">3-5 anos</option>
                  <option value="5-10anos">5-10 anos</option>
                  <option value="acima-10anos">Mais de 10 anos</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Objetivos */}
        {step === 2 && (
          <div className="absolute top-[138px] left-[32px] right-[32px]">
            <h1 className="text-[24px] font-bold text-white leading-[48px] mb-8">
              Quais são seus objetivos?
            </h1>

            <div className="space-y-6 max-w-[600px]">
              <div>
                <label className="block text-[14px] text-white mb-2">Objetivo principal</label>
                <select
                  value={formData.objetivoPrincipal}
                  onChange={(e) => setFormData({ ...formData, objetivoPrincipal: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="captar-recursos">Captar recursos</option>
                  <option value="estruturar-divida">Estruturar dívida</option>
                  <option value="expandir-negocio">Expandir negócio</option>
                  <option value="refinanciar">Refinanciar dívidas existentes</option>
                  <option value="investir-ativos">Investir em novos ativos</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Valor desejado (opcional)</label>
                <input
                  type="text"
                  placeholder="Ex: R$ 50.000.000,00"
                  value={formData.valorDesejado}
                  onChange={(e) => setFormData({ ...formData, valorDesejado: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
                />
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Prazo desejado para a operação</label>
                <select
                  value={formData.prazoDesejado}
                  onChange={(e) => setFormData({ ...formData, prazoDesejado: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="ate-12meses">Até 12 meses</option>
                  <option value="12-24meses">12-24 meses</option>
                  <option value="24-36meses">24-36 meses</option>
                  <option value="36-60meses">36-60 meses</option>
                  <option value="acima-60meses">Acima de 60 meses</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Já realizou operações no Mercado de Capitais?</label>
                <div className="flex gap-4">
                  <button
                    onClick={() => setFormData({ ...formData, jaRealizouOperacao: "sim" })}
                    className={`flex-1 h-[48px] rounded-[6px] border font-semibold text-[14px] transition-all ${
                      formData.jaRealizouOperacao === "sim"
                        ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                        : "border-[#818181] text-white hover:border-[#3482ff]/50"
                    }`}
                  >
                    Sim
                  </button>
                  <button
                    onClick={() => setFormData({ ...formData, jaRealizouOperacao: "nao" })}
                    className={`flex-1 h-[48px] rounded-[6px] border font-semibold text-[14px] transition-all ${
                      formData.jaRealizouOperacao === "nao"
                        ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                        : "border-[#818181] text-white hover:border-[#3482ff]/50"
                    }`}
                  >
                    Não
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Necessidades */}
        {step === 3 && (
          <div className="absolute top-[138px] left-[32px] right-[32px]">
            <h1 className="text-[24px] font-bold text-white leading-[48px] mb-8">
              Necessidades específicas
            </h1>

            <div className="space-y-6 max-w-[600px]">
              <div>
                <label className="block text-[14px] text-white mb-2">Tipo de ativo de interesse (pode selecionar múltiplos)</label>
                <div className="space-y-3">
                  {[
                    { id: "cri", label: "CRI - Certificado de Recebíveis Imobiliários" },
                    { id: "cra", label: "CRA - Certificado de Recebíveis do Agronegócio" },
                    { id: "debenture", label: "Debêntures" },
                    { id: "fidc", label: "FIDC - Fundo de Investimento em Direitos Creditórios" },
                    { id: "outro", label: "Outro" },
                  ].map((tipo) => (
                    <button
                      key={tipo.id}
                      onClick={() => {
                        const newTipos = formData.tipoAtivo.includes(tipo.id)
                          ? formData.tipoAtivo.filter(t => t !== tipo.id)
                          : [...formData.tipoAtivo, tipo.id];
                        setFormData({ ...formData, tipoAtivo: newTipos });
                      }}
                      className={`w-full h-[48px] px-4 rounded-[6px] border text-left font-medium text-[14px] transition-all flex items-center gap-3 ${
                        formData.tipoAtivo.includes(tipo.id)
                          ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                          : "border-[#818181] text-white hover:border-[#3482ff]/50"
                      }`}
                    >
                      <div className={`size-5 rounded border-2 flex items-center justify-center ${
                        formData.tipoAtivo.includes(tipo.id)
                          ? "border-[#3482ff] bg-[#3482ff]"
                          : "border-[#818181]"
                      }`}>
                        {formData.tipoAtivo.includes(tipo.id) && <Check className="size-3 text-white" />}
                      </div>
                      {tipo.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Qual a urgência da operação?</label>
                <select
                  value={formData.urgencia}
                  onChange={(e) => setFormData({ ...formData, urgencia: e.target.value })}
                  className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff] appearance-none"
                >
                  <option value="">Selecione</option>
                  <option value="imediata">Imediata (até 30 dias)</option>
                  <option value="curto-prazo">Curto prazo (1-3 meses)</option>
                  <option value="medio-prazo">Médio prazo (3-6 meses)</option>
                  <option value="planejamento">Planejamento futuro (6+ meses)</option>
                </select>
              </div>

              <div>
                <label className="block text-[14px] text-white mb-2">Documentação já está preparada?</label>
                <div className="flex gap-4">
                  <button
                    onClick={() => setFormData({ ...formData, documentacaoPreparada: "sim" })}
                    className={`flex-1 h-[48px] rounded-[6px] border font-semibold text-[14px] transition-all ${
                      formData.documentacaoPreparada === "sim"
                        ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                        : "border-[#818181] text-white hover:border-[#3482ff]/50"
                    }`}
                  >
                    Sim, está pronta
                  </button>
                  <button
                    onClick={() => setFormData({ ...formData, documentacaoPreparada: "nao" })}
                    className={`flex-1 h-[48px] rounded-[6px] border font-semibold text-[14px] transition-all ${
                      formData.documentacaoPreparada === "nao"
                        ? "border-[#3482ff] bg-[#3482ff]/10 text-[#3482ff]"
                        : "border-[#818181] text-white hover:border-[#3482ff]/50"
                    }`}
                  >
                    Preciso de ajuda
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="fixed bottom-0 right-0 left-[463px] h-[81px] border-t border-[#2e2e2e] bg-[#212121] flex items-center justify-between px-8">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="px-6 py-4 bg-[#292929] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#3a3a3a] transition-colors"
            >
              Voltar
            </button>
          )}
          <div className="ml-auto">
            <button
              onClick={handleContinue}
              className="px-6 py-4 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#2668dd] transition-colors"
            >
              {step === 3 ? "Finalizar" : "Continuar"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}