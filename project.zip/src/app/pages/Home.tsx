import { useNavigate } from "react-router";
import { Search, Bell, TrendingUp, Users, Clock, BarChart3, ArrowRight, Heart, Building2 } from "lucide-react";
import { Sidebar } from "../components/Sidebar";

export function Home() {
  const navigate = useNavigate();

  const recommendedOperations = [
    {
      id: "BS2#001",
      name: "CRI Fictor I",
      sellSide: "Banco BS2",
      volume: "R$ 12.900.000,00",
      remuneration: "IPCA + 18.80% a.a.",
      sector: "Imobiliário",
      match: 95,
    },
    {
      id: "BS2#002",
      name: "Debênture Solar Tech",
      sellSide: "XP Asset",
      volume: "R$ 50.000.000,00",
      remuneration: "CDI + 3.50% a.a.",
      sector: "Energia",
      match: 88,
    },
    {
      id: "BS2#003",
      name: "FIDC Agro Brasil",
      sellSide: "BTG Pactual",
      volume: "R$ 80.000.000,00",
      remuneration: "CDI + 2.00% a.a.",
      sector: "Agronegócio",
      match: 82,
    },
  ];

  const recentActivity = [
    {
      icon: <Users className="size-4" />,
      text: "XP Asset solicitou acesso à operação BS2#001",
      time: "Há 5 minutos",
    },
    {
      icon: <Heart className="size-4" />,
      text: "BTG Pactual manifestou interesse em CRI Fictor I",
      time: "Há 23 minutos",
    },
    {
      icon: <Clock className="size-4" />,
      text: "Nova operação publicada: Debênture Solar Tech",
      time: "Há 1 hora",
    },
  ];

  const profileCompleteness = 75;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex-1 max-w-[600px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar operações, membros, documentos... (Cmd+K)"
                  className="w-full pl-10 pr-4 py-2 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-950 dark:text-white text-[14px] placeholder-slate-500"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <svg className="size-5 text-slate-600 dark:text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <circle cx="12" cy="12" r="10" strokeWidth={2} />
                </svg>
              </button>

              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-400" />
                <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
              </button>

              <div className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-700">
                <div className="size-[40px] bg-[#2e61ff] rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-[14px]">BC</span>
                </div>
                <div>
                  <p className="text-[14px] font-semibold text-slate-950 dark:text-white">Bloxs Capital Partners LTDA</p>
                  <p className="text-[12px] text-slate-500">41.847.533/0001-90</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-y-auto">
          {/* Welcome Banner */}
          <div className="bg-gradient-to-r from-[#2e61ff] to-[#1b41f5] rounded-[24px] p-8 mb-8 text-white">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-[32px] font-bold mb-2">Bem-vindo de volta! 👋</h1>
                <p className="text-[16px] text-white/90 mb-6">
                  Você tem <strong>3 operações</strong> recomendadas baseadas no seu perfil
                </p>
                <button
                  onClick={() => navigate("/marketplace")}
                  className="bg-white text-[#2e61ff] px-6 py-3 rounded-[12px] font-semibold text-[14px] hover:bg-white/90 transition-colors inline-flex items-center gap-2"
                >
                  Explorar operações
                  <ArrowRight className="size-4" />
                </button>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-[16px] p-6 min-w-[200px]">
                <p className="text-[12px] text-white/80 mb-2">Perfil completo</p>
                <div className="flex items-end gap-2 mb-3">
                  <span className="text-[36px] font-bold">{profileCompleteness}%</span>
                </div>
                <div className="h-2 bg-white/20 rounded-full overflow-hidden mb-3">
                  <div className="h-full bg-white rounded-full" style={{ width: `${profileCompleteness}%` }} />
                </div>
                <button
                  onClick={() => navigate("/workspace/configuracoes")}
                  className="text-[12px] text-white hover:underline"
                >
                  Completar perfil →
                </button>
              </div>
            </div>
          </div>

          {/* Metrics Cards */}
          <div className="grid grid-cols-4 gap-6 mb-8">
            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="size-12 bg-blue-100 dark:bg-blue-950 rounded-[12px] flex items-center justify-center">
                  <TrendingUp className="size-6 text-[#2e61ff]" />
                </div>
              </div>
              <p className="text-[14px] text-slate-600 dark:text-slate-400 mb-1">Operações Ativas</p>
              <p className="text-[32px] font-bold text-slate-950 dark:text-white">24</p>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="size-12 bg-emerald-100 dark:bg-emerald-950 rounded-[12px] flex items-center justify-center">
                  <BarChart3 className="size-6 text-emerald-600 dark:text-emerald-400" />
                </div>
              </div>
              <p className="text-[14px] text-slate-600 dark:text-slate-400 mb-1">Volume Total</p>
              <p className="text-[32px] font-bold text-slate-950 dark:text-white">R$ 1.2B</p>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="size-12 bg-orange-100 dark:bg-orange-950 rounded-[12px] flex items-center justify-center">
                  <Users className="size-6 text-orange-600 dark:text-orange-400" />
                </div>
              </div>
              <p className="text-[14px] text-slate-600 dark:text-slate-400 mb-1">Buy Sides Ativos</p>
              <p className="text-[32px] font-bold text-slate-950 dark:text-white">48</p>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="size-12 bg-purple-100 dark:bg-purple-950 rounded-[12px] flex items-center justify-center">
                  <Clock className="size-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
              <p className="text-[14px] text-slate-600 dark:text-slate-400 mb-1">Tempo Médio</p>
              <p className="text-[32px] font-bold text-slate-950 dark:text-white">12d</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-6">
            {/* Recommended Operations */}
            <div className="col-span-2 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-[20px] font-semibold text-slate-950 dark:text-white">
                  Recomendadas para você
                </h2>
                <button
                  onClick={() => navigate("/marketplace")}
                  className="text-[14px] text-[#2e61ff] hover:underline font-medium"
                >
                  Ver todas →
                </button>
              </div>

              <div className="space-y-4">
                {recommendedOperations.map((operation) => (
                  <div
                    key={operation.id}
                    onClick={() => navigate(`/marketplace/${operation.id}`)}
                    className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 hover:border-[#2e61ff] dark:hover:border-[#2e61ff] transition-all cursor-pointer group"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-3">
                        <div className="size-12 bg-gradient-to-br from-[#2e61ff] to-[#1b41f5] rounded-[12px] flex items-center justify-center">
                          <Building2 className="size-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white mb-1">
                            {operation.name}
                          </h3>
                          <p className="text-[14px] text-slate-600 dark:text-slate-400">
                            {operation.sellSide}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-[6px] text-[12px] font-semibold mb-2">
                          <TrendingUp className="size-3" />
                          {operation.match}% match
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Volume</p>
                        <p className="text-[14px] font-semibold text-slate-950 dark:text-white">
                          {operation.volume}
                        </p>
                      </div>
                      <div>
                        <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Remuneração</p>
                        <p className="text-[14px] font-semibold text-slate-950 dark:text-white">
                          {operation.remuneration}
                        </p>
                      </div>
                      <div>
                        <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Setor</p>
                        <p className="text-[14px] font-semibold text-slate-950 dark:text-white">
                          {operation.sector}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-[20px] font-semibold text-slate-950 dark:text-white">
                  Atividade Recente
                </h2>
              </div>

              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div
                    key={index}
                    className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-4"
                  >
                    <div className="flex gap-3">
                      <div className="size-8 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center flex-shrink-0 text-slate-600 dark:text-slate-400">
                        {activity.icon}
                      </div>
                      <div className="flex-1">
                        <p className="text-[14px] text-slate-950 dark:text-white leading-relaxed mb-1">
                          {activity.text}
                        </p>
                        <p className="text-[12px] text-slate-500">{activity.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Actions */}
              <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
                <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white mb-4">
                  Ações Rápidas
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={() => navigate("/marketplace/gerenciar")}
                    className="w-full text-left px-4 py-3 rounded-[8px] hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-[14px] text-slate-700 dark:text-slate-300"
                  >
                    📊 Gerenciar operações
                  </button>
                  <button
                    onClick={() => navigate("/workspace/configuracoes")}
                    className="w-full text-left px-4 py-3 rounded-[8px] hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-[14px] text-slate-700 dark:text-slate-300"
                  >
                    ⚙️ Configurações
                  </button>
                  <button
                    onClick={() => navigate("/workspace/dealmatch")}
                    className="w-full text-left px-4 py-3 rounded-[8px] hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-[14px] text-slate-700 dark:text-slate-300"
                  >
                    🎯 Atualizar Dealmatch
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}