import { useState } from "react";
import { useNavigate, useLocation } from "react-router";
import { X } from "lucide-react";

export function QuotationStep3() {
  const navigate = useNavigate();
  const location = useLocation();
  const [details, setDetails] = useState("");
  const [link, setLink] = useState("");

  const handleSubmit = () => {
    // Submit quotation
    navigate("/cotacao/sucesso");
  };

  return (
    <div className="min-h-screen bg-[#212121] flex">
      {/* Left Sidebar (same structure) */}
      <div className="w-[463px] bg-[#292929] relative overflow-hidden">
        {/* ... same sidebar content ... */}
      </div>

      {/* Main Content */}
      <div className="flex-1 relative">
        <button
          onClick={() => navigate("/home")}
          className="absolute top-6 right-6 size-6 text-white"
        >
          <X className="size-6" />
        </button>

        <div className="absolute top-[80px] left-[32px] w-[216px]">
          <p className="text-[12px] text-white mb-2">Etapa 3 de 3</p>
          <div className="h-2 bg-[#292929] rounded-[20px] overflow-hidden">
            <div className="h-full w-full bg-[#3482ff] rounded-[20px]" />
          </div>
        </div>

        <div className="absolute top-[138px] left-[32px]">
          <h1 className="text-[24px] font-bold text-white leading-[48px]">
            Possui informações adicionais?
          </h1>
        </div>

        <textarea
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          placeholder="Escreva mais detalhes"
          className="absolute top-[218px] left-[32px] w-[893px] h-[399px] p-4 bg-transparent border border-[#818181] rounded-[6px] text-[12px] text-[#818181] placeholder-[#818181] focus:outline-none focus:border-[#3482ff] resize-none"
        />

        <div className="absolute top-[649px] left-[32px] w-[893px] h-px bg-[#515151]" />

        <p className="absolute top-[665px] left-[32px] text-[14px] font-semibold text-[#e3e3e3]">
          Insira aqui o link do material institucional da oferta
        </p>

        <input
          type="text"
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="Inserir Link"
          className="absolute top-[702px] left-[32px] w-[893px] h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-[#818181] placeholder-[#818181] focus:outline-none focus:border-[#3482ff]"
        />

        <div className="absolute bottom-0 left-0 right-0 h-px bg-[#2e2e2e]" />

        <div className="absolute bottom-6 left-[32px] right-[32px] flex justify-between">
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-4 bg-[#292929] text-white rounded-[8px] font-semibold text-[16px]"
          >
            Voltar
          </button>
          <button
            onClick={handleSubmit}
            className="px-6 py-4 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[16px]"
          >
            Enviar
          </button>
        </div>
      </div>
    </div>
  );
}
