import { useState } from "react";
import { useNavigate } from "react-router";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart,
  Calendar,
  Download,
  Eye,
  Filter,
  Search,
  Bell
} from "lucide-react";
import { Sidebar } from "../components/Sidebar";

export function Carteira() {
  const navigate = useNavigate();
  const [filterPeriod, setFilterPeriod] = useState("30d");
  const [filterType, setFilterType] = useState("todos");

  // Portfolio data
  const portfolioSummary = {
    totalInvested: "R$ 12.450.000,00",
    currentValue: "R$ 13.125.500,00",
    totalReturn: "R$ 675.500,00",
    returnPercent: "+5,42%",
    monthlyYield: "R$ 45.800,00",
    ytdReturn: "+8,23%"
  };

  const investments = [
    {
      id: "1",
      code: "CRI-2024-001",
      type: "CRI",
      issuer: "Construtora ABC",
      investedAmount: "R$ 2.000.000,00",
      currentValue: "R$ 2.085.000,00",
      return: "+4,25%",
      returnColor: "green",
      rate: "IPCA + 8,5% a.a.",
      maturity: "12/2026",
      nextPayment: "15/03/2024",
      status: "ativa"
    },
    {
      id: "2",
      code: "CRA-2024-002",
      type: "CRA",
      issuer: "Agro Invest",
      investedAmount: "R$ 1.500.000,00",
      currentValue: "R$ 1.590.000,00",
      return: "+6,00%",
      returnColor: "green",
      rate: "CDI + 3% a.a.",
      maturity: "08/2025",
      nextPayment: "20/03/2024",
      status: "ativa"
    },
    {
      id: "3",
      code: "DEB-2023-015",
      type: "Debênture",
      issuer: "Tech Solutions",
      investedAmount: "R$ 3.000.000,00",
      currentValue: "R$ 3.150.000,00",
      return: "+5,00%",
      returnColor: "green",
      rate: "12% a.a.",
      maturity: "06/2027",
      nextPayment: "01/04/2024",
      status: "ativa"
    },
    {
      id: "4",
      code: "CRI-2023-089",
      type: "CRI",
      issuer: "Imobiliária Premium",
      investedAmount: "R$ 2.500.000,00",
      currentValue: "R$ 2.425.000,00",
      return: "-3,00%",
      returnColor: "red",
      rate: "IPCA + 7% a.a.",
      maturity: "03/2025",
      nextPayment: "10/03/2024",
      status: "ativa"
    },
    {
      id: "5",
      code: "FIDC-2024-003",
      type: "FIDC",
      issuer: "Crédito Fácil",
      investedAmount: "R$ 3.450.000,00",
      currentValue: "R$ 3.875.500,00",
      return: "+12,33%",
      returnColor: "green",
      rate: "CDI + 4,5% a.a.",
      maturity: "11/2026",
      nextPayment: "25/03/2024",
      status: "ativa"
    }
  ];

  const allocation = [
    { type: "CRI", percentage: 36, value: "R$ 4.510.000,00", color: "#3482ff" },
    { type: "CRA", percentage: 12, value: "R$ 1.590.000,00", color: "#01bf73" },
    { type: "Debêntures", percentage: 24, value: "R$ 3.150.000,00", color: "#ffc709" },
    { type: "FIDC", percentage: 28, value: "R$ 3.875.500,00", color: "#9333ea" }
  ];

  const getTypeColor = (type: string) => {
    const colors: any = {
      CRI: "#3482ff",
      CRA: "#01bf73",
      Debênture: "#ffc709",
      FIDC: "#9333ea"
    };
    return colors[type] || "#818181";
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[28px] font-bold text-slate-950 dark:text-white mb-2">
                Minha Carteira
              </h1>
              <p className="text-[14px] text-slate-500 dark:text-slate-400">
                Acompanhe seus investimentos e performance em tempo real
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-400" />
                <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
              </button>

              <button className="px-4 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-950 dark:text-white rounded-[8px] text-[14px] font-semibold hover:border-blue-500 flex items-center gap-2">
                <Download className="size-4" />
                Exportar Relatório
              </button>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-6">
          <div className="grid grid-cols-6 gap-4">
            <div className="col-span-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] text-slate-500 dark:text-slate-400">Valor Total Investido</span>
                <DollarSign className="size-5 text-blue-500" />
              </div>
              <p className="text-[28px] font-bold text-slate-950 dark:text-white mb-1">{portfolioSummary.totalInvested}</p>
              <p className="text-[12px] text-slate-500 dark:text-slate-400">Atualizado hoje</p>
            </div>

            <div className="col-span-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] text-slate-500 dark:text-slate-400">Valor Atual</span>
                <TrendingUp className="size-5 text-green-500" />
              </div>
              <p className="text-[28px] font-bold text-slate-950 dark:text-white mb-1">{portfolioSummary.currentValue}</p>
              <div className="flex items-center gap-2">
                <span className="text-[12px] text-green-500">{portfolioSummary.returnPercent}</span>
                <span className="text-[12px] text-slate-500 dark:text-slate-400">• {portfolioSummary.totalReturn}</span>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] text-slate-500 dark:text-slate-400">Rendimento Mensal</span>
              </div>
              <p className="text-[20px] font-bold text-slate-950 dark:text-white mb-1">{portfolioSummary.monthlyYield}</p>
              <p className="text-[12px] text-slate-500 dark:text-slate-400">Fevereiro</p>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[12px] p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] text-slate-500 dark:text-slate-400">Retorno YTD</span>
              </div>
              <p className="text-[20px] font-bold text-green-500 mb-1">{portfolioSummary.ytdReturn}</p>
              <p className="text-[12px] text-slate-500 dark:text-slate-400">2024</p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 px-8 py-8">
          <div className="grid grid-cols-3 gap-6">
            {/* Left Column - Investments List */}
            <div className="col-span-2 space-y-6">
              {/* Filters */}
              <div className="flex items-center gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Buscar investimentos..."
                    className="w-full h-[48px] pl-11 pr-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] text-slate-950 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="h-[48px] px-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] text-slate-950 dark:text-white focus:outline-none focus:border-blue-500 appearance-none cursor-pointer"
                >
                  <option value="todos">Todos os tipos</option>
                  <option value="CRI">CRI</option>
                  <option value="CRA">CRA</option>
                  <option value="Debênture">Debêntures</option>
                  <option value="FIDC">FIDC</option>
                </select>

                <select
                  value={filterPeriod}
                  onChange={(e) => setFilterPeriod(e.target.value)}
                  className="h-[48px] px-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[14px] text-slate-950 dark:text-white focus:outline-none focus:border-blue-500 appearance-none cursor-pointer"
                >
                  <option value="7d">Últimos 7 dias</option>
                  <option value="30d">Últimos 30 dias</option>
                  <option value="90d">Últimos 90 dias</option>
                  <option value="1y">Último ano</option>
                </select>
              </div>

              {/* Investments Table */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] overflow-hidden">
                <div className="p-4 border-b border-slate-200 dark:border-slate-800">
                  <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white">
                    Meus Investimentos ({investments.length})
                  </h2>
                </div>

                <div className="divide-y divide-slate-200 dark:divide-slate-800">
                  {investments.map((investment) => (
                    <div
                      key={investment.id}
                      className="p-6 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      onClick={() => navigate(`/workspace/operacoes/${investment.id}`)}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-4">
                          <div
                            className="size-12 rounded-[8px] flex items-center justify-center"
                            style={{ backgroundColor: `${getTypeColor(investment.type)}15` }}
                          >
                            <span
                              className="text-[14px] font-bold"
                              style={{ color: getTypeColor(investment.type) }}
                            >
                              {investment.type}
                            </span>
                          </div>

                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white">
                                {investment.code}
                              </h3>
                              <span
                                className="px-2 py-0.5 rounded-[4px] text-[12px] font-semibold"
                                style={{
                                  backgroundColor: `${getTypeColor(investment.type)}15`,
                                  color: getTypeColor(investment.type)
                                }}
                              >
                                {investment.type}
                              </span>
                            </div>
                            <p className="text-[14px] text-slate-500 dark:text-slate-400 mb-2">
                              {investment.issuer}
                            </p>
                            <div className="flex items-center gap-4 text-[12px] text-slate-500 dark:text-slate-400">
                              <span>{investment.rate}</span>
                              <span>•</span>
                              <span>Vencimento: {investment.maturity}</span>
                            </div>
                          </div>
                        </div>

                        <div className="text-right">
                          <p className="text-[20px] font-bold text-slate-950 dark:text-white mb-1">
                            {investment.currentValue}
                          </p>
                          <p
                            className={`text-[14px] font-semibold ${
                              investment.returnColor === "green"
                                ? "text-green-500"
                                : "text-red-500"
                            }`}
                          >
                            {investment.return}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px]">
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-1">Investido</p>
                          <p className="text-[14px] font-semibold text-slate-950 dark:text-white">
                            {investment.investedAmount}
                          </p>
                        </div>

                        <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px]">
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-1">Próximo Pagamento</p>
                          <p className="text-[14px] font-semibold text-slate-950 dark:text-white">
                            {investment.nextPayment}
                          </p>
                        </div>

                        <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px] flex items-center justify-center">
                          <button className="flex items-center gap-2 text-blue-500 hover:text-blue-600 text-[14px] font-semibold">
                            <Eye className="size-4" />
                            Ver Detalhes
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Allocation */}
            <div className="space-y-6">
              {/* Alocação por Tipo */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] p-6">
                <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-6">
                  Alocação por Tipo
                </h2>

                <div className="space-y-4">
                  {allocation.map((item) => (
                    <div key={item.type}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div
                            className="size-3 rounded-full"
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="text-[14px] font-medium text-slate-950 dark:text-white">
                            {item.type}
                          </span>
                        </div>
                        <span className="text-[14px] font-semibold text-slate-950 dark:text-white">
                          {item.percentage}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${item.percentage}%`,
                            backgroundColor: item.color
                          }}
                        />
                      </div>
                      <p className="text-[12px] text-slate-500 dark:text-slate-400 mt-1">{item.value}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Próximos Pagamentos */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[12px] p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Calendar className="size-5 text-blue-500" />
                  <h2 className="text-[18px] font-semibold text-slate-950 dark:text-white">
                    Próximos Pagamentos
                  </h2>
                </div>

                <div className="space-y-3">
                  {investments.slice(0, 3).map((investment) => (
                    <div
                      key={investment.id}
                      className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px]"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[14px] font-semibold text-slate-950 dark:text-white">
                          {investment.code}
                        </span>
                        <span className="text-[12px] text-slate-500 dark:text-slate-400">
                          {investment.nextPayment}
                        </span>
                      </div>
                      <p className="text-[12px] text-slate-500 dark:text-slate-400">{investment.issuer}</p>
                    </div>
                  ))}
                </div>

                <button className="w-full mt-4 py-2 text-[14px] font-semibold text-blue-500 hover:text-blue-600 transition-colors">
                  Ver calendário completo
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}