import { useNavigate } from "react-router";

export function QuotationSuccess() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#212121] flex items-center justify-center relative overflow-hidden">
      {/* Radial Gradient Background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[815px] h-[815px] opacity-15">
          <div className="w-full h-full rounded-full bg-gradient-radial from-[#2e61ff] to-transparent blur-[75.65px]" />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center">
        {/* Bloxs Logo */}
        <div className="absolute top-[-300px] left-1/2 -translate-x-1/2">
          <svg width="104" height="24" viewBox="0 0 104 24" fill="none">
            <text x="0" y="18" fill="white" fontSize="20" fontWeight="600" fontFamily="Poppins">
              bloxs
            </text>
          </svg>
        </div>

        <h1 className="text-[32px] font-semibold text-white leading-normal tracking-[0.48px] mb-6">
          Cotação enviada com sucesso!
        </h1>

        <p className="text-[18px] font-medium text-white leading-normal max-w-[553px] mx-auto mb-12">
          Em breve, nosso time entrará em contato para dar sequência. Você também receberá um e-mail com o resumo da sua cotação e os próximos passos.
        </p>

        <button
          onClick={() => navigate("/home")}
          className="px-6 py-4 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[16px] hover:bg-[#2668dd] transition-colors"
        >
          Voltar para a plataforma
        </button>
      </div>
    </div>
  );
}
