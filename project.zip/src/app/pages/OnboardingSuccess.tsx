import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { CheckCircle2, Rocket, TrendingUp, Users, Building2, Sparkles } from "lucide-react";

export function OnboardingSuccess() {
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(5);
  const [userPersona, setUserPersona] = useState<"sell-side" | "buy-side" | null>(null);

  const handleRedirect = () => {
    if (userPersona === "sell-side") {
      navigate("/workspace/dashboard");
    } else {
      navigate("/home");
    }
  };

  useEffect(() => {
    // Obter persona do usuário
    const persona = localStorage.getItem("userPersona") as "sell-side" | "buy-side" | null;
    setUserPersona(persona);

    // Marcar onboarding como completo
    localStorage.setItem("onboardingComplete", "true");
    localStorage.setItem("onboardingStep", "completed");

    // Countdown para redirecionamento automático
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Separate effect to handle redirect when countdown reaches 0
  useEffect(() => {
    if (countdown === 0 && userPersona) {
      if (userPersona === "sell-side") {
        navigate("/workspace/dashboard");
      } else {
        navigate("/home");
      }
    }
  }, [countdown, userPersona, navigate]);

  const companyData = JSON.parse(localStorage.getItem("companyData") || "{}");

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#212121] via-[#2a2a2a] to-[#1a1a1a] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-[#3482ff]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-[#01bf73]/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-[800px]">
        {/* Success Icon */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="size-24 bg-[#01bf73] rounded-full flex items-center justify-center animate-pulse">
              <CheckCircle2 className="size-12 text-white" />
            </div>
            <div className="absolute -top-2 -right-2">
              <div className="size-8 bg-[#ffc709] rounded-full flex items-center justify-center">
                <Sparkles className="size-5 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="text-center mb-12">
          <h1 className="text-white text-[48px] font-bold mb-4">
            Tudo pronto! 🎉
          </h1>
          <p className="text-[#a4a4a4] text-[20px] max-w-[600px] mx-auto leading-relaxed">
            {companyData.razao_social || "Sua empresa"} está pronta para começar a transformar o Mercado de Capitais
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-4 mb-12">
          {userPersona === "sell-side" ? (
            <>
              <FeatureCard
                icon={Rocket}
                title="Estruture Operações"
                description="Com assistência de IA"
                color="#3482ff"
              />
              <FeatureCard
                icon={Users}
                title="Distribua para Investidores"
                description="Qualificados e verificados"
                color="#01bf73"
              />
              <FeatureCard
                icon={TrendingUp}
                title="Gerencie o Ciclo"
                description="Dashboard completo"
                color="#ffc709"
              />
            </>
          ) : (
            <>
              <FeatureCard
                icon={TrendingUp}
                title="Descubra Oportunidades"
                description="Mercado exclusivo"
                color="#3482ff"
              />
              <FeatureCard
                icon={Building2}
                title="Analise e Compare"
                description="Dados completos"
                color="#01bf73"
              />
              <FeatureCard
                icon={Users}
                title="Gerencie Carteira"
                description="Em tempo real"
                color="#ffc709"
              />
            </>
          )}
        </div>

        {/* Card Principal */}
        <div className="bg-[#292929] border border-[#434343] rounded-[24px] p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-white text-[24px] font-bold mb-2">
                Seu workspace está pronto!
              </h2>
              <p className="text-[#a4a4a4] text-[16px]">
                {userPersona === "sell-side" 
                  ? "Acesse seu dashboard e comece a estruturar operações" 
                  : "Explore o marketplace e encontre as melhores oportunidades"}
              </p>
            </div>
            
            <div className="size-16 bg-[#3482ff]/10 rounded-full flex items-center justify-center">
              <span className="text-[24px] font-bold text-[#3482ff]">{countdown}</span>
            </div>
          </div>

          {/* Progress Steps */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <StepComplete label="Cadastro" />
            <StepComplete label="Persona" />
            <StepComplete label="Perfil" />
            <StepComplete label="Workspace" />
          </div>

          {/* CTA Buttons */}
          <div className="flex gap-4">
            <button
              onClick={handleRedirect}
              className="flex-1 h-[56px] bg-[#3482ff] text-white rounded-[12px] font-semibold text-[16px] hover:bg-[#2668dd] transition-all flex items-center justify-center gap-2 group"
            >
              <span>Ir para {userPersona === "sell-side" ? "Dashboard" : "Marketplace"}</span>
              <Rocket className="size-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Auto-redirect message */}
          <p className="text-[#818181] text-[14px] text-center mt-4">
            Redirecionando automaticamente em {countdown} segundos...
          </p>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-[#818181] text-[14px]">
            Precisa de ajuda? {" "}
            <button 
              onClick={() => window.open("https://help.bloxs.com.br", "_blank")}
              className="text-[#3482ff] hover:underline"
            >
              Acesse nossa Central de Ajuda
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

interface FeatureCardProps {
  icon: typeof Rocket;
  title: string;
  description: string;
  color: string;
}

function FeatureCard({ icon: Icon, title, description, color }: FeatureCardProps) {
  return (
    <div className="bg-[#292929] border border-[#434343] rounded-[16px] p-6 hover:border-[#3482ff] transition-colors">
      <div 
        className="size-12 rounded-[12px] flex items-center justify-center mb-4"
        style={{ backgroundColor: `${color}15` }}
      >
        <Icon className="size-6" style={{ color }} />
      </div>
      <h3 className="text-white text-[16px] font-semibold mb-1">{title}</h3>
      <p className="text-[#a4a4a4] text-[14px]">{description}</p>
    </div>
  );
}

function StepComplete({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center">
      <div className="size-10 bg-[#01bf73] rounded-full flex items-center justify-center mb-2">
        <CheckCircle2 className="size-5 text-white" />
      </div>
      <span className="text-[#a4a4a4] text-[12px] font-medium">{label}</span>
    </div>
  );
}