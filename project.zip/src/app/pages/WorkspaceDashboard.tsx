import { useNavigate } from "react-router";
import { 
  TrendingUp, 
  Users, 
  FileText, 
  Settings, 
  Plus,
  ArrowUpRight,
  Building2,
  Target,
  Shield
} from "lucide-react";

export function WorkspaceDashboard() {
  const navigate = useNavigate();

  const stats = [
    {
      icon: FileText,
      label: "Operações Ativas",
      value: "12",
      change: "+3 este mês",
      trend: "up" as const,
      color: "#3482ff"
    },
    {
      icon: Users,
      label: "Membros do Workspace",
      value: "8",
      change: "2 pendentes",
      trend: "neutral" as const,
      color: "#ffc709"
    },
    {
      icon: TrendingUp,
      label: "Volume Total",
      value: "R$ 45,2M",
      change: "+12% vs mês anterior",
      trend: "up" as const,
      color: "#01bf73"
    },
    {
      icon: Target,
      label: "Matches Ativos",
      value: "24",
      change: "6 novos esta semana",
      trend: "up" as const,
      color: "#3482ff"
    }
  ];

  const quickActions = [
    {
      icon: Plus,
      label: "Nova Operação",
      description: "Criar uma nova operação",
      action: () => navigate("/workspace/operacoes"),
      color: "#3482ff"
    },
    {
      icon: FileText,
      label: "Solicitar Cotação",
      description: "Iniciar pedido de cotação",
      action: () => navigate("/cotacao/etapa-1"),
      color: "#01bf73"
    },
    {
      icon: Users,
      label: "Convidar Membros",
      description: "Adicionar pessoas ao workspace",
      action: () => navigate("/workspace/configuracoes"),
      color: "#ffc709"
    },
    {
      icon: Settings,
      label: "Configurações",
      description: "Gerenciar workspace e permissões",
      action: () => navigate("/workspace/configuracoes"),
      color: "#818181"
    }
  ];

  const recentActivity = [
    {
      type: "operation",
      title: "CRI Imobiliário aprovado",
      description: "Operação #OP-2024-001 foi aprovada",
      time: "2 horas atrás",
      icon: FileText,
      color: "#01bf73"
    },
    {
      type: "member",
      title: "Novo membro adicionado",
      description: "João Silva entrou no workspace",
      time: "5 horas atrás",
      icon: Users,
      color: "#3482ff"
    },
    {
      type: "match",
      title: "Novo match disponível",
      description: "3 investidores interessados na sua operação",
      time: "1 dia atrás",
      icon: Target,
      color: "#ffc709"
    },
    {
      type: "document",
      title: "Documentos enviados",
      description: "Contratos da operação CRA-2024-003",
      time: "2 dias atrás",
      icon: Shield,
      color: "#818181"
    }
  ];

  return (
    <div className="min-h-screen bg-[#212121]">
      {/* Header */}
      <div className="border-b border-[#2e2e2e] px-8 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-[28px] font-bold text-white mb-2">
              Bem-vindo ao seu Workspace
            </h1>
            <p className="text-[14px] text-[#a4a4a4]">
              Gerencie suas operações, membros e configurações em um só lugar
            </p>
          </div>

          <button
            onClick={() => navigate("/workspace/configuracoes")}
            className="px-4 py-2 bg-[#292929] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#3a3a3a] flex items-center gap-2"
          >
            <Settings className="size-4" />
            Configurações
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-[#292929] border border-[#434343] rounded-[12px] p-6 hover:border-[#3482ff]/50 transition-all cursor-pointer"
            >
              <div className="flex items-start justify-between mb-4">
                <div
                  className="size-12 rounded-[8px] flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}15` }}
                >
                  <stat.icon className="size-6" style={{ color: stat.color }} />
                </div>
                {stat.trend === "up" && (
                  <div className="flex items-center gap-1 px-2 py-1 bg-[#01bf73]/10 rounded-[4px]">
                    <ArrowUpRight className="size-3 text-[#01bf73]" />
                    <span className="text-[10px] font-semibold text-[#01bf73]">+12%</span>
                  </div>
                )}
              </div>

              <div className="mb-2">
                <p className="text-[12px] text-[#a4a4a4] mb-1">{stat.label}</p>
                <p className="text-[24px] font-bold text-white">{stat.value}</p>
              </div>

              <p className="text-[12px] text-[#a4a4a4]">{stat.change}</p>
            </div>
          ))}
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-2 gap-6">
          {/* Quick Actions */}
          <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
            <h2 className="text-[18px] font-semibold text-white mb-6">
              Ações rápidas
            </h2>

            <div className="space-y-3">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={action.action}
                  className="w-full flex items-center gap-4 p-4 bg-[#212121] border border-[#434343] rounded-[8px] hover:border-[#3482ff] transition-all text-left"
                >
                  <div
                    className="size-10 rounded-[8px] flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${action.color}15` }}
                  >
                    <action.icon className="size-5" style={{ color: action.color }} />
                  </div>

                  <div className="flex-1">
                    <p className="text-[14px] font-semibold text-white mb-1">
                      {action.label}
                    </p>
                    <p className="text-[12px] text-[#a4a4a4]">
                      {action.description}
                    </p>
                  </div>

                  <ArrowUpRight className="size-5 text-[#818181]" />
                </button>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-6">
            <h2 className="text-[18px] font-semibold text-white mb-6">
              Atividades recentes
            </h2>

            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div
                  key={index}
                  className="flex items-start gap-4 pb-4 border-b border-[#434343] last:border-0 last:pb-0"
                >
                  <div
                    className="size-10 rounded-[8px] flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${activity.color}15` }}
                  >
                    <activity.icon className="size-5" style={{ color: activity.color }} />
                  </div>

                  <div className="flex-1">
                    <p className="text-[14px] font-semibold text-white mb-1">
                      {activity.title}
                    </p>
                    <p className="text-[12px] text-[#a4a4a4] mb-2">
                      {activity.description}
                    </p>
                    <p className="text-[11px] text-[#818181]">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>

            <button className="w-full mt-4 py-2 text-[14px] font-semibold text-[#3482ff] hover:text-[#2668dd] transition-colors">
              Ver todas as atividades
            </button>
          </div>
        </div>

        {/* Workspace Info Banner */}
        <div className="mt-8 bg-gradient-to-r from-[#3482ff]/10 to-[#3482ff]/5 border border-[#3482ff]/20 rounded-[12px] p-6">
          <div className="flex items-center gap-4">
            <div className="size-12 bg-[#3482ff] rounded-[8px] flex items-center justify-center">
              <Building2 className="size-6 text-white" />
            </div>

            <div className="flex-1">
              <h3 className="text-[16px] font-semibold text-white mb-1">
                Complete seu perfil do workspace
              </h3>
              <p className="text-[14px] text-[#a4a4a4]">
                Adicione mais informações para receber recomendações personalizadas
              </p>
            </div>

            <button
              onClick={() => navigate("/workspace/dealmatch")}
              className="px-6 py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd] flex items-center gap-2"
            >
              Configurar Dealmatch
              <ArrowUpRight className="size-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}