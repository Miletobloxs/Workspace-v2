import { useState } from "react";
import { useNavigate } from "react-router";
import { Bell, Info, Search, Plus, Edit2, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { SuccessModal } from "../components/SuccessModal";
import { ErrorModal } from "../components/ErrorModal";
import { AddMemberModal } from "../components/AddMemberModal";
import imgBrazilFlag from "figma:asset/829b3120c34e95f5de6e1742ce9e5a0ad95414ea.png";

type Tab = "dados" | "membros";

export function WorkspaceSettings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("dados");
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);

  // Mock data
  const [workspaceData, setWorkspaceData] = useState({
    razaoSocial: "Bloxs Investimentos S.A.",
    nomeFantasia: "Bloxs",
    cnpj: "12.345.678/0001-90",
    telefone: "+55 11 3456-7890",
    email: "contato@bloxs.com.br",
    cep: "01310-100",
    endereco: "Av. Paulista, 1000",
    numero: "1000",
    complemento: "10º andar",
    bairro: "Bela Vista",
    cidade: "São Paulo",
    estado: "SP",
    pais: "Brasil"
  });

  const [members, setMembers] = useState([
    {
      id: "1",
      name: "Carlos Silva",
      email: "carlos@bloxs.com.br",
      role: "Admin",
      avatar: "https://i.pravatar.cc/150?img=1",
      lastActive: "Online"
    },
    {
      id: "2",
      name: "Maria Santos",
      email: "maria@bloxs.com.br",
      role: "Editor",
      avatar: "https://i.pravatar.cc/150?img=2",
      lastActive: "2 horas atrás"
    },
    {
      id: "3",
      name: "João Oliveira",
      email: "joao@bloxs.com.br",
      role: "Visualizador",
      avatar: "https://i.pravatar.cc/150?img=3",
      lastActive: "1 dia atrás"
    }
  ]);

  const handleSaveWorkspaceData = () => {
    // Simular salvamento
    setTimeout(() => {
      setShowSuccessModal(true);
    }, 500);
  };

  const handleAddMember = (memberData: any) => {
    // Simular adição de membro
    const newMember = {
      id: String(members.length + 1),
      name: memberData.name,
      email: memberData.email,
      role: memberData.role,
      avatar: `https://i.pravatar.cc/150?img=${members.length + 4}`,
      lastActive: "Agora"
    };
    setMembers([...members, newMember]);
    setShowAddMemberModal(false);
    setShowSuccessModal(true);
  };

  return (
    <div className="min-h-screen bg-[#212121]">
      {/* Header */}
      <div className="border-b border-[#2e2e2e] px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-[28px] font-bold text-white mb-2">
              Configurações do Workspace
            </h1>
            <p className="text-[14px] text-[#a4a4a4]">
              Gerencie os dados do seu workspace e membros da equipe
            </p>
          </div>

          <button className="p-2 bg-[#292929] border border-[#434343] rounded-[8px] text-white hover:border-[#3482ff] relative">
            <Bell className="size-5" />
            <div className="absolute top-1 right-1 size-2 bg-[#c50000] rounded-full" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-[#434343]">
          <button
            onClick={() => setActiveTab("dados")}
            className={`px-6 py-3 text-[14px] font-semibold border-b-2 transition-colors ${
              activeTab === "dados"
                ? "text-[#3482ff] border-[#3482ff]"
                : "text-[#a4a4a4] border-transparent hover:text-white"
            }`}
          >
            Dados do Workspace
          </button>
          <button
            onClick={() => setActiveTab("membros")}
            className={`px-6 py-3 text-[14px] font-semibold border-b-2 transition-colors ${
              activeTab === "membros"
                ? "text-[#3482ff] border-[#3482ff]"
                : "text-[#a4a4a4] border-transparent hover:text-white"
            }`}
          >
            Membros da Equipe
          </button>
        </div>
      </div>

      <div className="px-8 py-8">
        {/* Tab: Dados do Workspace */}
        {activeTab === "dados" && (
          <div className="max-w-[900px]">
            <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-8">
              <h2 className="text-[20px] font-semibold text-white mb-6">
                Informações da Empresa
              </h2>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[14px] text-white mb-2">Razão Social</label>
                    <input
                      type="text"
                      value={workspaceData.razaoSocial}
                      onChange={(e) =>
                        setWorkspaceData({ ...workspaceData, razaoSocial: e.target.value })
                      }
                      className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                    />
                  </div>

                  <div>
                    <label className="block text-[14px] text-white mb-2">Nome Fantasia</label>
                    <input
                      type="text"
                      value={workspaceData.nomeFantasia}
                      onChange={(e) =>
                        setWorkspaceData({ ...workspaceData, nomeFantasia: e.target.value })
                      }
                      className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[14px] text-white mb-2">CNPJ</label>
                    <input
                      type="text"
                      value={workspaceData.cnpj}
                      onChange={(e) =>
                        setWorkspaceData({ ...workspaceData, cnpj: e.target.value })
                      }
                      className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                    />
                  </div>

                  <div>
                    <label className="block text-[14px] text-white mb-2">Telefone</label>
                    <input
                      type="text"
                      value={workspaceData.telefone}
                      onChange={(e) =>
                        setWorkspaceData({ ...workspaceData, telefone: e.target.value })
                      }
                      className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[14px] text-white mb-2">Email</label>
                  <input
                    type="email"
                    value={workspaceData.email}
                    onChange={(e) =>
                      setWorkspaceData({ ...workspaceData, email: e.target.value })
                    }
                    className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                  />
                </div>

                <div className="pt-4 border-t border-[#434343]">
                  <h3 className="text-[16px] font-semibold text-white mb-4">Endereço</h3>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="col-span-1">
                      <label className="block text-[14px] text-white mb-2">CEP</label>
                      <input
                        type="text"
                        value={workspaceData.cep}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, cep: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>

                    <div className="col-span-2">
                      <label className="block text-[14px] text-white mb-2">Endereço</label>
                      <input
                        type="text"
                        value={workspaceData.endereco}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, endereco: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-[14px] text-white mb-2">Número</label>
                      <input
                        type="text"
                        value={workspaceData.numero}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, numero: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>

                    <div className="col-span-2">
                      <label className="block text-[14px] text-white mb-2">Complemento</label>
                      <input
                        type="text"
                        value={workspaceData.complemento}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, complemento: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[14px] text-white mb-2">Bairro</label>
                      <input
                        type="text"
                        value={workspaceData.bairro}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, bairro: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>

                    <div>
                      <label className="block text-[14px] text-white mb-2">Cidade</label>
                      <input
                        type="text"
                        value={workspaceData.cidade}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, cidade: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>

                    <div>
                      <label className="block text-[14px] text-white mb-2">Estado</label>
                      <input
                        type="text"
                        value={workspaceData.estado}
                        onChange={(e) =>
                          setWorkspaceData({ ...workspaceData, estado: e.target.value })
                        }
                        className="w-full h-[48px] px-4 bg-transparent border border-[#818181] rounded-[6px] text-[14px] text-white focus:outline-none focus:border-[#3482ff]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <button
                    onClick={() => navigate("/workspace/dashboard")}
                    className="px-6 py-3 bg-[#292929] border border-[#434343] text-white rounded-[8px] font-semibold text-[14px] hover:border-[#3482ff]"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleSaveWorkspaceData}
                    className="px-6 py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd]"
                  >
                    Salvar Alterações
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab: Membros */}
        {activeTab === "membros" && (
          <div className="max-w-[900px]">
            <div className="bg-[#292929] border border-[#434343] rounded-[12px] p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-[20px] font-semibold text-white">
                  Membros da Equipe ({members.length})
                </h2>

                <button
                  onClick={() => setShowAddMemberModal(true)}
                  className="px-4 py-2 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd] flex items-center gap-2"
                >
                  <Plus className="size-4" />
                  Adicionar Membro
                </button>
              </div>

              <div className="space-y-3">
                {members.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-4 bg-[#212121] border border-[#434343] rounded-[8px] hover:border-[#3482ff]/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="size-12 rounded-full"
                      />
                      <div>
                        <h3 className="text-[14px] font-semibold text-white mb-1">
                          {member.name}
                        </h3>
                        <p className="text-[12px] text-[#a4a4a4]">{member.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-[12px] font-semibold text-white mb-1">
                          {member.role}
                        </p>
                        <p className="text-[11px] text-[#a4a4a4]">{member.lastActive}</p>
                      </div>

                      <button className="p-2 bg-[#292929] border border-[#434343] rounded-[6px] text-white hover:border-[#3482ff]">
                        <Edit2 className="size-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {showSuccessModal && (
        <SuccessModal
          message="Alterações salvas com sucesso!"
          onClose={() => setShowSuccessModal(false)}
        />
      )}

      {showErrorModal && (
        <ErrorModal
          message="Erro ao salvar alterações. Tente novamente."
          onClose={() => setShowErrorModal(false)}
        />
      )}

      {showAddMemberModal && (
        <AddMemberModal
          onClose={() => setShowAddMemberModal(false)}
          onAdd={handleAddMember}
        />
      )}
    </div>
  );
}
