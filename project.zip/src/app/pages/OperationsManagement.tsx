import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, Bell, Info, TrendingUp, Users as UsersIcon, Clock, BarChart3, ChevronLeft, ChevronRight, MoreVertical, Lock, Download, Eye, ThumbsUp } from "lucide-react";
import { Sidebar } from "../components/Sidebar";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function OperationsManagement() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"ongoing" | "closed" | "drafts">("ongoing");
  const [currentPage, setCurrentPage] = useState(1);

  // Mock data para o gráfico
  const chartData = [
    { date: "10 Dez", value: 0 },
    { date: "11 Dez", value: 150 },
    { date: "12 Dez", value: 400 },
    { date: "13 Dez", value: 1000 },
    { date: "14 Dez", value: 2500 },
    { date: "15 Dez", value: 5000 },
    { date: "16 Dez", value: 3000 },
    { date: "17 Dez", value: 7000 },
    { date: "18 Dez", value: 8500 },
    { date: "19 Dez", value: 9000 },
  ];

  const operations = [
    {
      id: "BS2#001",
      name: "Neialy Lima",
      volume: "R$ 100.000.000,00",
      sector: "Infraestrutura",
      status: "Concluído",
      statusColor: "green",
      date: "17/10/2025 - 10:00",
      locked: true,
    },
    {
      id: "BS2#002",
      name: "Caio Paixão",
      volume: "R$ 100.000.000,00",
      sector: "Infraestrutura",
      status: "Em revisão",
      statusColor: "orange",
      date: "17/10/2025 - 10:00",
      locked: false,
    },
    {
      id: "BS2#003",
      name: "Lucas Ayres",
      volume: "R$ 10.000.000,00",
      sector: "Infraestrutura",
      status: "Concluído",
      statusColor: "green",
      date: "17/10/2025 - 10:00",
      locked: true,
    },
    {
      id: "BS2#004",
      name: "Filipe Goes",
      volume: "R$ 80.000.000,00",
      sector: "Infraestrutura",
      status: "Em revisão",
      statusColor: "orange",
      date: "17/10/2025 - 10:00",
      locked: false,
    },
    {
      id: "BS2#005",
      name: "Lucas Recout",
      volume: "R$ 1.000.000.000,00",
      sector: "Infraestrutura",
      status: "Concluído",
      statusColor: "green",
      date: "17/10/2025 - 10:00",
      locked: true,
    },
    {
      id: "BS2#006",
      name: "Filipe Goes",
      volume: "R$ 80.000.000,00",
      sector: "Infraestrutura",
      status: "Em revisão",
      statusColor: "orange",
      date: "17/10/2025 - 10:00",
      locked: false,
    },
  ];

  const recentActivities = [
    {
      icon: <UsersIcon className="size-4" />,
      text: "XP Asset solicitou acesso à operação",
      time: "10/02/2024 - 12:13",
    },
    {
      icon: <Download className="size-4" />,
      text: "BTG Pactual baixou o investment deck",
      time: "10/02/2024 - 10:30",
    },
    {
      icon: <Download className="size-4" />,
      text: "XP Asset baixou documentos do Data Room",
      time: "10/02/2024 - 12:13",
    },
    {
      icon: <ThumbsUp className="size-4" />,
      text: "BTG Pactual demonstrou interesse indicativo na operação",
      time: "10/02/2024 - 10:30",
    },
    {
      icon: <Eye className="size-4" />,
      text: "XP Asset baixou documentos do Data Room",
      time: "10/02/2024 - 10:30",
    },
    {
      icon: <Download className="size-4" />,
      text: "XP Asset baixou documentos do Data Room",
      time: "10/02/2024 - 10:30",
    },
    {
      icon: <UsersIcon className="size-4" />,
      text: "XP Asset solicitou acesso à operação BS2#001. Acessar solicitação",
      time: "10/02/2024 - 12:13",
      link: true,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-[14px] text-slate-500">
              <button onClick={() => navigate("/home")} className="hover:text-slate-950 dark:hover:text-white">
                Operações
              </button>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <svg className="size-5 text-slate-600 dark:text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <circle cx="12" cy="12" r="10" strokeWidth={2} />
                </svg>
              </button>

              <button className="relative p-2 rounded-[8px] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-400" />
                <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
              </button>

              <div className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-700">
                <div className="size-[40px] bg-[#2e61ff] rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-[14px]">BC</span>
                </div>
                <div>
                  <p className="text-[14px] font-semibold text-slate-950 dark:text-white">Bloxs Capital Partners LTDA</p>
                  <p className="text-[12px] text-slate-500">41.847.533/0001-90</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          {/* Tabs */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex gap-2">
              <button className="px-4 py-2 rounded-[8px] bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[14px] font-medium relative">
                <RefreshCw className="inline-block size-4 mr-2" />
                Consulta de viabilidade
              </button>
              <button className="px-4 py-2 rounded-[8px] text-slate-600 dark:text-slate-400 text-[14px] font-medium hover:text-slate-900 dark:hover:text-white">
                Ofertas públicas
              </button>
            </div>

            <button className="flex items-center gap-2 px-4 py-2 bg-[#2e61ff] text-white rounded-[8px] text-[14px] font-medium hover:bg-[#1b41f5] transition-colors">
              <svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Listar nova operação
            </button>
          </div>

          {/* Overview Section */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-6">
              <h2 className="text-[20px] font-semibold text-slate-950 dark:text-white">Overview</h2>
              <div className="relative group">
                <div className="bg-slate-800 dark:bg-slate-700 text-white text-[12px] px-3 py-2 rounded-[8px]">
                  <p className="font-semibold mb-1">Em consulta de viabilidade</p>
                  <p className="text-slate-300">Veja das operações em fase inicial de avaliação.</p>
                </div>
              </div>
            </div>

            {/* Metrics Cards */}
            <div className="grid grid-cols-4 gap-6 mb-8">
              <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Em consulta de viabilidade</span>
                    <Info className="size-4 text-slate-400" />
                  </div>
                  <ChevronRight className="size-5 text-slate-400" />
                </div>
                <div className="flex items-end gap-2">
                  <p className="text-[32px] font-bold text-slate-950 dark:text-white">R$ 1.2M</p>
                  <span className="text-[12px] text-red-500 bg-red-50 dark:bg-red-950 px-2 py-0.5 rounded-[4px] mb-2">
                    -3 deals
                  </span>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between text-[12px] text-slate-600 dark:text-slate-400 mb-2">
                    <span>R$ 300K para o objetivo</span>
                    <span>62%</span>
                  </div>
                  <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '62%' }} />
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Buy Sides engajados</span>
                    <Info className="size-4 text-slate-400" />
                  </div>
                </div>
                <p className="text-[32px] font-bold text-slate-950 dark:text-white mb-4">24</p>
                <div className="flex items-center -space-x-2">
                  {['bg-blue-500', 'bg-purple-500', 'bg-gray-700', 'bg-pink-500'].map((color, i) => (
                    <div key={i} className={`size-8 ${color} rounded-full border-2 border-white dark:border-slate-800 flex items-center justify-center`}>
                      <span className="text-white text-[10px] font-semibold">
                        {['BS', 'XP', 'SA', 'IT'][i]}
                      </span>
                    </div>
                  ))}
                  <div className="size-8 bg-slate-200 dark:bg-slate-700 rounded-full border-2 border-white dark:border-slate-800 flex items-center justify-center">
                    <span className="text-slate-600 dark:text-slate-400 text-[10px] font-semibold">+18</span>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Concluídos</span>
                    <Info className="size-4 text-slate-400" />
                  </div>
                </div>
                <div className="flex items-end gap-2 mb-4">
                  <p className="text-[32px] font-bold text-slate-950 dark:text-white">R$ 10M</p>
                  <span className="text-[12px] text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-[4px] mb-2">
                    5 deals
                  </span>
                </div>
                <div className="flex gap-2">
                  <div className="flex-1 h-2 bg-emerald-500 rounded-full" />
                  <div className="flex-1 h-2 bg-orange-500 rounded-full" />
                  <div className="flex-[0.5] h-2 bg-slate-200 dark:bg-slate-700 rounded-full" />
                </div>
                <div className="flex gap-4 mt-2 text-[11px]">
                  <span className="flex items-center gap-1">
                    <div className="size-2 bg-emerald-500 rounded-full" />
                    <span className="text-slate-600 dark:text-slate-400">Imobiliário</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <div className="size-2 bg-orange-500 rounded-full" />
                    <span className="text-slate-600 dark:text-slate-400">Agronegócio</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <div className="size-2 bg-slate-200 dark:bg-slate-700 rounded-full" />
                    <span className="text-slate-600 dark:text-slate-400">Outros</span>
                  </span>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[14px] text-slate-600 dark:text-slate-400">Tempo médio das operações</span>
                    <Info className="size-4 text-slate-400" />
                  </div>
                </div>
                <p className="text-[32px] font-bold text-slate-950 dark:text-white mb-4">12 dias</p>
                <div className="flex gap-2">
                  {[60, 80, 40, 90].map((height, i) => (
                    <div key={i} className="flex-1 bg-[#2e61ff] rounded-[4px]" style={{ height: `${height}px` }} />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Chart Section */}
          <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 p-6 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-[18px] font-semibold text-slate-950 dark:text-white">Acesso nos últimos 30 dias</h3>
              <div className="flex items-center gap-3">
                <button className="text-[12px] text-[#2e61ff] bg-blue-50 dark:bg-blue-950 px-3 py-1 rounded-[6px]">
                  BS2#003
                </button>
                <select className="text-[14px] text-slate-600 dark:text-slate-400 bg-transparent border-none cursor-pointer">
                  <option>Operações</option>
                </select>
              </div>
            </div>
            
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" className="dark:stroke-slate-700" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                  }}
                />
                <Line type="monotone" dataKey="value" stroke="#2e61ff" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Operations Table */}
          <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700">
            <div className="p-6 border-b border-slate-200 dark:border-slate-700">
              <div className="flex gap-6 mb-6">
                <button
                  onClick={() => setActiveTab("ongoing")}
                  className={`pb-2 text-[14px] font-medium border-b-2 transition-colors ${
                    activeTab === "ongoing"
                      ? "border-[#2e61ff] text-slate-950 dark:text-white"
                      : "border-transparent text-slate-600 dark:text-slate-400"
                  }`}
                >
                  <RefreshCw className="inline-block size-4 mr-2" />
                  Em andamento
                </button>
                <button
                  onClick={() => setActiveTab("closed")}
                  className={`pb-2 text-[14px] font-medium border-b-2 transition-colors ${
                    activeTab === "closed"
                      ? "border-[#2e61ff] text-slate-950 dark:text-white"
                      : "border-transparent text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Encerradas
                </button>
                <button
                  onClick={() => setActiveTab("drafts")}
                  className={`pb-2 text-[14px] font-medium border-b-2 transition-colors ${
                    activeTab === "drafts"
                      ? "border-[#2e61ff] text-slate-950 dark:text-white"
                      : "border-transparent text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Rascunhos
                </button>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Pesquisar"
                  className="w-full pl-10 pr-4 py-2 rounded-[8px] border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-950 dark:text-white text-[14px] placeholder-slate-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 dark:bg-slate-900">
                  <tr className="text-left text-[12px] text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                    <th className="px-6 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        Operação
                        <button>
                          <ChevronRight className="size-4 rotate-90" />
                        </button>
                      </div>
                    </th>
                    <th className="px-6 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        Volume
                        <button>
                          <ChevronRight className="size-4 rotate-90" />
                        </button>
                      </div>
                    </th>
                    <th className="px-6 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        Setor
                        <button>
                          <ChevronRight className="size-4 rotate-90" />
                        </button>
                      </div>
                    </th>
                    <th className="px-6 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        Status
                        <button>
                          <ChevronRight className="size-4 rotate-90" />
                        </button>
                      </div>
                    </th>
                    <th className="px-6 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        Data de publicação
                        <button>
                          <ChevronRight className="size-4 rotate-90" />
                        </button>
                      </div>
                    </th>
                    <th className="px-6 py-3 font-medium"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {operations.map((operation, index) => (
                    <tr key={index} className="hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          {operation.locked && <Lock className="size-4 text-slate-400" />}
                          <div>
                            <p className="text-[14px] font-semibold text-slate-950 dark:text-white">{operation.id}</p>
                            <p className="text-[12px] text-slate-600 dark:text-slate-400">{operation.name}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-[14px] text-slate-950 dark:text-white">{operation.volume}</td>
                      <td className="px-6 py-4 text-[14px] text-slate-600 dark:text-slate-400">{operation.sector}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-3 py-1 rounded-[6px] text-[12px] font-medium ${
                          operation.statusColor === "green"
                            ? "bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300"
                            : "bg-orange-50 dark:bg-orange-950 text-orange-700 dark:text-orange-300"
                        }`}>
                          {operation.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-[14px] text-slate-600 dark:text-slate-400">{operation.date}</td>
                      <td className="px-6 py-4">
                        <button className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-[4px]">
                          <MoreVertical className="size-4 text-slate-400" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-700">
              <span className="text-[14px] text-slate-600 dark:text-slate-400">1 de 6</span>
              <div className="flex items-center gap-2">
                <button className="size-8 flex items-center justify-center rounded-[6px] hover:bg-slate-100 dark:hover:bg-slate-700">
                  <ChevronLeft className="size-4 text-slate-600 dark:text-slate-400" />
                </button>
                {[1, 2, 3, "...", 4, 5].map((page, i) => (
                  <button
                    key={i}
                    className={`size-8 flex items-center justify-center rounded-[6px] text-[14px] ${
                      page === currentPage
                        ? "bg-[#2e61ff] text-white"
                        : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button className="size-8 flex items-center justify-center rounded-[6px] hover:bg-slate-100 dark:hover:bg-slate-700">
                  <ChevronRight className="size-4 text-slate-600 dark:text-slate-400" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity Sidebar */}
      <div className="w-[340px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 p-6">
        <div className="flex items-center gap-2 mb-6">
          <Clock className="size-5 text-slate-600 dark:text-slate-400" />
          <h3 className="text-[16px] font-semibold text-slate-950 dark:text-white">Histórico recente</h3>
        </div>

        <div className="space-y-4">
          {recentActivities.map((activity, index) => (
            <div key={index} className="flex gap-3">
              <div className="size-8 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center flex-shrink-0 text-slate-600 dark:text-slate-400">
                {activity.icon}
              </div>
              <div className="flex-1">
                <p className="text-[14px] text-slate-950 dark:text-white leading-relaxed">
                  {activity.text}
                  {activity.link && (
                    <button className="text-[#2e61ff] hover:underline ml-1">
                      Acessar solicitação
                    </button>
                  )}
                </p>
                <p className="text-[12px] text-slate-500 mt-1">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Import necessário
import { RefreshCw } from "lucide-react";
