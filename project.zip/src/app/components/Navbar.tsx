import { Logo } from "./Logo";
import { Bell } from "lucide-react";
import svgPaths from "../../imports/svg-pz712mnydb";

export function Navbar() {
  return (
    <div className="bg-white dark:bg-slate-900 h-[80px] relative shrink-0 w-full z-[3] border-b border-slate-200 dark:border-slate-800">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between px-[72px] py-[16px] relative size-full">
          <Logo />
          
          <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
            <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
              <button className="bg-white dark:bg-slate-800 content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0 border border-slate-200 dark:border-slate-700">
                <div className="relative shrink-0 size-[24px]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
                    <g>
                      <circle cx="23.2941" cy="19" opacity="0.1" r="14.5" stroke="url(#paint0_linear)" />
                      <g filter="url(#filter0_dddddddi)">
                        <circle cx="23.2941" cy="19" fill="#2E61FF" r="11.2941" />
                      </g>
                      <g>
                        <circle cx="18.8312" cy="1.9707" fill="#2E61FF" fillOpacity="0.7" opacity="0.3" r="0.75" />
                        <circle cx="10.0441" cy="3.75" fill="#2E61FF" fillOpacity="0.7" r="0.75" />
                        <circle cx="33.0441" cy="4.75" fill="#2E61FF" fillOpacity="0.7" r="0.75" />
                        <circle cx="40.0441" cy="9.75" fill="#2E61FF" fillOpacity="0.7" opacity="0.3" r="0.75" />
                        <circle cx="9.04412" cy="10.75" fill="#2E61FF" fillOpacity="0.7" opacity="0.3" r="0.75" />
                      </g>
                      <g>
                        <path d={svgPaths.p1063c100} fill="white" />
                        <path d={svgPaths.p17307780} fill="white" />
                      </g>
                    </g>
                    <defs>
                      <filter id="filter0_dddddddi" colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" width="46.5882" x="0" y="6.70588">
                        <feFlood floodOpacity="0" result="BackgroundImageFix" />
                        <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                      </filter>
                      <linearGradient id="paint0_linear" gradientUnits="userSpaceOnUse" x1="23.2941" x2="23.2941" y1="4" y2="34">
                        <stop stopColor="#2E61FF" stopOpacity="0" />
                        <stop offset="1" stopColor="#2E61FF" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </button>

              <button className="bg-white dark:bg-slate-800 content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0 border border-slate-200 dark:border-slate-700">
                <Bell className="size-[24px] text-slate-500" />
              </button>
              
              <div className="relative">
                <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]">
                  <div className="absolute bg-[#fb2c36] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-[9999px] size-[8px]" />
                </div>
              </div>
            </div>

            <div className="bg-slate-200 dark:bg-slate-700 h-[24px] rounded-[9999px] shrink-0 w-[2px]" />

            <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0">
              <div className="bg-slate-100 dark:bg-slate-800 relative rounded-[9999px] shrink-0 size-[40px]">
                <svg className="absolute left-0 size-[40px] top-0" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
                  <g>
                    <path d={svgPaths.pf5fe180} fill="white" />
                    <path d={svgPaths.p22fee400} fill="#E2E8F0" />
                    <path d={svgPaths.p33c16900} fill="#E2E8F0" />
                  </g>
                </svg>
              </div>
              
              <div className="content-stretch flex flex-col items-start not-italic relative shrink-0">
                <p className="font-medium leading-[1.4] text-slate-950 dark:text-white text-[14px] whitespace-nowrap">Sem empresa cadastrada</p>
                <p className="font-normal leading-[1.4] text-slate-500 text-[12px]">Ative seu workspace</p>
              </div>

              <svg className="size-[24px]" fill="none" viewBox="0 0 24 24">
                <path d="M8 10L12 14L16 10" stroke="currentColor" className="text-slate-500" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
