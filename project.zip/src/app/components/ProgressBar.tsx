import { Check } from "lucide-react";

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export function ProgressBar({ currentStep, totalSteps }: ProgressBarProps) {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full">
      {Array.from({ length: totalSteps }).map((_, index) => {
        const stepNumber = index + 1;
        const isCompleted = stepNumber < currentStep;
        const isCurrent = stepNumber === currentStep;

        return (
          <div key={stepNumber} className="flex items-center flex-1">
            <div className="relative shrink-0 size-[24px]">
              {isCompleted ? (
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="12" fill="#2E61FF" />
                  <Check className="absolute inset-0 m-auto size-4 text-white" strokeWidth={2.5} />
                </svg>
              ) : isCurrent ? (
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="12" fill="#2E61FF" />
                  <circle cx="12" cy="12" r="5" fill="white" />
                </svg>
              ) : (
                <div className="bg-white border-[1.2px] border-slate-300 dark:border-slate-600 border-solid rounded-full size-full flex items-center justify-center">
                  <span className="font-semibold text-slate-500 text-[12px] uppercase tracking-[1.2px]">{stepNumber}</span>
                </div>
              )}
            </div>
            
            {index < totalSteps - 1 && (
              <div className="flex flex-1 h-[2px] items-center justify-center min-h-px min-w-px mx-3">
                <div className={`h-[2px] w-full rounded-full ${
                  isCompleted ? 'bg-[#1b41f5]' : 'bg-slate-200 dark:bg-slate-700'
                }`} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
