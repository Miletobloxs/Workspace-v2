import { Heart, Download, FileText, FileCheck, Bell, TrendingUp, Clock, Users, BarChart } from "lucide-react";
import { useState } from "react";

interface Guarantee {
  type: string;
  value: string;
  status: string;
}

interface Operation {
  id: string;
  commercialName: string; // Nome comercial (ex: "CRI Fictor I")
  sellSideName: string;
  sellSideLogo?: string;
  type: "Oferta Pública" | "Consulta de Viabilidade";
  sector: string;
  volume: string;
  deadline: string;
  remuneration: string;
  risk: "Baixo" | "Médio" | "Alto";
  instruments: string[];
  guarantees: Guarantee[];
  documents: {
    prospectus?: string;
    factSheet?: string;
    announcement?: string;
  };
  liquidationStatus?: "pending" | "received" | "processing";
  liquidationValue?: string;
  liquidationDate?: string;
  isFavorite?: boolean;
  badges?: string[];
  
  // Campos específicos de Oferta Pública
  availableQuotas?: number;
  totalQuotas?: number;
  minInvestment?: string;
  startDate?: string;
  endDate?: string;
  
  // Campos específicos de Consulta de Viabilidade
  viabilityStatus?: "pre_approved" | "viable" | "structuring";
  estimatedLaunch?: string;
  analysisProgress?: number;
  interestedInvestors?: number;
}

interface OperationCardProps {
  operation: Operation;
  onLearnMore: (id: string) => void;
  onToggleFavorite?: (id: string) => void;
  onInterest?: (id: string, name: string) => void;
}

export function OperationCard({ operation, onLearnMore, onToggleFavorite, onInterest }: OperationCardProps) {
  const [favorite, setFavorite] = useState(operation.isFavorite || false);

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorite(!favorite);
    onToggleFavorite?.(operation.id);
  };

  // Filtrar garantias com valor zerado
  const validGuarantees = operation.guarantees.filter((g) => {
    const numValue = parseFloat(g.value.replace(/[^\d,]/g, "").replace(",", "."));
    return numValue > 0 || ["Aval", "Fiduciária", "Alienação Fiduciária"].includes(g.type);
  });

  // Badge de risco
  const riskColor = {
    Baixo: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
    Médio: "bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300",
    Alto: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300",
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-[16px] border border-slate-200 dark:border-slate-700 hover:border-[#2e61ff] dark:hover:border-[#2e61ff] transition-all hover:shadow-lg group">
      {/* Header com Avatar e Favorito */}
      <div className="p-6 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-3 flex-1">
            {operation.sellSideLogo ? (
              <img
                src={operation.sellSideLogo}
                alt={operation.sellSideName}
                className="size-12 rounded-[12px] object-cover"
              />
            ) : (
              <div className="size-12 bg-gradient-to-br from-[#2e61ff] to-[#1b41f5] rounded-[12px] flex items-center justify-center">
                <span className="text-white font-bold text-[16px]">
                  {operation.sellSideName.charAt(0)}
                </span>
              </div>
            )}
            <div className="flex-1 min-w-0">
              <h3 className="text-[18px] font-semibold text-slate-950 dark:text-white mb-1 truncate">
                {operation.commercialName}
              </h3>
              <p className="text-[14px] text-slate-600 dark:text-slate-400 truncate">
                {operation.sellSideName}
              </p>
            </div>
          </div>

          <button
            onClick={handleFavorite}
            className={`size-10 rounded-full flex items-center justify-center transition-all ${
              favorite
                ? "bg-red-50 dark:bg-red-950 text-red-500"
                : "bg-slate-100 dark:bg-slate-700 text-slate-400 hover:text-red-500"
            }`}
          >
            <Heart className={`size-5 ${favorite ? "fill-current" : ""}`} />
          </button>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-2">
          <span className="px-3 py-1 bg-[#2e61ff]/10 text-[#2e61ff] rounded-[6px] text-[12px] font-medium">
            {operation.type}
          </span>
          <span className={`px-3 py-1 rounded-[6px] text-[12px] font-medium ${riskColor[operation.risk]}`}>
            Risco {operation.risk}
          </span>
          {operation.badges?.map((badge, i) => (
            <span
              key={i}
              className="px-3 py-1 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-[6px] text-[12px] font-medium"
            >
              {badge}
            </span>
          ))}
        </div>
      </div>

      {/* Status de Liquidação (se aplicável) */}
      {operation.liquidationStatus && (
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900 border-b border-emerald-200 dark:border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="size-10 bg-emerald-500 rounded-full flex items-center justify-center">
              <FileCheck className="size-5 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <div className="size-2 bg-emerald-500 rounded-full animate-pulse" />
                <p className="text-[14px] font-semibold text-emerald-900 dark:text-emerald-100">
                  {operation.liquidationStatus === "received" && "✅ Valor Recebido"}
                  {operation.liquidationStatus === "processing" && "⏳ Em Processamento"}
                  {operation.liquidationStatus === "pending" && "⏸️ Aguardando Confirmação"}
                </p>
              </div>
              {operation.liquidationValue && (
                <p className="text-[12px] text-emerald-700 dark:text-emerald-300">
                  {operation.liquidationValue} • {operation.liquidationDate}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Detalhes da Operação */}
      <div className="p-6 space-y-4">
        {/* Grid de Informações */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Volume</p>
            <p className="text-[16px] font-semibold text-slate-950 dark:text-white">
              {operation.volume}
            </p>
          </div>
          <div>
            <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Prazo</p>
            <p className="text-[16px] font-semibold text-slate-950 dark:text-white">
              {operation.deadline}
            </p>
          </div>
          <div>
            <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Remuneração</p>
            <p className="text-[16px] font-semibold text-slate-950 dark:text-white">
              {operation.remuneration}
            </p>
          </div>
          <div>
            <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-1">Setor</p>
            <p className="text-[16px] font-semibold text-slate-950 dark:text-white truncate">
              {operation.sector}
            </p>
          </div>
        </div>

        {/* Instrumentos */}
        {operation.instruments.length > 0 && (
          <div>
            <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-2">
              Possíveis instrumentos
            </p>
            <div className="flex flex-wrap gap-2">
              {operation.instruments.map((instrument, i) => (
                <span
                  key={i}
                  className="px-2 py-1 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-[4px] text-[11px] font-medium"
                >
                  {instrument}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Garantias Inteligentes */}
        {validGuarantees.length > 0 && (
          <div>
            <p className="text-[12px] text-slate-500 dark:text-slate-400 mb-2">Garantias</p>
            <div className="space-y-2">
              {validGuarantees.map((guarantee, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-[8px]"
                >
                  <div className="flex items-center gap-2">
                    <div className="size-6 bg-emerald-100 dark:bg-emerald-950 rounded-full flex items-center justify-center">
                      <FileCheck className="size-3 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <span className="text-[13px] font-medium text-slate-900 dark:text-white">
                      {guarantee.type}
                    </span>
                  </div>
                  <div className="text-right">
                    {parseFloat(guarantee.value.replace(/[^\\d,]/g, "").replace(",", ".")) > 0 ? (
                      <p className="text-[13px] font-semibold text-slate-900 dark:text-white">
                        {guarantee.value}
                      </p>
                    ) : (
                      <span className="text-[11px] px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-[4px]">
                        {guarantee.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STATUS ESPECÍFICOS POR TIPO DE DEAL */}
        
        {/* OFERTA PÚBLICA - Informações de Disponibilidade */}
        {operation.type === "Oferta Pública" && operation.availableQuotas && (
          <div className="p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-[12px]">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="size-4 text-blue-600 dark:text-blue-400" />
              <p className="text-[12px] font-semibold text-blue-900 dark:text-blue-100 uppercase tracking-wide">
                Disponível para Investimento
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <p className="text-[10px] text-blue-600 dark:text-blue-400 mb-1">Cotas Disponíveis</p>
                <p className="text-[14px] font-bold text-blue-900 dark:text-blue-100">
                  {operation.availableQuotas.toLocaleString()} / {operation.totalQuotas?.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-blue-600 dark:text-blue-400 mb-1">Investimento Mínimo</p>
                <p className="text-[14px] font-bold text-blue-900 dark:text-blue-100">
                  {operation.minInvestment}
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            {operation.totalQuotas && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-blue-600 dark:text-blue-400">Ocupação</span>
                  <span className="text-[10px] font-semibold text-blue-900 dark:text-blue-100">
                    {Math.round(((operation.totalQuotas - operation.availableQuotas) / operation.totalQuotas) * 100)}%
                  </span>
                </div>
                <div className="h-2 bg-blue-100 dark:bg-blue-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-500 rounded-full transition-all"
                    style={{ 
                      width: `${((operation.totalQuotas - operation.availableQuotas) / operation.totalQuotas) * 100}%` 
                    }}
                  />
                </div>
              </div>
            )}

            {operation.endDate && (
              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-blue-200 dark:border-blue-800">
                <Clock className="size-3 text-blue-600 dark:text-blue-400" />
                <p className="text-[11px] text-blue-700 dark:text-blue-300">
                  Oferta encerra em: <span className="font-semibold">{operation.endDate}</span>
                </p>
              </div>
            )}
          </div>
        )}

        {/* CONSULTA DE VIABILIDADE - Status de Análise */}
        {operation.type === "Consulta de Viabilidade" && operation.viabilityStatus && (
          <div className="p-4 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-[12px]">
            <div className="flex items-center gap-2 mb-3">
              <BarChart className="size-4 text-amber-600 dark:text-amber-400" />
              <p className="text-[12px] font-semibold text-amber-900 dark:text-amber-100 uppercase tracking-wide">
                Em Análise de Viabilidade
              </p>
            </div>
            
            {/* Status Badge */}
            <div className="mb-3">
              {operation.viabilityStatus === "viable" && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-green-100 dark:bg-green-950 border border-green-300 dark:border-green-700 rounded-[6px]">
                  <div className="size-2 bg-green-500 rounded-full" />
                  <span className="text-[11px] font-semibold text-green-700 dark:text-green-300">
                    ✓ Operação Viável
                  </span>
                </div>
              )}
              {operation.viabilityStatus === "pre_approved" && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-100 dark:bg-blue-950 border border-blue-300 dark:border-blue-700 rounded-[6px]">
                  <div className="size-2 bg-blue-500 rounded-full animate-pulse" />
                  <span className="text-[11px] font-semibold text-blue-700 dark:text-blue-300">
                    ⏳ Pré-Aprovada
                  </span>
                </div>
              )}
              {operation.viabilityStatus === "structuring" && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-100 dark:bg-amber-950 border border-amber-300 dark:border-amber-700 rounded-[6px]">
                  <div className="size-2 bg-amber-500 rounded-full animate-pulse" />
                  <span className="text-[11px] font-semibold text-amber-700 dark:text-amber-300">
                    🔧 Em Estruturação
                  </span>
                </div>
              )}
            </div>

            {/* Progress */}
            {operation.analysisProgress !== undefined && (
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-amber-600 dark:text-amber-400">Progresso da Análise</span>
                  <span className="text-[10px] font-semibold text-amber-900 dark:text-amber-100">
                    {operation.analysisProgress}%
                  </span>
                </div>
                <div className="h-2 bg-amber-100 dark:bg-amber-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-amber-500 rounded-full transition-all"
                    style={{ width: `${operation.analysisProgress}%` }}
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              {operation.estimatedLaunch && (
                <div className="flex items-center gap-2">
                  <Clock className="size-3 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                  <div>
                    <p className="text-[10px] text-amber-600 dark:text-amber-400">Lançamento Previsto</p>
                    <p className="text-[11px] font-semibold text-amber-900 dark:text-amber-100">
                      {operation.estimatedLaunch}
                    </p>
                  </div>
                </div>
              )}
              {operation.interestedInvestors !== undefined && (
                <div className="flex items-center gap-2">
                  <Users className="size-3 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                  <div>
                    <p className="text-[10px] text-amber-600 dark:text-amber-400">Interessados</p>
                    <p className="text-[11px] font-semibold text-amber-900 dark:text-amber-100">
                      {operation.interestedInvestors} investidores
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Call to Action para Viabilidade */}
            <div className="mt-3 pt-3 border-t border-amber-200 dark:border-amber-800">
              <p className="text-[10px] text-amber-700 dark:text-amber-300 italic">
                💡 Manifeste interesse antecipado e seja notificado quando a oferta for lançada
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Footer com Documentos Obrigatórios (RCVM 88) */}
      <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 rounded-b-[16px]">
        {operation.type === "Oferta Pública" && (
          <div className="mb-4">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider">
              📄 Documentos obrigatórios (RCVM 88)
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(operation.documents.prospectus, "_blank");
                }}
                disabled={!operation.documents.prospectus}
                className="flex items-center justify-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:border-[#2e61ff] hover:text-[#2e61ff] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <FileText className="size-3" />
                Prospecto
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(operation.documents.factSheet, "_blank");
                }}
                disabled={!operation.documents.factSheet}
                className="flex items-center justify-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:border-[#2e61ff] hover:text-[#2e61ff] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <FileCheck className="size-3" />
                Lâmina
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(operation.documents.announcement, "_blank");
                }}
                disabled={!operation.documents.announcement}
                className="flex items-center justify-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[8px] text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:border-[#2e61ff] hover:text-[#2e61ff] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Bell className="size-3" />
                Anúncio
              </button>
            </div>
          </div>
        )}

        <button
          onClick={() => onLearnMore(operation.id)}
          className="w-full py-3 bg-[#2e61ff] text-white rounded-[12px] font-semibold text-[14px] hover:bg-[#1b41f5] transition-colors"
        >
          Saiba mais
        </button>
      </div>
    </div>
  );
}