import { useState } from "react";
import { X } from "lucide-react";

interface AddMemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  onError: (type: "corporate" | "duplicate") => void;
}

export function AddMemberModal({ isOpen, onClose, onSuccess, onError }: AddMemberModalProps) {
  const [email, setEmail] = useState("");
  const [permission, setPermission] = useState("Administrador");

  if (!isOpen) return null;

  const handleAdd = () => {
    // Validação de email corporativo
    const personalDomains = ["gmail.com", "hotmail.com", "outlook.com", "yahoo.com"];
    const domain = email.split("@")[1];

    if (personalDomains.includes(domain)) {
      onError("corporate");
      return;
    }

    // Simulação de verificação de membro já existente
    const existingEmails = ["lucas@bloxs.com.br", "jessica@bloxs.com.br"];
    if (existingEmails.includes(email)) {
      onError("duplicate");
      return;
    }

    // Sucesso
    onSuccess();
    setEmail("");
    setPermission("Administrador");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-[#292929] rounded-[12px] border border-[#434343] shadow-xl max-w-[400px] w-full mx-4">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-[18px] font-semibold text-white mb-1">
                Adicionar membro
              </h2>
              <p className="text-[14px] text-[#a4a4a4] leading-relaxed">
                Informe o e-mail e o tipo de permissão. Um convite será enviado por e-mail para que ele acesse o workspace.
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white/60 hover:text-white transition-colors"
            >
              <X className="size-5" />
            </button>
          </div>

          {/* Form */}
          <div className="space-y-4">
            {/* Email Input */}
            <div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="E-mail corporativo"
                className="w-full px-4 py-3 bg-[#313131] border border-[#a4a4a4] rounded-[6px] text-[14px] text-[#a4a4a4] placeholder-[#a4a4a4] focus:outline-none focus:border-[#3482ff] transition-colors"
              />
            </div>

            {/* Permission Select */}
            <div>
              <label className="block text-[12px] text-[#a4a4a4] mb-2">Permissão</label>
              <select
                value={permission}
                onChange={(e) => setPermission(e.target.value)}
                className="w-full px-4 py-3 bg-[#313131] border border-[#a4a4a4] rounded-[6px] text-[14px] text-[#a4a4a4] focus:outline-none focus:border-[#3482ff] transition-colors appearance-none cursor-pointer"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='8' viewBox='0 0 14 8' fill='none'%3E%3Cpath d='M1 1L7 7L13 1' stroke='%23818181' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                  backgroundRepeat: "no-repeat",
                  backgroundPosition: "right 16px center",
                  backgroundSize: "14px 8px",
                }}
              >
                <option value="Administrador">Administrador</option>
                <option value="Membro">Membro</option>
                <option value="Visualizador">Visualizador</option>
              </select>
            </div>

            {/* Button */}
            <button
              onClick={handleAdd}
              disabled={!email}
              className="w-full py-3 bg-[#3482ff] text-white rounded-[8px] font-semibold text-[14px] hover:bg-[#2668dd] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Adicionar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
