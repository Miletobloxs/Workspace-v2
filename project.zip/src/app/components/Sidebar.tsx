import { Home, RefreshCw, Briefcase, Rocket, Wrench, Users, HelpCircle } from "lucide-react";
import { useLocation, useNavigate } from "react-router";
import { Logo } from "./Logo";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className = "" }: SidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const menuItems = [
    { icon: Home, label: "Home", path: "/home" },
    { icon: RefreshCw, label: "Marketplace", path: "/marketplace" },
    { icon: Briefcase, label: "Carteira", path: "/carteira" },
    { icon: Rocket, label: "Soluções", path: "/solucoes" },
    { icon: Wrench, label: "Tools", path: "/tools" },
    { icon: Users, label: "Comunidade", path: "/comunidade" },
    { icon: HelpCircle, label: "Ajuda", path: "/ajuda" },
  ];

  return (
    <div className={`w-[68px] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col items-center py-4 ${className}`}>
      <div className="mb-8 flex items-center justify-center w-[40px] h-[40px] bg-[#2e61ff] rounded-[8px]">
        <div className="w-[24px] h-[24px]">
          <svg viewBox="0 0 24 24" fill="none">
            <rect width="10" height="10" rx="2" fill="white" />
            <rect x="14" width="10" height="10" rx="2" fill="white" />
            <rect y="14" width="10" height="10" rx="2" fill="white" />
          </svg>
        </div>
      </div>

      <nav className="flex-1 flex flex-col gap-2 w-full px-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`relative flex flex-col items-center justify-center gap-1 py-3 rounded-[8px] transition-colors ${
                isActive
                  ? "text-[#2e61ff] bg-blue-50 dark:bg-blue-950"
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800"
              }`}
              title={item.label}
            >
              <Icon className="size-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}