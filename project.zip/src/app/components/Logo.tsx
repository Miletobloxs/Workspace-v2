import svgPaths from "../../imports/svg-pz712mnydb";

export function Logo() {
  return (
    <div className="h-[36px] overflow-clip relative shrink-0 w-[112px]">
      <div className="absolute inset-[5.49%_-0.11%_22.16%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 112.126 26.0459">
          <g>
            <path d={svgPaths.p2adb5e00} fill="currentColor" className="text-slate-950 dark:text-white" />
            <path d={svgPaths.p26b68980} fill="currentColor" className="text-slate-950 dark:text-white" />
            <path d={svgPaths.p322ea900} fill="currentColor" className="text-slate-950 dark:text-white" />
            <path d={svgPaths.p3e2b1380} fill="currentColor" className="text-slate-950 dark:text-white" />
            <path d={svgPaths.p23bbae00} fill="currentColor" className="text-slate-950 dark:text-white" />
            <path d={svgPaths.p915fd00} fill="currentColor" className="text-slate-950 dark:text-white" />
            <path d={svgPaths.p1a2d4800} fill="#2E61FF" />
          </g>
        </svg>
      </div>
    </div>
  );
}
