import svgPaths from "./svg-giu3ru9rgf";
import imgTexture from "figma:asset/49b10b9ed2e210e5e2ae2f86906940de3b56018c.png";

function Camada() {
  return (
    <div className="absolute inset-[5.49%_-0.11%_22.16%_0]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 112.126 26.0459">
        <g id="Camada_1-2">
          <path d={svgPaths.p2adb5e00} fill="var(--fill-0, #F1F5F9)" id="Vector" />
          <path d={svgPaths.p26b68980} fill="var(--fill-0, #F1F5F9)" id="Vector_2" />
          <path d={svgPaths.p322ea900} fill="var(--fill-0, #F1F5F9)" id="Vector_3" />
          <path d={svgPaths.p3e2b1380} fill="var(--fill-0, #F1F5F9)" id="Vector_4" />
          <path d={svgPaths.p23bbae00} fill="var(--fill-0, #F1F5F9)" id="Vector_5" />
          <path d={svgPaths.p915fd00} fill="var(--fill-0, #F1F5F9)" id="Vector_6" />
          <path d={svgPaths.p1a2d4800} fill="var(--fill-0, #2E61FF)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function Logotype() {
  return (
    <div className="h-[36px] overflow-clip relative shrink-0 w-[112px]" data-name="logotype">
      <Camada />
    </div>
  );
}

function Component1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Component 11">
      <div className="absolute inset-[-29.17%_-47.06%_-147.06%_-47.06%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
          <g id="Component 11">
            <circle cx="23.2941" cy="19" id="Ellipse 516" opacity="0.1" r="14.5" stroke="url(#paint0_linear_1_6126)" />
            <g filter="url(#filter0_dddddddi_1_6126)" id="Ellipse 515">
              <circle cx="23.2941" cy="19" fill="var(--fill-0, #2E61FF)" r="11.2941" />
              <circle cx="23.2941" cy="19" fill="url(#paint1_linear_1_6126)" fillOpacity="0.1" r="11.2941" />
            </g>
            <g id="Frame 427321015">
              <circle cx="18.8312" cy="1.9707" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1434" opacity="0.3" r="0.75" />
              <circle cx="10.0441" cy="3.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1435" r="0.75" />
              <circle cx="33.0441" cy="4.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1446" r="0.75" />
              <circle cx="40.0441" cy="9.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1451" opacity="0.3" r="0.75" />
              <circle cx="9.04412" cy="10.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1449" opacity="0.3" r="0.75" />
            </g>
            <g id="IA">
              <path d={svgPaths.p1063c100} fill="var(--fill-0, white)" />
              <path d={svgPaths.p17307780} fill="var(--fill-0, white)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" id="filter0_dddddddi_1_6126" width="46.5882" x="2.98023e-07" y="6.70588">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="12" result="effect1_dropShadow_1_6126" />
              <feOffset dy="24" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="6" result="effect2_dropShadow_1_6126" />
              <feOffset dy="12" />
              <feGaussianBlur stdDeviation="6" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_6126" mode="normal" result="effect2_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="3" result="effect3_dropShadow_1_6126" />
              <feOffset dy="6" />
              <feGaussianBlur stdDeviation="3" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect2_dropShadow_1_6126" mode="normal" result="effect3_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.5" result="effect4_dropShadow_1_6126" />
              <feOffset dy="3" />
              <feGaussianBlur stdDeviation="1.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.02 0" />
              <feBlend in2="effect3_dropShadow_1_6126" mode="normal" result="effect4_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.5" result="effect5_dropShadow_1_6126" />
              <feOffset dy="1" />
              <feGaussianBlur stdDeviation="0.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect4_dropShadow_1_6126" mode="normal" result="effect5_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect6_dropShadow_1_6126" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect5_dropShadow_1_6126" mode="normal" result="effect6_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect7_dropShadow_1_6126" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0588235 0 0 0 0 0.0901961 0 0 0 0 0.164706 0 0 0 1 0" />
              <feBlend in2="effect6_dropShadow_1_6126" mode="normal" result="effect7_dropShadow_1_6126" />
              <feBlend in="SourceGraphic" in2="effect7_dropShadow_1_6126" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="shape" mode="normal" result="effect8_innerShadow_1_6126" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_6126" x1="23.2941" x2="23.2941" y1="4" y2="34">
              <stop stopColor="#2E61FF" stopOpacity="0" />
              <stop offset="1" stopColor="#2E61FF" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_6126" x1="23.2941" x2="23.2941" y1="30.2941" y2="7.70588">
              <stop stopColor="white" stopOpacity="0" />
              <stop offset="1" stopColor="white" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#0f172a] content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Component1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p39ce2c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.5 21H13.5" id="Path_3" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MusicAudioBellNotifications() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Music, Audio/Bell, Notifications">
      <Group />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#0f172a] content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <MusicAudioBellNotifications />
    </div>
  );
}

function CircleRedSolid() {
  return (
    <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]" data-name="circle-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#ff6467] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="container">
      <Button />
      <Button1 />
      <CircleRedSolid />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute left-0 size-[40px] top-0">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Frame 1">
          <g clipPath="url(#clip0_1_6111)">
            <path d={svgPaths.pf5fe180} data-figma-bg-blur-radius="2.32101" fill="var(--fill-0, #0F172A)" id="Building" />
            <path d={svgPaths.p22fee400} fill="var(--fill-0, #334155)" id="Square" />
            <path d={svgPaths.p33c16900} fill="var(--fill-0, #334155)" id="Square_2" />
            <path d={svgPaths.p10fd16f0} fill="var(--fill-0, #334155)" id="Square_3" />
            <path d={svgPaths.p3149f040} fill="var(--fill-0, #0F172A)" id="Building_2" />
            <path d={svgPaths.p19324e70} fill="var(--fill-0, #334155)" id="Square_4" />
            <path d={svgPaths.p3ccb5500} fill="var(--fill-0, #334155)" id="Square_5" />
            <path d={svgPaths.p340fa100} fill="var(--fill-0, #334155)" id="Square_6" />
            <path d={svgPaths.pa1f5780} fill="var(--fill-0, #334155)" id="Square_7" />
            <path d={svgPaths.p1672d180} fill="var(--fill-0, #334155)" id="Square_8" />
            <path d={svgPaths.p33129c00} fill="var(--fill-0, #334155)" id="Square_9" />
            <path d={svgPaths.p40e1080} fill="var(--fill-0, #334155)" id="Square_10" />
            <path d={svgPaths.p1574400} fill="var(--fill-0, #334155)" id="Square_11" />
          </g>
        </g>
        <defs>
          <clipPath id="bgblur_1_1_6111_clip_path" transform="translate(-3.67899 -11.9075)">
            <path d={svgPaths.pf5fe180} />
          </clipPath>
          <clipPath id="clip0_1_6111">
            <path d={svgPaths.p3c12f200} fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Person() {
  return (
    <div className="absolute bottom-0 right-0 size-[16px]" data-name="person">
      <div className="absolute inset-[-6.25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
          <g id="person">
            <g clipPath="url(#clip0_1_6107)">
              <path d={svgPaths.pcc89de0} fill="var(--fill-0, #334155)" />
              <ellipse cx="9" cy="15.5349" fill="var(--fill-0, #0F172A)" id="Body" rx="5.95349" ry="4.46512" />
              <circle cx="9" cy="6.97674" fill="var(--fill-0, #0F172A)" id="Head" opacity="0.9" r="2.97674" />
            </g>
            <path d={svgPaths.p389f1700} stroke="var(--stroke-0, #0F172A)" />
          </g>
          <defs>
            <clipPath id="clip0_1_6107">
              <path d={svgPaths.pcc89de0} fill="white" />
            </clipPath>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Avatar() {
  return (
    <div className="bg-[#1e293b] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame1 />
      <Person />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#f1f5f9] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Sem empresa cadastrada</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#94a3b8] text-[12px]">Ative seu workspace</p>
    </div>
  );
}

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0" data-name="container">
      <Avatar />
      <Content />
      <ArrowsDiagramsArrow />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
      <Container />
      <div className="bg-[#1e293b] h-[24px] rounded-[9999px] shrink-0 w-[2px]" data-name="divider" />
      <Container1 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="bg-[#0f172a] h-[80px] relative shrink-0 w-full z-[3]" data-name="Navbar">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between px-[72px] py-[16px] relative size-full">
          <Logotype />
          <Frame4 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#1e293b] border-b border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[12px] items-start min-h-px min-w-px not-italic relative">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.1] relative shrink-0 text-[#f1f5f9] text-[32px] tracking-[-0.16px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Bem-vindo à Bloxs!
      </p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#cbd5e1] text-[0px] text-[14px]">
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">Antes de começar</span>
        <span className="leading-[1.4]">, complete as etapas abaixo para liberar o acesso total à plataforma.</span>
      </p>
    </div>
  );
}

function Number() {
  return (
    <div className="bg-[#0f172a] content-stretch flex items-center justify-center p-[8.182px] relative rounded-[78.545px] shrink-0" data-name="Number">
      <div aria-hidden="true" className="absolute border-[#0f172a] border-[1.636px] border-solid inset-[-1.636px] pointer-events-none rounded-[80.181px]" />
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] not-italic relative shrink-0 text-[#2e61ff] text-[14px] text-center w-[19.636px]">
        <p className="leading-[1.4] whitespace-pre-wrap">01</p>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] not-italic relative shrink-0 whitespace-nowrap" data-name="Frame">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center relative shrink-0 text-[#f1f5f9] text-[14px] text-center">
        <p className="leading-[1.4]">Personalize o espaço</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#cbd5e1] text-[12px]">
        <p className="leading-[1.4]">Adicione logo, capa e descrição da empresa</p>
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <Number />
      <Frame />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] items-end justify-center relative shrink-0 w-full" data-name="Container">
      <Frame11 />
      <Frame12 />
    </div>
  );
}

function Dot() {
  return <div className="absolute bg-[#2e61ff] h-[4px] left-0 rounded-br-[9999px] rounded-tr-[9999px] top-0 w-[480px]" data-name="dot" />;
}

function Status() {
  return (
    <div className="bg-[#1e293b] h-[4px] overflow-clip relative shrink-0 w-[1440px]" data-name="status">
      <Dot />
    </div>
  );
}

function Header() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col gap-[32px] items-center pt-[32px] px-[72px] relative w-full">
          <Container2 />
          <Status />
        </div>
      </div>
    </div>
  );
}

function DesignToolsWorkspace() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Design, Tools/Workspace">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p39666180} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path clipRule="evenodd" d={svgPaths.p30925b40} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M9 3H3" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M9 7H3" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M9 11H3" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_6" />
        </g>
      </svg>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex gap-[12px] h-[40px] items-center relative shrink-0 w-[624px]">
      <DesignToolsWorkspace />
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#f1f5f9] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Dê a cara do seu workspace
      </p>
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full" data-name="Content">
      <Frame9 />
      <p className="font-['Inter:Regular',sans-serif] font-normal h-[40px] leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px] w-[624px] whitespace-pre-wrap">
        {`Adicione o logo, a imagem de capa e uma breve descrição para deixar `}
        <br aria-hidden="true" />
        seu espaço com a cara da sua empresa.
      </p>
    </div>
  );
}

function Label() {
  return (
    <div className="content-stretch flex gap-[6px] items-center leading-[0] not-italic relative shrink-0 text-[14px] whitespace-nowrap" data-name="Label">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#f1f5f9]">
        <p className="leading-[1.4]">Nome do worskpace</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#fb2c36]">
        <p className="leading-[1.4]">*</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-[#0f172a] h-[48px] relative rounded-[8px] shrink-0 w-full" data-name="container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[12px] relative size-full">
          <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#94a3b8] text-[14px] whitespace-pre-wrap">Digite o nome do workspace</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function TextInput() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Text Input">
      <Label />
      <Container5 />
    </div>
  );
}

function Label1() {
  return (
    <div className="content-stretch flex gap-[6px] items-center leading-[0] not-italic relative shrink-0 text-[14px] whitespace-nowrap" data-name="Label">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#f1f5f9]">
        <p className="leading-[1.4]">Descrição da empresa</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#fb2c36]">
        <p className="leading-[1.4]">*</p>
      </div>
    </div>
  );
}

function Resize() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Resize">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Resize">
          <path d={svgPaths.p20c3d500} id="Vector" stroke="var(--stroke-0, #475569)" />
        </g>
      </svg>
    </div>
  );
}

function CharacterCounter() {
  return (
    <div className="content-stretch flex gap-[6px] items-center justify-end relative shrink-0 w-full" data-name="Character Counter">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-right">0/200</p>
      <Resize />
    </div>
  );
}

function Container6() {
  return (
    <div className="bg-[#0f172a] h-[112px] relative rounded-[8px] shrink-0 w-full" data-name="container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start justify-between p-[12px] relative size-full">
          <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#94a3b8] text-[14px] w-full whitespace-pre-wrap">Digite uma descrição da empresa</p>
          <CharacterCounter />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Textarea() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Textarea">
      <Label1 />
      <Container6 />
    </div>
  );
}

function Label2() {
  return (
    <div className="content-stretch flex gap-[6px] items-center leading-[0] not-italic relative shrink-0 text-[14px] whitespace-nowrap" data-name="Label">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#f1f5f9]">
        <p className="leading-[1.4]">Foto de capa</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#fb2c36]">
        <p className="leading-[1.4]">*</p>
      </div>
    </div>
  );
}

function InternetNetworkCloudCloudStorageUpload() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Internet, Network, Cloud/cloud-storage-upload">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Rectangle" />
          <path d={svgPaths.p299d8a00} id="Path" stroke="var(--stroke-0, #F1F5F9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M14 16L12 14L10 16" id="Path_2" stroke="var(--stroke-0, #F1F5F9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 19V14" id="Path_3" stroke="var(--stroke-0, #F1F5F9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] items-center leading-[1.4] not-italic relative shrink-0 text-center w-full whitespace-pre-wrap" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#f1f5f9] text-[14px] w-full">Escolha um arquivo ou arraste e solte-o aqui.</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#cbd5e1] text-[12px] w-full">Formatos JPEG ou PNG, até 50 MB.</p>
    </div>
  );
}

function FileUploadArea() {
  return (
    <div className="bg-[#0f172a] relative rounded-[12px] shrink-0 w-full" data-name="File Upload Area">
      <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[20px] items-center justify-center p-[32px] relative w-full">
          <InternetNetworkCloudCloudStorageUpload />
          <Text />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-dashed inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Input() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Input">
      <Label2 />
      <FileUploadArea />
    </div>
  );
}

function Label3() {
  return (
    <div className="content-stretch flex gap-[6px] items-center leading-[0] not-italic relative shrink-0 text-[14px] whitespace-nowrap" data-name="Label">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#f1f5f9]">
        <p className="leading-[1.4]">Foto de perfil</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#fb2c36]">
        <p className="leading-[1.4]">*</p>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex items-start relative shrink-0">
      <Label3 />
    </div>
  );
}

function Avatar1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Avatar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Avatar">
          <g clipPath="url(#clip0_1_6052)">
            <path d={svgPaths.p3c12f200} fill="var(--fill-0, white)" fillOpacity="0.08" />
            <ellipse cx="20" cy="36.3372" fill="var(--fill-0, white)" fillOpacity="0.8" id="Body" rx="14.8837" ry="11.1628" />
            <circle cx="20" cy="14.9419" fill="var(--fill-0, white)" fillOpacity="0.8" id="Head" opacity="0.9" r="7.44186" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_6052">
            <path d={svgPaths.p3c12f200} fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#f1f5f9] text-center">Carregue seu avatar</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#94a3b8]">JPEG ou PNG, até 128x128px</p>
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[12px]">Carregar</p>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#0f172a] h-[32px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[inherit]">
        <Content2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#0f172a] relative rounded-[12px] shrink-0 w-full" data-name="container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[16px] relative w-full">
          <Avatar1 />
          <Frame5 />
          <Button2 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Input1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Input">
      <Frame3 />
      <Container7 />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[24px] items-start min-h-px min-w-px relative" data-name="Container">
      <Content1 />
      <TextInput />
      <Textarea />
      <Input />
      <Input1 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-4.17%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5 19.5">
          <g id="Group">
            <path d={svgPaths.p7495000} id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M13.25 9.75H9.25V4.75" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pbba0e00} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p837f280} id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function InterfaceEssentialClockTimerDotsLine() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[24px] top-[calc(50%+0.5px)]" data-name="Interface, Essential/clock-timer-dots-line">
      <Group3 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="bg-[#0f172a] col-1 ml-0 mt-0 overflow-clip relative rounded-[9999px] row-1 size-[40px]">
      <InterfaceEssentialClockTimerDotsLine />
    </div>
  );
}

function Group2() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative row-1">
      <Frame6 />
    </div>
  );
}

function Group1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid place-items-start relative shrink-0">
      <Group2 />
    </div>
  );
}

function Text1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start justify-center min-h-px min-w-px not-italic relative" data-name="Text">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center relative shrink-0 text-[#f1f5f9] text-[14px] w-full">
        <p className="leading-[1.4] whitespace-pre-wrap">Atualização em tempo real</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#cbd5e1] text-[12px] w-full">
        <p className="leading-[1.4] whitespace-pre-wrap">{`Está prévia mostra como o seu workspace aparecerá para os membros da equipe. `}</p>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[20px] items-center leading-[0] min-h-px min-w-px relative">
      <Group1 />
      <Text1 />
    </div>
  );
}

function Alert() {
  return (
    <div className="absolute bg-[#1e293b] content-stretch flex h-[122px] items-end left-0 p-[24px] rounded-[16px] top-[240px] w-[624px]" data-name="Alert">
      <Frame7 />
    </div>
  );
}

function Mosaic() {
  return (
    <div className="absolute h-[108px] left-0 mix-blend-difference opacity-10 top-0 w-[628px]" data-name="mosaic">
      <div className="absolute bg-size-[320.0000047683716px_320.0000047683716px] bg-top-left inset-0 mix-blend-difference" data-name="texture" style={{ backgroundImage: `url('${imgTexture}')` }} />
    </div>
  );
}

function Component() {
  return (
    <div className="absolute contents left-0 top-0" data-name="1">
      <Mosaic />
      <div className="absolute flex h-[108px] items-center justify-center left-[-1px] top-0 w-[629px]">
        <div className="-scale-y-100 flex-none">
          <div className="bg-[rgba(255,255,255,0.34)] h-[108px] opacity-10 w-[629px]" />
        </div>
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="absolute bg-[#0f172a] border-2 border-[rgba(255,255,255,0.08)] border-solid left-[24px] overflow-clip rounded-[9999px] shadow-[0px_23.867px_41.767px_-5.967px_rgba(32,49,86,0.03),0px_11.933px_17.9px_-5.967px_rgba(33,49,86,0.03),0px_5.967px_11.933px_-2.983px_rgba(32,49,86,0.03),0px_2.983px_5.967px_-1.492px_rgba(32,49,86,0.03),0px_1.492px_2.238px_0px_rgba(32,49,86,0.03),0px_0.559px_0.559px_0px_rgba(55,55,82,0.04),0px_0px_0px_0.746px_rgba(55,55,82,0.04)] size-[112px] top-[77px]">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] left-[calc(50%-21px)] not-italic text-[#cbd5e1] text-[24px] top-[calc(50%-17px)]">NW</p>
    </div>
  );
}

function VerifiedBadge() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="verified-badge">
      <div className="absolute inset-[-7.03%_-14.05%_-21.08%_-14.05%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.2154 19.2154">
          <g id="verified-badge">
            <g filter="url(#filter0_dii_1_6041)" id="Vector">
              <path clipRule="evenodd" d={svgPaths.p1c360c00} fill="var(--fill-0, #2E61FF)" fillRule="evenodd" />
              <path clipRule="evenodd" d={svgPaths.p1c360c00} fill="url(#paint0_linear_1_6041)" fillOpacity="0.2" fillRule="evenodd" />
              <path d={svgPaths.p21e6b100} stroke="var(--stroke-0, black)" strokeOpacity="0.2" strokeWidth="0.5" />
            </g>
            <g id="check-mini">
              <path d={svgPaths.p629fee0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="19.2154" id="filter0_dii_1_6041" width="19.2154" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.05385" />
              <feGaussianBlur stdDeviation="1.05385" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_6041" />
              <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_6041" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.05385" />
              <feGaussianBlur stdDeviation="1.05385" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.1 0" />
              <feBlend in2="shape" mode="normal" result="effect2_innerShadow_1_6041" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1.05385" />
              <feGaussianBlur stdDeviation="2.63462" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.1 0" />
              <feBlend in2="effect2_innerShadow_1_6041" mode="normal" result="effect3_innerShadow_1_6041" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_6041" x1="9.60769" x2="9.60769" y1="1.05385" y2="16.0538">
              <stop stopColor="white" />
              <stop offset="1" stopColor="white" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] not-italic overflow-hidden relative shrink-0 text-[#f1f5f9] text-[24px] text-ellipsis tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Nome do workspace
      </p>
      <VerifiedBadge />
    </div>
  );
}

function CircleGreenSolid() {
  return (
    <div className="absolute left-[-56px] overflow-clip size-[32px] top-[24px]" data-name="circle-green-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#00bc7d] border-2 border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[19998px] size-[16px] top-1/2" />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] items-start left-[160px] top-[132px]">
      <Frame10 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#94a3b8] text-[14px]">Breve descrição do seu negócio.</p>
      <CircleGreenSolid />
    </div>
  );
}

function CardsDealboard() {
  return (
    <div className="absolute blur-[0px] h-[229px] left-0 overflow-clip rounded-[16px] shadow-[0px_23.867px_41.767px_-5.967px_rgba(30,41,59,0.03),0px_11.933px_17.9px_-5.967px_rgba(30,41,59,0.03),0px_5.967px_11.933px_-2.983px_rgba(30,41,59,0.03),0px_2.983px_5.967px_-1.492px_rgba(30,41,59,0.03),0px_1.492px_2.238px_0px_rgba(30,41,59,0.03),0px_0.559px_0.559px_0px_rgba(30,41,59,0.04),0px_0px_0px_0.746px_rgba(255,255,255,0.04)] top-[44px] w-[624px]" data-name="Cards-Dealboard" style={{ backgroundImage: "linear-gradient(216.317deg, rgba(46, 97, 255, 0) 71.692%, rgba(46, 97, 255, 0.1) 136.27%), linear-gradient(90deg, rgb(15, 23, 42) 0%, rgb(15, 23, 42) 100%)" }}>
      <div className="absolute bg-[#eef4ff] h-[108px] left-0 opacity-10 top-0 w-[628px]" />
      <Component />
      <Frame8 />
      <Frame2 />
    </div>
  );
}

function Profile() {
  return (
    <div className="absolute contents left-0 top-[44px]" data-name="Profile">
      <Alert />
      <CardsDealboard />
    </div>
  );
}

function Dots() {
  return (
    <div className="h-[82px] relative w-[142px]" data-name="dots">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 142 82">
        <g id="dots">
          <circle cx="11" cy="1" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21868" r="1" />
          <circle cx="61" cy="1" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21871" r="1" />
          <circle cx="71" cy="1" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21876" r="1" />
          <circle cx="81" cy="1" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21879" r="1" />
          <circle cx="21" cy="11" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21874" r="1" />
          <circle cx="31" cy="11" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21875" r="1" />
          <circle cx="51" cy="11" fill="var(--fill-0, #F1F5F9)" id="Ellipse 21870" opacity="0.3" r="1" />
          <circle cx="61" cy="11" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21871_2" r="1" />
          <circle cx="71" cy="11" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21876_2" r="1" />
          <circle cx="71" cy="21" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21876_3" r="1" />
          <circle cx="81" cy="21" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21879_2" r="1" />
          <circle cx="11" cy="31" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21868_2" r="1" />
          <circle cx="121" cy="2" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21875_2" r="1" />
          <circle cx="131" cy="2" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21869" r="1" />
          <circle cx="141" cy="2" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21870_2" r="1" />
          <circle cx="81" cy="31" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21879_3" r="1" />
          <circle cx="11" cy="41" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21868_3" r="1" />
          <circle cx="21" cy="41" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21874_2" r="1" />
          <circle cx="131" cy="12" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21869_2" r="1" />
          <circle cx="81" cy="41" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21879_4" r="1" />
          <circle cx="141" cy="22" fill="var(--fill-0, #F1F5F9)" id="Ellipse 21870_3" opacity="0.3" r="1" />
          <circle cx="71" cy="51" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21876_4" r="1" />
          <circle cx="1" cy="61" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21867" r="1" />
          <circle cx="11" cy="61" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21882" r="1" />
          <circle cx="21" cy="71" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21879_5" r="1" />
          <circle cx="91" cy="71" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21901" r="1" />
          <circle cx="111" cy="71" fill="var(--fill-0, #F1F5F9)" id="Ellipse 21902" opacity="0.3" r="1" />
          <circle cx="121" cy="71" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21892" r="1" />
          <circle cx="141" cy="71" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21880" r="1" />
          <circle cx="11" cy="81" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21893" r="1" />
          <circle cx="41" cy="81" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21906" r="1" />
          <circle cx="91" cy="81" fill="var(--fill-0, white)" fillOpacity="0.32" id="Ellipse 21895" r="1" />
          <circle cx="121" cy="81" fill="var(--fill-0, white)" fillOpacity="0.06" id="Ellipse 21910" r="1" />
        </g>
      </svg>
    </div>
  );
}

function CircleBlueSolid() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="circle-blue-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#598dff] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Content3() {
  return (
    <div className="absolute content-stretch flex gap-[6px] items-center right-0 top-0" data-name="Content">
      <CircleBlueSolid />
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#f1f5f9] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Preview real</p>
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="flex-[1_0_0] h-[676px] min-h-px min-w-px relative" data-name="Container">
      <Profile />
      <div className="absolute bottom-0 flex h-[82px] items-center justify-center right-0 w-[142px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <Dots />
        </div>
      </div>
      <Content3 />
    </div>
  );
}

function Container3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex gap-[48px] items-start px-[72px] py-[40px] relative w-full">
        <Container4 />
        <Container8 />
      </div>
    </div>
  );
}

function WorkArea() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col items-start relative rounded-bl-[24px] rounded-br-[24px] shrink-0 w-full z-[2]" data-name="Work Area">
      <div aria-hidden="true" className="absolute border-[#1e293b] border-b border-solid inset-0 pointer-events-none rounded-bl-[24px] rounded-br-[24px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <Header />
      <Container3 />
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M14 8L10 12L14 16" id="Path" stroke="var(--stroke-0, #F1F5F9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[14px]">Voltar</p>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#0f172a] h-[40px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[20px] py-[8px] relative rounded-[inherit]">
        <ArrowsDiagramsArrow1 />
        <Content4 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Avançar</p>
    </div>
  );
}

function ArrowsDiagramsArrow2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M10 16L14 12L10 8" id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[40px] items-center justify-center overflow-clip px-[20px] py-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content5 />
      <ArrowsDiagramsArrow2 />
    </div>
  );
}

function Footer() {
  return (
    <div className="relative shrink-0 w-full z-[1]" data-name="Footer">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[72px] py-[24px] relative w-full">
          <Button3 />
          <p className="font-['Inter:Medium',sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#94a3b8] text-[12px] text-center tracking-[1.2px] uppercase">
            <span className="leading-[1.5]">{`[ `}</span>
            <span className="leading-[1.5]">{`passo 1 de 3 `}</span>
            <span className="leading-[1.5]">]</span>
          </p>
          <Button4 />
        </div>
      </div>
    </div>
  );
}

export default function Component2CriacaoDeWorkspacePersonalizacaoDarkMode() {
  return (
    <div className="bg-[#1e293b] content-stretch flex flex-col isolate items-center overflow-clip relative rounded-[24px] size-full" data-name="2. Criação de Workspace | Personalização [Dark Mode]">
      <Navbar />
      <WorkArea />
      <Footer />
    </div>
  );
}