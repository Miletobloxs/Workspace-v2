import svgPaths from "./svg-af027p678u";
import imgTexture from "figma:asset/49b10b9ed2e210e5e2ae2f86906940de3b56018c.png";
import imgFrame1321314670 from "figma:asset/4e47467b904f6cf80272c7ebc90bbc02b523e519.png";
import { imgBg } from "./svg-80xhb";

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M14 8L10 12L14 16" id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Voltar</p>
    </div>
  );
}

function TextLink() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center overflow-clip relative rounded-[8px] shrink-0" data-name="Text Link">
      <ArrowsDiagramsArrow />
      <Content />
    </div>
  );
}

function Check() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="check">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g filter="url(#filter0_iiii_1_3567)" id="check">
          <path d={svgPaths.p2018a100} fill="var(--fill-0, #2E61FF)" />
          <path d={svgPaths.p33f89880} id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="26" id="filter0_iiii_1_3567" width="24" x="0" y="0">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.02 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3567" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feMorphology in="SourceAlpha" operator="erode" radius="0.75" result="effect2_innerShadow_1_3567" />
            <feOffset />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.06 0" />
            <feBlend in2="effect1_innerShadow_1_3567" mode="normal" result="effect2_innerShadow_1_3567" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect2_innerShadow_1_3567" mode="normal" result="effect3_innerShadow_1_3567" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="1" />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect3_innerShadow_1_3567" mode="normal" result="effect4_innerShadow_1_3567" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

function Check1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="check">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g filter="url(#filter0_iiii_1_3564)" id="check">
          <path d={svgPaths.p2018a100} fill="var(--fill-0, #2E61FF)" />
          <path d={svgPaths.p38873cb0} id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="26" id="filter0_iiii_1_3564" width="24" x="0" y="0">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.02 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3564" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feMorphology in="SourceAlpha" operator="erode" radius="0.75" result="effect2_innerShadow_1_3564" />
            <feOffset />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.06 0" />
            <feBlend in2="effect1_innerShadow_1_3564" mode="normal" result="effect2_innerShadow_1_3564" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect2_innerShadow_1_3564" mode="normal" result="effect3_innerShadow_1_3564" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="1" />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect3_innerShadow_1_3564" mode="normal" result="effect4_innerShadow_1_3564" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

function Check2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="check">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g filter="url(#filter0_iiii_1_3476)" id="check">
          <path d={svgPaths.p2018a100} fill="var(--fill-0, #2E61FF)" />
          <g filter="url(#filter1_iiii_1_3476)" id="Ellipse 21916">
            <circle cx="12.1333" cy="12" fill="var(--fill-0, white)" r="5" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="26" id="filter0_iiii_1_3476" width="24" x="0" y="0">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.02 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3476" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feMorphology in="SourceAlpha" operator="erode" radius="0.75" result="effect2_innerShadow_1_3476" />
            <feOffset />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.06 0" />
            <feBlend in2="effect1_innerShadow_1_3476" mode="normal" result="effect2_innerShadow_1_3476" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect2_innerShadow_1_3476" mode="normal" result="effect3_innerShadow_1_3476" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="1" />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect3_innerShadow_1_3476" mode="normal" result="effect4_innerShadow_1_3476" />
          </filter>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="12" id="filter1_iiii_1_3476" width="10" x="7.1333" y="7">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.02 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3476" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feMorphology in="SourceAlpha" operator="erode" radius="0.75" result="effect2_innerShadow_1_3476" />
            <feOffset />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.06 0" />
            <feBlend in2="effect1_innerShadow_1_3476" mode="normal" result="effect2_innerShadow_1_3476" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect2_innerShadow_1_3476" mode="normal" result="effect3_innerShadow_1_3476" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="1" />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect3_innerShadow_1_3476" mode="normal" result="effect4_innerShadow_1_3476" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

function Box() {
  return (
    <div className="bg-white relative rounded-[11998.801px] shrink-0 size-[24px]" data-name="box">
      <div className="content-stretch flex flex-col items-center overflow-clip px-[8px] py-[2.4px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#475569] text-[12px] text-center tracking-[1.2px] uppercase w-[19.2px] whitespace-pre-wrap">4</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#cbd5e1] border-[1.2px] border-solid inset-0 pointer-events-none rounded-[11998.801px]" />
    </div>
  );
}

function ContentTimeline() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Content Timeline">
      <Check />
      <div className="flex flex-[1_0_0] h-[2px] items-center justify-center min-h-px min-w-px relative" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90 w-full">
          <div className="h-[138.667px] relative rounded-[9999px] w-full" data-name="Status Indicator">
            <div aria-hidden="true" className="absolute border border-[#1b41f5] border-solid inset-0 pointer-events-none rounded-[9999px]" />
          </div>
        </div>
      </div>
      <Check1 />
      <div className="flex flex-[1_0_0] h-[2px] items-center justify-center min-h-px min-w-px relative" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90 w-full">
          <div className="h-[138.667px] relative rounded-[9999px] w-full" data-name="Status Indicator">
            <div aria-hidden="true" className="absolute border border-[#1b41f5] border-solid inset-0 pointer-events-none rounded-[9999px]" />
          </div>
        </div>
      </div>
      <Check2 />
      <div className="flex flex-[1_0_0] h-[2px] items-center justify-center min-h-px min-w-px relative" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90 w-full">
          <div className="h-[138.667px] relative rounded-[9999px] w-full" data-name="Status Indicator">
            <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[9999px]" />
          </div>
        </div>
      </div>
      <Box />
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap" data-name="content">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.1] relative shrink-0 text-[#020617] text-[32px] tracking-[-0.16px] w-full" style={{ fontFeatureSettings: "\'salt\'" }}>
        Envie os documentos da sua empresa
      </p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#475569] text-[0px] text-[14px] w-full">
        <span className="leading-[1.4]">
          {`Para validar seu cadastro, precisamos de alguns documentos oficiais. `}
          <br aria-hidden="true" />
        </span>
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">Fique tranquilo:</span>
        <span className="leading-[1.4]">{` seus dados são tratados com total sigilo e segurança.`}</span>
      </p>
    </div>
  );
}

function FilesDocumentsFileText() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Files/documents-file-text">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p185c8100} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M13.3333 14.1667H6.66667" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M13.3333 11.25H6.66667" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M9.16667 8.33333H6.66667" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p9084218} id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Frame47() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0">
      <FilesDocumentsFileText />
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#020617] text-[16px]">Frente</p>
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="content">
      <Frame47 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">O arquivo deve mostrar frente do documento e com todas as informações visíveis.</p>
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[12px] text-white">Anexar</p>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[32px] items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content3 />
    </div>
  );
}

function ButtonRoundedFilled() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="button: rounded/ filled">
      <Button />
    </div>
  );
}

function UploadUploadUrl() {
  return (
    <div className="bg-white h-[48px] relative rounded-[8px] shrink-0 w-full" data-name="upload: upload URL">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[16px] pr-[8px] py-[16px] relative size-full">
          <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[0] min-h-px min-w-px not-italic relative text-[#475569] text-[0px] text-[12px] whitespace-pre-wrap">
            <span className="leading-[1.4]">{`Anexe o documento em `}</span>
            <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">PDF</span>
            <span className="leading-[1.4]">{`, com até `}</span>
            <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">X MB</span>
            <span className="leading-[1.4]">.</span>
          </p>
          <ButtonRoundedFilled />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="container">
      <Content2 />
      <UploadUploadUrl />
    </div>
  );
}

function FilesDocumentsFileText1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Files/documents-file-text">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p185c8100} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M13.3333 14.1667H6.66667" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M13.3333 11.25H6.66667" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M9.16667 8.33333H6.66667" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p9084218} id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Frame49() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0">
      <FilesDocumentsFileText1 />
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#020617] text-[16px]">Verso</p>
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="content">
      <Frame49 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">O arquivo deve mostrar verso do documento e com todas as informações visíveis.</p>
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[12px] text-white">Anexar</p>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[32px] items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content5 />
    </div>
  );
}

function ButtonRoundedFilled1() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="button: rounded/ filled">
      <Button1 />
    </div>
  );
}

function UploadUploadUrl1() {
  return (
    <div className="bg-white h-[48px] relative rounded-[8px] shrink-0 w-full" data-name="upload: upload URL">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[16px] pr-[8px] py-[16px] relative size-full">
          <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[0] min-h-px min-w-px not-italic relative text-[#475569] text-[0px] text-[12px] whitespace-pre-wrap">
            <span className="leading-[1.4]">{`Anexe o documento em `}</span>
            <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">PDF</span>
            <span className="leading-[1.4]">{`, com até `}</span>
            <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">X MB</span>
            <span className="leading-[1.4]">.</span>
          </p>
          <ButtonRoundedFilled1 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="container">
      <Content4 />
      <UploadUploadUrl1 />
    </div>
  );
}

function FilesDocumentsFileText2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Files/documents-file-text">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p185c8100} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M13.3333 14.1667H6.66667" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M13.3333 11.25H6.66667" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M9.16667 8.33333H6.66667" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p9084218} id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Frame48() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0">
      <FilesDocumentsFileText2 />
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#020617] text-[16px]">Comprovante de endereço</p>
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="content">
      <Frame48 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Anexe seu comprovante de endereço recente (até 30 dias).</p>
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[12px] text-white">Anexar</p>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[32px] items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content7 />
    </div>
  );
}

function ButtonRoundedFilled2() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="button: rounded/ filled">
      <Button2 />
    </div>
  );
}

function UploadUploadUrl2() {
  return (
    <div className="bg-white h-[48px] relative rounded-[8px] shrink-0 w-full" data-name="upload: upload URL">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[16px] pr-[8px] py-[16px] relative size-full">
          <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[0] min-h-px min-w-px not-italic relative text-[#475569] text-[0px] text-[12px] whitespace-pre-wrap">
            <span className="leading-[1.4]">{`Arquivo no formato `}</span>
            <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">PDF</span>
            <span className="leading-[1.4]">{` e com no máximo `}</span>
            <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">X MB</span>
            <span className="leading-[1.4]">.</span>
          </p>
          <ButtonRoundedFilled2 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="container">
      <Content6 />
      <UploadUploadUrl2 />
    </div>
  );
}

function Form() {
  return (
    <div className="content-stretch flex flex-col gap-[32px] items-start relative shrink-0 w-full" data-name="form">
      <Container3 />
      <Container4 />
      <Container5 />
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Avançar</p>
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M10 16L14 12L10 8" id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#2e61ff] h-[48px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[12px] py-[16px] relative size-full">
          <Content8 />
          <ArrowsDiagramsArrow1 />
        </div>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex flex-col gap-[32px] items-start relative shrink-0 w-full" data-name="container">
      <Form />
      <Button3 />
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[40px] items-start justify-center min-h-px min-w-px relative w-full" data-name="container">
      <TextLink />
      <ContentTimeline />
      <Content1 />
      <Container2 />
    </div>
  );
}

function Container() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="container">
      <div className="flex flex-col justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[64px] items-start justify-center px-[64px] py-[32px] relative size-full">
          <Container1 />
          <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[12px] w-full whitespace-pre-wrap">© 2025 Bloxs Tech Desenvolvedora de Programas. Todos os direitos reservados.</p>
        </div>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="h-[379.867px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-498.651px_336.315px] mask-size-[712px_1008px] opacity-60 relative w-[562.464px]" style={{ maskImage: `url('${imgBg}')` }}>
      <div className="absolute inset-[-68.67%_-46.38%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1084.17 901.573">
          <g id="Group 1410103855" style={{ mixBlendMode: "luminosity" }}>
            <g filter="url(#filter0_f_1_3489)" id="Ellipse 1229" opacity="0.1">
              <circle cx="657.023" cy="427.147" fill="var(--fill-0, #2E61FF)" r="166.294" />
            </g>
            <g filter="url(#filter1_f_1_3489)" id="Ellipse 1230" opacity="0.1">
              <circle cx="427.147" cy="474.426" fill="var(--fill-0, #2E61FF)" r="166.294" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="854.293" id="filter0_f_1_3489" width="854.293" x="229.876" y="1.18572e-06">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3489" stdDeviation="130.426" />
            </filter>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="854.293" id="filter1_f_1_3489" width="854.293" x="-2.53117e-06" y="47.2794">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3489" stdDeviation="130.426" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Light1() {
  return (
    <div className="absolute contents h-[951.716px] left-[327.76px] mix-blend-multiply top-[-460.51px] w-[823.184px]" data-name="light">
      <div className="absolute flex h-[596.129px] items-center justify-center left-[619.47px] mix-blend-luminosity top-[-392.89px] w-[243.55px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[16.23deg]">
          <div className="h-[597.687px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-619.466px_392.888px] mask-size-[712px_1008px] opacity-60 relative w-[79.661px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-2.59%_-21.24%_-1.35%_-21.22%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 113.482 621.283">
                <g filter="url(#filter0_f_1_3533)" id="Rectangle 8413" opacity="0.3" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p3e6a0300} fill="url(#paint0_linear_1_3533)" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="621.283" id="filter0_f_1_3533" width="113.482" x="-2.38419e-07" y="-2.38419e-07">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3533" stdDeviation="8.96682" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3533" x1="91.7538" x2="68.1913" y1="-75.3538" y2="1016.56">
                    <stop offset="0.214779" stopColor="#2E61FF" />
                    <stop offset="0.567446" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[362.779px] items-center justify-center left-[546.39px] mix-blend-luminosity top-[-374.18px] w-[523.345px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[29.99deg] skew-x-[-2.58deg]">
          <div className="h-[114.131px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-546.387px_374.182px] mask-size-[712px_1008px] opacity-60 relative w-[533.318px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-137.13%_-29.35%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 846.342 427.155">
                <g filter="url(#filter0_f_1_3562)" id="Ellipse 1227" opacity="0.31" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p27f3b2f1} fill="var(--fill-0, #2E61FF)" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="427.155" id="filter0_f_1_3562" width="846.342" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3562" stdDeviation="78.2559" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[569.129px] items-center justify-center left-[387.05px] mix-blend-luminosity top-[-164.58px] w-[643.675px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[50.49deg] skew-x-[-4.93deg]">
          <div className="h-[490.603px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-387.049px_164.584px] mask-size-[712px_1008px] opacity-60 relative w-[376.808px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-2.76%_-3.63%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 404.186 517.681">
                <g filter="url(#filter0_f_1_3525)" id="Vector 3412" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p2eb4ca00} stroke="url(#paint0_linear_1_3525)" strokeWidth="1.63033" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="517.681" id="filter0_f_1_3525" width="404.186" x="1.78814e-07" y="-2.68221e-07">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3525" stdDeviation="6.52132" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3525" x1="69.5557" x2="216.077" y1="91.3956" y2="265.418">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[294.439px] items-center justify-center left-[466.63px] mix-blend-luminosity top-[-204.29px] w-[335.398px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[52.79deg] skew-x-[-5.04deg]">
          <div className="h-[252.932px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-466.625px_204.29px] mask-size-[712px_1008px] opacity-60 relative w-[200.591px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-4.91%_-6.33%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 225.97 277.783">
                <g filter="url(#filter0_f_1_3497)" id="Vector 3411" opacity="0.1" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p1b9f83c0} stroke="url(#paint0_linear_1_3497)" strokeWidth="3.26066" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="277.783" id="filter0_f_1_3497" width="225.97" x="-3.57628e-07" y="2.38419e-07">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3497" stdDeviation="5.70616" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3497" x1="39.6012" x2="262.569" y1="46.8152" y2="342.417">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Light() {
  return (
    <div className="absolute contents left-[52px] mix-blend-multiply size-[1374.695px] top-[-672px]" data-name="light">
      <div className="absolute flex h-[675.859px] items-center justify-center left-[498.65px] mix-blend-multiply top-[-336.32px] w-[603.678px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[61.23deg]">
          <Group4 />
        </div>
      </div>
      <Light1 />
      <div className="absolute flex h-[256.851px] items-center justify-center left-[754.89px] mix-blend-multiply top-[-223.92px] w-[70.415px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[11.11deg]">
          <div className="h-[257.592px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-754.89px_223.923px] mask-size-[712px_1008px] opacity-60 relative w-[21.194px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-12.66%_-153.85%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 86.4075 322.805">
                <g filter="url(#filter0_f_1_3429)" id="Ellipse 1231" style={{ mixBlendMode: "luminosity" }}>
                  <ellipse cx="43.2038" cy="161.403" fill="url(#paint0_linear_1_3429)" rx="10.5971" ry="128.796" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="322.805" id="filter0_f_1_3429" width="86.4075" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3429" stdDeviation="16.3033" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3429" x1="41.1126" x2="43.2038" y1="170.211" y2="290.199">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[398.577px] items-center justify-center left-[691.96px] mix-blend-multiply top-[-410.58px] w-[66.971px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[4.97deg]">
          <div className="h-[397.239px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-691.964px_410.577px] mask-size-[712px_1008px] opacity-60 relative w-[32.684px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-13.13%_-159.62%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 137.025 501.58">
                <g filter="url(#filter0_f_1_3493)" id="Ellipse 1232" style={{ mixBlendMode: "luminosity" }}>
                  <ellipse cx="68.5127" cy="250.79" fill="url(#paint0_linear_1_3493)" rx="16.3421" ry="198.62" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="501.58" id="filter0_f_1_3493" width="137.025" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3493" stdDeviation="26.0853" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3493" x1="68.5127" x2="68.5127" y1="52.1706" y2="449.41">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[390.541px] items-center justify-center left-[781.29px] mix-blend-multiply top-[-174.35px] w-[142.417px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[16.23deg]">
          <div className="h-[397.239px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-781.294px_174.352px] mask-size-[712px_1008px] opacity-60 relative w-[32.684px]" style={{ maskImage: `url('${imgBg}')` }}>
            <div className="absolute inset-[-11.08%_-134.68%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 120.722 485.277">
                <g filter="url(#filter0_f_1_3406)" id="Ellipse 1233" style={{ mixBlendMode: "luminosity" }}>
                  <ellipse cx="60.361" cy="242.639" fill="url(#paint0_linear_1_3406)" rx="16.3421" ry="198.62" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="485.277" id="filter0_f_1_3406" width="120.722" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3406" stdDeviation="22.0095" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3406" x1="60.361" x2="50.4292" y1="44.0189" y2="360.801">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Galaxy() {
  return (
    <div className="absolute inset-[-28.27%_-107.21%_26.05%_-107.16%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[763px_285px] mask-size-[712px_1008px]" data-name="Galaxy" style={{ maskImage: `url('${imgBg}')` }}>
      <div className="absolute inset-[-5.39%_-10.26%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2697.44 1141.52">
          <g id="Galaxy">
            <g filter="url(#filter0_f_1_3483)" id="Vector 2">
              <path d={svgPaths.p34a73f80} fill="url(#paint0_linear_1_3483)" fillOpacity="0.32" />
            </g>
            <g filter="url(#filter1_f_1_3483)" id="Vector 3">
              <path d={svgPaths.p3ff46c00} fill="url(#paint1_linear_1_3483)" fillOpacity="0.32" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="764.173" id="filter0_f_1_3483" width="1460.24" x="1237.2" y="377.346">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3483" stdDeviation="112" />
            </filter>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="764.173" id="filter1_f_1_3483" width="1460.24" x="1.90735e-06" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3483" stdDeviation="112" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3483" x1="1497.88" x2="2188.34" y1="856.836" y2="569.241">
              <stop stopColor="#032952" stopOpacity="0" />
              <stop offset="0.333333" stopColor="#4577FF" />
              <stop offset="0.666667" stopColor="#2E61FF" />
              <stop offset="1" stopColor="#032952" stopOpacity="0" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_3483" x1="1199.57" x2="509.105" y1="284.684" y2="572.278">
              <stop stopColor="#032952" stopOpacity="0" />
              <stop offset="0.333333" stopColor="#4577FF" />
              <stop offset="0.666667" stopColor="#2E61FF" />
              <stop offset="1" stopColor="#032952" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Bg() {
  return (
    <div className="-translate-x-1/2 absolute contents left-1/2 top-0" data-name="bg">
      <div className="-translate-x-1/2 absolute h-[1008px] left-1/2 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[712px_1008px] top-0 w-[712px]" data-name="bg" style={{ backgroundImage: "linear-gradient(90deg, rgba(176, 201, 254, 0.2) 0%, rgba(176, 201, 254, 0.2) 100%), linear-gradient(90deg, rgb(248, 250, 252) 0%, rgb(248, 250, 252) 100%)", maskImage: `url('${imgBg}')` }} />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[2203.627px] left-[calc(50%+0.25px)] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[682px_1118px] mask-size-[712px_1008px] mix-blend-overlay top-[calc(50%-520.19px)] w-[2076.495px]" data-name="Vector" style={{ maskImage: `url('${imgBg}')` }}>
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2077.12 2204.19">
          <g id="Vector" style={{ mixBlendMode: "overlay" }}>
            <path d={svgPaths.p3b2d6700} stroke="var(--stroke-0, white)" strokeOpacity="0.3" />
          </g>
        </svg>
      </div>
      <Light />
      <Galaxy />
      <div className="absolute bottom-[-39px] h-[701px] left-[76.97%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-548px_-346px] mask-size-[712px_1008px] mix-blend-plus-lighter right-[-58.71%]" data-name="Vector" style={{ maskImage: `url('${imgBg}')` }}>
        <div className="absolute inset-[-35.95%_-43.3%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1086.01 1205.01">
            <g filter="url(#filter0_f_1_3481)" id="Vector" opacity="0.3" style={{ mixBlendMode: "plus-lighter" }}>
              <path d={svgPaths.p346c9c00} stroke="url(#paint0_linear_1_3481)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="432" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="1205.01" id="filter0_f_1_3481" width="1086.01" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_1_3481" stdDeviation="18" />
              </filter>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3481" x1="593.006" x2="474.909" y1="1137.94" y2="121.947">
                <stop offset="0.014" stopColor="white" />
                <stop offset="0.316" stopColor="#032952" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Mosaic() {
  return (
    <div className="absolute h-[1008px] left-0 mix-blend-difference top-0 w-[712px]" data-name="mosaic">
      <div className="absolute bg-size-[425.11401176452637px_425.11401176452637px] bg-top-left inset-0 mix-blend-difference" data-name="texture" style={{ backgroundImage: `url('${imgTexture}')` }} />
    </div>
  );
}

function Component() {
  return (
    <div className="absolute contents left-0 top-0" data-name="1">
      <Mosaic />
      <div className="absolute flex h-[110.699px] items-center justify-center left-[52.82px] top-[701.6px] w-[570.1px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="blur-[18.45px] h-[570.1px] w-[110.699px]" style={{ backgroundImage: "url(\'data:image/svg+xml;utf8,<svg viewBox=\\'0 0 110.7 570.1\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'0.20000000298023224\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(13.468 7.1373 -6.1425 68.102 -79.334 255.09)\\'><stop stop-color=\\'rgba(46,97,255,1)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(46,97,255,0)\\' offset=\\'1\\'/></radialGradient></defs></svg>\')" }} />
        </div>
      </div>
      <div className="absolute flex h-[271.213px] items-center justify-center left-[15px] top-[185px] w-[103.319px]">
        <div className="-scale-y-100 flex-none">
          <div className="bg-gradient-to-b blur-[18.45px] from-[rgba(255,255,255,0)] h-[271.213px] to-[rgba(255,255,255,0.6)] w-[103.319px]" />
        </div>
      </div>
      <div className="absolute flex h-[271.213px] items-center justify-center left-[515px] top-[-46px] w-[413.277px]">
        <div className="flex-none rotate-180">
          <div className="bg-gradient-to-b blur-[18.45px] from-[rgba(255,255,255,0)] h-[271.213px] rounded-[9224.001px] to-[rgba(255,255,255,0.6)] w-[413.277px]" />
        </div>
      </div>
    </div>
  );
}

function Texture() {
  return (
    <div className="absolute contents left-0 top-0" data-name="texture">
      <Component />
    </div>
  );
}

function Frame26() {
  return <div className="absolute bg-[rgba(3,41,82,0.01)] border-[0.922px] border-[rgba(3,41,82,0.06)] border-solid h-[440.029px] left-[67.58px] rounded-bl-[14.76px] rounded-br-[14.76px] rounded-tl-[11.07px] rounded-tr-[14.76px] top-[291.09px] w-[547.038px]" />;
}

function Frame2() {
  return (
    <div className="absolute bg-white h-[35.055px] left-[98.95px] rounded-[11.07px] shadow-[0px_0px_0px_0.922px_rgba(3,41,82,0.04),0px_0.922px_0.922px_0.461px_rgba(3,41,82,0.04),0px_2.767px_2.767px_-1.384px_rgba(3,41,82,0.02),0px_5.535px_5.535px_-2.767px_rgba(3,41,82,0.04),0px_11.07px_11.07px_-5.535px_rgba(3,41,82,0.04),0px_22.14px_22.14px_-11.07px_rgba(3,41,82,0.04),0px_44.28px_44.28px_-22.14px_rgba(3,41,82,0.04),0px_88.559px_88.559px_-29.52px_rgba(3,41,82,0.06)] top-[232.05px] w-[484.309px]">
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.922px_0.922px_-0.461px_rgba(3,41,82,0.06)]" />
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute h-[25.83px] left-[98.95px] rounded-[11.07px] top-[232.05px] w-[484.309px]">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[11.07px] size-full" src={imgFrame1321314670} />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[5.535px] items-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[9.225px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.22492 9.22492">
          <g filter="url(#filter0_i_1_3487)" id="Ellipse 21911">
            <circle cx="4.61246" cy="4.61246" fill="var(--fill-0, #E2E8F0)" r="4.61246" />
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="9.91679" id="filter0_i_1_3487" width="9.22492" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="0.691869" />
              <feGaussianBlur stdDeviation="0.345935" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.08 0" />
              <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3487" />
            </filter>
          </defs>
        </svg>
      </div>
      <div className="relative shrink-0 size-[9.225px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.22492 9.22492">
          <g filter="url(#filter0_i_1_3487)" id="Ellipse 21911">
            <circle cx="4.61246" cy="4.61246" fill="var(--fill-0, #E2E8F0)" r="4.61246" />
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="9.91679" id="filter0_i_1_3487" width="9.22492" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="0.691869" />
              <feGaussianBlur stdDeviation="0.345935" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.08 0" />
              <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3487" />
            </filter>
          </defs>
        </svg>
      </div>
      <div className="relative shrink-0 size-[9.225px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.22492 9.22492">
          <g filter="url(#filter0_i_1_3487)" id="Ellipse 21911">
            <circle cx="4.61246" cy="4.61246" fill="var(--fill-0, #E2E8F0)" r="4.61246" />
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="9.91679" id="filter0_i_1_3487" width="9.22492" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="0.691869" />
              <feGaussianBlur stdDeviation="0.345935" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.08 0" />
              <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_3487" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Svg() {
  return (
    <div className="relative shrink-0 size-[12.915px]" data-name="SVG">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.9149 12.9149">
        <g id="SVG">
          <path clipRule="evenodd" d={svgPaths.p21e0e050} fill="var(--fill-0, #94A3B8)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[12.915px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.9149 12.9149">
        <g clipPath="url(#clip0_1_3450)" id="icon">
          <path d={svgPaths.p1aee6d80} fill="var(--fill-0, #94A3B8)" id="ô£" />
        </g>
        <defs>
          <clipPath id="clip0_1_3450">
            <rect fill="white" height="12.9149" width="12.9149" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame5() {
  return (
    <div className="bg-[#f1f5f9] flex-[1_0_0] min-h-px min-w-px relative rounded-[7.38px]">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between px-[11.07px] py-[5.535px] relative w-full">
          <Svg />
          <div className="flex flex-[1_0_0] flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] min-h-px min-w-px not-italic relative text-[#94a3b8] text-[11.07px] text-center">
            <p className="leading-[14.76px] whitespace-pre-wrap">app.bloxs.com.br</p>
          </div>
          <Icon />
        </div>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[18.45px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.4498 18.4498">
        <g id="icon">
          <path d={svgPaths.pb645a00} fill="var(--fill-0, #94A3B8)" id="ô¸" />
        </g>
      </svg>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[18.45px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.4498 18.4498">
        <g id="icon">
          <path d={svgPaths.p106d2200} fill="var(--fill-0, #94A3B8)" id="ô¼" />
        </g>
      </svg>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14.76px] items-center justify-end min-h-px min-w-px relative">
      <Icon1 />
      <Icon2 />
    </div>
  );
}

function Header() {
  return (
    <div className="relative shrink-0 w-full" data-name="header">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between px-[14.76px] py-[11.07px] relative w-full">
          <Frame4 />
          <Frame5 />
          <Frame24 />
        </div>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute inset-[24.98%_28.35%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.7824 14.7739">
        <g id="Group 1410103880">
          <path d={svgPaths.pa8957f0} fill="var(--fill-0, #A4BEF5)" id="Rectangle 42467" />
          <path d={svgPaths.p1193b680} fill="var(--fill-0, #D2E0FF)" id="Rectangle 42468" />
          <path d={svgPaths.p215700f0} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42469" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="bg-white relative rounded-[5.535px] shrink-0 size-[29.52px]">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Group5 />
      </div>
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-[0.922px] border-solid inset-0 pointer-events-none rounded-[5.535px]" />
    </div>
  );
}

function Frame44() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14.76px] items-center min-h-px min-w-px relative">
      <Frame />
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#1e293b] text-[12.915px] whitespace-nowrap">
        <p className="leading-[1.4]">Sua marca aqui</p>
      </div>
    </div>
  );
}

function Frame45() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <Frame44 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[9.225px] items-center min-h-px min-w-px relative">
      <div className="bg-[#e2e8f0] h-[11.07px] rounded-[2.767px] shrink-0 w-[3.69px]" />
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#1e293b] text-[12.915px] whitespace-nowrap">
        <p className="leading-[1.4]">Status da operação</p>
      </div>
    </div>
  );
}

function Bg1() {
  return <div className="bg-[#b0c9fe] rounded-[2.767px] shrink-0 size-[9.225px]" data-name="bg" />;
}

function Frame28() {
  return (
    <div className="content-stretch flex gap-[7.38px] items-center relative shrink-0">
      <Bg1 />
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[11.992px] whitespace-nowrap">
        <p className="leading-[1.4]">Aguardando</p>
      </div>
    </div>
  );
}

function Bg2() {
  return <div className="bg-[#2e61ff] rounded-[2.767px] shrink-0 size-[9.225px]" data-name="bg" />;
}

function Frame29() {
  return (
    <div className="content-stretch flex gap-[7.38px] items-center relative shrink-0">
      <Bg2 />
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[11.992px] whitespace-nowrap">
        <p className="leading-[1.4]">Análise</p>
      </div>
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex gap-[18.45px] items-start relative shrink-0">
      <Frame28 />
      <Frame29 />
    </div>
  );
}

function Frame46() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Frame8 />
      <Frame30 />
    </div>
  );
}

function InterfaceEssentialSearchChartMiddle() {
  return (
    <div className="absolute left-[11.07px] size-[22.14px] top-[11.07px]" data-name="Interface, Essential/search-chart-middle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 22.1398">
        <g id="Group">
          <g id="Path">
            <path clipRule="evenodd" d={svgPaths.pbe70280} fill="var(--fill-0, white)" fillOpacity="0.25" fillRule="evenodd" />
            <path d={svgPaths.pbe70280} stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          </g>
          <path d={svgPaths.pff15420} id="Path_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p2655c080} id="Path_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p1bda1b00} id="Path_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.pb7fc700} id="Path_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function Card() {
  return (
    <div className="bg-[#2e61ff] overflow-clip relative rounded-[921.57px] shadow-[0px_3.69px_7.38px_-1.845px_rgba(3,41,82,0.03),0px_1.845px_2.767px_0px_rgba(3,41,82,0.03),0px_0.692px_0.692px_0px_rgba(3,41,82,0.04),0px_0px_0px_0.922px_rgba(3,41,82,0.04)] shrink-0 size-[44.28px]" data-name="card_1">
      <InterfaceEssentialSearchChartMiddle />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col gap-[3.69px] items-center leading-[0] not-italic relative shrink-0 text-[11.992px] whitespace-nowrap">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#334155]">
        <p className="leading-[1.4]">Triagem</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#475569]">
        <p className="leading-[1.4]">16/04/25</p>
      </div>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-center relative shrink-0">
      <Card />
      <Frame10 />
    </div>
  );
}

function FoldersFolder() {
  return (
    <div className="absolute left-[10.84px] size-[22.14px] top-[11.07px]" data-name="Folders/folder">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 22.1398">
        <g id="Group">
          <g id="Path" />
          <g id="Path_2">
            <path clipRule="evenodd" d={svgPaths.pa3b7e60} fill="var(--fill-0, white)" fillOpacity="0.24" fillRule="evenodd" />
            <path d={svgPaths.p13053480} fill="var(--fill-0, white)" fillOpacity="0.24" />
            <path d={svgPaths.p2d1713c0} stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-[#2e61ff] overflow-clip relative rounded-[921.57px] shadow-[0px_3.69px_7.38px_-1.845px_rgba(3,41,82,0.06),0px_1.845px_2.767px_0px_rgba(3,41,82,0.06),0px_0.692px_0.692px_0px_rgba(3,41,82,0.06),0px_0px_0px_2.767px_white,0px_0px_0px_6.457px_rgba(46,97,255,0.08)] shrink-0 size-[44.28px]" data-name="card_1">
      <FoldersFolder />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col gap-[3.69px] items-center leading-[0] not-italic relative shrink-0 text-[11.992px] whitespace-nowrap">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#334155]">
        <p className="leading-[1.4]">Documentação</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#475569]">
        <p className="leading-[1.4]">18/04/25</p>
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-center relative shrink-0">
      <Card1 />
      <Frame14 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 22.1398">
        <g id="Group">
          <g id="Path">
            <path clipRule="evenodd" d={svgPaths.p24bed800} fill="var(--fill-0, #F1F5F9)" fillRule="evenodd" />
            <path d={svgPaths.p24bed800} stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          </g>
          <g id="Path_2">
            <path clipRule="evenodd" d={svgPaths.pe00ba84} fill="var(--fill-0, #F1F5F9)" fillRule="evenodd" />
            <path d={svgPaths.pe00ba84} stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          </g>
          <g id="Path_3" />
          <path clipRule="evenodd" d={svgPaths.p2e2cd780} fill="var(--fill-0, #F1F5F9)" fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
        </g>
      </svg>
    </div>
  );
}

function SeoGraphGoogleAnalitycs() {
  return (
    <div className="absolute left-[10.61px] size-[22.14px] top-[11.07px]" data-name="SEO/Graph, Google, Analitycs">
      <Group />
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-white overflow-clip relative rounded-[921.57px] shadow-[0px_3.69px_7.38px_-1.845px_rgba(3,41,82,0.03),0px_1.845px_2.767px_0px_rgba(3,41,82,0.03),0px_0.692px_0.692px_0px_rgba(3,41,82,0.04),0px_0px_0px_0.922px_rgba(3,41,82,0.04)] shrink-0 size-[44.28px]" data-name="card_1">
      <SeoGraphGoogleAnalitycs />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#64748b] text-[11.992px] whitespace-nowrap">
        <p className="leading-[1.4]">Análise</p>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-center relative shrink-0">
      <Card2 />
      <Frame16 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[16.67%_12.51%_16.67%_16.67%]" data-name="Group">
      <div className="absolute inset-[-4.69%_-4.41%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.065 16.1433">
          <g id="Group">
            <g id="Path">
              <path clipRule="evenodd" d={svgPaths.p2554f980} fill="var(--fill-0, #F1F5F9)" fillRule="evenodd" />
              <path d={svgPaths.p2554f980} stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
            </g>
            <path d="M4.84308 15.4494V5.96294" id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function InterfaceEssentialThumbsUpLike3Big() {
  return (
    <div className="absolute left-[11.3px] size-[22.14px] top-[11.07px]" data-name="Interface, Essential/thumbs-up-like-3-big">
      <Group1 />
    </div>
  );
}

function Card3() {
  return (
    <div className="bg-white overflow-clip relative rounded-[921.57px] shadow-[0px_3.69px_7.38px_-1.845px_rgba(3,41,82,0.03),0px_1.845px_2.767px_0px_rgba(3,41,82,0.03),0px_0.692px_0.692px_0px_rgba(3,41,82,0.04),0px_0px_0px_0.922px_rgba(3,41,82,0.04)] shrink-0 size-[44.28px]" data-name="card_1">
      <InterfaceEssentialThumbsUpLike3Big />
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#64748b] text-[11.992px] whitespace-nowrap">
        <p className="leading-[1.4]">Contratação</p>
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-center relative shrink-0">
      <Card3 />
      <Frame18 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.149 22.149">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.pf251d80} fill="var(--fill-0, #F1F5F9)" fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p2ee8b100} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p1bfd72c0} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path clipRule="evenodd" d={svgPaths.pccd2000} fill="var(--fill-0, #F1F5F9)" fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function TechnologySpaceSpaceRocket() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-[calc(50%+0.92px)] size-[22.14px] top-1/2" data-name="Technology, Space/space-rocket">
      <Group2 />
    </div>
  );
}

function Card4() {
  return (
    <div className="bg-white overflow-clip relative rounded-[921.57px] shadow-[0px_3.69px_7.38px_-1.845px_rgba(3,41,82,0.03),0px_1.845px_2.767px_0px_rgba(3,41,82,0.03),0px_0.692px_0.692px_0px_rgba(3,41,82,0.04),0px_0px_0px_0.922px_rgba(3,41,82,0.04)] shrink-0 size-[44.28px]" data-name="card_1">
      <TechnologySpaceSpaceRocket />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#64748b] text-[11.992px] whitespace-nowrap">
        <p className="leading-[1.4]">Oferta</p>
      </div>
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-center relative shrink-0">
      <Card4 />
      <Frame20 />
    </div>
  );
}

function SpinnerDots() {
  return (
    <div className="absolute left-[67.34px] size-[22.14px] top-[11.07px]" data-name="spinner-dots">
      <div className="absolute inset-[-8.33%_-25%_-41.67%_-25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 33.2097 33.2097">
          <g filter="url(#filter0_ddddi_1_3431)" id="spinner-dots">
            <rect fill="var(--fill-0, white)" height="22.1398" rx="11.0699" shapeRendering="crispEdges" width="22.1398" x="5.53495" y="1.84498" />
            <path d="M16.4203 7.74885V9.65745" id="Line" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d={svgPaths.p480fd80} id="Line_2" opacity="0.8" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d="M21.9556 13.2838H20.047" id="Line_3" opacity="0.7" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d={svgPaths.pcb26200} id="Line_4" opacity="0.6" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d="M16.4203 18.8189V16.9103" id="Line_5" opacity="0.5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d={svgPaths.p33386c40} id="Line_6" opacity="0.3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d="M10.8854 13.2838H12.794" id="Line_7" opacity="0.2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
            <path d={svgPaths.p30a7a80} id="Line_8" opacity="0.1" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.61038" />
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="33.2097" id="filter0_ddddi_1_3431" width="33.2097" x="-2.38419e-07" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="0.922492" />
              <feGaussianBlur stdDeviation="0.922492" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_3431" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.84498" />
              <feGaussianBlur stdDeviation="1.84498" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_3431" mode="normal" result="effect2_dropShadow_1_3431" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.84498" result="effect3_dropShadow_1_3431" />
              <feOffset dy="3.68997" />
              <feGaussianBlur stdDeviation="3.68997" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.06 0" />
              <feBlend in2="effect2_dropShadow_1_3431" mode="normal" result="effect3_dropShadow_1_3431" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.922492" result="effect4_dropShadow_1_3431" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect3_dropShadow_1_3431" mode="normal" result="effect4_dropShadow_1_3431" />
              <feBlend in="SourceGraphic" in2="effect4_dropShadow_1_3431" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.461246" result="effect5_innerShadow_1_3431" />
              <feOffset dy="-0.922492" />
              <feGaussianBlur stdDeviation="0.461246" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.06 0" />
              <feBlend in2="shape" mode="normal" result="effect5_innerShadow_1_3431" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <div className="absolute h-[11.07px] left-[44.28px] top-[10.15px] w-[7.38px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7.37994 11.0699">
          <path d={svgPaths.p38eb3000} fill="var(--fill-0, #2E61FF)" id="Rectangle 42439" />
        </svg>
      </div>
      <div className="absolute flex h-[11.07px] items-center justify-center left-[44.28px] top-[23.06px] w-[7.38px]">
        <div className="-scale-y-100 flex-none">
          <div className="h-[11.07px] relative w-[7.38px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7.37994 11.0699">
              <path d={svgPaths.p38eb3000} fill="var(--fill-0, #2E61FF)" id="Rectangle 42439" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute h-0 left-[27.67px] top-[22.14px] w-[404.052px]">
        <div className="absolute inset-[-0.92px_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 404.052 1.84498">
            <path d="M404.052 0.922492H0" id="Vector 3476" stroke="var(--stroke-0, #F1F5F9)" strokeWidth="1.84498" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[47.05px] top-[22.14px] w-[85.792px]">
        <div className="absolute inset-[-0.92px_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 85.7918 1.84498">
            <path d="M85.7918 0.922492H0" id="Vector 3477" stroke="url(#paint0_linear_1_3408)" strokeWidth="1.84498" />
            <defs>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3408" x1="0" x2="85.7918" y1="1.42249" y2="1.42249">
                <stop stopColor="#2E61FF" />
                <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <Frame9 />
      <Frame12 />
      <Frame15 />
      <Frame17 />
      <Frame19 />
      <SpinnerDots />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[22.14px] items-start relative shrink-0 w-full">
      <Frame46 />
      <Frame11 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex gap-[9.225px] items-center relative shrink-0 w-full">
      <div className="bg-[#e2e8f0] h-[11.07px] rounded-[2.767px] shrink-0 w-[3.69px]" />
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#1e293b] text-[12.915px] whitespace-nowrap">
        <p className="leading-[1.4]">Ação da etapa</p>
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame23 />
    </div>
  );
}

function FilesDocumentsFilesMinus() {
  return (
    <div className="relative shrink-0 size-[22.14px]" data-name="Files/documents-files-minus">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 22.1398">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p15629180} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d="M11.5312 10.6087H14.2986" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p2597e800} id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path clipRule="evenodd" d={svgPaths.p2773f100} fillRule="evenodd" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
        </g>
      </svg>
    </div>
  );
}

function Checkbox() {
  return (
    <div className="relative shrink-0 size-[18.45px]" data-name="checkbox">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.4498 18.4498">
        <g id="checkbox">
          <rect fill="var(--fill-0, #2E61FF)" height="14.7599" id="bg" rx="3.68997" width="14.7599" x="1.84498" y="1.84496" />
          <path d={svgPaths.p388f100} id="Vector 26" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
        </g>
      </svg>
    </div>
  );
}

function Frame31() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <FilesDocumentsFilesMinus />
      <Checkbox />
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex flex-col gap-[9.225px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#0f172a] text-[12.915px] whitespace-nowrap">
        <p className="leading-[1.4]">Contrato social</p>
      </div>
      <div className="bg-gradient-to-r from-[#e2e8f0] h-[9.225px] rounded-[921.57px] shrink-0 to-[#e2e8f0] via-[72.596%] via-[rgba(226,232,240,0.4)] w-[92.249px]" />
    </div>
  );
}

function Frame27() {
  return (
    <div className="bg-white relative rounded-[11.07px] shrink-0 w-[174.966px]">
      <div className="content-stretch flex flex-col gap-[22.14px] items-start overflow-clip pb-[22.14px] pt-[18.45px] px-[14.76px] relative rounded-[inherit] w-full">
        <Frame31 />
        <Frame32 />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.922px_0.922px_-0.461px_rgba(3,41,82,0.06)]" />
      <div aria-hidden="true" className="absolute border-[0.922px] border-[rgba(69,119,255,0.6)] border-solid inset-0 pointer-events-none rounded-[11.07px] shadow-[0px_3.69px_7.38px_-1.845px_rgba(3,41,82,0.06),0px_1.845px_3.69px_0px_rgba(3,41,82,0.04),0px_0.922px_1.845px_0px_rgba(3,41,82,0.04),0px_0px_0px_3.69px_rgba(46,97,255,0.04)]" />
    </div>
  );
}

function FilesDocumentsFilesMinus1() {
  return (
    <div className="relative shrink-0 size-[22.14px]" data-name="Files/documents-files-minus">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 22.1398">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p15629180} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d="M11.5312 10.6087H14.2986" id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p2597e800} id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path clipRule="evenodd" d={svgPaths.p2773f100} fillRule="evenodd" id="Path_5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
        </g>
      </svg>
    </div>
  );
}

function Checkbox1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[18.45px]" data-name="checkbox">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#e2e8f0] left-1/2 rounded-[3.69px] size-[14.76px] top-1/2" data-name="bg" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-white left-1/2 rounded-[2.398px] shadow-[0px_1.845px_1.845px_0px_rgba(27,28,29,0.12)] size-[11.992px] top-1/2" data-name="box" />
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <FilesDocumentsFilesMinus1 />
      <Checkbox1 />
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#94a3b8] text-[12.915px] whitespace-nowrap">
        <p className="leading-[1.4]">Balanço patrimonial</p>
      </div>
      <div className="bg-gradient-to-r from-[#e2e8f0] h-[9.225px] opacity-40 rounded-[921.57px] shrink-0 to-[#e2e8f0] via-[72.596%] via-[rgba(226,232,240,0.4)] w-[92.249px]" />
    </div>
  );
}

function Frame33() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[22.14px] items-start overflow-clip pb-[22.14px] pt-[18.45px] px-[14.76px] relative rounded-[11.07px] shrink-0 w-[174.966px]">
      <Frame34 />
      <Frame35 />
    </div>
  );
}

function FilesDocumentsFilesMinus2() {
  return (
    <div className="relative shrink-0 size-[22.14px]" data-name="Files/documents-files-minus">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 22.1398">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p15629180} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d="M11.5312 10.6087H14.2986" id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path d={svgPaths.p2597e800} id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
          <path clipRule="evenodd" d={svgPaths.p2773f100} fillRule="evenodd" id="Path_5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.38374" />
        </g>
      </svg>
    </div>
  );
}

function Checkbox2() {
  return (
    <div className="overflow-clip relative shrink-0 size-[18.45px]" data-name="checkbox">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#e2e8f0] left-1/2 rounded-[3.69px] size-[14.76px] top-1/2" data-name="bg" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-white left-1/2 rounded-[2.398px] shadow-[0px_1.845px_1.845px_0px_rgba(27,28,29,0.12)] size-[11.992px] top-1/2" data-name="box" />
    </div>
  );
}

function Frame37() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <FilesDocumentsFilesMinus2 />
      <Checkbox2 />
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex flex-col gap-[11.07px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#94a3b8] text-[12.915px] whitespace-nowrap">
        <p className="leading-[1.4]">Apresentação Institucional</p>
      </div>
      <div className="bg-gradient-to-r from-[#e2e8f0] h-[9.225px] opacity-40 rounded-[921.57px] shrink-0 to-[#e2e8f0] via-[72.596%] via-[rgba(226,232,240,0.4)] w-[92.249px]" />
    </div>
  );
}

function Frame36() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[22.14px] items-start overflow-clip pb-[22.14px] pt-[18.45px] px-[14.76px] relative rounded-[11.07px] shrink-0">
      <Frame37 />
      <Frame38 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="content-stretch flex gap-[14.76px] items-start relative shrink-0 w-full">
      <Frame27 />
      <Frame33 />
      <Frame36 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col gap-[22.14px] items-start relative shrink-0 w-full">
      <Frame22 />
      <Frame25 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#f8fafc] relative rounded-[11.07px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[22.14px] items-start p-[14.76px] relative w-full">
          <Frame45 />
          <Frame13 />
          <div className="bg-[#e2e8f0] h-[0.922px] relative shrink-0 w-full">
            <div aria-hidden="true" className="absolute border-solid border-t-[0.922px] border-white inset-[-0.922px_0_0_0] pointer-events-none" />
          </div>
          <Frame21 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-[0.922px] border-solid inset-0 pointer-events-none rounded-[11.07px]" />
    </div>
  );
}

function Frame6() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col items-start pb-[7.38px] px-[7.38px] relative w-full">
        <Frame7 />
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col items-start left-[76.81px] overflow-clip rounded-[11.07px] shadow-[0px_0px_0px_0.922px_rgba(3,41,82,0.04),0px_0.922px_0.922px_0.461px_rgba(3,41,82,0.04),0px_2.767px_2.767px_-1.384px_rgba(3,41,82,0.02),0px_5.535px_5.535px_-2.767px_rgba(3,41,82,0.04),0px_11.07px_11.07px_-5.535px_rgba(3,41,82,0.04),0px_22.14px_22.14px_-11.07px_rgba(3,41,82,0.04),0px_44.28px_44.28px_-22.14px_rgba(3,41,82,0.04),0px_88.559px_88.559px_-29.52px_rgba(3,41,82,0.06)] top-[243.12px] w-[528.588px]">
      <Header />
      <Frame6 />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.922px_0.922px_-0.461px_rgba(3,41,82,0.06)]" />
    </div>
  );
}

function Lines() {
  return (
    <div className="absolute h-[44.28px] left-[16.84px] top-[661.01px] w-[22.14px]" data-name="lines">
      <div className="absolute inset-[-1.04%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1398 45.2021">
          <g id="lines">
            <path d={svgPaths.p35eb0c80} id="line" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <path d={svgPaths.pa414c80} id="line_2" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <path d={svgPaths.p16a6a300} id="line_3" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <path d={svgPaths.pd614880} id="line_4" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <path d={svgPaths.p3350d08} id="line_5" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <path d={svgPaths.p37e6ea00} id="line_6" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <path d={svgPaths.p2f55be40} id="line_7" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.922492" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame41() {
  return (
    <div className="h-[7.741px] relative shrink-0 w-[27.094px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27.0942 7.74121">
        <g id="Frame 1321314703">
          <path d={svgPaths.p383d1900} fill="var(--fill-0, #CBD5E1)" id="Vector" />
          <path d={svgPaths.p35eeb400} fill="var(--fill-0, #E2E8F0)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Frame42() {
  return (
    <div className="h-[37.158px] relative shrink-0 w-[54.962px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 54.9625 37.1577">
        <g id="Frame 1321314701">
          <path d={svgPaths.p1341700} fill="var(--fill-0, #E2E8F0)" id="Vector" />
          <path d={svgPaths.p36ebc480} fill="var(--fill-0, #E2E8F0)" id="Vector_2" />
          <path d={svgPaths.p1fc2e400} fill="var(--fill-0, #E2E8F0)" id="Vector_3" />
          <path d={svgPaths.p293a7c00} fill="var(--fill-0, #E2E8F0)" id="Vector_4" />
          <path d={svgPaths.p221238f2} fill="var(--fill-0, #E2E8F0)" id="Vector_5" />
          <path d={svgPaths.p3ab5f200} fill="var(--fill-0, #E2E8F0)" id="Vector_6" />
        </g>
      </svg>
    </div>
  );
}

function Seal() {
  return (
    <div className="h-[16.185px] relative shrink-0 w-[16.184px]" data-name="Seal 2 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.1841 16.1847">
        <g id="Seal 2 1">
          <path d={svgPaths.p17c2a300} fill="var(--fill-0, #E2E8F0)" id="Path 643 1" />
          <path d={svgPaths.p1d5a6500} fill="var(--fill-0, #E2E8F0)" id="Path 644 1" />
        </g>
      </svg>
    </div>
  );
}

function Group3() {
  return (
    <div className="h-[17.28px] relative shrink-0 w-[24.997px]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.9973 17.2803">
        <g id="Group">
          <path d={svgPaths.p3bffc700} fill="var(--fill-0, #CBD5E1)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame43() {
  return (
    <div className="content-stretch flex gap-[12.386px] items-end relative shrink-0">
      <Seal />
      <Group3 />
    </div>
  );
}

function Frame40() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[9.289px] h-[98.313px] items-center overflow-clip p-[9.289px] relative rounded-[0.922px] shadow-[0px_0px_0px_0.774px_rgba(3,41,82,0.04),0px_3.096px_6.193px_-1.548px_rgba(3,41,82,0.06),0px_1.548px_3.096px_0px_rgba(3,41,82,0.04),0px_0.774px_1.548px_0px_rgba(3,41,82,0.04)] shrink-0 w-[71.993px]">
      <Frame41 />
      <Frame42 />
      <Frame43 />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.774px_0.774px_-0.387px_rgba(3,41,82,0.06)]" />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[6.19px] top-[71.22px]">
      <div className="absolute bg-[#b0c9fe] h-[1.548px] left-[6.19px] top-[73.54px] w-[71.993px]" />
      <div className="absolute flex h-[6.193px] items-center justify-center left-[6.19px] top-[71.22px] w-[1.548px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 -scale-y-100 flex-none">
          <div className="bg-[#b0c9fe] h-[1.548px] rounded-[6.193px] w-[6.193px]" />
        </div>
      </div>
      <div className="absolute flex h-[6.193px] items-center justify-center left-[76.64px] top-[71.22px] w-[1.548px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="-rotate-90 -scale-y-100 flex-none">
          <div className="bg-[#b0c9fe] h-[1.548px] rounded-[6.193px] w-[6.193px]" />
        </div>
      </div>
    </div>
  );
}

function Frame39() {
  return (
    <div className="absolute backdrop-blur-[9.225px] content-stretch flex flex-col h-[110.699px] items-start left-[542.67px] overflow-clip p-[6.193px] rounded-[7.38px] shadow-[0px_0px_0px_0.774px_rgba(3,41,82,0.04),0px_0.774px_0.774px_0.387px_rgba(3,41,82,0.04),0px_2.322px_2.322px_-1.161px_rgba(3,41,82,0.02),0px_4.645px_4.645px_-2.322px_rgba(3,41,82,0.04),0px_9.289px_9.289px_-4.645px_rgba(3,41,82,0.04),0px_18.579px_18.579px_-9.289px_rgba(3,41,82,0.04),0px_37.158px_37.158px_-18.579px_rgba(3,41,82,0.04)] top-[508.79px] w-[84.379px]" style={{ backgroundImage: "linear-gradient(257.002deg, rgb(255, 255, 255) 153.49%, rgba(255, 255, 255, 0) 101.8%)" }}>
      <Frame40 />
      <div className="absolute bg-gradient-to-b from-[rgba(46,97,255,0.1)] h-[30.965px] left-[6.19px] to-[rgba(46,97,255,0)] top-[73.54px] w-[71.993px]" />
      <Group6 />
      <div className="absolute flex items-center justify-center left-[5.53px] size-[11.07px] top-[5.53px]">
        <div className="flex-none rotate-180">
          <div className="relative size-[11.07px]" data-name="Border (Stroke)">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.0699 11.0699">
              <path clipRule="evenodd" d={svgPaths.p9e0b220} fill="var(--fill-0, #4577FF)" fillRule="evenodd" id="Border (Stroke)" opacity="0.5" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[68.26px] size-[11.07px] top-[5.53px]">
        <div className="-scale-y-100 flex-none">
          <div className="relative size-[11.07px]" data-name="Border (Stroke)">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.0699 11.0699">
              <path clipRule="evenodd" d={svgPaths.p9e0b220} fill="var(--fill-0, #4577FF)" fillRule="evenodd" id="Border (Stroke)" opacity="0.5" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[5.53px] size-[11.07px] top-[94.09px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[11.07px]" data-name="Border (Stroke)">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.0699 11.0699">
              <path clipRule="evenodd" d={svgPaths.p9e0b220} fill="var(--fill-0, #4577FF)" fillRule="evenodd" id="Border (Stroke)" opacity="0.5" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[68.26px] size-[11.07px] top-[94.09px]" data-name="Border (Stroke)">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.0699 11.0699">
          <path clipRule="evenodd" d={svgPaths.p9e0b220} fill="var(--fill-0, #4577FF)" fillRule="evenodd" id="Border (Stroke)" opacity="0.5" />
        </svg>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.774px_0.774px_-0.387px_rgba(3,41,82,0.06)]" />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[542.67px] top-[508.79px]">
      <Frame39 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[-0.5px] top-0">
      <Texture />
      <div className="absolute h-[40.59px] left-[-0.5px] top-[731.12px] w-[211.068px]" data-name="line">
        <div className="absolute inset-[-0.76%_-0.16%_-1.14%_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 211.41 41.3613">
            <path d={svgPaths.p1b162240} id="line" stroke="url(#paint0_linear_1_3422)" strokeOpacity="0.6" strokeWidth="0.922492" />
            <defs>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3422" x1="15.5" x2="839.139" y1="20.6052" y2="20.6052">
                <stop stopColor="#D4E1FD" stopOpacity="0" />
                <stop offset="0.0384615" stopColor="#D4E1FD" />
                <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute flex h-[40.59px] items-center justify-center left-[626.61px] top-[470.97px] w-[156.824px]">
        <div className="flex-none rotate-180">
          <div className="h-[40.59px] relative w-[156.824px]" data-name="line">
            <div className="absolute inset-[-0.67%_-0.24%_-1.14%_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 157.196 41.3228">
                <path d={svgPaths.p2b6773c0} id="line" stroke="url(#paint0_linear_1_3527)" strokeOpacity="0.6" strokeWidth="0.922492" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3527" x1="0" x2="660.466" y1="20.5667" y2="20.5667">
                    <stop stopColor="#D4E1FD" />
                    <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[40.59px] items-center justify-center left-[556.5px] top-[731px] w-[156.824px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="h-[40.59px] relative w-[156.824px]" data-name="line">
            <div className="absolute inset-[-0.67%_-0.24%_-1.14%_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 157.196 41.3228">
                <path d={svgPaths.p2b6773c0} id="line" stroke="url(#paint0_linear_1_3479)" strokeOpacity="0.6" strokeWidth="0.922492" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3479" x1="0" x2="660.466" y1="20.5667" y2="20.5667">
                    <stop stopColor="#D4E1FD" />
                    <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[310.88px] items-center justify-center left-[13.15px] top-[185px] w-[29.52px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-[29.52px] relative w-[310.88px]" data-name="line">
            <div className="absolute inset-[-1.56%_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 310.88 30.4422">
                <path d={svgPaths.p13e35000} id="line" stroke="url(#paint0_linear_1_3474)" strokeOpacity="0.6" strokeWidth="0.922492" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3474" x1="-3.22588e-07" x2="310.88" y1="11.5312" y2="11.5312">
                    <stop stopColor="#D4E1FD" />
                    <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame26 />
      <Frame2 />
      <Frame3 />
      <Frame1 />
      <Lines />
      <Group7 />
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center not-italic relative shrink-0 text-center" data-name="content">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Uma plataforma, múltiplas soluções
      </p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#475569] text-[16px] w-[442px] whitespace-pre-wrap">
        {`Transformando o Mercado de Capitais `}
        <br aria-hidden="true" />
        em um ambiente 100% digital.
      </p>
    </div>
  );
}

function Dot() {
  return <div className="bg-[#2e61ff] h-[8px] rounded-[9999px] shrink-0 w-[32px]" data-name="dot" />;
}

function Dot1() {
  return <div className="bg-[rgba(15,23,42,0.08)] rounded-[9999px] shrink-0 size-[8px]" data-name="dot" />;
}

function Dot2() {
  return <div className="bg-[rgba(15,23,42,0.08)] rounded-[9999px] shrink-0 size-[8px]" data-name="dot" />;
}

function Dots() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="dots">
      <Dot />
      <Dot1 />
      <Dot2 />
    </div>
  );
}

function Frame50() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[32px] items-center left-[calc(50%+0.02px)] top-[831px]">
      <Content9 />
      <Dots />
    </div>
  );
}

function Camada() {
  return (
    <div className="absolute inset-[5.49%_-0.11%_22.16%_0]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 112.126 26.0459">
        <g id="Camada_1-2">
          <path d={svgPaths.p2adb5e00} fill="var(--fill-0, #020617)" id="Vector" />
          <path d={svgPaths.p26b68980} fill="var(--fill-0, #020617)" id="Vector_2" />
          <path d={svgPaths.p322ea900} fill="var(--fill-0, #020617)" id="Vector_3" />
          <path d={svgPaths.p3e2b1380} fill="var(--fill-0, #020617)" id="Vector_4" />
          <path d={svgPaths.p23bbae00} fill="var(--fill-0, #020617)" id="Vector_5" />
          <path d={svgPaths.p915fd00} fill="var(--fill-0, #020617)" id="Vector_6" />
          <path d={svgPaths.p1a2d4800} fill="var(--fill-0, #2E61FF)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function Logotype() {
  return (
    <div className="-translate-x-1/2 absolute h-[36px] left-1/2 overflow-clip top-[32px] w-[112px]" data-name="logotype">
      <Camada />
    </div>
  );
}

function Dots1() {
  return (
    <div className="h-[82px] relative w-[142px]" data-name="dots">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 142 82">
        <g id="dots">
          <circle cx="11" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21868" r="1" />
          <circle cx="121" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21871" r="1" />
          <circle cx="131" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21876" r="1" />
          <circle cx="141" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21879" r="1" />
          <circle cx="21" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21874" r="1" />
          <circle cx="31" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21875" r="1" />
          <circle cx="111" cy="11" fill="var(--fill-0, #2E61FF)" id="Ellipse 21870" opacity="0.3" r="1" />
          <circle cx="121" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21871_2" r="1" />
          <circle cx="131" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21876_2" r="1" />
          <circle cx="131" cy="21" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21876_3" r="1" />
          <circle cx="141" cy="21" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21879_2" r="1" />
          <circle cx="11" cy="31" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21868_2" r="1" />
          <circle cx="51" cy="31" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21870_2" r="1" />
          <circle cx="11" cy="41" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21868_3" r="1" />
          <circle cx="41" cy="41" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21869" r="1" />
          <circle cx="1" cy="61" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21867" r="1" />
          <circle cx="61" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21872" r="1" />
          <circle cx="91" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21901" r="1" />
          <circle cx="111" cy="71" fill="var(--fill-0, #2E61FF)" id="Ellipse 21902" opacity="0.3" r="1" />
          <circle cx="121" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21892" r="1" />
          <circle cx="141" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21880" r="1" />
          <circle cx="41" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21906" r="1" />
          <circle cx="91" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21895" r="1" />
          <circle cx="121" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21910" r="1" />
        </g>
      </svg>
    </div>
  );
}

function Dots2() {
  return (
    <div className="h-[82px] relative w-[142px]" data-name="dots">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 142 82">
        <g id="dots">
          <circle cx="11" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21868" r="1" />
          <circle cx="71" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21876" r="1" />
          <circle cx="81" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21879" r="1" />
          <circle cx="21" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21874" r="1" />
          <circle cx="31" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21875" r="1" />
          <circle cx="11" cy="31" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21868_2" r="1" />
          <circle cx="11" cy="41" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21868_3" r="1" />
          <circle cx="21" cy="41" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21874_2" r="1" />
          <circle cx="81" cy="41" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21879_2" r="1" />
          <circle cx="71" cy="51" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21876_2" r="1" />
          <circle cx="1" cy="61" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21867" r="1" />
          <circle cx="11" cy="61" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21882" r="1" />
          <circle cx="21" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21879_3" r="1" />
          <circle cx="91" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21901" r="1" />
          <circle cx="111" cy="71" fill="var(--fill-0, #2E61FF)" id="Ellipse 21902" opacity="0.3" r="1" />
          <circle cx="121" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21892" r="1" />
          <circle cx="141" cy="71" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21880" r="1" />
          <circle cx="11" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21893" r="1" />
          <circle cx="41" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21906" r="1" />
          <circle cx="91" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21895" r="1" />
          <circle cx="121" cy="81" fill="var(--fill-0, #032952)" fillOpacity="0.12" id="Ellipse 21910" r="1" />
        </g>
      </svg>
    </div>
  );
}

function LoginImage() {
  return (
    <div className="h-[1008px] overflow-clip relative rounded-[24px] shrink-0 w-[712px]" data-name="Login Image">
      <Bg />
      <Group8 />
      <Frame50 />
      <Logotype />
      <div className="absolute flex h-[82px] items-center justify-center left-[526px] top-[117px] w-[142px]">
        <div className="flex-none rotate-180">
          <Dots1 />
        </div>
      </div>
      <div className="absolute flex h-[82px] items-center justify-center left-[25px] top-[896px] w-[142px]">
        <div className="-scale-y-100 flex-none rotate-180">
          <Dots2 />
        </div>
      </div>
    </div>
  );
}

export default function Component1CadastroDadosIniciaisLightMode() {
  return (
    <div className="bg-white content-stretch flex items-center justify-between overflow-clip p-[8px] relative rounded-[24px] size-full" data-name="1. Cadastro / Dados Iniciais [Light Mode]">
      <Container />
      <LoginImage />
    </div>
  );
}