import svgPaths from "./svg-a81a4s0sas";
import imgTexture from "figma:asset/49b10b9ed2e210e5e2ae2f86906940de3b56018c.png";
import imgImage from "figma:asset/2e2cf1b6f441c6f28c3b0e1e0eb4863eb80b7401.png";
import imgImage1 from "figma:asset/54632d2d8b3aae9b589a5e7462a72e6cd10174ef.png";
import imgImage2 from "figma:asset/e59efe492be663f219c2dd8f5bf13c835d1e95d3.png";
import imgImage3 from "figma:asset/b62370d72a2407a4e768af8668fbcd5db0e16279.png";
import imgImage4 from "figma:asset/d688ab8bff2aebfc3cab587865468c4713ecad78.png";
import imgImage5 from "figma:asset/9a8e3295558857dc96c9e60a2ae4f30d3cab6c73.png";

function Mosaic() {
  return (
    <div className="absolute h-[108px] left-0 mix-blend-difference top-0 w-[1272px]" data-name="mosaic">
      <div className="absolute bg-size-[320.0000047683716px_320.0000047683716px] bg-top-left inset-0 mix-blend-difference" data-name="texture" style={{ backgroundImage: `url('${imgTexture}')` }} />
    </div>
  );
}

function Component() {
  return (
    <div className="absolute contents left-[-1px] top-[-1px]" data-name="1">
      <Mosaic />
      <div className="absolute flex h-[108px] items-center justify-center left-[-1px] top-0 w-[1273px]">
        <div className="-scale-y-100 flex-none">
          <div className="bg-[rgba(255,255,255,0.34)] h-[108px] w-[1273px]" />
        </div>
      </div>
    </div>
  );
}

function Surface() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 59.0675 31.9832">
        <g id="surface1">
          <path d={svgPaths.p274f7d80} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p10814780} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p3b748c00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[32px] left-[calc(50%-0.15px)] overflow-clip top-1/2 w-[59.692px]" data-name="Frame">
      <Surface />
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute bg-[#001fa1] blur-[0px] left-[23px] overflow-clip rounded-[9999px] shadow-[0px_23.867px_41.767px_-5.967px_rgba(32,49,86,0.03),0px_11.933px_17.9px_-5.967px_rgba(33,49,86,0.03),0px_5.967px_11.933px_-2.983px_rgba(32,49,86,0.03),0px_2.983px_5.967px_-1.492px_rgba(32,49,86,0.03),0px_1.492px_2.238px_0px_rgba(32,49,86,0.03),0px_0.559px_0.559px_0px_rgba(55,55,82,0.04),0px_0px_0px_0.746px_rgba(55,55,82,0.04)] size-[112px] top-[76px]">
      <Frame />
    </div>
  );
}

function VerifiedBadge() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="verified-badge">
      <div className="absolute inset-[-7.03%_-14.05%_-21.08%_-14.05%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.2154 19.2154">
          <g id="verified-badge">
            <g filter="url(#filter0_dii_8_26475)" id="Vector">
              <path clipRule="evenodd" d={svgPaths.p1c360c00} fill="var(--fill-0, #2E61FF)" fillRule="evenodd" />
              <path clipRule="evenodd" d={svgPaths.p1c360c00} fill="url(#paint0_linear_8_26475)" fillOpacity="0.2" fillRule="evenodd" />
              <path d={svgPaths.p21e6b100} stroke="var(--stroke-0, black)" strokeOpacity="0.2" strokeWidth="0.5" />
            </g>
            <g id="check-mini">
              <path d={svgPaths.p3c992d80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="19.2154" id="filter0_dii_8_26475" width="19.2154" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.05385" />
              <feGaussianBlur stdDeviation="1.05385" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_8_26475" />
              <feBlend in="SourceGraphic" in2="effect1_dropShadow_8_26475" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.05385" />
              <feGaussianBlur stdDeviation="1.05385" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.1 0" />
              <feBlend in2="shape" mode="normal" result="effect2_innerShadow_8_26475" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1.05385" />
              <feGaussianBlur stdDeviation="2.63462" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.1 0" />
              <feBlend in2="effect2_innerShadow_8_26475" mode="normal" result="effect3_innerShadow_8_26475" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_8_26475" x1="9.60769" x2="9.60769" y1="1.05385" y2="16.0538">
              <stop stopColor="white" />
              <stop offset="1" stopColor="white" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] not-italic overflow-hidden relative shrink-0 text-[#020617] text-[24px] text-ellipsis tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Banco BS2
      </p>
      <VerifiedBadge />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] items-start left-[167px] top-[131px]">
      <Frame4 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#64748b] text-[14px]">71.027.866/0001-34</p>
    </div>
  );
}

function ContentEditPenEdit() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Content, Edit/Pen, Edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2765a600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.75 7.16L16.84 10.25" id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-white right-[11px] rounded-[8px] size-[40px] top-[11px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[inherit] size-full">
        <ContentEditPenEdit />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p3c2ff9e0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path clipRule="evenodd" d={svgPaths.p2d11b5f0} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialPenEdit() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Pen, Edit">
      <Group />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-white left-[103px] rounded-[9999px] size-[32px] top-[156px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[inherit] size-full">
        <InterfaceEssentialPenEdit />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[9999px] shadow-[0px_0px_0px_3px_white]" />
    </div>
  );
}

function CardsDealboard() {
  return (
    <div className="border border-[#e2e8f0] border-solid col-1 h-[229px] ml-0 mt-0 overflow-clip relative rounded-[16px] row-1 w-[1272px]" data-name="Cards-Dealboard" style={{ backgroundImage: "linear-gradient(199.829deg, rgba(46, 97, 255, 0) 71.692%, rgba(46, 97, 255, 0.1) 136.27%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }}>
      <div className="absolute bg-[#eef4ff] h-[108px] left-[-1px] top-[-1px] w-[1272px]" />
      <Component />
      <Frame3 />
      <Frame1 />
      <Button />
      <Button1 />
    </div>
  );
}

function Profile() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Profile">
      <CardsDealboard />
    </div>
  );
}

function Divider() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1276 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="1276" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function SettingsIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Settings Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.p35d24f80} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="12" cy="12" id="Oval" r="3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function SidebarHeader() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="Sidebar Header">
      <SettingsIcon />
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[18px] whitespace-nowrap">
        <p className="leading-[1.5]">Configurações</p>
      </div>
    </div>
  );
}

function CompanyDataIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Company Data Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p22f32f00} id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p32853d00} id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pd7b1ac0} id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M9.5 17H14.5" id="Path_4" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M13.5 17V21" id="Path_5" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.5 21V17" id="Path_6" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10 10.5H14" id="Path_7" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10 13.5H14" id="Path_8" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10 7.5H14" id="Path_9" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M5 13.5H7" id="Path_10" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M5 17H7" id="Path_11" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M17 13.5H19" id="Path_12" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M17 17H19" id="Path_13" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M23 21H1" id="Path_14" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_15" />
        </g>
      </svg>
    </div>
  );
}

function CompanyDataContainer() {
  return (
    <div className="relative rounded-[12px] shrink-0 w-full" data-name="Company Data Container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <CompanyDataIcon />
          <div className="flex flex-[1_0_0] flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] min-h-px min-w-px not-italic relative text-[#64748b] text-[16px]">
            <p className="leading-[1.5] whitespace-pre-wrap">Dados da empresa</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MembersIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Members Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p358e6980} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p360dfe60} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2dfcc6e0} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-white h-[24px] relative rounded-[9999px] shrink-0 w-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[16px] py-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[9999px]" />
    </div>
  );
}

function MembersContainer() {
  return (
    <div className="bg-white relative rounded-[12px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)] shrink-0 w-full" data-name="Members Container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <MembersIcon />
          <div className="flex flex-[1_0_0] flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] min-h-px min-w-px not-italic relative text-[#020617] text-[16px]">
            <p className="leading-[1.5] whitespace-pre-wrap">Membros</p>
          </div>
          <Button2 />
        </div>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[8.33%_12.5%_8.34%_12.5%]" data-name="Group">
      <div className="absolute inset-[-3.75%_-4.17%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5 21.5">
          <g id="Group">
            <path d={svgPaths.p35fd9d80} id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p383c1a80} id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3a10fec8} id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1ad24780} id="Path_4" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1615cf80} id="Path_5" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p967d100} id="Path_6" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2469e920} id="Path_7" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M4.5 6L5.75 7.25" id="Path_8" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M7.75 5.25L5.75 7.25" id="Path_9" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.25 6.75H14.75" id="Path_10" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function DealmatchIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Dealmatch Icon">
      <Group1 />
    </div>
  );
}

function InformationCircleSolid() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_8_26492)" id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.p4d4ee00} fill="var(--fill-0, #94A3B8)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_8_26492">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function DealmatchContainer() {
  return (
    <div className="relative rounded-[12px] shrink-0 w-full" data-name="Dealmatch Container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <DealmatchIcon />
          <div className="flex flex-[1_0_0] flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] min-h-px min-w-px not-italic relative text-[#64748b] text-[16px]">
            <p className="leading-[1.5] whitespace-pre-wrap">Dealmatch</p>
          </div>
          <InformationCircleSolid />
        </div>
      </div>
    </div>
  );
}

function SidebarMenu() {
  return (
    <div className="bg-[#f1f5f9] relative rounded-[16px] shrink-0 w-full" data-name="Sidebar Menu">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[12px] items-start px-[12px] py-[8px] relative w-full">
          <CompanyDataContainer />
          <MembersContainer />
          <DealmatchContainer />
          <div className="absolute bg-[#2e61ff] h-[56px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[76px] w-[3px]" data-name="state" />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-[295px]" data-name="Sidebar">
      <SidebarHeader />
      <SidebarMenu />
    </div>
  );
}

function WorkspaceMembersIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Workspace Members Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p358e6980} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p360dfe60} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2dfcc6e0} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p396e8020} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M19 19L15.71 15.71" id="Path_3" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialSearchLoupe() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Search, Loupe">
      <Group2 />
    </div>
  );
}

function Search() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0 w-[250px]" data-name="Search">
      <div className="content-stretch flex gap-[8px] items-center overflow-clip px-[12px] relative rounded-[inherit] size-full">
        <InterfaceEssentialSearchLoupe />
        <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#64748b] text-[14px] whitespace-pre-wrap">Buscar membros</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Adicionar membros</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d="M12 8V16" id="Path_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M16 12H8" id="Path_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialPlusAdd() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Plus, Add">
      <Group3 />
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[40px] items-center justify-center overflow-clip px-[20px] py-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content />
      <InterfaceEssentialPlusAdd />
    </div>
  );
}

function WorkspaceMembersActions() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0" data-name="Workspace Members Actions">
      <Search />
      <div className="flex h-[16px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[16px]" data-name="line">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 1">
                <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="16" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Button3 />
    </div>
  );
}

function WorkspaceMembersHeader() {
  return (
    <div className="content-stretch flex gap-[12px] items-center pb-[24px] relative shrink-0 w-full" data-name="Workspace Members Header">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <WorkspaceMembersIcon />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[18px] whitespace-pre-wrap">Membro do workspace</p>
      <WorkspaceMembersActions />
    </div>
  );
}

function SortingIcons() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[24px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Membro</p>
      <SortingIcons />
    </div>
  );
}

function SortingIcons1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label1() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[229px] top-[10px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Permissão</p>
      <SortingIcons1 />
    </div>
  );
}

function SortingIcons2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label2() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[447px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Status</p>
      <SortingIcons2 />
    </div>
  );
}

function SortingIcons3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label3() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[676px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Último acesso</p>
      <SortingIcons3 />
    </div>
  );
}

function Header() {
  return (
    <div className="h-[48px] overflow-clip relative rounded-[16px] shrink-0 w-full" data-name="header">
      <Label />
      <Label1 />
      <Label2 />
      <Label3 />
    </div>
  );
}

function Avatar() {
  return (
    <div className="bg-[#e2e8f0] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Lucas Ayres</p>
      </div>
    </div>
  );
}

function TableRowCell() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar />
          <Content1 />
        </div>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Dono</p>
    </div>
  );
}

function TableRowCell1() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content2 />
        </div>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Ativo</p>
    </div>
  );
}

function Badge() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content3 />
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge />
    </div>
  );
}

function TableRowCell2() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container1 />
        </div>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Há 2 semanas</p>
    </div>
  );
}

function TableRowCell3() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content4 />
        </div>
      </div>
    </div>
  );
}

function ContentEditPenEdit1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Content, Edit/Pen, Edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2765a600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.75 7.16L16.84 10.25" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell4() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <ContentEditPenEdit1 />
    </div>
  );
}

function MemberRow() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Member Row">
      <TableRowCell />
      <TableRowCell1 />
      <TableRowCell2 />
      <TableRowCell3 />
      <TableRowCell4 />
    </div>
  );
}

function Divider1() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar1() {
  return (
    <div className="bg-[#fed7aa] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Jessica Mota</p>
      </div>
    </div>
  );
}

function TableRowCell5() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar1 />
          <Content5 />
        </div>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Administrador</p>
    </div>
  );
}

function TableRowCell6() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content6 />
        </div>
      </div>
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Ativo</p>
    </div>
  );
}

function Badge1() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content7 />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge1 />
    </div>
  );
}

function TableRowCell7() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container2 />
        </div>
      </div>
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Há 24 minutos</p>
    </div>
  );
}

function TableRowCell8() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content8 />
        </div>
      </div>
    </div>
  );
}

function ContentEditPenEdit2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Content, Edit/Pen, Edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2765a600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.75 7.16L16.84 10.25" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell9() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <ContentEditPenEdit2 />
    </div>
  );
}

function MemberRow1() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Member Row">
      <TableRowCell5 />
      <TableRowCell6 />
      <TableRowCell7 />
      <TableRowCell8 />
      <TableRowCell9 />
    </div>
  );
}

function Divider2() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar2() {
  return (
    <div className="bg-[#a4f4cf] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
      </div>
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Caio Paixão</p>
      </div>
    </div>
  );
}

function TableRowCell10() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar2 />
          <Content9 />
        </div>
      </div>
    </div>
  );
}

function Content10() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Membro</p>
    </div>
  );
}

function TableRowCell11() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content10 />
        </div>
      </div>
    </div>
  );
}

function Content11() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Ativo</p>
    </div>
  );
}

function Badge2() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content11 />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge2 />
    </div>
  );
}

function TableRowCell12() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container3 />
        </div>
      </div>
    </div>
  );
}

function Content12() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Há 3 meses</p>
    </div>
  );
}

function TableRowCell13() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content12 />
        </div>
      </div>
    </div>
  );
}

function ContentEditPenEdit3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Content, Edit/Pen, Edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2765a600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.75 7.16L16.84 10.25" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell14() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <ContentEditPenEdit3 />
    </div>
  );
}

function MemberRow2() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Member Row">
      <TableRowCell10 />
      <TableRowCell11 />
      <TableRowCell12 />
      <TableRowCell13 />
      <TableRowCell14 />
    </div>
  );
}

function Divider3() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar3() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="avatar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="avatar">
          <g clipPath="url(#clip0_8_26507)">
            <path d={svgPaths.p16b6ae00} fill="var(--fill-0, #F1F5F9)" />
            <ellipse cx="16" cy="29.6" fill="var(--fill-0, #F8FAFC)" id="Body" rx="12.8" ry="9.6" />
            <circle cx="16" cy="10.4" fill="var(--fill-0, #F8FAFC)" id="Head" opacity="0.9" r="5.6" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_8_26507">
            <path d={svgPaths.p16b6ae00} fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Content13() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Nataly Lima</p>
      </div>
    </div>
  );
}

function TableRowCell15() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar3 />
          <Content13 />
        </div>
      </div>
    </div>
  );
}

function Content14() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Visualizador</p>
    </div>
  );
}

function TableRowCell16() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content14 />
        </div>
      </div>
    </div>
  );
}

function Content15() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Desativado</p>
    </div>
  );
}

function Badge3() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content15 />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge3 />
    </div>
  );
}

function TableRowCell17() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container4 />
        </div>
      </div>
    </div>
  );
}

function Content16() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Há 8 meses</p>
    </div>
  );
}

function TableRowCell18() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content16 />
        </div>
      </div>
    </div>
  );
}

function ContentEditPenEdit4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Content, Edit/Pen, Edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2765a600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.75 7.16L16.84 10.25" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell19() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <ContentEditPenEdit4 />
    </div>
  );
}

function MemberRow3() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Member Row">
      <TableRowCell15 />
      <TableRowCell16 />
      <TableRowCell17 />
      <TableRowCell18 />
      <TableRowCell19 />
    </div>
  );
}

function Divider4() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar4() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="avatar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="avatar">
          <g clipPath="url(#clip0_8_26507)">
            <path d={svgPaths.p16b6ae00} fill="var(--fill-0, #F1F5F9)" />
            <ellipse cx="16" cy="29.6" fill="var(--fill-0, #F8FAFC)" id="Body" rx="12.8" ry="9.6" />
            <circle cx="16" cy="10.4" fill="var(--fill-0, #F8FAFC)" id="Head" opacity="0.9" r="5.6" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_8_26507">
            <path d={svgPaths.p16b6ae00} fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Content17() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Filipe Goes</p>
      </div>
    </div>
  );
}

function TableRowCell20() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar4 />
          <Content17 />
        </div>
      </div>
    </div>
  );
}

function Content18() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Membro</p>
    </div>
  );
}

function TableRowCell21() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content18 />
        </div>
      </div>
    </div>
  );
}

function Content19() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Desativado</p>
    </div>
  );
}

function Badge4() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content19 />
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge4 />
    </div>
  );
}

function TableRowCell22() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container5 />
        </div>
      </div>
    </div>
  );
}

function Content20() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">Ontem</p>
    </div>
  );
}

function TableRowCell23() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content20 />
        </div>
      </div>
    </div>
  );
}

function ContentEditPenEdit5() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Content, Edit/Pen, Edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2765a600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.75 7.16L16.84 10.25" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function TableRowCell24() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <ContentEditPenEdit5 />
    </div>
  );
}

function MemberRow4() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Member Row">
      <TableRowCell20 />
      <TableRowCell21 />
      <TableRowCell22 />
      <TableRowCell23 />
      <TableRowCell24 />
    </div>
  );
}

function Divider5() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p7773800} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow1 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function PaginationItem() {
  return (
    <div className="bg-[#f8fafc] content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">1</p>
      </div>
    </div>
  );
}

function PaginationItem1() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">2</p>
      </div>
    </div>
  );
}

function PaginationItem2() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">3</p>
      </div>
    </div>
  );
}

function PaginationItem3() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">...</p>
      </div>
    </div>
  );
}

function PaginationItem4() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">4</p>
      </div>
    </div>
  );
}

function PaginationItem5() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">5</p>
      </div>
    </div>
  );
}

function ArrowsDiagramsArrow2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0" data-name="container">
      <Button4 />
      <PaginationItem />
      <PaginationItem1 />
      <PaginationItem2 />
      <PaginationItem3 />
      <PaginationItem4 />
      <PaginationItem5 />
      <Button5 />
    </div>
  );
}

function PaginationGroup() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Pagination Group">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">1 de 6</p>
      <Container6 />
    </div>
  );
}

function Pagination() {
  return (
    <div className="absolute bg-white bottom-0 h-[72px] left-0 w-[941px]" data-name="Pagination">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[24px] relative rounded-[inherit] size-full">
        <PaginationGroup />
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-solid border-t inset-0 pointer-events-none" />
    </div>
  );
}

function Container() {
  return (
    <div className="bg-white h-[431px] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <MemberRow />
        <Divider1 />
        <MemberRow1 />
        <Divider2 />
        <MemberRow2 />
        <Divider3 />
        <MemberRow3 />
        <Divider4 />
        <MemberRow4 />
        <Divider5 />
        <Pagination />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Card() {
  return (
    <div className="bg-[#f1f5f9] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header />
        <Container />
      </div>
    </div>
  );
}

function WorkspaceMembersSection() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Workspace Members Section">
      <WorkspaceMembersHeader />
      <Card />
    </div>
  );
}

function AccessRequestsIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Access Requests Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d={svgPaths.pa572100} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.paa85480} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2c50fd00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1c9a3f80} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p39974300} fillRule="evenodd" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_6" />
        </g>
      </svg>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p396e8020} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M19 19L15.71 15.71" id="Path_3" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialSearchLoupe1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Search, Loupe">
      <Group4 />
    </div>
  );
}

function Search1() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0 w-[250px]" data-name="Search">
      <div className="content-stretch flex gap-[8px] items-center overflow-clip px-[12px] relative rounded-[inherit] size-full">
        <InterfaceEssentialSearchLoupe1 />
        <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#64748b] text-[14px] whitespace-pre-wrap">Buscar solicitações</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function AccessRequestsActions() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Access Requests Actions">
      <Search1 />
    </div>
  );
}

function AccessRequestsHeader() {
  return (
    <div className="content-stretch flex gap-[12px] items-center pb-[24px] relative shrink-0 w-full" data-name="Access Requests Header">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <AccessRequestsIcon />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[18px] whitespace-pre-wrap">Solicitações de acesso ao workspace</p>
      <AccessRequestsActions />
    </div>
  );
}

function SortingIcons4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label4() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[24px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Solicitante</p>
      <SortingIcons4 />
    </div>
  );
}

function SortingIcons5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label5() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[215px] top-[14px] w-[66px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Status</p>
      <SortingIcons5 />
    </div>
  );
}

function SortingIcons6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label6() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[417px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Data de solicitação</p>
      <SortingIcons6 />
    </div>
  );
}

function SortingIcons7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Sorting Icons">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="expand-up-down-fill">
          <path d={svgPaths.p192db800} fill="var(--fill-0, #94A3B8)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Label7() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-center left-[631px] top-[14px]" data-name="Label">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Decisor</p>
      <SortingIcons7 />
    </div>
  );
}

function Header1() {
  return (
    <div className="h-[48px] overflow-clip relative rounded-[16px] shrink-0 w-full" data-name="header">
      <Label4 />
      <Label5 />
      <Label6 />
      <Label7 />
    </div>
  );
}

function Avatar5() {
  return (
    <div className="bg-[#e2e8f0] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
      </div>
    </div>
  );
}

function Content21() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Lucas Ayres</p>
      </div>
    </div>
  );
}

function TableRowCell25() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar5 />
          <Content21 />
        </div>
      </div>
    </div>
  );
}

function Content22() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Pendente</p>
    </div>
  );
}

function Badge5() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content22 />
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge5 />
    </div>
  );
}

function TableRowCell26() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container8 />
        </div>
      </div>
    </div>
  );
}

function Content23() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">10/12/2025 - 14:00</p>
    </div>
  );
}

function TableRowCell27() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content23 />
        </div>
      </div>
    </div>
  );
}

function Content24() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">-</p>
    </div>
  );
}

function TableRowCell28() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content24 />
        </div>
      </div>
    </div>
  );
}

function Content25() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px]">Gerenciar</p>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-white h-[32px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[inherit]">
        <Content25 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableRowCell29() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <Button6 />
    </div>
  );
}

function RequestRow() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Request Row">
      <TableRowCell25 />
      <TableRowCell26 />
      <TableRowCell27 />
      <TableRowCell28 />
      <TableRowCell29 />
    </div>
  );
}

function Divider6() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar6() {
  return (
    <div className="bg-[#fed7aa] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Content26() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Jessica Mota</p>
      </div>
    </div>
  );
}

function TableRowCell30() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar6 />
          <Content26 />
        </div>
      </div>
    </div>
  );
}

function Content27() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">Aceito</p>
    </div>
  );
}

function Badge6() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content27 />
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge6 />
    </div>
  );
}

function TableRowCell31() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container9 />
        </div>
      </div>
    </div>
  );
}

function Content28() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">10/12/2025 - 14:00</p>
    </div>
  );
}

function TableRowCell32() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content28 />
        </div>
      </div>
    </div>
  );
}

function Avatar7() {
  return (
    <div className="bg-[#e2e8f0] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
      </div>
    </div>
  );
}

function Content29() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Lucas Ayres</p>
      </div>
    </div>
  );
}

function TableRowCell33() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar7 />
          <Content29 />
        </div>
      </div>
    </div>
  );
}

function TableRowCell34() {
  return <div className="bg-white h-full shrink-0 w-[132px]" data-name="Table Row Cell" />;
}

function RequestRow1() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Request Row">
      <TableRowCell30 />
      <TableRowCell31 />
      <TableRowCell32 />
      <TableRowCell33 />
      <TableRowCell34 />
    </div>
  );
}

function Divider7() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar8() {
  return (
    <div className="bg-[#a4f4cf] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
      </div>
    </div>
  );
}

function Content30() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Caio Paixão</p>
      </div>
    </div>
  );
}

function TableRowCell35() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar8 />
          <Content30 />
        </div>
      </div>
    </div>
  );
}

function Content31() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9f0712] text-[12px]">Rejeitado</p>
    </div>
  );
}

function Badge7() {
  return (
    <div className="bg-[#ffe2e2] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content31 />
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge7 />
    </div>
  );
}

function TableRowCell36() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container10 />
        </div>
      </div>
    </div>
  );
}

function Content32() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">10/12/2025 - 14:00</p>
    </div>
  );
}

function TableRowCell37() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content32 />
        </div>
      </div>
    </div>
  );
}

function Avatar9() {
  return (
    <div className="bg-[#d9e5ff] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
      </div>
    </div>
  );
}

function Content33() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Filipe Goes</p>
      </div>
    </div>
  );
}

function TableRowCell38() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar9 />
          <Content33 />
        </div>
      </div>
    </div>
  );
}

function TableRowCell39() {
  return <div className="bg-white h-full shrink-0 w-[132px]" data-name="Table Row Cell" />;
}

function RequestRow2() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Request Row">
      <TableRowCell35 />
      <TableRowCell36 />
      <TableRowCell37 />
      <TableRowCell38 />
      <TableRowCell39 />
    </div>
  );
}

function Divider8() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar10() {
  return (
    <div className="bg-[#ffc9c9] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage4} />
      </div>
    </div>
  );
}

function Content34() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Nataly Lima</p>
      </div>
    </div>
  );
}

function TableRowCell40() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar10 />
          <Content34 />
        </div>
      </div>
    </div>
  );
}

function Content35() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Pendente</p>
    </div>
  );
}

function Badge8() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content35 />
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge8 />
    </div>
  );
}

function TableRowCell41() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container11 />
        </div>
      </div>
    </div>
  );
}

function Content36() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">10/12/2025 - 14:00</p>
    </div>
  );
}

function TableRowCell42() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content36 />
        </div>
      </div>
    </div>
  );
}

function Content37() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">-</p>
    </div>
  );
}

function TableRowCell43() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content37 />
        </div>
      </div>
    </div>
  );
}

function Content38() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px]">Gerenciar</p>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-white h-[32px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[inherit]">
        <Content38 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableRowCell44() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <Button7 />
    </div>
  );
}

function RequestRow3() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Request Row">
      <TableRowCell40 />
      <TableRowCell41 />
      <TableRowCell42 />
      <TableRowCell43 />
      <TableRowCell44 />
    </div>
  );
}

function Divider9() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Avatar11() {
  return (
    <div className="bg-[#d9e5ff] overflow-clip relative rounded-[19998px] shrink-0 size-[32px]" data-name="Avatar">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[32px] top-1/2" data-name="image">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
      </div>
    </div>
  );
}

function Content39() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Filipe Goes</p>
      </div>
    </div>
  );
}

function TableRowCell45() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[12px] relative size-full">
          <Avatar11 />
          <Content39 />
        </div>
      </div>
    </div>
  );
}

function Content40() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Pendente</p>
    </div>
  );
}

function Badge9() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content40 />
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-full" data-name="Container">
      <Badge9 />
    </div>
  );
}

function TableRowCell46() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center p-[12px] relative size-full">
          <Container12 />
        </div>
      </div>
    </div>
  );
}

function Content41() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">10/12/2025 - 14:00</p>
    </div>
  );
}

function TableRowCell47() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[12px] relative size-full">
          <Content41 />
        </div>
      </div>
    </div>
  );
}

function Content42() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">-</p>
    </div>
  );
}

function TableRowCell48() {
  return (
    <div className="bg-white flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Table Row Cell">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[24px] py-[12px] relative size-full">
          <Content42 />
        </div>
      </div>
    </div>
  );
}

function Content43() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px]">Gerenciar</p>
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-white h-[32px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[10px] py-[6px] relative rounded-[inherit]">
        <Content43 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableRowCell49() {
  return (
    <div className="bg-white content-stretch flex flex-col h-full items-end justify-center px-[24px] py-[12px] relative shrink-0" data-name="Table Row Cell">
      <Button8 />
    </div>
  );
}

function RequestRow4() {
  return (
    <div className="content-stretch flex h-[72px] items-center relative shrink-0 w-full" data-name="Request Row">
      <TableRowCell45 />
      <TableRowCell46 />
      <TableRowCell47 />
      <TableRowCell48 />
      <TableRowCell49 />
    </div>
  );
}

function Divider10() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 941 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="941" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ArrowsDiagramsArrow3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p7773800} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function PaginationItem6() {
  return (
    <div className="bg-[#f8fafc] content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">1</p>
      </div>
    </div>
  );
}

function PaginationItem7() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">2</p>
      </div>
    </div>
  );
}

function PaginationItem8() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">3</p>
      </div>
    </div>
  );
}

function PaginationItem9() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">...</p>
      </div>
    </div>
  );
}

function PaginationItem10() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">4</p>
      </div>
    </div>
  );
}

function PaginationItem11() {
  return (
    <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[8px] shrink-0 size-[32px]" data-name="Pagination Item">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[12px] text-center whitespace-nowrap">
        <p className="leading-[1.4]">5</p>
      </div>
    </div>
  );
}

function ArrowsDiagramsArrow4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="content-stretch flex items-center justify-center overflow-clip p-[6px] relative rounded-[inherit] size-full">
        <ArrowsDiagramsArrow4 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0" data-name="container">
      <Button9 />
      <PaginationItem6 />
      <PaginationItem7 />
      <PaginationItem8 />
      <PaginationItem9 />
      <PaginationItem10 />
      <PaginationItem11 />
      <Button10 />
    </div>
  );
}

function PaginationGroup1() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Pagination Group">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px]">1 de 6</p>
      <Container13 />
    </div>
  );
}

function Pagination1() {
  return (
    <div className="absolute bg-white bottom-0 h-[72px] left-0 w-[941px]" data-name="Pagination">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[24px] relative rounded-[inherit] size-full">
        <PaginationGroup1 />
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-solid border-t inset-0 pointer-events-none" />
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-white h-[431px] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <RequestRow />
        <Divider6 />
        <RequestRow1 />
        <Divider7 />
        <RequestRow2 />
        <Divider8 />
        <RequestRow3 />
        <Divider9 />
        <RequestRow4 />
        <Divider10 />
        <Pagination1 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-[#f1f5f9] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header1 />
        <Container7 />
      </div>
    </div>
  );
}

function AccessRequestsSection() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Access Requests Section">
      <AccessRequestsHeader />
      <Card1 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[32px] items-start min-h-px min-w-px relative" data-name="Main Content">
      <WorkspaceMembersSection />
      <AccessRequestsSection />
    </div>
  );
}

function MainContainer() {
  return (
    <div className="content-stretch flex gap-[32px] items-start relative shrink-0 w-full" data-name="Main Container">
      <Sidebar />
      <MainContent />
    </div>
  );
}

function WorkArea() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[32px] items-start left-[100px] overflow-clip px-[32px] py-[24px] top-[78px] w-[1340px]" data-name="Work Area">
      <Profile />
      <Divider />
      <MainContainer />
    </div>
  );
}

function Component1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Component 11">
      <div className="absolute inset-[-29.17%_-47.06%_-147.06%_-47.06%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
          <g id="Component 11">
            <circle cx="23.2941" cy="19" id="Ellipse 516" opacity="0.1" r="14.5" stroke="url(#paint0_linear_1_5947)" />
            <g filter="url(#filter0_dddddddi_1_5947)" id="Ellipse 515">
              <circle cx="23.2941" cy="19" fill="var(--fill-0, #2E61FF)" r="11.2941" />
              <circle cx="23.2941" cy="19" fill="url(#paint1_linear_1_5947)" fillOpacity="0.1" r="11.2941" />
            </g>
            <g id="Frame 427321015">
              <circle cx="18.8312" cy="1.9707" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1434" opacity="0.3" r="0.75" />
              <circle cx="10.0441" cy="3.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1435" r="0.75" />
              <circle cx="33.0441" cy="4.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1446" r="0.75" />
              <circle cx="40.0441" cy="9.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1451" opacity="0.3" r="0.75" />
              <circle cx="9.04412" cy="10.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1449" opacity="0.3" r="0.75" />
            </g>
            <g id="IA">
              <path d={svgPaths.p1063c100} fill="var(--fill-0, white)" />
              <path d={svgPaths.p17307780} fill="var(--fill-0, white)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" id="filter0_dddddddi_1_5947" width="46.5882" x="2.98023e-07" y="6.70588">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="12" result="effect1_dropShadow_1_5947" />
              <feOffset dy="24" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="6" result="effect2_dropShadow_1_5947" />
              <feOffset dy="12" />
              <feGaussianBlur stdDeviation="6" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_5947" mode="normal" result="effect2_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="3" result="effect3_dropShadow_1_5947" />
              <feOffset dy="6" />
              <feGaussianBlur stdDeviation="3" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect2_dropShadow_1_5947" mode="normal" result="effect3_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.5" result="effect4_dropShadow_1_5947" />
              <feOffset dy="3" />
              <feGaussianBlur stdDeviation="1.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.02 0" />
              <feBlend in2="effect3_dropShadow_1_5947" mode="normal" result="effect4_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.5" result="effect5_dropShadow_1_5947" />
              <feOffset dy="1" />
              <feGaussianBlur stdDeviation="0.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect4_dropShadow_1_5947" mode="normal" result="effect5_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect6_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect5_dropShadow_1_5947" mode="normal" result="effect6_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect7_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0" />
              <feBlend in2="effect6_dropShadow_1_5947" mode="normal" result="effect7_dropShadow_1_5947" />
              <feBlend in="SourceGraphic" in2="effect7_dropShadow_1_5947" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="shape" mode="normal" result="effect8_innerShadow_1_5947" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_5947" x1="23.2941" x2="23.2941" y1="4" y2="34">
              <stop stopColor="#2E61FF" stopOpacity="0" />
              <stop offset="1" stopColor="#2E61FF" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_5947" x1="23.2941" x2="23.2941" y1="30.2941" y2="7.70588">
              <stop stopColor="white" stopOpacity="0" />
              <stop offset="1" stopColor="white" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Component1 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p39ce2c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.5 21H13.5" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MusicAudioBellNotifications() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Music, Audio/Bell, Notifications">
      <Group5 />
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <MusicAudioBellNotifications />
    </div>
  );
}

function CircleRedSolid() {
  return (
    <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]" data-name="circle-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#fb2c36] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Container14() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="container">
      <Button11 />
      <Button12 />
      <CircleRedSolid />
    </div>
  );
}

function Logotype() {
  return (
    <div className="absolute inset-[42.65%_22.8%_42.65%_22.5%]" data-name="logotype">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.8804 5.87683">
        <g id="logotype">
          <path d={svgPaths.p1fa77d80} fill="var(--fill-0, white)" id="Vector" />
          <g id="Group">
            <path d={svgPaths.pe40ba00} fill="var(--fill-0, white)" id="Vector_2" />
            <path d={svgPaths.p1b629600} fill="var(--fill-0, white)" id="Vector_3" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Person() {
  return (
    <div className="absolute bg-[#e2e8f0] bottom-0 right-0 rounded-[9999px] size-[16px]" data-name="person">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="absolute h-[64px] left-[-12px] top-[-6px] w-[35px]" data-name="image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage5} />
        </div>
        <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-gradient-to-b from-[86.008%] from-[rgba(42,56,73,0)] left-1/2 rounded-[9999px] size-[16px] to-[rgba(42,56,73,0.3)] top-1/2" data-name="filter" />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-[-1px] pointer-events-none rounded-[10000px]" />
    </div>
  );
}

function Avatar12() {
  return (
    <div className="bg-[#2e61ff] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Logotype />
      <Person />
    </div>
  );
}

function Content44() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Bloxs Capital Partners LTDA</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#64748b] text-[12px]">41.847.533/0001-90</p>
    </div>
  );
}

function ArrowsDiagramsArrow5() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container15() {
  return (
    <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0" data-name="container">
      <Avatar12 />
      <Content44 />
      <ArrowsDiagramsArrow5 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
      <Container14 />
      <div className="bg-[#e2e8f0] h-[24px] rounded-[9999px] shrink-0 w-[2px]" data-name="divider" />
      <Container15 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="absolute h-[80px] left-[100px] top-0 w-[1340px]" data-name="Navbar">
      <div className="content-stretch flex items-center justify-between overflow-clip px-[32px] py-[16px] relative rounded-[inherit] size-full">
        <Frame2 />
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Camada() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0002 24">
        <g id="Camada_1-2">
          <path d={svgPaths.p8744780} fill="var(--fill-0, #020617)" id="Vector" />
          <path d={svgPaths.p2e0a3600} fill="var(--fill-0, #2E61FF)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute content-stretch flex flex-col h-[80px] items-center justify-center left-0 px-[24px] py-[16px] top-0 w-[100px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <Camada />
    </div>
  );
}

function InterfaceEssentialHomeClassic() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/home-classic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Rectangle" />
          <path clipRule="evenodd" d={svgPaths.pf024880} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p32312200} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Button14() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <InterfaceEssentialHomeClassic />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Home</p>
    </div>
  );
}

function SeoSearchGraph() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="SEO/Search, Graph">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d="M16 12.157V9H12.843" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p1ecf540} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M19 5L20 4" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M20 8H21" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M16 4V3" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p3b77e00} id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
          </g>
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Button15() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <SeoSearchGraph />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px] text-center">Operações</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p1b647048} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p29968a80} fillRule="evenodd" id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p129ae5c0} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p7859880} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MoneyWalletMoney() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Money/Wallet, Money">
      <Group6 />
    </div>
  );
}

function Button16() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <MoneyWalletMoney />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Carteira</p>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.pcf2900} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1e3f0a80} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1bc35740} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p3ed71a00} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function TechnologySpaceSpaceRocket() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Technology, Space/space-rocket">
      <Group7 />
    </div>
  );
}

function Button17() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <TechnologySpaceSpaceRocket />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Soluções</p>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-4.17%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.4993 19.4993">
          <g id="Group">
            <path clipRule="evenodd" d={svgPaths.p2d1c8c80} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ConstructionToolsToolsWench() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Construction, Tools/tools-wench">
      <Group8 />
    </div>
  );
}

function Button18() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <ConstructionToolsToolsWench />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Tools</p>
    </div>
  );
}

function UserUsers() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="User/Users">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d={svgPaths.p2c68bbc0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="9" cy="7" id="Oval" r="4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe930c00} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p8cf1c80} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function Button19() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <UserUsers />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Comunidade</p>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <circle cx="12.005" cy="12.005" id="Oval" r="9.00375" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2756080} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22612800} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p116d3c00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialQuestionCircle() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/question-circle">
      <Group9 />
    </div>
  );
}

function Button20() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-[84px]" data-name="Button">
      <InterfaceEssentialQuestionCircle />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Ajuda</p>
    </div>
  );
}

function Main() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[14px] items-start left-[8px] top-[96px] w-[84px]" data-name="main">
      <Button14 />
      <Button15 />
      <Button16 />
      <Button17 />
      <Button18 />
      <Button19 />
      <Button20 />
    </div>
  );
}

function Sidebar1() {
  return (
    <div className="bg-white border-[#e2e8f0] border-r border-solid h-[1601px] overflow-clip pointer-events-auto sticky top-0 w-[100px]" data-name="Sidebar">
      <Button13 />
      <div className="absolute bg-[#2e61ff] h-[75px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[185px] w-[3px]" data-name="state" />
      <Main />
    </div>
  );
}

export default function Component7WorkspaceConfiguracoesMembrosLightMode() {
  return (
    <div className="bg-white overflow-clip relative rounded-[24px] size-full" data-name="7. Workspace | Configurações | Membros [Light Mode]">
      <WorkArea />
      <Navbar />
      <div className="absolute bottom-0 h-[1601px] left-0 pointer-events-none top-0">
        <Sidebar1 />
      </div>
    </div>
  );
}