import svgPaths from "./svg-tkt5ku8vli";

function Arrows() {
  return (
    <div className="absolute inset-[5.21%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.5 21.5">
        <g id="arrows">
          <path d={svgPaths.pb28c280} fill="var(--fill-0, white)" id="check-circle" />
        </g>
      </svg>
    </div>
  );
}

function CheckCircle() {
  return (
    <div className="col-1 ml-[15px] mt-[15px] overflow-clip relative row-1 size-[24px]" data-name="check-circle">
      <Arrows />
    </div>
  );
}

function Group() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <div className="col-1 ml-0 mt-0 relative row-1 size-[54px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 54 54">
          <circle cx="27" cy="27" fill="var(--fill-0, #215B20)" id="Ellipse 472" r="27" />
        </svg>
      </div>
      <div className="col-1 ml-[6px] mt-[6px] relative row-1 size-[42px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 42 42">
          <circle cx="21" cy="21" fill="var(--fill-0, #247223)" id="Ellipse 473" r="21" />
        </svg>
      </div>
      <div className="col-1 ml-[12px] mt-[12px] relative row-1 size-[30px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
          <circle cx="15" cy="15" fill="var(--fill-0, #2A9128)" id="Ellipse 474" r="15" />
        </svg>
      </div>
      <CheckCircle />
    </div>
  );
}

function Arrows1() {
  return (
    <div className="absolute inset-[27.89%_27.94%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5907 10.6107">
        <g id="arrows">
          <path d={svgPaths.p23ecbb80} fill="var(--fill-0, white)" id="cross" />
        </g>
      </svg>
    </div>
  );
}

function Cross() {
  return (
    <div className="overflow-clip relative shrink-0 size-[24px]" data-name="cross">
      <Arrows1 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex items-start relative shrink-0">
      <Cross />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-[479px]">
      <Group />
      <Frame />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start leading-[28px] not-italic relative shrink-0 text-white w-[479px] whitespace-pre-wrap">
      <p className="font-['Poppins:SemiBold',sans-serif] relative shrink-0 text-[18px] w-[479px]">Alterações salvas!</p>
      <p className="font-['Poppins:Regular',sans-serif] relative shrink-0 text-[14px] w-[479px]">Suas alterações foram salvas com sucesso. As atualizações já estão aplicadas.</p>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col gap-[32px] items-end relative shrink-0">
      <Frame4 />
      <Frame1 />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#3482ff] content-stretch flex items-center justify-center px-[48px] py-[12px] relative rounded-[8px] shrink-0" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[14px] text-white">OK</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <Button />
    </div>
  );
}

export default function Modal() {
  return (
    <div className="bg-[#161616] content-stretch flex flex-col gap-[32px] items-end p-[32px] relative rounded-[8px] shadow-[-12px_4px_15.6px_0px_rgba(0,0,0,0.15)] size-full" data-name="Modal">
      <Frame3 />
      <Frame2 />
    </div>
  );
}