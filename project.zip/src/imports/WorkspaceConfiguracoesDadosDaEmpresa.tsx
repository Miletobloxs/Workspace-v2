import svgPaths from "./svg-nfyee3cbmh";
import imgEllipse475 from "figma:asset/829b3120c34e95f5de6e1742ce9e5a0ad95414ea.png";
import imgEllipse7 from "figma:asset/076dd2cc2f1522a0beb35373c1bc6963f82e8c32.png";
import imgImage1 from "figma:asset/6168d4c37b79a510ce2db4649dcfdc3fff4de4db.png";
import imgRectangle4539 from "figma:asset/0759735ede8c602eb18a588297c76ab07db99d8a.png";

function Frame21() {
  return (
    <div className="content-stretch flex items-start px-[32px] relative shrink-0">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Configurações</p>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Dados da empresa</p>
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[32px] pr-[16px] py-[16px] relative shrink-0 w-[300px]">
      <Frame15 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="bg-[#313131] content-stretch flex flex-col items-start relative shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#3482ff] border-l-3 border-solid inset-0 pointer-events-none" />
      <Frame22 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Membros</p>
      </div>
    </div>
  );
}

function Frame23() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col items-start px-[32px] py-[16px] relative w-full">
        <Frame16 />
      </div>
    </div>
  );
}

function Support() {
  return (
    <div className="absolute inset-[8.33%]" data-name="support">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="support">
          <path d={svgPaths.p1460ed00} fill="var(--fill-0, #3482FF)" id="information-1" />
        </g>
      </svg>
    </div>
  );
}

function Information() {
  return (
    <div className="overflow-clip relative shrink-0 size-[24px]" data-name="information 1">
      <Support />
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Dealmatch</p>
      </div>
      <Information />
    </div>
  );
}

function Frame26() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col items-start px-[32px] py-[16px] relative w-full">
        <Frame17 />
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame25 />
      <Frame23 />
      <Frame26 />
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <Frame21 />
      <div className="h-0 relative shrink-0 w-full">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 1">
            <line id="Line 72" stroke="var(--stroke-0, #515151)" x2="300" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <Frame24 />
    </div>
  );
}

function Frame27() {
  return (
    <div className="absolute bg-[#292929] left-[144px] rounded-[8px] top-[468px] w-[300px]">
      <div className="content-stretch flex flex-col items-start overflow-clip py-[24px] relative rounded-[inherit] w-full">
        <Frame35 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#292929] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#434343] border-b border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col gap-[4px] items-start justify-center not-italic p-[16px] relative text-white w-full">
          <p className="font-['Poppins:SemiBold',sans-serif] leading-[35px] relative shrink-0 text-[20px]">Informações da empresa</p>
          <p className="font-['Poppins:Regular',sans-serif] leading-[normal] relative shrink-0 text-[14px]">Atualize as informações cadastrais e os dados básicos do sua empresa.</p>
        </div>
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] h-[34px] items-start not-italic relative shrink-0 w-[188px] whitespace-pre-wrap" data-name="Text">
      <p className="font-['Poppins:Regular',sans-serif] leading-[10px] relative shrink-0 text-[#818181] text-[10px] tracking-[-0.3px] w-full">CNPJ</p>
      <p className="font-['Poppins:SemiBold',sans-serif] h-[19px] leading-[normal] relative shrink-0 text-[#a4a4a4] text-[14px] w-full">71.027.866/0001-34</p>
    </div>
  );
}

function InputText() {
  return (
    <div className="bg-[#313131] h-[48px] relative rounded-[6px] shrink-0 w-full" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#818181] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-[16px] py-[8px] relative size-full">
          <Text />
        </div>
      </div>
    </div>
  );
}

function PadlockSquare() {
  return (
    <div className="absolute left-[24px] size-[14px] top-[96px]" data-name="Padlock Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_15_6100)" id="Padlock Square">
          <path clipRule="evenodd" d={svgPaths.pced4f80} fill="var(--fill-0, #818181)" fillRule="evenodd" id="icon" />
        </g>
        <defs>
          <clipPath id="clip0_15_6100">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text1() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] h-[34px] items-start not-italic relative shrink-0" data-name="Text">
      <p className="font-['Poppins:Regular',sans-serif] leading-[10px] min-w-full relative shrink-0 text-[#818181] text-[10px] tracking-[-0.3px] w-[min-content] whitespace-pre-wrap">Razão Social</p>
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] relative shrink-0 text-[#a4a4a4] text-[14px]">Banco BS2 SA</p>
    </div>
  );
}

function InputText1() {
  return (
    <div className="bg-[#313131] h-[48px] relative rounded-[6px] shrink-0 w-full" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#818181] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-[16px] py-[8px] relative size-full">
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function PadlockSquare1() {
  return (
    <div className="absolute left-[24px] size-[14px] top-[192px]" data-name="Padlock Square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_15_6100)" id="Padlock Square">
          <path clipRule="evenodd" d={svgPaths.pced4f80} fill="var(--fill-0, #818181)" fillRule="evenodd" id="icon" />
        </g>
        <defs>
          <clipPath id="clip0_15_6100">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[5px] items-start min-h-px min-w-px not-italic relative whitespace-pre-wrap" data-name="Text">
      <p className="font-['Poppins:Medium',sans-serif] leading-[10px] relative shrink-0 text-[#818181] text-[10px] tracking-[-0.3px] w-full">Nome Fantasia</p>
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] relative shrink-0 text-[#a4a4a4] text-[14px] w-full">Banco BS2</p>
    </div>
  );
}

function InputText2() {
  return (
    <div className="flex-[1_0_0] h-[48px] min-h-px min-w-px relative rounded-[6px]" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-[16px] py-[10px] relative size-full">
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[5px] items-start min-h-px min-w-px relative" data-name="Text">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#a4a4a4] text-[14px] w-full whitespace-pre-wrap">Área de atuação da empresa</p>
    </div>
  );
}

function Arrows() {
  return (
    <div className="absolute inset-[38.5%_21.31%_28.17%_20.35%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.0016 8.00081">
        <g id="arrows">
          <path d={svgPaths.p34125580} fill="var(--fill-0, #818181)" id="down" />
        </g>
      </svg>
    </div>
  );
}

function Down() {
  return (
    <div className="overflow-clip relative shrink-0 size-[24px]" data-name="down">
      <Arrows />
    </div>
  );
}

function InputText3() {
  return (
    <div className="flex-[1_0_0] h-[48px] min-h-px min-w-px relative rounded-[6px]" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[16px] py-[10px] relative size-full">
          <Text3 />
          <Down />
        </div>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[5px] items-start min-h-px min-w-px relative" data-name="Text">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#a4a4a4] text-[14px] w-full whitespace-pre-wrap">Quantidade de funcionários</p>
    </div>
  );
}

function Arrows1() {
  return (
    <div className="absolute inset-[38.5%_21.31%_28.17%_20.35%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.0016 8.00081">
        <g id="arrows">
          <path d={svgPaths.p34125580} fill="var(--fill-0, #818181)" id="down" />
        </g>
      </svg>
    </div>
  );
}

function Down1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[24px]" data-name="down">
      <Arrows1 />
    </div>
  );
}

function InputText4() {
  return (
    <div className="flex-[1_0_0] h-[48px] min-h-px min-w-px relative rounded-[6px]" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[16px] py-[10px] relative size-full">
          <Text4 />
          <Down1 />
        </div>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex gap-[24px] items-start relative shrink-0 w-full">
      <InputText2 />
      <InputText3 />
      <InputText4 />
    </div>
  );
}

function Text5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Text">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[0] not-italic relative shrink-0 text-[#818181] text-[0px] w-full whitespace-pre-wrap">
        <span className="leading-[12px] text-[12px]">{`Fale um pouco sobre a empresa `}</span>
        <span className="leading-[12px] text-[10px]">(max 200 caracteres)</span>
      </p>
    </div>
  );
}

function InputText5() {
  return (
    <div className="flex-[1_0_0] h-[80px] min-h-px min-w-px relative rounded-[6px]" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="content-stretch flex items-start px-[16px] py-[12px] relative size-full">
        <Text5 />
      </div>
    </div>
  );
}

function Frame33() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full">
      <InputText5 />
    </div>
  );
}

function Frame29() {
  return (
    <div className="bg-[#292929] relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
        <InputText />
        <PadlockSquare />
        <InputText1 />
        <PadlockSquare1 />
        <Frame32 />
        <Frame33 />
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#3482ff] content-stretch flex items-center justify-center px-[16px] py-[12px] relative rounded-[8px] shrink-0" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[14px] text-white">Salvar</p>
    </div>
  );
}

function Footer() {
  return (
    <div className="bg-[#292929] h-[81px] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-full" data-name="Footer">
      <div aria-hidden="true" className="absolute border-[#434343] border-solid border-t inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center justify-end size-full">
        <div className="content-stretch flex items-center justify-end p-[16px] relative size-full">
          <Button />
        </div>
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="content-stretch flex flex-col items-start relative rounded-[8px] shrink-0 w-full" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-[-1px] pointer-events-none rounded-[9px]" />
      <Header />
      <Frame29 />
      <Footer />
    </div>
  );
}

function Header1() {
  return (
    <div className="bg-[#292929] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#434343] border-b border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col gap-[4px] items-start justify-center not-italic p-[16px] relative text-white w-full">
          <p className="font-['Poppins:SemiBold',sans-serif] leading-[35px] relative shrink-0 text-[20px]">Perfil de atuação</p>
          <p className="font-['Poppins:Regular',sans-serif] leading-[normal] relative shrink-0 text-[14px]">Defina o perfil da sua empresa: Buy Side, Sell Side ou ambos.</p>
        </div>
      </div>
    </div>
  );
}

function Checkbox1() {
  return (
    <div className="relative shrink-0 size-[30px]" data-name="Checkbox">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="Checkbox">
          <rect fill="var(--fill-0, #FFC709)" height="30" rx="7" width="30" />
          <path d={svgPaths.p37facb40} fill="var(--fill-0, #292929)" id="Path 94" />
        </g>
      </svg>
    </div>
  );
}

function Checkbox() {
  return (
    <div className="absolute bg-[#3482ff] content-stretch flex items-center left-[23px] rounded-[7px] top-[31px]" data-name="Checkbox">
      <Checkbox1 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="absolute border border-[#e3e3e3] border-solid h-[203px] left-0 overflow-clip rounded-[12px] top-0 w-[430px]">
      <p className="absolute font-['Poppins:SemiBold',sans-serif] leading-[35px] left-[23px] not-italic text-[20px] text-white top-[85px]">Sell Side</p>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[23px] not-italic text-[#a4a4a4] text-[14px] top-[128px] w-[382px] whitespace-pre-wrap">Empresas que buscam captar recursos e estruturar operações financeiras.</p>
      <Checkbox />
    </div>
  );
}

function Checkbox3() {
  return (
    <div className="relative rounded-[7px] shrink-0 size-[30px]" data-name="Checkbox">
      <div aria-hidden="true" className="absolute border-[#3482ff] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[7px]" />
    </div>
  );
}

function Checkbox2() {
  return (
    <div className="absolute content-stretch flex items-center left-[23px] rounded-[4px] top-[31px]" data-name="Checkbox">
      <Checkbox3 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="absolute border border-[#e3e3e3] border-solid h-[203px] left-[454px] overflow-clip rounded-[12px] top-0 w-[430px]">
      <p className="absolute font-['Poppins:SemiBold',sans-serif] leading-[35px] left-[23px] not-italic text-[20px] text-white top-[85px]">Buy Side</p>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[23px] not-italic text-[#a4a4a4] text-[14px] top-[128px] w-[382px] whitespace-pre-wrap">Investidores que procuram oportunidades estruturadas no Mercado de Capitais.</p>
      <Checkbox2 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="h-[203px] relative shrink-0 w-[884px]">
      <Frame20 />
      <Frame19 />
    </div>
  );
}

function Frame30() {
  return (
    <div className="bg-[#292929] relative shrink-0 w-full">
      <div className="content-stretch flex flex-col items-start p-[24px] relative w-full">
        <Frame18 />
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#3482ff] content-stretch flex items-center justify-center px-[16px] py-[12px] relative rounded-[8px] shrink-0" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[14px] text-white">Salvar</p>
    </div>
  );
}

function Footer1() {
  return (
    <div className="bg-[#292929] h-[81px] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-full" data-name="Footer">
      <div aria-hidden="true" className="absolute border-[#434343] border-solid border-t inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center justify-end size-full">
        <div className="content-stretch flex items-center justify-end p-[16px] relative size-full">
          <Button1 />
        </div>
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="content-stretch flex flex-col items-start relative rounded-[8px] shrink-0 w-full" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-[-1px] pointer-events-none rounded-[9px]" />
      <Header1 />
      <Frame30 />
      <Footer1 />
    </div>
  );
}

function Header2() {
  return (
    <div className="bg-[#292929] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#434343] border-b border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col gap-[4px] items-start justify-center not-italic p-[16px] relative text-white w-full">
          <p className="font-['Poppins:SemiBold',sans-serif] leading-[35px] relative shrink-0 text-[20px]">Contato</p>
          <p className="font-['Poppins:Regular',sans-serif] leading-[normal] relative shrink-0 text-[14px]">Mantenha seus dados de contato atualizados</p>
        </div>
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Text">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#a4a4a4] text-[14px] w-full whitespace-pre-wrap">E-mail de contato</p>
    </div>
  );
}

function InputText6() {
  return (
    <div className="h-[48px] relative rounded-[6px] shrink-0 w-full" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-[16px] py-[10px] relative size-full">
          <Text6 />
        </div>
      </div>
    </div>
  );
}

function Arrows2() {
  return (
    <div className="absolute inset-[38.5%_20.85%_28.17%_20.81%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5012 6.00061">
        <g id="arrows">
          <path d={svgPaths.pdc37900} fill="var(--fill-0, #A4A4A4)" id="down" />
        </g>
      </svg>
    </div>
  );
}

function Down2() {
  return (
    <div className="overflow-clip relative shrink-0 size-[18px]" data-name="down">
      <Arrows2 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex gap-[8px] h-[48px] items-center pl-[16px] pr-[10px] py-[10px] relative shrink-0">
      <div aria-hidden="true" className="absolute border-[#a4a4a4] border-r border-solid inset-0 pointer-events-none" />
      <div className="relative shrink-0 size-[18px]">
        <img alt="" className="block max-w-none size-full" height="18" src={imgEllipse475} width="18" />
      </div>
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#a4a4a4] text-[14px]">+55</p>
      <Down2 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex h-[48px] items-center pl-[16px] pr-[10px] py-[10px] relative shrink-0 w-[344px]">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#a4a4a4] text-[14px]">Telefone</p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex h-[48px] items-start relative rounded-[8px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame4 />
      <Frame5 />
    </div>
  );
}

function Text7() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Text">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#a4a4a4] text-[14px] w-full whitespace-pre-wrap">Perfil do LinkedIn da empresa (opcional)</p>
    </div>
  );
}

function InputText7() {
  return (
    <div className="h-[48px] relative rounded-[6px] shrink-0 w-full" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#a4a4a4] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-[16px] py-[10px] relative size-full">
          <Text7 />
        </div>
      </div>
    </div>
  );
}

function Frame31() {
  return (
    <div className="bg-[#292929] relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
        <InputText6 />
        <Frame6 />
        <InputText7 />
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#3482ff] content-stretch flex items-center justify-center px-[16px] py-[12px] relative rounded-[8px] shrink-0" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[14px] text-white">Salvar</p>
    </div>
  );
}

function Footer2() {
  return (
    <div className="bg-[#292929] h-[81px] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-full" data-name="Footer">
      <div aria-hidden="true" className="absolute border-[#434343] border-solid border-t inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center justify-end size-full">
        <div className="content-stretch flex items-center justify-end p-[16px] relative size-full">
          <Button2 />
        </div>
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div className="content-stretch flex flex-col items-start relative rounded-[8px] shrink-0 w-full" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-[-1px] pointer-events-none rounded-[9px]" />
      <Header2 />
      <Frame31 />
      <Footer2 />
    </div>
  );
}

function Frame36() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[32px] items-start left-[468px] top-[468px] w-[942px]">
      <Card />
      <Card1 />
      <Card2 />
    </div>
  );
}

function Component9() {
  return (
    <div className="relative shrink-0 size-[34px]" data-name="Component 13">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <path d={svgPaths.p21e0d180} fill="var(--fill-0, #FFCD39)" id="Ellipse 511" />
      </svg>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <path d={svgPaths.p21e0d180} fill="url(#paint0_linear_15_6002)" id="Ellipse 514" />
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_15_6002" x1="17" x2="35.4571" y1="0" y2="26.7143">
            <stop stopColor="#FFC709" />
            <stop offset="1" stopColor="#FD7E14" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-[2.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <g id="Ellipse 515" />
        </svg>
      </div>
      <p className="absolute font-['Poppins:Medium',sans-serif] inset-[20.62%_30.33%_20.56%_34.37%] leading-[1.7] not-italic text-[#ffc709] text-[11.657px]">IA</p>
    </div>
  );
}

function NotificationOn1() {
  return (
    <div className="absolute inset-[8.38%_10.69%_9.14%_10.66%]" data-name="notification-on">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.8756 19.7955">
        <g id="notification-on">
          <path d={svgPaths.p1df35100} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p3b5e6b80} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p31c13800} fill="var(--fill-0, white)" id="Vector_3" />
          <path d={svgPaths.pd5f100} fill="var(--fill-0, white)" id="Vector_4" />
          <path d={svgPaths.p1b141a00} fill="var(--fill-0, white)" id="Vector_5" />
        </g>
      </svg>
    </div>
  );
}

function Notification() {
  return (
    <div className="absolute contents inset-[8.38%_10.69%_9.14%_10.66%]" data-name="notification">
      <NotificationOn1 />
    </div>
  );
}

function NotificationOn() {
  return (
    <div className="absolute inset-1/4 overflow-clip" data-name="notification-on">
      <Notification />
    </div>
  );
}

function Component8() {
  return (
    <div className="col-1 ml-0 mt-0 relative row-1 size-[48px]" data-name="Component 12">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 48">
        <circle cx="24" cy="24" fill="var(--fill-0, #292929)" id="Ellipse 4" r="24" />
      </svg>
      <NotificationOn />
    </div>
  );
}

function Group() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Component8 />
      <div className="col-1 ml-[38px] mt-[6.5px] relative row-1 size-[10px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
          <ellipse cx="5" cy="5" fill="var(--fill-0, #B53939)" id="Ellipse 5" rx="5" ry="5" />
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="relative shrink-0 size-[48px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 48">
        <g id="Group 18877">
          <circle cx="24" cy="24" fill="var(--fill-0, white)" id="image" r="24" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col font-['Poppins:Medium',sans-serif] items-start leading-[1.7] not-italic relative shrink-0">
      <p className="relative shrink-0 text-[16px] text-white">Banco BS2</p>
      <p className="relative shrink-0 text-[#818181] text-[14px]">71.027.866/0001-34</p>
    </div>
  );
}

function Arrows3() {
  return (
    <div className="absolute inset-[38.5%_20.85%_28.17%_20.81%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.668 6.66734">
        <g id="arrows">
          <path d={svgPaths.p121cad00} fill="var(--fill-0, white)" id="down" />
        </g>
      </svg>
    </div>
  );
}

function Down3() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="down">
      <Arrows3 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex gap-[12px] items-center justify-center relative shrink-0">
      <Group1 />
      <Frame />
      <Down3 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <Frame2 />
      <div className="absolute left-[37px] size-[16px] top-[31px]">
        <img alt="" className="block max-w-none size-full" height="16" src={imgEllipse7} width="16" />
      </div>
      <div className="absolute left-[9px] size-[29px] top-[12px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex gap-[32px] items-center justify-end relative shrink-0">
      <Component9 />
      <Group />
      <div className="flex h-[22px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[22px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 1">
                <line id="Line 62" stroke="var(--stroke-0, #515151)" x2="22" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame1 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="bg-[#212121] flex-[1_0_0] min-h-px min-w-px relative">
      <div aria-hidden="true" className="absolute border-[#515151] border-b border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-end size-full">
        <div className="content-stretch flex gap-[16px] items-center justify-end px-[24px] py-[16px] relative w-full">
          <Frame7 />
        </div>
      </div>
    </div>
  );
}

function Header3() {
  return (
    <div className="absolute content-stretch flex items-center justify-end left-[120px] top-0 w-[1320px]" data-name="Header">
      <Frame3 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[-196px] top-[-13px]">
      <div className="absolute bg-gradient-to-t from-white h-[171px] left-0 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-194px_-11px] mask-size-[1468px_1102px] to-[#262626] to-[82.456%] top-0 w-[1207px]" style={{ maskImage: `url('${imgRectangle4539}')` }} />
    </div>
  );
}

function Layer() {
  return (
    <div className="absolute inset-[9.37%_5.21%_9.38%_5.21%]" data-name="Layer 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.3333 13">
        <g id="Layer 2">
          <path d={svgPaths.p23f0c840} fill="var(--fill-0, #292929)" id="Vector" />
          <path d={svgPaths.p38b79700} fill="var(--fill-0, #292929)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function CameraSolid() {
  return (
    <div className="-translate-x-1/2 absolute left-1/2 opacity-90 overflow-clip size-[16px] top-0" data-name="camera-solid">
      <Layer />
    </div>
  );
}

function ArrowRight() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-right">
      <CameraSolid />
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#e3e3e3] content-stretch flex gap-[16px] items-center justify-center left-[957px] px-[12px] py-[8px] rounded-[8px] top-[112px]" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[#292929] text-[12px]">{`Alterar capa do Workspace `}</p>
      <ArrowRight />
    </div>
  );
}

function Component7() {
  return (
    <div className="absolute bg-[#161616] border-2 border-[#a4a4a4] border-solid h-[162px] left-[24px] overflow-clip rounded-[10px] top-[24px] w-[1223px]" data-name="Component 10">
      <Group2 />
      <div className="absolute flex inset-[calc(-298.15%-13.93px)_calc(58.07%+0.32px)_calc(-113.67%-6.55px)_calc(-26.76%-3.07px)] items-center justify-center">
        <div className="flex-none h-[685.377px] rotate-[105.19deg] skew-x-[0.38deg] w-[677.605px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 678.605 686.377">
              <path d={svgPaths.p1bee7880} fill="url(#paint0_linear_15_6068)" fillOpacity="0.1" id="Vector" stroke="url(#paint1_radial_15_6068)" strokeMiterlimit="10" />
              <defs>
                <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_15_6068" x1="0.5" x2="678.105" y1="343.188" y2="343.188">
                  <stop stopColor="#D9D9D9" />
                  <stop offset="1" stopColor="#737373" />
                </linearGradient>
                <radialGradient cx="0" cy="0" gradientTransform="matrix(223.7 -207.283 204.933 226.265 529.973 173.869)" gradientUnits="userSpaceOnUse" id="paint1_radial_15_6068" r="1">
                  <stop offset="0.384826" stopColor="white" />
                  <stop offset="1" stopColor="#212121" />
                </radialGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute flex inset-[calc(35.19%-0.59px)_calc(-2.4%-2.1px)_calc(-213.58%-10.54px)_calc(65.12%+0.6px)] items-center justify-center">
        <div className="-rotate-90 flex-none h-[455.965px] w-[451px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-[-0.11%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 452 456.965">
                <path d={svgPaths.p3d589d00} fill="url(#paint0_linear_15_6060)" fillOpacity="0.05" id="Vector" stroke="url(#paint1_radial_15_6060)" strokeMiterlimit="10" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_15_6060" x1="451.5" x2="0.5" y1="228.483" y2="228.483">
                    <stop stopColor="#D9D9D9" />
                    <stop offset="1" stopColor="#737373" />
                  </linearGradient>
                  <radialGradient cx="0" cy="0" gradientTransform="matrix(148.89 -137.901 136.399 150.529 352.906 115.838)" gradientUnits="userSpaceOnUse" id="paint1_radial_15_6060" r="1">
                    <stop offset="0.384826" stopColor="white" />
                    <stop offset="1" stopColor="#212121" />
                  </radialGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Button3 />
    </div>
  );
}

function Verificado() {
  return (
    <div className="absolute left-[263px] size-[16px] top-[237px]" data-name="verificado 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_15_6018)" id="verificado 1">
          <path d={svgPaths.p12cae680} fill="var(--fill-0, #3482FF)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_15_6018">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Layer1() {
  return (
    <div className="absolute inset-[9.37%_5.21%_9.38%_5.21%]" data-name="Layer 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.3333 13">
        <g id="Layer 2">
          <path d={svgPaths.p23f0c840} fill="var(--fill-0, #434343)" id="Vector" />
          <path d={svgPaths.p38b79700} fill="var(--fill-0, #434343)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function CameraSolid1() {
  return (
    <div className="-translate-x-1/2 absolute left-[calc(50%+1px)] opacity-90 overflow-clip size-[16px] top-[4px]" data-name="camera-solid">
      <Layer1 />
    </div>
  );
}

function Item() {
  return (
    <div className="absolute bg-[#a4a4a4] h-[24px] left-[24px] opacity-68 rounded-bl-[8px] rounded-br-[8px] top-[270px] w-[80px]" data-name="item">
      <CameraSolid1 />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[24px] top-[214px]">
      <p className="absolute font-['Poppins:SemiBold',sans-serif] leading-[48px] left-[120px] not-italic text-[24px] text-white top-[220px]">Banco BS2</p>
      <Verificado />
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[120px] not-italic text-[14px] text-white top-[268px]">71.027.866/0001-34</p>
      <div className="absolute bg-white left-[24px] rounded-[8px] size-[80px] top-[214px]" />
      <div className="absolute left-[46px] size-[36px] top-[232px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <Item />
    </div>
  );
}

function Arrows4() {
  return (
    <div className="absolute inset-[21.5%_21.55%_21.08%_20.83%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.21806 9.18735">
        <g id="arrows">
          <path d={svgPaths.p158466a0} fill="var(--fill-0, #A4A4A4)" id="arrow-right" />
        </g>
      </svg>
    </div>
  );
}

function ArrowRight1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-right">
      <Arrows4 />
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute content-stretch flex gap-[16px] items-center justify-center left-[1028px] rounded-[8px] top-[246px]" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[#a4a4a4] text-[12px]">Acessar página do Workspace</p>
      <ArrowRight1 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="absolute bg-[#212121] h-[321px] left-[144px] overflow-clip rounded-[8px] shadow-[0px_5px_26px_8px_rgba(22,22,22,0.55)] top-[115px] w-[1272px]">
      <Component7 />
      <div className="absolute bg-[#515151] h-px left-[24px] top-[322px] w-[1208px]" data-name="Line" />
      <Group3 />
      <Button4 />
    </div>
  );
}

function G() {
  return (
    <div className="h-[27.81px] relative shrink-0 w-[73px]" data-name="g14">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73 27.8095">
        <g id="g14">
          <path d={svgPaths.p1dc4a100} fill="var(--fill-0, white)" id="polygon4" />
          <path d={svgPaths.p39e85800} fill="var(--fill-0, white)" id="path6" />
          <path d={svgPaths.p790c700} fill="var(--fill-0, white)" id="path8" />
          <path d={svgPaths.p2ee1e80} fill="var(--fill-0, white)" id="polygon10" />
          <path d={svgPaths.p17226170} fill="var(--fill-0, white)" id="path12" />
        </g>
      </svg>
    </div>
  );
}

function LogoBlack() {
  return (
    <div className="content-stretch flex items-center overflow-clip relative shrink-0 w-[73px]" data-name="logo-black 8">
      <G />
    </div>
  );
}

function General() {
  return (
    <div className="absolute inset-[5.16%_5.12%_5.25%_5.29%]" data-name="general">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9172 17.9184">
        <g id="general">
          <path d={svgPaths.p31701200} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Home1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="home">
      <General />
    </div>
  );
}

function Home() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Home1 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Home</p>
    </div>
  );
}

function Inicio() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home />
      <Frame8 />
    </div>
  );
}

function Component() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 2">
      <Inicio />
    </div>
  );
}

function Business() {
  return (
    <div className="absolute inset-[5.21%_5.21%_5.46%_5.21%]" data-name="business">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9167 17.8667">
        <g id="business">
          <path d={svgPaths.p838f080} fill="var(--fill-0, white)" id="graph-up" />
        </g>
      </svg>
    </div>
  );
}

function GraphUp() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="graph-up">
      <Business />
    </div>
  );
}

function Home2() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <GraphUp />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Operações</p>
    </div>
  );
}

function Inicio1() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home2 />
      <Frame9 />
    </div>
  );
}

function Component1() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 3">
      <Inicio1 />
    </div>
  );
}

function Finance1() {
  return (
    <div className="absolute inset-[10.4%_5.21%]" data-name="finance">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9167 15.84">
        <g id="finance">
          <path d={svgPaths.p345a8ef0} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p1cebdd00} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p39b1a700} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Finance() {
  return (
    <div className="absolute contents inset-[10.4%_5.21%]" data-name="finance">
      <Finance1 />
    </div>
  );
}

function Wallet() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="wallet">
      <Finance />
    </div>
  );
}

function Home3() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Wallet />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Minha carteira</p>
    </div>
  );
}

function Inicio2() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home3 />
      <Frame10 />
    </div>
  );
}

function Component2() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 4">
      <Inicio2 />
    </div>
  );
}

function General1() {
  return (
    <div className="absolute inset-[5.38%_5.27%_5.12%_5.24%]" data-name="general">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.8962 17.8999">
        <g id="general">
          <path d={svgPaths.p1010bf00} fill="var(--fill-0, white)" id="rocket" />
        </g>
      </svg>
    </div>
  );
}

function Rocket() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="rocket">
      <General1 />
    </div>
  );
}

function Home4() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Rocket />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Soluções</p>
    </div>
  );
}

function Inicio3() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home4 />
      <Frame11 />
    </div>
  );
}

function Component3() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 5">
      <Inicio3 />
    </div>
  );
}

function ItNetwork() {
  return (
    <div className="absolute inset-[5.12%_5.2%_5.12%_5.18%]" data-name="it-network">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9228 17.9512">
        <g id="it-network">
          <path d={svgPaths.p3ba9d00} fill="var(--fill-0, white)" id="it-8" />
        </g>
      </svg>
    </div>
  );
}

function Wrench() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="wrench">
      <ItNetwork />
    </div>
  );
}

function Home5() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Wrench />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Tools</p>
    </div>
  );
}

function Inicio4() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home5 />
      <Frame12 />
    </div>
  );
}

function Component4() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 6">
      <Inicio4 />
    </div>
  );
}

function Users() {
  return (
    <div className="absolute inset-[5.04%_7.79%]" data-name="users">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.8833 17.9832">
        <g id="users">
          <path d={svgPaths.p3a2ad900} fill="var(--fill-0, white)" id="people" />
        </g>
      </svg>
    </div>
  );
}

function People() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="people">
      <Users />
    </div>
  );
}

function Home6() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <People />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Comunidade</p>
    </div>
  );
}

function Inicio5() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home6 />
      <Frame13 />
    </div>
  );
}

function Component6() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 8">
      <Inicio5 />
    </div>
  );
}

function HelpCircle() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="help-circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_15_5997)" id="help-circle">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22540600} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10 14.1667H10.0083" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_15_5997">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Home7() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <HelpCircle />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Ajuda</p>
    </div>
  );
}

function Inicio6() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home7 />
      <Frame14 />
    </div>
  );
}

function Component5() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 7">
      <Inicio6 />
    </div>
  );
}

function Default() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-full" data-name="Default">
      <Component />
      <Component1 />
      <Component2 />
      <Component3 />
      <Component4 />
      <Component6 />
      <Component5 />
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex flex-col gap-[68px] items-center relative shrink-0 w-full">
      <LogoBlack />
      <Default />
    </div>
  );
}

function Menu() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[90px] h-[991px] items-center left-0 px-[8px] py-[24px] top-0 w-[120px]" data-name="Menu">
      <div aria-hidden="true" className="absolute border-[#515151] border-r border-solid inset-0 pointer-events-none" />
      <Frame34 />
    </div>
  );
}

export default function WorkspaceConfiguracoesDadosDaEmpresa() {
  return (
    <div className="bg-[#212121] relative size-full" data-name="Workspace > Configurações > Dados da empresa">
      <Frame27 />
      <Frame36 />
      <Header3 />
      <Frame28 />
      <Menu />
    </div>
  );
}