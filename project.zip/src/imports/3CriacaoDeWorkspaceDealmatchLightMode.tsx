import svgPaths from "./svg-cik2uk32m6";

function Camada() {
  return (
    <div className="absolute inset-[5.49%_-0.11%_22.16%_0]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 112.126 26.0459">
        <g id="Camada_1-2">
          <path d={svgPaths.p2adb5e00} fill="var(--fill-0, #020617)" id="Vector" />
          <path d={svgPaths.p26b68980} fill="var(--fill-0, #020617)" id="Vector_2" />
          <path d={svgPaths.p322ea900} fill="var(--fill-0, #020617)" id="Vector_3" />
          <path d={svgPaths.p3e2b1380} fill="var(--fill-0, #020617)" id="Vector_4" />
          <path d={svgPaths.p23bbae00} fill="var(--fill-0, #020617)" id="Vector_5" />
          <path d={svgPaths.p915fd00} fill="var(--fill-0, #020617)" id="Vector_6" />
          <path d={svgPaths.p1a2d4800} fill="var(--fill-0, #2E61FF)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function Logotype() {
  return (
    <div className="h-[36px] overflow-clip relative shrink-0 w-[112px]" data-name="logotype">
      <Camada />
    </div>
  );
}

function Component() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Component 11">
      <div className="absolute inset-[-29.17%_-47.06%_-147.06%_-47.06%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
          <g id="Component 11">
            <circle cx="23.2941" cy="19" id="Ellipse 516" opacity="0.1" r="14.5" stroke="url(#paint0_linear_1_5947)" />
            <g filter="url(#filter0_dddddddi_1_5947)" id="Ellipse 515">
              <circle cx="23.2941" cy="19" fill="var(--fill-0, #2E61FF)" r="11.2941" />
              <circle cx="23.2941" cy="19" fill="url(#paint1_linear_1_5947)" fillOpacity="0.1" r="11.2941" />
            </g>
            <g id="Frame 427321015">
              <circle cx="18.8312" cy="1.9707" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1434" opacity="0.3" r="0.75" />
              <circle cx="10.0441" cy="3.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1435" r="0.75" />
              <circle cx="33.0441" cy="4.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1446" r="0.75" />
              <circle cx="40.0441" cy="9.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1451" opacity="0.3" r="0.75" />
              <circle cx="9.04412" cy="10.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1449" opacity="0.3" r="0.75" />
            </g>
            <g id="IA">
              <path d={svgPaths.p1063c100} fill="var(--fill-0, white)" />
              <path d={svgPaths.p17307780} fill="var(--fill-0, white)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" id="filter0_dddddddi_1_5947" width="46.5882" x="2.98023e-07" y="6.70588">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="12" result="effect1_dropShadow_1_5947" />
              <feOffset dy="24" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="6" result="effect2_dropShadow_1_5947" />
              <feOffset dy="12" />
              <feGaussianBlur stdDeviation="6" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_5947" mode="normal" result="effect2_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="3" result="effect3_dropShadow_1_5947" />
              <feOffset dy="6" />
              <feGaussianBlur stdDeviation="3" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect2_dropShadow_1_5947" mode="normal" result="effect3_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.5" result="effect4_dropShadow_1_5947" />
              <feOffset dy="3" />
              <feGaussianBlur stdDeviation="1.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.02 0" />
              <feBlend in2="effect3_dropShadow_1_5947" mode="normal" result="effect4_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.5" result="effect5_dropShadow_1_5947" />
              <feOffset dy="1" />
              <feGaussianBlur stdDeviation="0.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect4_dropShadow_1_5947" mode="normal" result="effect5_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect6_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect5_dropShadow_1_5947" mode="normal" result="effect6_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect7_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0" />
              <feBlend in2="effect6_dropShadow_1_5947" mode="normal" result="effect7_dropShadow_1_5947" />
              <feBlend in="SourceGraphic" in2="effect7_dropShadow_1_5947" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="shape" mode="normal" result="effect8_innerShadow_1_5947" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_5947" x1="23.2941" x2="23.2941" y1="4" y2="34">
              <stop stopColor="#2E61FF" stopOpacity="0" />
              <stop offset="1" stopColor="#2E61FF" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_5947" x1="23.2941" x2="23.2941" y1="30.2941" y2="7.70588">
              <stop stopColor="white" stopOpacity="0" />
              <stop offset="1" stopColor="white" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Component />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p39ce2c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.5 21H13.5" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MusicAudioBellNotifications() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Music, Audio/Bell, Notifications">
      <Group />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <MusicAudioBellNotifications />
    </div>
  );
}

function CircleRedSolid() {
  return (
    <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]" data-name="circle-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#fb2c36] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="container">
      <Button />
      <Button1 />
      <CircleRedSolid />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute left-0 size-[40px] top-0">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Frame 1">
          <g clipPath="url(#clip0_1_5972)">
            <path d={svgPaths.pf5fe180} data-figma-bg-blur-radius="2.32101" fill="var(--fill-0, white)" id="Building" />
            <path d={svgPaths.p22fee400} fill="var(--fill-0, #E2E8F0)" id="Square" />
            <path d={svgPaths.p33c16900} fill="var(--fill-0, #E2E8F0)" id="Square_2" />
            <path d={svgPaths.p10fd16f0} fill="var(--fill-0, #E2E8F0)" id="Square_3" />
            <path d={svgPaths.p3149f040} fill="var(--fill-0, #F8FAFC)" id="Building_2" />
            <path d={svgPaths.p19324e70} fill="var(--fill-0, #E2E8F0)" id="Square_4" />
            <path d={svgPaths.p3ccb5500} fill="var(--fill-0, #E2E8F0)" id="Square_5" />
            <path d={svgPaths.p340fa100} fill="var(--fill-0, #E2E8F0)" id="Square_6" />
            <path d={svgPaths.pa1f5780} fill="var(--fill-0, #E2E8F0)" id="Square_7" />
            <path d={svgPaths.p1672d180} fill="var(--fill-0, #E2E8F0)" id="Square_8" />
            <path d={svgPaths.p33129c00} fill="var(--fill-0, #E2E8F0)" id="Square_9" />
            <path d={svgPaths.p40e1080} fill="var(--fill-0, #E2E8F0)" id="Square_10" />
            <path d={svgPaths.p1574400} fill="var(--fill-0, #E2E8F0)" id="Square_11" />
          </g>
        </g>
        <defs>
          <clipPath id="bgblur_1_1_5972_clip_path" transform="translate(-3.67899 -11.9075)">
            <path d={svgPaths.pf5fe180} />
          </clipPath>
          <clipPath id="clip0_1_5972">
            <path d={svgPaths.p3c12f200} fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Person() {
  return (
    <div className="absolute bottom-0 right-0 size-[16px]" data-name="person">
      <div className="absolute inset-[-6.25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
          <g id="person">
            <g clipPath="url(#clip0_1_5875)">
              <path d={svgPaths.pcc89de0} fill="var(--fill-0, #E2E8F0)" />
              <ellipse cx="9" cy="15.5349" fill="var(--fill-0, #F8FAFC)" id="Body" rx="5.95349" ry="4.46512" />
              <circle cx="9" cy="6.97674" fill="var(--fill-0, #F8FAFC)" id="Head" opacity="0.9" r="2.97674" />
            </g>
            <path d={svgPaths.p389f1700} stroke="var(--stroke-0, white)" />
          </g>
          <defs>
            <clipPath id="clip0_1_5875">
              <path d={svgPaths.pcc89de0} fill="white" />
            </clipPath>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Avatar() {
  return (
    <div className="bg-[#f1f5f9] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame1 />
      <Person />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Sem empresa cadastrada</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#64748b] text-[12px]">Ative seu workspace</p>
    </div>
  );
}

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0" data-name="container">
      <Avatar />
      <Content />
      <ArrowsDiagramsArrow />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
      <Container />
      <div className="bg-[#e2e8f0] h-[24px] rounded-[9999px] shrink-0 w-[2px]" data-name="divider" />
      <Container1 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="bg-white h-[80px] relative shrink-0 w-full z-[3]" data-name="Navbar">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between px-[72px] py-[16px] relative size-full">
          <Logotype />
          <Frame8 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[12px] items-start min-h-px min-w-px not-italic relative">
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.1] relative shrink-0 text-[#020617] text-[32px] tracking-[-0.16px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Bem-vindo à Bloxs!
      </p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#475569] text-[0px] text-[14px]">
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">Antes de começar</span>
        <span className="leading-[1.4]">, complete as etapas abaixo para liberar o acesso total à plataforma.</span>
      </p>
    </div>
  );
}

function Number() {
  return (
    <div className="bg-white content-stretch flex items-center justify-center p-[8.182px] relative rounded-[78.545px] shrink-0" data-name="Number">
      <div aria-hidden="true" className="absolute border-[1.636px] border-solid border-white inset-[-1.636px] pointer-events-none rounded-[80.181px]" />
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] not-italic relative shrink-0 text-[#2e61ff] text-[14px] text-center w-[19.636px]">
        <p className="leading-[1.4] whitespace-pre-wrap">03</p>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] not-italic relative shrink-0 whitespace-nowrap" data-name="Frame">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center relative shrink-0 text-[#020617] text-[14px] text-center">
        <p className="leading-[1.4]">Dealmatch</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[#475569] text-[12px]">
        <p className="leading-[1.4]">Responda para receber recomendações certas.</p>
      </div>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <Number />
      <Frame />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] items-end justify-center relative shrink-0 w-full" data-name="Container">
      <Frame9 />
      <Frame10 />
    </div>
  );
}

function Dot() {
  return <div className="absolute bg-[#2e61ff] h-[4px] left-0 rounded-br-[9999px] rounded-tr-[9999px] top-0 w-[480px]" data-name="dot" />;
}

function Status() {
  return (
    <div className="bg-[#e2e8f0] h-[4px] overflow-clip relative shrink-0 w-[1440px]" data-name="status">
      <Dot />
    </div>
  );
}

function Header() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col gap-[32px] items-center pt-[32px] px-[72px] relative w-full">
          <Container2 />
          <Status />
        </div>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p2656a480} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p3dfa5c00} fillRule="evenodd" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function BusinessProductsBusinessChart() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Business, Products/Business, Chart">
      <Group1 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Group">
          <g id="Path" />
          <path d="M7 7.65333V5.47167" id="Path_2" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path d={svgPaths.p24f24480} id="Path_3" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path clipRule="evenodd" d={svgPaths.p555f300} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialWarning() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Interface, Essential/Warning">
      <Group2 />
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Não preenchido</p>
    </div>
  );
}

function StatusBadge() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex gap-[4px] h-[24px] items-center justify-center overflow-clip pl-[10px] pr-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Status Badge">
      <InterfaceEssentialWarning />
      <Content1 />
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-white content-stretch flex items-center justify-center p-[2px] relative rounded-[8px] shrink-0" data-name="button">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <ArrowsDiagramsArrow1 />
        </div>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full">
      <BusinessProductsBusinessChart />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[16px] whitespace-pre-wrap">Interesses de investimentos</p>
      <StatusBadge />
      <Button2 />
    </div>
  );
}

function Divider() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1248 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="1248" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Box() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[14px] top-1/2" data-name="box">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g filter="url(#filter0_iiii_1_7238)" id="box">
          <path d={svgPaths.p26976600} fill="var(--fill-0, #2E61FF)" />
          <path d="M11 4L5.5 10L3 7.27273" id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="16" id="filter0_iiii_1_7238" width="14" x="0" y="0">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.02 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_1_7238" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feMorphology in="SourceAlpha" operator="erode" radius="0.75" result="effect2_innerShadow_1_7238" />
            <feOffset />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.06 0" />
            <feBlend in2="effect1_innerShadow_1_7238" mode="normal" result="effect2_innerShadow_1_7238" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect2_innerShadow_1_7238" mode="normal" result="effect3_innerShadow_1_7238" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="1" />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.04 0" />
            <feBlend in2="effect3_innerShadow_1_7238" mode="normal" result="effect4_innerShadow_1_7238" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

function CheckboxItem() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Checkbox Item">
      <Box />
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Imobiliário</p>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="bg-[#eef4ff] relative rounded-[12px] shrink-0">
      <div className="content-stretch flex gap-[8px] items-center overflow-clip px-[14px] py-[6px] relative rounded-[inherit]">
        <CheckboxItem />
        <Content2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#d9e5ff] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Agronegócio</p>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0">
      <div className="content-stretch flex items-center overflow-clip px-[14px] py-[6px] relative rounded-[inherit]">
        <Content3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Ativos Judiciais</p>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0">
      <div className="content-stretch flex items-center overflow-clip px-[14px] py-[6px] relative rounded-[inherit]">
        <Content4 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Infraestrutura</p>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0">
      <div className="content-stretch flex items-center overflow-clip px-[14px] py-[6px] relative rounded-[inherit]">
        <Content5 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#475569] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Crédito Corporativo</p>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0">
      <div className="content-stretch flex items-center overflow-clip px-[14px] py-[6px] relative rounded-[inherit]">
        <Content6 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-center flex flex-wrap gap-[16px] items-center relative shrink-0 w-full">
      <Frame3 />
      <Frame4 />
      <Frame5 />
      <Frame6 />
      <Frame7 />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px] w-full whitespace-pre-wrap">Selecione os setores que se alinham melhor ao seu perfil de investimento:</p>
      <Frame2 />
    </div>
  );
}

function InformationCircleSolid() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g clipPath="url(#clip0_1_7245)" id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.p191d3280} fill="var(--fill-0, #94A3B8)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_7245">
            <rect fill="white" height="15" width="15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Label() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0" data-name="Label">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Tipo de instrumento</p>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#e7000b] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">*</p>
      </div>
      <InformationCircleSolid />
    </div>
  );
}

function ArrowsDiagramsArrow2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-white h-[48px] relative rounded-[8px] shrink-0 w-full" data-name="container">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[12px] relative size-full">
          <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#64748b] text-[14px] whitespace-pre-wrap">CRI, CRA, Debenture</p>
          <ArrowsDiagramsArrow2 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function TextInput() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-[400px]" data-name="Text Input">
      <Label />
      <Container5 />
    </div>
  );
}

function Tail1() {
  return (
    <div className="h-[6px] relative w-[12px]" data-name="Tail">
      <div className="absolute inset-[-33.33%_-25%_-6.31%_-25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 8.37868">
          <g id="Tail">
            <path d={svgPaths.pa581200} fill="var(--fill-0, #0F172A)" id="Tail_2" stroke="var(--stroke-0, #334155)" />
            <rect fill="var(--fill-0, #0F172A)" height="2" id="Safe" rx="1" width="18" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail() {
  return (
    <div className="content-stretch flex flex-col h-full items-center justify-center relative w-[46px]" data-name="Tail">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Tail1 />
        </div>
      </div>
    </div>
  );
}

function Tooltip1() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[8px] z-[1]" data-name="Tooltip">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start px-[12px] py-[6px] relative w-full">
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[12px] whitespace-pre-wrap">Escolha os tipos de instrumentos que sua instituição busca.</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#334155] border-solid inset-[-1px] pointer-events-none rounded-[9px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Tooltip() {
  return (
    <div className="absolute content-stretch flex isolate items-start justify-center left-[205px] top-[168px] w-[224px]" data-name="Tooltip">
      <div className="flex items-center justify-center relative self-stretch shrink-0 w-[6px] z-[2]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none h-full">
          <Tail />
        </div>
      </div>
      <Tooltip1 />
    </div>
  );
}

function Items() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0 w-full" data-name="items">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start pb-[24px] pt-[16px] px-[24px] relative w-full">
          <Frame11 />
          <Divider />
          <Container4 />
          <TextInput />
          <Tooltip />
          <div className="absolute left-[189px] size-[16px] top-[208px]" data-name="Vector">
            <div className="absolute inset-[-18.75%_-25%_-31.25%_-25%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0001 24.0001">
                <g filter="url(#filter0_d_1_7275)" id="Vector">
                  <path d={svgPaths.p17bb8880} fill="var(--fill-0, #475569)" />
                  <path d={svgPaths.p265c6800} stroke="var(--stroke-0, white)" strokeWidth="2" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="24.0001" id="filter0_d_1_7275" width="24.0001" x="-2.38419e-07" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                    <feOffset dy="1" />
                    <feGaussianBlur stdDeviation="1" />
                    <feComposite in2="hardAlpha" operator="out" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.05 0" />
                    <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_7275" />
                    <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_7275" mode="normal" result="shape" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path d="M10 10.9333V7.81667" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2dddf100} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p3f21b200} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialWarning1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/Warning">
      <Group3 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Group">
          <g id="Path" />
          <path d="M7 7.65333V5.47167" id="Path_2" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path d={svgPaths.p24f24480} id="Path_3" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path clipRule="evenodd" d={svgPaths.p555f300} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialWarning2() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Interface, Essential/Warning">
      <Group4 />
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Não preenchido</p>
    </div>
  );
}

function StatusBadge1() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex gap-[4px] h-[24px] items-center justify-center overflow-clip pl-[10px] pr-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Status Badge">
      <InterfaceEssentialWarning2 />
      <Content7 />
    </div>
  );
}

function ArrowsDiagramsArrow3() {
  return (
    <div className="relative size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-white content-stretch flex items-center justify-center p-[2px] relative rounded-[8px]" data-name="button">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <ArrowsDiagramsArrow3 />
        </div>
      </div>
    </div>
  );
}

function Items1() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0 w-full" data-name="items">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[16px] relative w-full">
          <InterfaceEssentialWarning1 />
          <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[16px] whitespace-pre-wrap">Perfil de risco</p>
          <StatusBadge1 />
          <div className="flex items-center justify-center relative shrink-0">
            <div className="-scale-y-100 flex-none">
              <Button3 />
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function PaymentsFinanceBank() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Payments, Finance/Bank">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p10bb6400} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M12.2025 8.33333V15" id="a" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M15.8333 15V8.33333" id="b" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M12.2025 8.33333V15" id="a_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M15.8333 15V8.33333" id="b_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M4.16667 8.33333V15" id="c" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M7.7975 15V8.33333" id="d" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M4.16667 8.33333V15" id="c_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M7.7975 15V8.33333" id="d_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path clipRule="evenodd" d={svgPaths.p373b1600} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Group">
          <g id="Path" />
          <path d="M7 7.65333V5.47167" id="Path_2" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path d={svgPaths.p24f24480} id="Path_3" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path clipRule="evenodd" d={svgPaths.p555f300} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialWarning3() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Interface, Essential/Warning">
      <Group5 />
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Não preenchido</p>
    </div>
  );
}

function StatusBadge2() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex gap-[4px] h-[24px] items-center justify-center overflow-clip pl-[10px] pr-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Status Badge">
      <InterfaceEssentialWarning3 />
      <Content8 />
    </div>
  );
}

function ArrowsDiagramsArrow4() {
  return (
    <div className="relative size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-white content-stretch flex items-center justify-center p-[2px] relative rounded-[8px]" data-name="button">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <ArrowsDiagramsArrow4 />
        </div>
      </div>
    </div>
  );
}

function Items2() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0 w-full" data-name="items">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[16px] relative w-full">
          <PaymentsFinanceBank />
          <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[16px] whitespace-pre-wrap">Localização e garantias</p>
          <StatusBadge2 />
          <div className="flex items-center justify-center relative shrink-0">
            <div className="-scale-y-100 flex-none">
              <Button4 />
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute inset-[12.5%_16.67%]" data-name="Group">
      <div className="absolute inset-[-5%_-5.63%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.8333 16.5">
          <g id="Group">
            <path clipRule="evenodd" d={svgPaths.p33a25a00} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p15d45d80} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function InterfaceEssentialClipboard1Check() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/clipboard-1-check">
      <Group6 />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Group">
          <g id="Path" />
          <path d="M7 7.65333V5.47167" id="Path_2" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path d={svgPaths.p24f24480} id="Path_3" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
          <path clipRule="evenodd" d={svgPaths.p555f300} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #9A3412)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.3125" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialWarning4() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Interface, Essential/Warning">
      <Group7 />
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#9a3412] text-[12px]">Não preenchido</p>
    </div>
  );
}

function StatusBadge3() {
  return (
    <div className="bg-[#ffedd5] content-stretch flex gap-[4px] h-[24px] items-center justify-center overflow-clip pl-[10px] pr-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Status Badge">
      <InterfaceEssentialWarning4 />
      <Content9 />
    </div>
  );
}

function ArrowsDiagramsArrow5() {
  return (
    <div className="relative size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-white content-stretch flex items-center justify-center p-[2px] relative rounded-[8px]" data-name="button">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <ArrowsDiagramsArrow5 />
        </div>
      </div>
    </div>
  );
}

function Items3() {
  return (
    <div className="bg-white relative rounded-[12px] shrink-0 w-full" data-name="items">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[24px] py-[16px] relative w-full">
          <InterfaceEssentialClipboard1Check />
          <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#020617] text-[16px] whitespace-pre-wrap">Exigências</p>
          <StatusBadge3 />
          <div className="flex items-center justify-center relative shrink-0">
            <div className="-scale-y-100 flex-none">
              <Button5 />
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Container3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[24px] items-start px-[72px] py-[40px] relative w-full">
        <Items />
        <Items1 />
        <Items2 />
        <Items3 />
      </div>
    </div>
  );
}

function WorkArea() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative rounded-bl-[24px] rounded-br-[24px] shrink-0 w-full z-[2]" data-name="Work Area">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none rounded-bl-[24px] rounded-br-[24px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <Header />
      <Container3 />
    </div>
  );
}

function ArrowsDiagramsArrow6() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M14 8L10 12L14 16" id="Path" stroke="var(--stroke-0, #020617)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Content10() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Voltar</p>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[20px] py-[8px] relative rounded-[inherit]">
        <ArrowsDiagramsArrow6 />
        <Content10 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cbd5e1] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Content11() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Finalizar</p>
    </div>
  );
}

function ArrowsDiagramsArrow7() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M10 16L14 12L10 8" id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[40px] items-center justify-center overflow-clip px-[20px] py-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content11 />
      <ArrowsDiagramsArrow7 />
    </div>
  );
}

function Footer() {
  return (
    <div className="relative shrink-0 w-full z-[1]" data-name="Footer">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[72px] py-[24px] relative w-full">
          <Button6 />
          <p className="font-['Inter:Medium',sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#64748b] text-[12px] text-center tracking-[1.2px] uppercase">
            <span className="leading-[1.5]">{`[ `}</span>
            <span className="leading-[1.5]">{`passo `}</span>
            <span className="leading-[1.5]">3</span>
            <span className="leading-[1.5]">{` de 3 `}</span>
            <span className="leading-[1.5]">]</span>
          </p>
          <Button7 />
        </div>
      </div>
    </div>
  );
}

export default function Component3CriacaoDeWorkspaceDealmatchLightMode() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col isolate items-center overflow-clip relative rounded-[24px] size-full" data-name="3. Criação de Workspace | Dealmatch [Light Mode]">
      <Navbar />
      <WorkArea />
      <Footer />
    </div>
  );
}