import svgPaths from "./svg-ns7rzdjnz6";
import imgTexture from "figma:asset/49b10b9ed2e210e5e2ae2f86906940de3b56018c.png";
import imgFrame1321314670 from "figma:asset/4ca9b70621c34953fa1ba17819512fec86ad1987.png";
import imgImage from "figma:asset/9a8e3295558857dc96c9e60a2ae4f30d3cab6c73.png";
import { imgRectangle1058 } from "./svg-4vleh";

function Mosaic() {
  return (
    <div className="absolute h-[199px] left-0 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[1272px_199px] mix-blend-difference top-0 w-[1272px]" data-name="mosaic" style={{ maskImage: `url('${imgRectangle1058}')` }}>
      <div className="absolute bg-size-[320.0000047683716px_320.0000047683716px] bg-top-left inset-0 mix-blend-difference" data-name="texture" style={{ backgroundImage: `url('${imgTexture}')` }} />
    </div>
  );
}

function Component() {
  return (
    <div className="absolute contents left-0 top-0" data-name="1">
      <Mosaic />
      <div className="absolute flex h-[199px] items-center justify-center left-[616px] top-0 w-[656px]">
        <div className="-scale-y-100 flex-none">
          <div className="bg-[rgba(255,255,255,0.34)] h-[199px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-616px_0px] mask-size-[1272px_199px] w-[656px]" style={{ maskImage: `url('${imgRectangle1058}')` }} />
        </div>
      </div>
      <div className="absolute flex h-[91px] items-center justify-center left-[-87px] top-[162px] w-[197px]">
        <div className="-scale-y-100 flex-none">
          <div className="bg-[#1b41f5] blur-[56px] h-[91px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[87px_-162px] mask-size-[1272px_199px] opacity-10 w-[197px]" style={{ maskImage: `url('${imgRectangle1058}')` }} />
        </div>
      </div>
    </div>
  );
}

function Group16() {
  return (
    <div className="h-[379.867px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1031.651px_360.315px] mask-size-[1272px_199px] opacity-60 relative w-[562.464px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
      <div className="absolute inset-[-68.67%_-46.38%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1084.17 901.573">
          <g id="Group 1410103855" style={{ mixBlendMode: "luminosity" }}>
            <g filter="url(#filter0_f_1_3724)" id="Ellipse 1229" opacity="0.1">
              <circle cx="657.023" cy="427.147" fill="var(--fill-0, #2E61FF)" r="166.294" />
            </g>
            <g filter="url(#filter1_f_1_3724)" id="Ellipse 1230" opacity="0.1">
              <circle cx="427.147" cy="474.426" fill="var(--fill-0, #2E61FF)" r="166.294" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="854.293" id="filter0_f_1_3724" width="854.293" x="229.876" y="1.18572e-06">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3724" stdDeviation="130.426" />
            </filter>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="854.293" id="filter1_f_1_3724" width="854.293" x="-2.53117e-06" y="47.2794">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3724" stdDeviation="130.426" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Light1() {
  return (
    <div className="absolute contents h-[951.716px] left-[860.76px] mix-blend-multiply top-[-484.51px] w-[823.184px]" data-name="light">
      <div className="absolute flex h-[596.129px] items-center justify-center left-[1152.47px] mix-blend-luminosity top-[-416.89px] w-[243.55px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[16.23deg]">
          <div className="h-[597.687px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1152.466px_416.889px] mask-size-[1272px_199px] opacity-60 relative w-[79.661px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-2.59%_-21.24%_-1.35%_-21.22%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 113.482 621.283">
                <g filter="url(#filter0_f_1_3777)" id="Rectangle 8413" opacity="0.3" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p3e6a0300} fill="url(#paint0_linear_1_3777)" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="621.283" id="filter0_f_1_3777" width="113.482" x="-2.38419e-07" y="-2.38419e-07">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3777" stdDeviation="8.96682" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3777" x1="91.7538" x2="68.1913" y1="-75.3538" y2="1016.56">
                    <stop offset="0.214779" stopColor="#2E61FF" />
                    <stop offset="0.567446" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[362.779px] items-center justify-center left-[1079.39px] mix-blend-luminosity top-[-398.18px] w-[523.345px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[29.99deg] skew-x-[-2.58deg]">
          <div className="h-[114.131px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1079.387px_398.183px] mask-size-[1272px_199px] opacity-60 relative w-[533.318px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-137.13%_-29.35%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 846.342 427.155">
                <g filter="url(#filter0_f_1_3800)" id="Ellipse 1227" opacity="0.31" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p27f3b2f1} fill="var(--fill-0, #2E61FF)" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="427.155" id="filter0_f_1_3800" width="846.342" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3800" stdDeviation="78.2559" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[569.129px] items-center justify-center left-[920.05px] mix-blend-luminosity top-[-188.58px] w-[643.675px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[50.49deg] skew-x-[-4.93deg]">
          <div className="h-[490.603px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-920.049px_188.584px] mask-size-[1272px_199px] opacity-60 relative w-[376.808px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-2.76%_-3.63%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 404.186 517.681">
                <g filter="url(#filter0_f_1_3765)" id="Vector 3412" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p2eb4ca00} stroke="url(#paint0_linear_1_3765)" strokeWidth="1.63033" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="517.681" id="filter0_f_1_3765" width="404.186" x="1.78814e-07" y="-2.68221e-07">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3765" stdDeviation="6.52132" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3765" x1="69.5557" x2="216.077" y1="91.3956" y2="265.418">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[294.439px] items-center justify-center left-[999.63px] mix-blend-luminosity top-[-228.29px] w-[335.398px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[52.79deg] skew-x-[-5.04deg]">
          <div className="h-[252.932px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-999.625px_228.29px] mask-size-[1272px_199px] opacity-60 relative w-[200.591px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-4.91%_-6.33%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 225.97 277.783">
                <g filter="url(#filter0_f_1_3734)" id="Vector 3411" opacity="0.1" style={{ mixBlendMode: "plus-lighter" }}>
                  <path d={svgPaths.p1b9f83c0} stroke="url(#paint0_linear_1_3734)" strokeWidth="3.26066" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="277.783" id="filter0_f_1_3734" width="225.97" x="-3.57628e-07" y="2.38419e-07">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3734" stdDeviation="5.70616" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3734" x1="39.6012" x2="262.569" y1="46.8152" y2="342.417">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Light() {
  return (
    <div className="absolute contents left-[585px] mix-blend-multiply size-[1374.695px] top-[-696px]" data-name="light">
      <div className="absolute flex h-[675.859px] items-center justify-center left-[1031.65px] mix-blend-multiply top-[-360.32px] w-[603.678px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[61.23deg]">
          <Group16 />
        </div>
      </div>
      <Light1 />
      <div className="absolute flex h-[256.851px] items-center justify-center left-[1287.89px] mix-blend-multiply top-[-247.92px] w-[70.415px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[11.11deg]">
          <div className="h-[257.592px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1287.89px_247.923px] mask-size-[1272px_199px] opacity-60 relative w-[21.194px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-12.66%_-153.85%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 86.4075 322.805">
                <g filter="url(#filter0_f_5_14755)" id="Ellipse 1231" style={{ mixBlendMode: "luminosity" }}>
                  <ellipse cx="43.2038" cy="161.403" fill="url(#paint0_linear_5_14755)" rx="10.5971" ry="128.796" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="322.805" id="filter0_f_5_14755" width="86.4075" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_5_14755" stdDeviation="16.3033" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_14755" x1="41.1126" x2="43.2038" y1="170.211" y2="290.199">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[398.577px] items-center justify-center left-[1224.96px] mix-blend-multiply top-[-434.58px] w-[66.971px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[4.97deg]">
          <div className="h-[397.239px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1224.964px_434.578px] mask-size-[1272px_199px] opacity-60 relative w-[32.684px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-13.13%_-159.62%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 137.025 501.58">
                <g filter="url(#filter0_f_5_14741)" id="Ellipse 1232" style={{ mixBlendMode: "luminosity" }}>
                  <ellipse cx="68.5127" cy="250.79" fill="url(#paint0_linear_5_14741)" rx="16.3421" ry="198.62" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="501.58" id="filter0_f_5_14741" width="137.025" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_5_14741" stdDeviation="26.0853" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_14741" x1="68.5127" x2="68.5127" y1="52.1706" y2="449.41">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[390.541px] items-center justify-center left-[1314.29px] mix-blend-multiply top-[-198.35px] w-[142.417px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-[16.23deg]">
          <div className="h-[397.239px] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1314.294px_198.353px] mask-size-[1272px_199px] opacity-60 relative w-[32.684px]" style={{ maskImage: `url('${imgRectangle1058}')` }}>
            <div className="absolute inset-[-11.08%_-134.68%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 120.722 485.277">
                <g filter="url(#filter0_f_1_3664)" id="Ellipse 1233" style={{ mixBlendMode: "luminosity" }}>
                  <ellipse cx="60.361" cy="242.639" fill="url(#paint0_linear_1_3664)" rx="16.3421" ry="198.62" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="485.277" id="filter0_f_1_3664" width="120.722" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_1_3664" stdDeviation="22.0095" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3664" x1="60.361" x2="50.4292" y1="44.0189" y2="360.801">
                    <stop stopColor="#2E61FF" />
                    <stop offset="1" stopColor="#2E61FF" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Galaxy() {
  return (
    <div className="absolute inset-[-143.22%_-15.99%_-274.56%_-59.98%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[763px_285px] mask-size-[1272px_199px]" data-name="Galaxy" style={{ maskImage: `url('${imgRectangle1058}')` }}>
      <div className="absolute inset-[-5.39%_-10.26%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2697.44 1141.52">
          <g id="Galaxy">
            <g filter="url(#filter0_f_1_3711)" id="Vector 2">
              <path d={svgPaths.p34a73f80} fill="url(#paint0_linear_1_3711)" fillOpacity="0.32" />
            </g>
            <g filter="url(#filter1_f_1_3711)" id="Vector 3">
              <path d={svgPaths.p3ff46c00} fill="url(#paint1_linear_1_3711)" fillOpacity="0.32" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="764.173" id="filter0_f_1_3711" width="1460.24" x="1237.2" y="377.346">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3711" stdDeviation="112" />
            </filter>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="764.173" id="filter1_f_1_3711" width="1460.24" x="1.90735e-06" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_1_3711" stdDeviation="112" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3711" x1="1497.88" x2="2188.34" y1="856.836" y2="569.241">
              <stop stopColor="#032952" stopOpacity="0" />
              <stop offset="0.333333" stopColor="#4577FF" />
              <stop offset="0.666667" stopColor="#2E61FF" />
              <stop offset="1" stopColor="#032952" stopOpacity="0" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_3711" x1="1199.57" x2="509.105" y1="284.684" y2="572.278">
              <stop stopColor="#032952" stopOpacity="0" />
              <stop offset="0.333333" stopColor="#4577FF" />
              <stop offset="0.666667" stopColor="#2E61FF" />
              <stop offset="1" stopColor="#032952" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Bg() {
  return (
    <div className="-translate-x-1/2 absolute contents left-1/2 top-0" data-name="bg">
      <div className="absolute bg-gradient-to-l from-[#eef4ff] h-[199px] left-0 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[1272px_199px] to-[60.241%] to-white top-0 w-[1272px]" style={{ maskImage: `url('${imgRectangle1058}')` }} />
      <Component />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[2203.627px] left-[calc(50%-279.75px)] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[682px_1118px] mask-size-[1272px_199px] mix-blend-overlay top-[calc(50%-115.69px)] w-[2076.495px]" data-name="Vector" style={{ maskImage: `url('${imgRectangle1058}')` }}>
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2077.12 2204.19">
          <g id="Vector" style={{ mixBlendMode: "overlay" }}>
            <path d={svgPaths.p3b2d6700} stroke="var(--stroke-0, white)" strokeOpacity="0.3" />
          </g>
        </svg>
      </div>
      <Light />
      <Galaxy />
      <div className="absolute bottom-[-848px] h-[701px] left-[43.08%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-548px_-346px] mask-size-[1272px_199px] mix-blend-plus-lighter right-[11.16%]" data-name="Vector" style={{ maskImage: `url('${imgRectangle1058}')` }}>
        <div className="absolute inset-[-35.95%_-43.3%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1086.01 1205.01">
            <g filter="url(#filter0_f_1_3706)" id="Vector" opacity="0.3" style={{ mixBlendMode: "plus-lighter" }}>
              <path d={svgPaths.p346c9c00} stroke="url(#paint0_linear_1_3706)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="432" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="1205.01" id="filter0_f_1_3706" width="1086.01" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_1_3706" stdDeviation="18" />
              </filter>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_3706" x1="593.006" x2="474.909" y1="1137.94" y2="121.947">
                <stop offset="0.014" stopColor="white" />
                <stop offset="0.316" stopColor="#032952" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame16() {
  return <div className="absolute bg-[rgba(3,41,82,0.01)] border-[0.686px] border-[rgba(3,41,82,0.06)] border-solid h-[129px] left-[759px] rounded-bl-[10.977px] rounded-br-[10.977px] rounded-tl-[8.233px] rounded-tr-[10.977px] top-[53px] w-[296px]" />;
}

function Frame14() {
  return (
    <div className="absolute bg-white h-[26px] left-[777px] rounded-[8.233px] shadow-[0px_0px_0px_0.686px_rgba(3,41,82,0.04),0px_0.686px_0.686px_0.343px_rgba(3,41,82,0.04),0px_2.058px_2.058px_-1.029px_rgba(3,41,82,0.02),0px_4.116px_4.116px_-2.058px_rgba(3,41,82,0.04),0px_8.233px_8.233px_-4.116px_rgba(3,41,82,0.04),0px_16.466px_16.466px_-8.233px_rgba(3,41,82,0.04),0px_32.932px_32.932px_-16.466px_rgba(3,41,82,0.04),0px_65.864px_65.864px_-21.955px_rgba(3,41,82,0.06)] top-[32.04px] w-[259px]">
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.686px_0.686px_-0.343px_rgba(3,41,82,0.06)]" />
    </div>
  );
}

function Frame15() {
  return (
    <div className="absolute h-[19px] left-[777px] rounded-[8.233px] top-[32.04px] w-[259px]">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[8.233px] size-full" src={imgFrame1321314670} />
    </div>
  );
}

function Group10() {
  return (
    <div className="relative shrink-0 size-[34.337px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34.3371 34.3371">
        <g id="Group 18877">
          <circle cx="17.1685" cy="17.1685" fill="var(--fill-0, white)" id="Ellipse 6" r="16.7393" stroke="var(--stroke-0, #F1F5F9)" strokeWidth="0.858427" />
          <path d={svgPaths.p332a1700} fill="var(--fill-0, #B0C9FE)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center leading-[1.4] not-italic relative shrink-0 text-[10.301px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#94a3b8]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#0f172a]">123 Capital</p>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[13.735px] items-center min-h-px min-w-px relative">
      <Group10 />
      <Frame8 />
    </div>
  );
}

function InterfaceEssentialLock() {
  return (
    <div className="relative shrink-0 size-[13.735px]" data-name="Interface, Essential/Lock">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.7348 13.7348">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p1121f500} fill="var(--fill-0, #CBD5E1)" fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28764" />
            <path d={svgPaths.p13c12f80} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28764" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[6.867px] items-center relative shrink-0">
      <InterfaceEssentialLock />
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#94a3b8] text-[10.301px]">Privado</p>
    </div>
  );
}

function Frame25() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pb-[13.735px] pt-[17.169px] px-[20.602px] relative w-full">
          <Frame22 />
          <Frame10 />
        </div>
      </div>
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col gap-[3.434px] items-start leading-[1.4] not-italic relative shrink-0">
      <p className="font-['Inter:Medium',sans-serif] font-medium overflow-hidden relative shrink-0 text-[#334155] text-[11.16px] text-ellipsis">XPTO#001</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b] text-[10.301px]">Incorporação</p>
    </div>
  );
}

function BasicBadges() {
  return (
    <div className="bg-[rgba(176,201,254,0.2)] col-1 content-stretch flex items-center justify-center ml-0 mt-0 px-[8.584px] py-[5.151px] relative rounded-[3.434px] row-1" data-name="Basic Badges">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[10.301px] not-italic relative shrink-0 text-[#2e61ff] text-[9.443px]">Imobiliário</p>
    </div>
  );
}

function Group13() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative row-1">
      <BasicBadges />
    </div>
  );
}

function Group12() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group13 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex items-start justify-between pb-[20.602px] pt-[13.735px] px-[20.602px] relative w-full">
        <Frame20 />
        <Group12 />
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col items-start left-[765px] overflow-clip rounded-[10.301px] shadow-[0px_0px_0px_0.686px_rgba(3,41,82,0.04),0px_10.977px_5.489px_-5.489px_rgba(3,41,82,0.01),0px_8.233px_4.116px_-4.116px_rgba(3,41,82,0.02),0px_3.43px_3.43px_-1.715px_rgba(3,41,82,0.08),0px_0.686px_2.058px_-1.029px_rgba(3,41,82,0.16)] top-[40.72px] w-[283.281px]">
      <Frame25 />
      <div className="bg-[#f1f5f9] h-[0.858px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border-solid border-t-[0.858px] border-white inset-[-0.858px_0_0_0] pointer-events-none" />
      </div>
      <Frame18 />
      <div className="bg-[#f1f5f9] h-[0.858px] relative shrink-0 w-full">
        <div aria-hidden="true" className="absolute border-solid border-t-[0.858px] border-white inset-[-0.858px_0_0_0] pointer-events-none" />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.343px_0.343px_0px_rgba(3,41,82,0.08)]" />
    </div>
  );
}

function Frame26() {
  return (
    <div className="h-[65.24px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="size-full" />
      </div>
    </div>
  );
}

function Frame19() {
  return (
    <div className="h-[67.816px] relative shrink-0 w-full">
      <div className="size-full" />
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute left-[1070.02px] rounded-[10.301px] top-[37.72px] w-[266.112px]">
      <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] w-full">
        <Frame26 />
        <Frame19 />
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(3,41,82,0.06)] border-dashed inset-0 pointer-events-none rounded-[10.301px]" />
    </div>
  );
}

function Frame17() {
  return (
    <div className="absolute bg-[#2e61ff] content-stretch flex h-[25.353px] items-start justify-center left-[1082.88px] overflow-clip px-[5.071px] py-[3.38px] rounded-tl-[5.071px] rounded-tr-[5.071px] shadow-[0px_0px_0px_0.845px_#2e61ff,0px_0.845px_0.845px_0.423px_rgba(3,41,82,0.04),0px_2.535px_2.535px_-1.268px_rgba(3,41,82,0.02),0px_5.071px_5.071px_-2.535px_rgba(3,41,82,0.04),0px_10.141px_10.141px_-5.071px_rgba(3,41,82,0.04),0px_20.282px_20.282px_-10.141px_rgba(3,41,82,0.04),0px_29.13px_58.26px_0px_rgba(3,41,82,0.1)] top-[16px] w-[102.679px]">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[7.606px] text-white whitespace-nowrap">
        <p className="leading-[1.2]">Match ideal encontrado!</p>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_0.845px_0px_0px_rgba(255,255,255,0.12)]" />
    </div>
  );
}

function Group11() {
  return (
    <div className="relative shrink-0 size-[33.804px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 33.8038 33.8038">
        <g id="Group 18877">
          <circle cx="16.9019" cy="16.9019" fill="var(--fill-0, white)" id="Ellipse 6" r="16.4793" stroke="var(--stroke-0, #F1F5F9)" strokeWidth="0.845094" />
          <path d={svgPaths.p28de77c0} fill="var(--fill-0, #B0C9FE)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center leading-[1.4] not-italic relative shrink-0 text-[10.141px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[#94a3b8]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#0f172a]">123 Capital</p>
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[13.522px] items-center min-h-px min-w-px relative">
      <Group11 />
      <Frame9 />
    </div>
  );
}

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[20.282px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.2823 20.2823">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p25aec980} id="Path" stroke="var(--stroke-0, #B0C9FE)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.26764" />
            <path d={svgPaths.p2e289460} id="Path_2" stroke="var(--stroke-0, #B0C9FE)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.26764" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame27() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pb-[13.522px] pt-[16.902px] px-[20.282px] relative w-full">
          <Frame23 />
          <ArrowsDiagramsArrow />
        </div>
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col gap-[3.38px] items-start leading-[1.4] not-italic relative shrink-0">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold overflow-hidden relative shrink-0 text-[#334155] text-[10.986px] text-ellipsis">XPTO#001</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b] text-[10.141px]">Built to Suit</p>
    </div>
  );
}

function BasicBadges1() {
  return (
    <div className="bg-[rgba(176,201,254,0.2)] col-1 content-stretch flex items-center justify-center ml-0 mt-0 px-[8.451px] py-[5.071px] relative rounded-[3.38px] row-1" data-name="Basic Badges">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[10.141px] not-italic relative shrink-0 text-[#2e61ff] text-[9.296px]">Imobiliário</p>
    </div>
  );
}

function Group15() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative row-1">
      <BasicBadges1 />
    </div>
  );
}

function Group14() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group15 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex items-start justify-between pb-[16.902px] pt-[13.522px] px-[20.282px] relative w-full">
        <Frame24 />
        <Group14 />
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="absolute bg-white h-[128.439px] left-[1082px] rounded-[10.141px] top-[32.06px] w-[228.175px]">
      <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <Frame27 />
        <div className="bg-[#f1f5f9] h-[0.845px] relative shrink-0 w-full">
          <div aria-hidden="true" className="absolute border-solid border-t-[0.845px] border-white inset-[-0.845px_0_0_0] pointer-events-none" />
        </div>
        <Frame21 />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-0.845px_0.845px_-0.423px_rgba(3,41,82,0.06)]" />
      <div aria-hidden="true" className="absolute border-[0.845px] border-[rgba(69,119,255,0.6)] border-solid inset-0 pointer-events-none rounded-[10.141px] shadow-[0px_3.38px_6.761px_-1.69px_rgba(3,41,82,0.06),0px_1.69px_3.38px_0px_rgba(3,41,82,0.04),0px_0.845px_1.69px_0px_rgba(3,41,82,0.04),0px_0px_0px_3.38px_rgba(46,97,255,0.04)]" />
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute contents left-[1082px] top-[16px]">
      <Frame17 />
      <Frame13 />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="icon">
          <path d={svgPaths.p3b733500} fill="var(--fill-0, #2E61FF)" id="Ellipse 21860" />
          <path d={svgPaths.p10ba4d00} fill="var(--fill-0, #B0C9FE)" id="Ellipse 21861" />
        </g>
      </svg>
    </div>
  );
}

function Frame30() {
  return (
    <div className="-translate-y-1/2 absolute content-stretch flex flex-col gap-[16px] items-start left-[48px] top-[calc(50%-0.5px)] w-[419px]">
      <Icon />
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] min-w-full not-italic relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px] w-[min-content] whitespace-pre-wrap" style={{ fontFeatureSettings: "\'salt\'" }}>
        {`Encontre oportunidades `}
        <br aria-hidden="true" />
        exclusivas do Mercado de Capitais
      </p>
    </div>
  );
}

function Lines() {
  return (
    <div className="absolute h-[32.932px] left-[724px] top-[111px] w-[16.466px]" data-name="lines">
      <div className="absolute inset-[-1.04%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.466 33.6179">
          <g id="lines">
            <path d={svgPaths.p3dab1480} id="line" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <path d={svgPaths.p1a3e3b00} id="line_2" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <path d={svgPaths.p27cf5500} id="line_3" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <path d={svgPaths.p1f69da80} id="line_4" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <path d={svgPaths.p3ddc1340} id="line_5" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <path d={svgPaths.p2f0742c0} id="line_6" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <path d={svgPaths.pb6d2600} id="line_7" stroke="var(--stroke-0, #D4E1FD)" strokeOpacity="0.6" strokeWidth="0.68608" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Dots() {
  return (
    <div className="h-[52px] relative w-[92px]" data-name="dots">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 92 52">
        <g id="dots">
          <circle cx="11" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21871" r="1" />
          <circle cx="21" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21876" r="1" />
          <circle cx="31" cy="1" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21879" r="1" />
          <circle cx="1" cy="11" fill="var(--fill-0, #032952)" id="Ellipse 21870" opacity="0.3" r="1" />
          <circle cx="11" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.32" id="Ellipse 21871_2" r="1" />
          <circle cx="21" cy="11" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21876_2" r="1" />
          <circle cx="21" cy="21" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21876_3" r="1" />
          <circle cx="31" cy="21" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21879_2" r="1" />
          <circle cx="71" cy="2" fill="var(--fill-0, #032952)" fillOpacity="0.32" id="Ellipse 21875" r="1" />
          <circle cx="81" cy="2" fill="var(--fill-0, #032952)" fillOpacity="0.32" id="Ellipse 21869" r="1" />
          <circle cx="91" cy="2" fill="var(--fill-0, #032952)" fillOpacity="0.32" id="Ellipse 21870_2" r="1" />
          <circle cx="31" cy="31" fill="var(--fill-0, #032952)" fillOpacity="0.32" id="Ellipse 21879_3" r="1" />
          <circle cx="81" cy="12" fill="var(--fill-0, #032952)" fillOpacity="0.32" id="Ellipse 21869_2" r="1" />
          <circle cx="31" cy="41" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21879_4" r="1" />
          <circle cx="91" cy="22" fill="var(--fill-0, #032952)" id="Ellipse 21870_3" opacity="0.3" r="1" />
          <circle cx="21" cy="51" fill="var(--fill-0, #032952)" fillOpacity="0.06" id="Ellipse 21876_4" r="1" />
        </g>
      </svg>
    </div>
  );
}

function HeaderOperations() {
  return (
    <div className="blur-[0px] h-[199px] mb-[-24px] overflow-clip relative rounded-[15px] shadow-[0px_23.867px_41.767px_-5.967px_rgba(32,49,86,0.03),0px_11.933px_17.9px_-5.967px_rgba(33,49,86,0.03),0px_5.967px_11.933px_-2.983px_rgba(32,49,86,0.03),0px_2.983px_5.967px_-1.492px_rgba(32,49,86,0.03),0px_1.492px_2.238px_0px_rgba(32,49,86,0.03),0px_0.559px_0.559px_0px_rgba(55,55,82,0.04)] shrink-0 w-[1272px] z-[2]" data-name="header_operations" style={{ backgroundImage: "linear-gradient(197.398deg, rgba(46, 97, 255, 0) 71.692%, rgba(46, 97, 255, 0.1) 136.27%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }}>
      <Bg />
      <Frame16 />
      <Frame14 />
      <Frame15 />
      <Frame11 />
      <Frame12 />
      <Group17 />
      <Frame30 />
      <Lines />
      <div className="absolute flex h-[182px] items-center justify-center left-[682px] top-0 w-[17px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-[17px] relative w-[182px]" data-name="line">
            <div className="absolute inset-[-2.02%_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 182 17.6861">
                <path d={svgPaths.p2ba598c0} id="line" stroke="url(#paint0_linear_5_14709)" strokeOpacity="0.6" strokeWidth="0.68608" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_14709" x1="-1.88854e-07" x2="182" y1="6.71804" y2="6.71804">
                    <stop stopColor="#D4E1FD" />
                    <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute h-[17px] left-0 top-[22px] w-[182px]" data-name="line">
        <div className="absolute inset-[-2.02%_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 182 17.6861">
            <path d={svgPaths.p5b00b40} id="line" stroke="url(#paint0_linear_5_14711)" strokeOpacity="0.6" strokeWidth="0.68608" />
            <defs>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_14711" x1="-1.88854e-07" x2="182" y1="6.71804" y2="6.71804">
                <stop stopColor="#D4E1FD" />
                <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute flex h-[44px] items-center justify-center left-[1046px] top-0 w-[17px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="-scale-y-100 flex-none rotate-90">
          <div className="h-[17px] relative w-[44px]" data-name="line">
            <div className="absolute inset-[-1.39%_-0.57%_-2.02%_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44.2492 17.5788">
                <path d={svgPaths.p3566a580} id="line" stroke="url(#paint0_linear_5_14648)" strokeOpacity="0.6" strokeWidth="0.68608" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_14648" x1="-1.50422e-07" x2="144.963" y1="6.61072" y2="6.61072">
                    <stop stopColor="#D4E1FD" />
                    <stop offset="1" stopColor="#D4E1FD" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[52px] items-center justify-center left-[350px] top-[42px] w-[92px]">
        <div className="flex-none rotate-180">
          <Dots />
        </div>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Todos</p>
    </div>
  );
}

function Tab() {
  return (
    <div className="content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative rounded-[8px] shrink-0" data-name="Tab">
      <Content />
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[14px]">Oferta pública</p>
    </div>
  );
}

function Tab1() {
  return (
    <div className="content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative rounded-[8px] shrink-0" data-name="Tab">
      <Content1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <path d={svgPaths.p21e79c40} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p2bbfc300} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p1f5ccf80} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p15583a00} id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p3bdcf300} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path clipRule="evenodd" d={svgPaths.p25e4c80} fillRule="evenodd" id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function SeoSearchLoapFast() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="SEO/search-loap-fast">
      <Group />
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Consulta de viabilidade</p>
    </div>
  );
}

function Tab2() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0" data-name="Tab">
      <div className="content-stretch flex gap-[8px] h-full items-center justify-center overflow-clip px-[16px] py-[10px] relative rounded-[inherit]">
        <SeoSearchLoapFast />
        <Content2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center overflow-clip p-[2px] relative rounded-[8px] shrink-0">
      <Tab />
      <Tab1 />
      <Tab2 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p396e8020} id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M19 19L15.71 15.71" id="Path_3" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialSearchLoupe() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Search, Loupe">
      <Group1 />
    </div>
  );
}

function Search() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0 w-[400px]" data-name="Search">
      <div className="content-stretch flex gap-[8px] items-center overflow-clip px-[12px] relative rounded-[inherit] size-full">
        <InterfaceEssentialSearchLoupe />
        <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#64748b] text-[14px] whitespace-pre-wrap">O que você está buscando?</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">Filtros</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[22.22%_22.22%_18.75%_22.22%]" data-name="Group">
      <div className="absolute inset-[-4.41%_-4.69%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.5833 15.4168">
          <g id="Group">
            <path d={svgPaths.p21c3e300} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
            <path d={svgPaths.p2fae5ca0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-[8.33%]" data-name="Group">
      <Group3 />
      <div className="absolute inset-[8.33%]" data-name="Rectangle" />
    </div>
  );
}

function InterfaceEssentialFilterSort() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/Filter, Sort">
      <Group2 />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-white h-[40px] relative rounded-[8px] shrink-0" data-name="Button">
      <div className="content-stretch flex gap-[4px] h-full items-center justify-center overflow-clip px-[20px] py-[8px] relative rounded-[inherit]">
        <Content3 />
        <InterfaceEssentialFilterSort />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0">
      <Search />
      <Button />
    </div>
  );
}

function Frame31() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <Frame28 />
      <Frame6 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col items-start mb-[-24px] pb-[24px] pt-[48px] px-[24px] relative rounded-bl-[16px] rounded-br-[16px] shrink-0 w-[1272px] z-[1]">
      <Frame31 />
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col isolate items-start pb-[26px] pt-[2px] px-[2px] relative rounded-[16px] shrink-0" data-name="Header">
      <HeaderOperations />
      <Frame7 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <path d={svgPaths.p1a4eab00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe92c800} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p283fc500} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p35f63600} id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pc6f000} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p1041c640} fillRule="evenodd" id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function SeoSearchLoapFast1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="SEO/search-loap-fast">
      <Group4 />
    </div>
  );
}

function Title() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="title">
      <SeoSearchLoapFast1 />
      <p className="font-['Helvetica_Now_Text:Medium',sans-serif] leading-[1.2] not-italic relative shrink-0 text-[#020617] text-[24px] tracking-[-0.12px]" style={{ fontFeatureSettings: "\'salt\'" }}>
        Consulta de viabilidade
      </p>
    </div>
  );
}

function Divider() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1276 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="1276" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Surface() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1502 11.9937">
        <g id="surface1">
          <path d={svgPaths.p36a63580} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p25ac2400} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p15945d00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute inset-[35%_22.17%_35%_21.87%] overflow-clip" data-name="Frame">
      <Surface />
    </div>
  );
}

function Avatar() {
  return (
    <div className="bg-[#001fa1] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame />
    </div>
  );
}

function HeaderText() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]" data-name="Header Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">Banco BS2</p>
    </div>
  );
}

function HeaderContent() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14px] items-center min-h-px min-w-px relative" data-name="Header Content">
      <Avatar />
      <HeaderText />
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#1726b6] text-[12px]">Petróleo</p>
    </div>
  );
}

function Badge() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content4 />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">FIDC</p>
    </div>
  );
}

function Badge1() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content5 />
    </div>
  );
}

function Tags() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Tags">
      <Badge />
      <Badge1 />
    </div>
  );
}

function Header1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <HeaderContent />
          <Tags />
        </div>
      </div>
    </div>
  );
}

function Divider1() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 409.333 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="409.333" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MainText() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[14px] text-ellipsis" data-name="Main Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold min-w-full overflow-hidden relative shrink-0 text-[#020617] w-[min-content] whitespace-nowrap">Fundo Vale Belterra Fiagro FIDC</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal overflow-hidden relative shrink-0 text-[#64748b]">Cotas de FIDC</p>
    </div>
  );
}

function MainContent() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main Content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <MainText />
        </div>
      </div>
    </div>
  );
}

function Divider2() {
  return (
    <div className="h-0 relative shrink-0 w-[377.33px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 377.33 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="377.33" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 4" rx="1.26" width="2.52" x="1.95978" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 3" rx="1.26" width="2.52" x="5.74005" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 2" rx="1.26" width="2.52" x="9.5199" y="4.19999" />
          <rect fill="var(--fill-0, #2E61FF)" height="12.6" id="Detail Icon Part 1" rx="1.26" transform="rotate(90 13.3002 10.78)" width="2.52" x="13.3002" y="10.78" />
          <path d={svgPaths.p14916c00} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="6.99983" cy="3.14999" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.05" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon1 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">R$ 12,9 milhões</p>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <path d={svgPaths.p36d02100} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p27f520f0} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem1() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon2 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">30 meses</p>
    </div>
  );
}

function DetailIcon() {
  return (
    <div className="absolute h-[11.611px] left-[0.99px] top-[1.4px] w-[12.023px]" data-name="Detail Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0233 11.6115">
        <g id="Detail Icon">
          <g id="Vector">
            <path d={svgPaths.p2ac2c0f0} fill="#B0C9FE" />
            <path d={svgPaths.p1184b7f0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <DetailIcon />
    </div>
  );
}

function DetailItem2() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon3 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">IPCA + 18.80% a.a.</p>
    </div>
  );
}

function Details() {
  return (
    <div className="relative shrink-0 w-full" data-name="Details">
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[16px] relative w-full">
        <DetailItem />
        <DetailItem1 />
        <DetailItem2 />
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Saiba mais</p>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#2e61ff] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[8px]" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[20px] py-[8px] relative size-full">
          <Content6 />
        </div>
      </div>
    </div>
  );
}

function ButtonContainer() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center pb-[16px] pt-[8px] px-[16px] relative w-full">
          <Button1 />
        </div>
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[409.333px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-px items-center overflow-clip relative rounded-[inherit] w-full">
        <Header1 />
        <Divider1 />
        <MainContent />
        <Divider2 />
        <Details />
        <ButtonContainer />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Surface1() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1502 11.9937">
        <g id="surface1">
          <path d={svgPaths.p36a63580} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p25ac2400} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p15945d00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute inset-[35%_22.17%_35%_21.87%] overflow-clip" data-name="Frame">
      <Surface1 />
    </div>
  );
}

function Avatar1() {
  return (
    <div className="bg-[#001fa1] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame1 />
    </div>
  );
}

function HeaderText1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]" data-name="Header Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">Banco BS2</p>
    </div>
  );
}

function HeaderContent1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14px] items-center min-h-px min-w-px relative" data-name="Header Content">
      <Avatar1 />
      <HeaderText1 />
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#1726b6] text-[12px]">Petróleo</p>
    </div>
  );
}

function Badge2() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content7 />
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">FIDC</p>
    </div>
  );
}

function Badge3() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content8 />
    </div>
  );
}

function Tags1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Tags">
      <Badge2 />
      <Badge3 />
    </div>
  );
}

function Header2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <HeaderContent1 />
          <Tags1 />
        </div>
      </div>
    </div>
  );
}

function Divider3() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 409.333 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="409.333" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MainText1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[14px] text-ellipsis" data-name="Main Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold min-w-full overflow-hidden relative shrink-0 text-[#020617] w-[min-content] whitespace-nowrap">Fundo Vale Belterra Fiagro FIDC</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal overflow-hidden relative shrink-0 text-[#64748b]">Cotas de FIDC</p>
    </div>
  );
}

function MainContent1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main Content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <MainText1 />
        </div>
      </div>
    </div>
  );
}

function Divider4() {
  return (
    <div className="h-0 relative shrink-0 w-[377.33px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 377.33 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="377.33" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 4" rx="1.26" width="2.52" x="1.95978" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 3" rx="1.26" width="2.52" x="5.74005" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 2" rx="1.26" width="2.52" x="9.5199" y="4.19999" />
          <rect fill="var(--fill-0, #2E61FF)" height="12.6" id="Detail Icon Part 1" rx="1.26" transform="rotate(90 13.3002 10.78)" width="2.52" x="13.3002" y="10.78" />
          <path d={svgPaths.p14916c00} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="6.99983" cy="3.14999" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.05" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem3() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon4 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">R$ 12,9 milhões</p>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <path d={svgPaths.p36d02100} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p27f520f0} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem4() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon5 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">30 meses</p>
    </div>
  );
}

function DetailIcon1() {
  return (
    <div className="absolute h-[11.611px] left-[0.99px] top-[1.4px] w-[12.023px]" data-name="Detail Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0233 11.6115">
        <g id="Detail Icon">
          <g id="Vector">
            <path d={svgPaths.p2ac2c0f0} fill="#B0C9FE" />
            <path d={svgPaths.p1184b7f0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <DetailIcon1 />
    </div>
  );
}

function DetailItem5() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon6 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">IPCA + 18.80% a.a.</p>
    </div>
  );
}

function Details1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Details">
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[16px] relative w-full">
        <DetailItem3 />
        <DetailItem4 />
        <DetailItem5 />
      </div>
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Saiba mais</p>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#2e61ff] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[8px]" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[20px] py-[8px] relative size-full">
          <Content9 />
        </div>
      </div>
    </div>
  );
}

function ButtonContainer1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center pb-[16px] pt-[8px] px-[16px] relative w-full">
          <Button2 />
        </div>
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[409.333px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-px items-center overflow-clip relative rounded-[inherit] w-full">
        <Header2 />
        <Divider3 />
        <MainContent1 />
        <Divider4 />
        <Details1 />
        <ButtonContainer1 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Surface2() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1502 11.9937">
        <g id="surface1">
          <path d={svgPaths.p36a63580} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p25ac2400} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p15945d00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute inset-[35%_22.17%_35%_21.87%] overflow-clip" data-name="Frame">
      <Surface2 />
    </div>
  );
}

function Avatar2() {
  return (
    <div className="bg-[#001fa1] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame2 />
    </div>
  );
}

function HeaderText2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]" data-name="Header Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">Banco BS2</p>
    </div>
  );
}

function HeaderContent2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14px] items-center min-h-px min-w-px relative" data-name="Header Content">
      <Avatar2 />
      <HeaderText2 />
    </div>
  );
}

function Content10() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#1726b6] text-[12px]">Petróleo</p>
    </div>
  );
}

function Badge4() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content10 />
    </div>
  );
}

function Content11() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">FIDC</p>
    </div>
  );
}

function Badge5() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content11 />
    </div>
  );
}

function Tags2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Tags">
      <Badge4 />
      <Badge5 />
    </div>
  );
}

function Header3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <HeaderContent2 />
          <Tags2 />
        </div>
      </div>
    </div>
  );
}

function Divider5() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 409.333 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="409.333" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MainText2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[14px] text-ellipsis" data-name="Main Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold min-w-full overflow-hidden relative shrink-0 text-[#020617] w-[min-content] whitespace-nowrap">Fundo Vale Belterra Fiagro FIDC</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal overflow-hidden relative shrink-0 text-[#64748b]">Cotas de FIDC</p>
    </div>
  );
}

function MainContent2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main Content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <MainText2 />
        </div>
      </div>
    </div>
  );
}

function Divider6() {
  return (
    <div className="h-0 relative shrink-0 w-[377.33px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 377.33 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="377.33" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 4" rx="1.26" width="2.52" x="1.95978" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 3" rx="1.26" width="2.52" x="5.74005" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 2" rx="1.26" width="2.52" x="9.5199" y="4.19999" />
          <rect fill="var(--fill-0, #2E61FF)" height="12.6" id="Detail Icon Part 1" rx="1.26" transform="rotate(90 13.3002 10.78)" width="2.52" x="13.3002" y="10.78" />
          <path d={svgPaths.p14916c00} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="6.99983" cy="3.14999" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.05" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem6() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon7 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">R$ 12,9 milhões</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <path d={svgPaths.p36d02100} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p27f520f0} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem7() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon8 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">30 meses</p>
    </div>
  );
}

function DetailIcon2() {
  return (
    <div className="absolute h-[11.611px] left-[0.99px] top-[1.4px] w-[12.023px]" data-name="Detail Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0233 11.6115">
        <g id="Detail Icon">
          <g id="Vector">
            <path d={svgPaths.p2ac2c0f0} fill="#B0C9FE" />
            <path d={svgPaths.p1184b7f0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <DetailIcon2 />
    </div>
  );
}

function DetailItem8() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon9 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">IPCA + 18.80% a.a.</p>
    </div>
  );
}

function Details2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Details">
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[16px] relative w-full">
        <DetailItem6 />
        <DetailItem7 />
        <DetailItem8 />
      </div>
    </div>
  );
}

function Content12() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Saiba mais</p>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#2e61ff] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[8px]" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[20px] py-[8px] relative size-full">
          <Content12 />
        </div>
      </div>
    </div>
  );
}

function ButtonContainer2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center pb-[16px] pt-[8px] px-[16px] relative w-full">
          <Button3 />
        </div>
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[409.333px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-px items-center overflow-clip relative rounded-[inherit] w-full">
        <Header3 />
        <Divider5 />
        <MainContent2 />
        <Divider6 />
        <Details2 />
        <ButtonContainer2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Row() {
  return (
    <div className="content-stretch flex gap-[24px] items-start overflow-clip relative shrink-0 w-full" data-name="Row">
      <Card />
      <Card1 />
      <Card2 />
    </div>
  );
}

function Surface3() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1502 11.9937">
        <g id="surface1">
          <path d={svgPaths.p36a63580} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p25ac2400} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p15945d00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute inset-[35%_22.17%_35%_21.87%] overflow-clip" data-name="Frame">
      <Surface3 />
    </div>
  );
}

function Avatar3() {
  return (
    <div className="bg-[#001fa1] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame3 />
    </div>
  );
}

function HeaderText3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]" data-name="Header Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">Banco BS2</p>
    </div>
  );
}

function HeaderContent3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14px] items-center min-h-px min-w-px relative" data-name="Header Content">
      <Avatar3 />
      <HeaderText3 />
    </div>
  );
}

function Content13() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#1726b6] text-[12px]">Petróleo</p>
    </div>
  );
}

function Badge6() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content13 />
    </div>
  );
}

function Content14() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">FIDC</p>
    </div>
  );
}

function Badge7() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content14 />
    </div>
  );
}

function Tags3() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Tags">
      <Badge6 />
      <Badge7 />
    </div>
  );
}

function Header4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <HeaderContent3 />
          <Tags3 />
        </div>
      </div>
    </div>
  );
}

function Divider7() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 409.333 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="409.333" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MainText3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[14px] text-ellipsis" data-name="Main Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold min-w-full overflow-hidden relative shrink-0 text-[#020617] w-[min-content] whitespace-nowrap">Fundo Vale Belterra Fiagro FIDC</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal overflow-hidden relative shrink-0 text-[#64748b]">Cotas de FIDC</p>
    </div>
  );
}

function MainContent3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main Content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <MainText3 />
        </div>
      </div>
    </div>
  );
}

function Divider8() {
  return (
    <div className="h-0 relative shrink-0 w-[377.33px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 377.33 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="377.33" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 4" rx="1.26" width="2.52" x="1.95978" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 3" rx="1.26" width="2.52" x="5.74005" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 2" rx="1.26" width="2.52" x="9.5199" y="4.19999" />
          <rect fill="var(--fill-0, #2E61FF)" height="12.6" id="Detail Icon Part 1" rx="1.26" transform="rotate(90 13.3002 10.78)" width="2.52" x="13.3002" y="10.78" />
          <path d={svgPaths.p14916c00} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="6.99983" cy="3.14999" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.05" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem9() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon10 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">R$ 12,9 milhões</p>
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <path d={svgPaths.p36d02100} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p27f520f0} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem10() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon11 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">30 meses</p>
    </div>
  );
}

function DetailIcon3() {
  return (
    <div className="absolute h-[11.611px] left-[0.99px] top-[1.4px] w-[12.023px]" data-name="Detail Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0233 11.6115">
        <g id="Detail Icon">
          <g id="Vector">
            <path d={svgPaths.p2ac2c0f0} fill="#B0C9FE" />
            <path d={svgPaths.p1184b7f0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <DetailIcon3 />
    </div>
  );
}

function DetailItem11() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon12 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">IPCA + 18.80% a.a.</p>
    </div>
  );
}

function Details3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Details">
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[16px] relative w-full">
        <DetailItem9 />
        <DetailItem10 />
        <DetailItem11 />
      </div>
    </div>
  );
}

function Content15() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Saiba mais</p>
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[#2e61ff] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[8px]" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[20px] py-[8px] relative size-full">
          <Content15 />
        </div>
      </div>
    </div>
  );
}

function ButtonContainer3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center pb-[16px] pt-[8px] px-[16px] relative w-full">
          <Button4 />
        </div>
      </div>
    </div>
  );
}

function Card3() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[409.333px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-px items-center overflow-clip relative rounded-[inherit] w-full">
        <Header4 />
        <Divider7 />
        <MainContent3 />
        <Divider8 />
        <Details3 />
        <ButtonContainer3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Surface4() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1502 11.9937">
        <g id="surface1">
          <path d={svgPaths.p36a63580} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p25ac2400} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p15945d00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame4() {
  return (
    <div className="absolute inset-[35%_22.17%_35%_21.87%] overflow-clip" data-name="Frame">
      <Surface4 />
    </div>
  );
}

function Avatar4() {
  return (
    <div className="bg-[#001fa1] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame4 />
    </div>
  );
}

function HeaderText4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]" data-name="Header Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">Banco BS2</p>
    </div>
  );
}

function HeaderContent4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14px] items-center min-h-px min-w-px relative" data-name="Header Content">
      <Avatar4 />
      <HeaderText4 />
    </div>
  );
}

function Content16() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#1726b6] text-[12px]">Petróleo</p>
    </div>
  );
}

function Badge8() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content16 />
    </div>
  );
}

function Content17() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">FIDC</p>
    </div>
  );
}

function Badge9() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content17 />
    </div>
  );
}

function Tags4() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Tags">
      <Badge8 />
      <Badge9 />
    </div>
  );
}

function Header5() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <HeaderContent4 />
          <Tags4 />
        </div>
      </div>
    </div>
  );
}

function Divider9() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 409.333 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="409.333" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MainText4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[14px] text-ellipsis" data-name="Main Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold min-w-full overflow-hidden relative shrink-0 text-[#020617] w-[min-content] whitespace-nowrap">Fundo Vale Belterra Fiagro FIDC</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal overflow-hidden relative shrink-0 text-[#64748b]">Cotas de FIDC</p>
    </div>
  );
}

function MainContent4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main Content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <MainText4 />
        </div>
      </div>
    </div>
  );
}

function Divider10() {
  return (
    <div className="h-0 relative shrink-0 w-[377.33px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 377.33 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="377.33" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 4" rx="1.26" width="2.52" x="1.95978" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 3" rx="1.26" width="2.52" x="5.74005" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 2" rx="1.26" width="2.52" x="9.5199" y="4.19999" />
          <rect fill="var(--fill-0, #2E61FF)" height="12.6" id="Detail Icon Part 1" rx="1.26" transform="rotate(90 13.3002 10.78)" width="2.52" x="13.3002" y="10.78" />
          <path d={svgPaths.p14916c00} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="6.99983" cy="3.14999" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.05" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem12() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon13 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">R$ 12,9 milhões</p>
    </div>
  );
}

function Icon14() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <path d={svgPaths.p36d02100} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p27f520f0} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem13() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon14 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">30 meses</p>
    </div>
  );
}

function DetailIcon4() {
  return (
    <div className="absolute h-[11.611px] left-[0.99px] top-[1.4px] w-[12.023px]" data-name="Detail Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0233 11.6115">
        <g id="Detail Icon">
          <g id="Vector">
            <path d={svgPaths.p2ac2c0f0} fill="#B0C9FE" />
            <path d={svgPaths.p1184b7f0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon15() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <DetailIcon4 />
    </div>
  );
}

function DetailItem14() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon15 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">IPCA + 18.80% a.a.</p>
    </div>
  );
}

function Details4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Details">
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[16px] relative w-full">
        <DetailItem12 />
        <DetailItem13 />
        <DetailItem14 />
      </div>
    </div>
  );
}

function Content18() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Saiba mais</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-[#2e61ff] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[8px]" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[20px] py-[8px] relative size-full">
          <Content18 />
        </div>
      </div>
    </div>
  );
}

function ButtonContainer4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center pb-[16px] pt-[8px] px-[16px] relative w-full">
          <Button5 />
        </div>
      </div>
    </div>
  );
}

function Card4() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[409.333px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-px items-center overflow-clip relative rounded-[inherit] w-full">
        <Header5 />
        <Divider9 />
        <MainContent4 />
        <Divider10 />
        <Details4 />
        <ButtonContainer4 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Surface5() {
  return (
    <div className="absolute inset-[0_0.53%_0.05%_0.52%]" data-name="surface1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1502 11.9937">
        <g id="surface1">
          <path d={svgPaths.p36a63580} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p25ac2400} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p15945d00} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute inset-[35%_22.17%_35%_21.87%] overflow-clip" data-name="Frame">
      <Surface5 />
    </div>
  );
}

function Avatar5() {
  return (
    <div className="bg-[#001fa1] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Frame5 />
    </div>
  );
}

function HeaderText5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center leading-[1.4] min-h-px min-w-px not-italic relative text-[14px]" data-name="Header Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[#64748b]">Sell Side</p>
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#020617]">Banco BS2</p>
    </div>
  );
}

function HeaderContent5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[14px] items-center min-h-px min-w-px relative" data-name="Header Content">
      <Avatar5 />
      <HeaderText5 />
    </div>
  );
}

function Content19() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#1726b6] text-[12px]">Petróleo</p>
    </div>
  );
}

function Badge10() {
  return (
    <div className="bg-[#eef4ff] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content19 />
    </div>
  );
}

function Content20() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#006045] text-[12px]">FIDC</p>
    </div>
  );
}

function Badge11() {
  return (
    <div className="bg-[#d0fae5] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content20 />
    </div>
  );
}

function Tags5() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Tags">
      <Badge10 />
      <Badge11 />
    </div>
  );
}

function Header6() {
  return (
    <div className="relative shrink-0 w-full" data-name="Header">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <HeaderContent5 />
          <Tags5 />
        </div>
      </div>
    </div>
  );
}

function Divider11() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 409.333 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="409.333" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MainText5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start leading-[1.4] min-h-px min-w-px not-italic relative text-[14px] text-ellipsis" data-name="Main Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold min-w-full overflow-hidden relative shrink-0 text-[#020617] w-[min-content] whitespace-nowrap">Fundo Vale Belterra Fiagro FIDC</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal overflow-hidden relative shrink-0 text-[#64748b]">Cotas de FIDC</p>
    </div>
  );
}

function MainContent5() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main Content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between p-[16px] relative w-full">
          <MainText5 />
        </div>
      </div>
    </div>
  );
}

function Divider12() {
  return (
    <div className="h-0 relative shrink-0 w-[377.33px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 377.33 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #E2E8F0)" x2="377.33" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon16() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 4" rx="1.26" width="2.52" x="1.95978" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 3" rx="1.26" width="2.52" x="5.74005" y="4.19999" />
          <rect fill="var(--fill-0, #B0C9FE)" height="7.84" id="Detail Icon Part 2" rx="1.26" width="2.52" x="9.5199" y="4.19999" />
          <rect fill="var(--fill-0, #2E61FF)" height="12.6" id="Detail Icon Part 1" rx="1.26" transform="rotate(90 13.3002 10.78)" width="2.52" x="13.3002" y="10.78" />
          <path d={svgPaths.p14916c00} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="6.99983" cy="3.14999" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.05" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem15() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon16 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">R$ 12,9 milhões</p>
    </div>
  );
}

function Icon17() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="icon">
          <path d={svgPaths.p36d02100} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p27f520f0} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function DetailItem16() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon17 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">30 meses</p>
    </div>
  );
}

function DetailIcon5() {
  return (
    <div className="absolute h-[11.611px] left-[0.99px] top-[1.4px] w-[12.023px]" data-name="Detail Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0233 11.6115">
        <g id="Detail Icon">
          <g id="Vector">
            <path d={svgPaths.p2ac2c0f0} fill="#B0C9FE" />
            <path d={svgPaths.p1184b7f0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon18() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="icon">
      <DetailIcon5 />
    </div>
  );
}

function DetailItem17() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-[377.333px]" data-name="Detail Item">
      <Icon18 />
      <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-h-px min-w-px not-italic relative text-[#475569] text-[14px] whitespace-pre-wrap">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[14px]">IPCA + 18.80% a.a.</p>
    </div>
  );
}

function Details5() {
  return (
    <div className="relative shrink-0 w-full" data-name="Details">
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[16px] relative w-full">
        <DetailItem15 />
        <DetailItem16 />
        <DetailItem17 />
      </div>
    </div>
  );
}

function Content21() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Saiba mais</p>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-[#2e61ff] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[8px]" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[20px] py-[8px] relative size-full">
          <Content21 />
        </div>
      </div>
    </div>
  );
}

function ButtonContainer5() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center pb-[16px] pt-[8px] px-[16px] relative w-full">
          <Button6 />
        </div>
      </div>
    </div>
  );
}

function Card5() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[409.333px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-px items-center overflow-clip relative rounded-[inherit] w-full">
        <Header6 />
        <Divider11 />
        <MainContent5 />
        <Divider12 />
        <Details5 />
        <ButtonContainer5 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Row1() {
  return (
    <div className="content-stretch flex gap-[24px] items-start overflow-clip relative shrink-0 w-full" data-name="Row">
      <Card3 />
      <Card4 />
      <Card5 />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Container">
      <Row />
      <Row1 />
    </div>
  );
}

function WorkArea() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[32px] items-start left-[100px] overflow-clip px-[32px] py-[24px] top-[78px] w-[1340px]" data-name="Work Area">
      <Header />
      <Title />
      <Divider />
      <Container />
    </div>
  );
}

function Component1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Component 11">
      <div className="absolute inset-[-29.17%_-47.06%_-147.06%_-47.06%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
          <g id="Component 11">
            <circle cx="23.2941" cy="19" id="Ellipse 516" opacity="0.1" r="14.5" stroke="url(#paint0_linear_1_5947)" />
            <g filter="url(#filter0_dddddddi_1_5947)" id="Ellipse 515">
              <circle cx="23.2941" cy="19" fill="var(--fill-0, #2E61FF)" r="11.2941" />
              <circle cx="23.2941" cy="19" fill="url(#paint1_linear_1_5947)" fillOpacity="0.1" r="11.2941" />
            </g>
            <g id="Frame 427321015">
              <circle cx="18.8312" cy="1.9707" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1434" opacity="0.3" r="0.75" />
              <circle cx="10.0441" cy="3.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1435" r="0.75" />
              <circle cx="33.0441" cy="4.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1446" r="0.75" />
              <circle cx="40.0441" cy="9.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1451" opacity="0.3" r="0.75" />
              <circle cx="9.04412" cy="10.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1449" opacity="0.3" r="0.75" />
            </g>
            <g id="IA">
              <path d={svgPaths.p1063c100} fill="var(--fill-0, white)" />
              <path d={svgPaths.p17307780} fill="var(--fill-0, white)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" id="filter0_dddddddi_1_5947" width="46.5882" x="2.98023e-07" y="6.70588">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="12" result="effect1_dropShadow_1_5947" />
              <feOffset dy="24" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="6" result="effect2_dropShadow_1_5947" />
              <feOffset dy="12" />
              <feGaussianBlur stdDeviation="6" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_5947" mode="normal" result="effect2_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="3" result="effect3_dropShadow_1_5947" />
              <feOffset dy="6" />
              <feGaussianBlur stdDeviation="3" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect2_dropShadow_1_5947" mode="normal" result="effect3_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.5" result="effect4_dropShadow_1_5947" />
              <feOffset dy="3" />
              <feGaussianBlur stdDeviation="1.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.02 0" />
              <feBlend in2="effect3_dropShadow_1_5947" mode="normal" result="effect4_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.5" result="effect5_dropShadow_1_5947" />
              <feOffset dy="1" />
              <feGaussianBlur stdDeviation="0.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect4_dropShadow_1_5947" mode="normal" result="effect5_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect6_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect5_dropShadow_1_5947" mode="normal" result="effect6_dropShadow_1_5947" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect7_dropShadow_1_5947" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0" />
              <feBlend in2="effect6_dropShadow_1_5947" mode="normal" result="effect7_dropShadow_1_5947" />
              <feBlend in="SourceGraphic" in2="effect7_dropShadow_1_5947" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="shape" mode="normal" result="effect8_innerShadow_1_5947" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_5947" x1="23.2941" x2="23.2941" y1="4" y2="34">
              <stop stopColor="#2E61FF" stopOpacity="0" />
              <stop offset="1" stopColor="#2E61FF" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_5947" x1="23.2941" x2="23.2941" y1="30.2941" y2="7.70588">
              <stop stopColor="white" stopOpacity="0" />
              <stop offset="1" stopColor="white" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Component1 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p39ce2c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.5 21H13.5" id="Path_3" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MusicAudioBellNotifications() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Music, Audio/Bell, Notifications">
      <Group5 />
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <MusicAudioBellNotifications />
    </div>
  );
}

function CircleRedSolid() {
  return (
    <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]" data-name="circle-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#fb2c36] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="container">
      <Button7 />
      <Button8 />
      <CircleRedSolid />
    </div>
  );
}

function Logotype() {
  return (
    <div className="absolute inset-[42.65%_22.8%_42.65%_22.5%]" data-name="logotype">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.8804 5.87683">
        <g id="logotype">
          <path d={svgPaths.p1fa77d80} fill="var(--fill-0, white)" id="Vector" />
          <g id="Group">
            <path d={svgPaths.pe40ba00} fill="var(--fill-0, white)" id="Vector_2" />
            <path d={svgPaths.p1b629600} fill="var(--fill-0, white)" id="Vector_3" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Person() {
  return (
    <div className="absolute bg-[#e2e8f0] bottom-0 right-0 rounded-[9999px] size-[16px]" data-name="person">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="absolute h-[64px] left-[-12px] top-[-6px] w-[35px]" data-name="image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
        </div>
        <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-gradient-to-b from-[86.008%] from-[rgba(42,56,73,0)] left-1/2 rounded-[9999px] size-[16px] to-[rgba(42,56,73,0.3)] top-1/2" data-name="filter" />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-[-1px] pointer-events-none rounded-[10000px]" />
    </div>
  );
}

function Avatar6() {
  return (
    <div className="bg-[#2e61ff] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Logotype />
      <Person />
    </div>
  );
}

function Content22() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#020617] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Bloxs Capital Partners LTDA</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#64748b] text-[12px]">41.847.533/0001-90</p>
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0" data-name="container">
      <Avatar6 />
      <Content22 />
      <ArrowsDiagramsArrow1 />
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
      <Container1 />
      <div className="bg-[#e2e8f0] h-[24px] rounded-[9999px] shrink-0 w-[2px]" data-name="divider" />
      <Container2 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="absolute h-[80px] left-[100px] top-0 w-[1340px]" data-name="Navbar">
      <div className="content-stretch flex items-center justify-between overflow-clip px-[32px] py-[16px] relative rounded-[inherit] size-full">
        <Frame29 />
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Camada() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0002 24">
        <g id="Camada_1-2">
          <path d={svgPaths.p8744780} fill="var(--fill-0, #020617)" id="Vector" />
          <path d={svgPaths.p2e0a3600} fill="var(--fill-0, #2E61FF)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute content-stretch flex flex-col h-[80px] items-center justify-center left-0 px-[24px] py-[16px] top-0 w-[100px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-b border-solid inset-0 pointer-events-none" />
      <Camada />
    </div>
  );
}

function InterfaceEssentialHomeClassic() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/home-classic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Rectangle" />
          <path clipRule="evenodd" d={svgPaths.pf024880} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p32312200} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <InterfaceEssentialHomeClassic />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Home</p>
    </div>
  );
}

function SeoSearchGraph() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="SEO/Search, Graph">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d="M16 12.157V9H12.843" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p1ecf540} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M19 5L20 4" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M20 8H21" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M16 4V3" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p3b77e00} id="Path_6" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
          </g>
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <SeoSearchGraph />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#020617] text-[12px] text-center">Operações</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p1b647048} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p29968a80} fillRule="evenodd" id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p129ae5c0} id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p7859880} id="Path_5" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MoneyWalletMoney() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Money/Wallet, Money">
      <Group6 />
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <MoneyWalletMoney />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Carteira</p>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.p30859780} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p18659d80} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p189b6c00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p2ceff7c0} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function TechnologySpaceSpaceRocket() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Technology, Space/space-rocket">
      <Group7 />
    </div>
  );
}

function Button13() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <TechnologySpaceSpaceRocket />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Soluções</p>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-4.17%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.4993 19.4993">
          <g id="Group">
            <path clipRule="evenodd" d={svgPaths.p2d1c8c80} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ConstructionToolsToolsWench() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Construction, Tools/tools-wench">
      <Group8 />
    </div>
  );
}

function Button14() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <ConstructionToolsToolsWench />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Tools</p>
    </div>
  );
}

function UserUsers() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="User/Users">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d={svgPaths.p2c68bbc0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="9" cy="7" id="Oval" r="4" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe930c00} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p8cf1c80} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function Button15() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <UserUsers />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Comunidade</p>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <circle cx="12.005" cy="12.005" id="Oval" r="9.00375" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2756080} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22612800} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p116d3c00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialQuestionCircle() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/question-circle">
      <Group9 />
    </div>
  );
}

function Button16() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-[84px]" data-name="Button">
      <InterfaceEssentialQuestionCircle />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#475569] text-[12px] text-center">Ajuda</p>
    </div>
  );
}

function Main() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[14px] items-start left-[8px] top-[96px] w-[84px]" data-name="main">
      <Button10 />
      <Button11 />
      <Button12 />
      <Button13 />
      <Button14 />
      <Button15 />
      <Button16 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="bg-white border-[#e2e8f0] border-r border-solid h-[1252px] overflow-clip pointer-events-auto sticky top-0 w-[100px]" data-name="Sidebar">
      <Button9 />
      <div className="absolute bg-[#2e61ff] h-[75px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[185px] w-[3px]" data-name="state" />
      <Main />
    </div>
  );
}

export default function Component5OperacoesConsultaDeViabilidadeLightMode() {
  return (
    <div className="bg-white overflow-clip relative rounded-[24px] size-full" data-name="5. Operações | Consulta de Viabilidade [Light Mode]">
      <WorkArea />
      <Navbar />
      <div className="absolute bottom-0 h-[1252px] left-0 pointer-events-none top-0">
        <Sidebar />
      </div>
    </div>
  );
}