import svgPaths from "./svg-ldfhlqohb2";
import imgEllipse1 from "figma:asset/5c991cba745f224aa2af8779a0d799048a4c3559.png";
import imgEllipse7 from "figma:asset/076dd2cc2f1522a0beb35373c1bc6963f82e8c32.png";
import imgImage1 from "figma:asset/6168d4c37b79a510ce2db4649dcfdc3fff4de4db.png";
import imgRectangle4539 from "figma:asset/0759735ede8c602eb18a588297c76ab07db99d8a.png";

function Frame19() {
  return (
    <div className="content-stretch flex items-start px-[32px] relative shrink-0">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Configurações</p>
      </div>
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Dados da empresa</p>
      </div>
    </div>
  );
}

function Frame21() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col items-start px-[32px] py-[16px] relative w-full">
        <Frame16 />
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Membros</p>
      </div>
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[32px] pr-[16px] py-[16px] relative shrink-0 w-[300px]">
      <Frame17 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="bg-[#313131] content-stretch flex flex-col items-start relative shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#3482ff] border-l-3 border-solid inset-0 pointer-events-none" />
      <Frame20 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Dealmatch</p>
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col items-start px-[32px] py-[16px] relative w-full">
        <Frame18 />
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame21 />
      <Frame23 />
      <Frame24 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="absolute bg-[#292929] left-[144px] rounded-[8px] top-[460px] w-[300px]">
      <div className="content-stretch flex flex-col gap-[24px] items-start overflow-clip py-[24px] relative rounded-[inherit] w-full">
        <Frame19 />
        <div className="h-0 relative shrink-0 w-full">
          <div className="absolute inset-[-1px_0_0_0]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 300 1">
              <line id="Line 72" stroke="var(--stroke-0, #515151)" x2="300" y1="0.5" y2="0.5" />
            </svg>
          </div>
        </div>
        <Frame22 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-white w-full whitespace-pre-wrap">Membros do Workspace</p>
    </div>
  );
}

function General() {
  return (
    <div className="absolute inset-[7.97%_8.24%_8.29%_8.55%]" data-name="general">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6494 11.7232">
        <g id="general">
          <path d={svgPaths.p15ca4080} fill="var(--fill-0, #818181)" id="magnifier" />
        </g>
      </svg>
    </div>
  );
}

function Magnifier() {
  return (
    <div className="absolute left-0 overflow-clip size-[14px] top-0" data-name="magnifier">
      <General />
    </div>
  );
}

function Text() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0 w-[148px]" data-name="Text">
      <Magnifier />
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] min-w-full not-italic relative shrink-0 text-[#818181] text-[12px] w-[min-content] whitespace-pre-wrap">Buscar membros</p>
    </div>
  );
}

function InputText() {
  return (
    <div className="content-stretch flex h-[40px] items-center px-[16px] relative rounded-[6px] shrink-0" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#818181] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <Text />
    </div>
  );
}

function Arrows() {
  return (
    <div className="absolute inset-[20.83%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.33333 9.33333">
        <g id="arrows">
          <path d={svgPaths.pd1e3e80} fill="var(--fill-0, #212121)" id="plus" />
        </g>
      </svg>
    </div>
  );
}

function Plus() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="plus">
      <Arrows />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#3482ff] content-stretch flex gap-[16px] items-center justify-center px-[16px] py-[12px] relative rounded-[8px] shrink-0" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[14px] text-white">Adicionar membros</p>
      <Plus />
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex gap-[16px] items-center justify-end relative shrink-0">
      <InputText />
      <Button />
    </div>
  );
}

function Frame1() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Frame3 />
          <Frame27 />
        </div>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Membro</p>
      </div>
    </div>
  );
}

function IconOrderArrowDown() {
  return (
    <div className="absolute left-[5px] size-[10px] top-[6px]" data-name="Icon / order arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon / order arrow down">
          <path d={svgPaths.p173b1400} fill="var(--fill-0, white)" id="order-arrow-down" />
        </g>
      </svg>
    </div>
  );
}

function IconOrderArrowUp() {
  return (
    <div className="absolute left-px size-[10px] top-0" data-name="Icon / order arrow up">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon / order arrow up">
          <path d={svgPaths.p2e697a70} fill="var(--fill-0, white)" id="order-arrow-up" />
        </g>
      </svg>
    </div>
  );
}

function IconRight() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon Right">
      <IconOrderArrowDown />
      <IconOrderArrowUp />
    </div>
  );
}

function CellRowCell() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Text1 />
          <IconRight />
        </div>
      </div>
    </div>
  );
}

function Cell() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-[48px] items-center min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell />
    </div>
  );
}

function Text2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Permissão</p>
      </div>
    </div>
  );
}

function IconOrderArrowDown1() {
  return (
    <div className="absolute left-[5px] size-[10px] top-[6px]" data-name="Icon / order arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon / order arrow down">
          <path d={svgPaths.p173b1400} fill="var(--fill-0, white)" id="order-arrow-down" />
        </g>
      </svg>
    </div>
  );
}

function IconOrderArrowUp1() {
  return (
    <div className="absolute left-px size-[10px] top-0" data-name="Icon / order arrow up">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon / order arrow up">
          <path d={svgPaths.p2e697a70} fill="var(--fill-0, white)" id="order-arrow-up" />
        </g>
      </svg>
    </div>
  );
}

function IconRight1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon Right">
      <IconOrderArrowDown1 />
      <IconOrderArrowUp1 />
    </div>
  );
}

function CellRowCell1() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Text2 />
          <IconRight1 />
        </div>
      </div>
    </div>
  );
}

function Cell1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-[48px] items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell1 />
    </div>
  );
}

function Text3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Status</p>
      </div>
    </div>
  );
}

function IconOrderArrowDown2() {
  return (
    <div className="absolute left-[5px] size-[10px] top-[6px]" data-name="Icon / order arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon / order arrow down">
          <path d={svgPaths.p173b1400} fill="var(--fill-0, white)" id="order-arrow-down" />
        </g>
      </svg>
    </div>
  );
}

function IconOrderArrowUp2() {
  return (
    <div className="absolute left-px size-[10px] top-0" data-name="Icon / order arrow up">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon / order arrow up">
          <path d={svgPaths.p2e697a70} fill="var(--fill-0, white)" id="order-arrow-up" />
        </g>
      </svg>
    </div>
  );
}

function IconRight2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon Right">
      <IconOrderArrowDown2 />
      <IconOrderArrowUp2 />
    </div>
  );
}

function CellRowCell2() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Text3 />
          <IconRight2 />
        </div>
      </div>
    </div>
  );
}

function Cell2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-[48px] items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell2 />
    </div>
  );
}

function Text4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Último acesso</p>
      </div>
    </div>
  );
}

function CellRowCell3() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text4 />
        </div>
      </div>
    </div>
  );
}

function Cell3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-[48px] items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell3 />
    </div>
  );
}

function CellRowCell4() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[12px] size-full" />
      </div>
    </div>
  );
}

function Cell4() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 size-[48px]" data-name="Cell">
      <CellRowCell4 />
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#292929] relative shrink-0 w-full" data-name="Header">
      <div className="content-stretch flex items-center overflow-clip relative rounded-[inherit] w-full">
        <Cell />
        <Cell1 />
        <Cell2 />
        <Cell3 />
        <Cell4 />
      </div>
      <div aria-hidden="true" className="absolute border-[#434343] border-b border-solid border-t inset-0 pointer-events-none" />
    </div>
  );
}

function Text5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Lucas Ayres</p>
      </div>
    </div>
  );
}

function RowCell() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <div className="relative shrink-0 size-[24px]">
            <img alt="" className="block max-w-none size-full" height="24" src={imgEllipse1} width="24" />
          </div>
          <Text5 />
        </div>
      </div>
    </div>
  );
}

function Cell5() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell />
    </div>
  );
}

function Text6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Dono</p>
      </div>
    </div>
  );
}

function CellRowCell5() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text6 />
        </div>
      </div>
    </div>
  );
}

function Cell6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell5 />
    </div>
  );
}

function Status() {
  return (
    <div className="bg-[#242320] content-stretch flex gap-[6px] h-[28px] items-center justify-center px-[8px] py-[4px] relative rounded-[30px] shrink-0" data-name="Status">
      <div aria-hidden="true" className="absolute border border-[rgba(197,154,0,0.2)] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <div className="bg-[#d9aa00] rounded-[20px] shrink-0 size-[6px]" />
      <p className="font-['Poppins:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#d9aa00] text-[12px]">Status</p>
    </div>
  );
}

function RowCell1() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Status />
        </div>
      </div>
    </div>
  );
}

function Cell7() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell1 />
    </div>
  );
}

function Text7() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Há 2 semanas</p>
      </div>
    </div>
  );
}

function CellRowCell6() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text7 />
        </div>
      </div>
    </div>
  );
}

function Cell8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell6 />
    </div>
  );
}

function FilesFolders() {
  return (
    <div className="absolute inset-[5.08%_5.17%_5.21%_5.17%]" data-name="files-folders">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9333 17.9418">
        <g id="files-folders">
          <path d={svgPaths.p3b713a80} fill="var(--fill-0, white)" id="notepad-edit" />
        </g>
      </svg>
    </div>
  );
}

function IconLeft() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon Left">
      <FilesFolders />
    </div>
  );
}

function CellRowCell7() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[12px] relative size-full">
          <IconLeft />
        </div>
      </div>
    </div>
  );
}

function Cell9() {
  return (
    <div className="content-stretch flex h-[64px] items-start relative shrink-0 w-[48px]" data-name="Cell">
      <CellRowCell7 />
    </div>
  );
}

function RowMainRecomponentizeDuplicate() {
  return (
    <div className="bg-[#212121] content-stretch flex h-[64px] items-start overflow-clip relative shrink-0 w-full" data-name="Row / Main (recomponentize & duplicate)">
      <Cell5 />
      <Cell6 />
      <Cell7 />
      <Cell8 />
      <Cell9 />
    </div>
  );
}

function Text8() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Jessica Mota</p>
      </div>
    </div>
  );
}

function RowCell2() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <div className="relative shrink-0 size-[24px]">
            <img alt="" className="block max-w-none size-full" height="24" src={imgEllipse1} width="24" />
          </div>
          <Text8 />
        </div>
      </div>
    </div>
  );
}

function Cell10() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell2 />
    </div>
  );
}

function Text9() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Admin</p>
      </div>
    </div>
  );
}

function CellRowCell8() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text9 />
        </div>
      </div>
    </div>
  );
}

function Cell11() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell8 />
    </div>
  );
}

function Status1() {
  return (
    <div className="bg-[#242320] content-stretch flex gap-[6px] h-[28px] items-center justify-center px-[8px] py-[4px] relative rounded-[30px] shrink-0" data-name="Status">
      <div aria-hidden="true" className="absolute border border-[rgba(197,154,0,0.2)] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <div className="bg-[#d9aa00] rounded-[20px] shrink-0 size-[6px]" />
      <p className="font-['Poppins:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#d9aa00] text-[12px]">Status</p>
    </div>
  );
}

function RowCell3() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Status1 />
        </div>
      </div>
    </div>
  );
}

function Cell12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell3 />
    </div>
  );
}

function Text10() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Há 34 minutos</p>
      </div>
    </div>
  );
}

function CellRowCell9() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text10 />
        </div>
      </div>
    </div>
  );
}

function Cell13() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell9 />
    </div>
  );
}

function FilesFolders1() {
  return (
    <div className="absolute inset-[5.08%_5.17%_5.21%_5.17%]" data-name="files-folders">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9333 17.9418">
        <g id="files-folders">
          <path d={svgPaths.p3b713a80} fill="var(--fill-0, white)" id="notepad-edit" />
        </g>
      </svg>
    </div>
  );
}

function IconLeft1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon Left">
      <FilesFolders1 />
    </div>
  );
}

function CellRowCell10() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[12px] relative size-full">
          <IconLeft1 />
        </div>
      </div>
    </div>
  );
}

function Cell14() {
  return (
    <div className="content-stretch flex h-[64px] items-start relative shrink-0 w-[48px]" data-name="Cell">
      <CellRowCell10 />
    </div>
  );
}

function RowMainRecomponentizeDuplicate1() {
  return (
    <div className="content-stretch flex h-[64px] items-start overflow-clip relative shrink-0 w-full" data-name="Row / Main (recomponentize & duplicate)">
      <Cell10 />
      <Cell11 />
      <Cell12 />
      <Cell13 />
      <Cell14 />
    </div>
  );
}

function Text11() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Caio Paixão</p>
      </div>
    </div>
  );
}

function RowCell4() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <div className="relative shrink-0 size-[24px]">
            <img alt="" className="block max-w-none size-full" height="24" src={imgEllipse1} width="24" />
          </div>
          <Text11 />
        </div>
      </div>
    </div>
  );
}

function Cell15() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell4 />
    </div>
  );
}

function Text12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Membro</p>
      </div>
    </div>
  );
}

function CellRowCell11() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text12 />
        </div>
      </div>
    </div>
  );
}

function Cell16() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell11 />
    </div>
  );
}

function Status2() {
  return (
    <div className="bg-[#242320] content-stretch flex gap-[6px] h-[28px] items-center justify-center px-[8px] py-[4px] relative rounded-[30px] shrink-0" data-name="Status">
      <div aria-hidden="true" className="absolute border border-[rgba(197,154,0,0.2)] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <div className="bg-[#d9aa00] rounded-[20px] shrink-0 size-[6px]" />
      <p className="font-['Poppins:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#d9aa00] text-[12px]">Status</p>
    </div>
  );
}

function RowCell5() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Status2 />
        </div>
      </div>
    </div>
  );
}

function Cell17() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell5 />
    </div>
  );
}

function Text13() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Há 3 meses</p>
      </div>
    </div>
  );
}

function CellRowCell12() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text13 />
        </div>
      </div>
    </div>
  );
}

function Cell18() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell12 />
    </div>
  );
}

function FilesFolders2() {
  return (
    <div className="absolute inset-[5.08%_5.17%_5.21%_5.17%]" data-name="files-folders">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9333 17.9418">
        <g id="files-folders">
          <path d={svgPaths.p3b713a80} fill="var(--fill-0, white)" id="notepad-edit" />
        </g>
      </svg>
    </div>
  );
}

function IconLeft2() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon Left">
      <FilesFolders2 />
    </div>
  );
}

function CellRowCell13() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[12px] relative size-full">
          <IconLeft2 />
        </div>
      </div>
    </div>
  );
}

function Cell19() {
  return (
    <div className="content-stretch flex h-[64px] items-start relative shrink-0 w-[48px]" data-name="Cell">
      <CellRowCell13 />
    </div>
  );
}

function RowMainRecomponentizeDuplicate2() {
  return (
    <div className="bg-[#212121] content-stretch flex h-[64px] items-start overflow-clip relative shrink-0 w-full" data-name="Row / Main (recomponentize & duplicate)">
      <Cell15 />
      <Cell16 />
      <Cell17 />
      <Cell18 />
      <Cell19 />
    </div>
  );
}

function Text14() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Nataly Lima</p>
      </div>
    </div>
  );
}

function RowCell6() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <div className="relative shrink-0 size-[24px]">
            <img alt="" className="block max-w-none size-full" height="24" src={imgEllipse1} width="24" />
          </div>
          <Text14 />
        </div>
      </div>
    </div>
  );
}

function Cell20() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell6 />
    </div>
  );
}

function Text15() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Visualizador</p>
      </div>
    </div>
  );
}

function CellRowCell14() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text15 />
        </div>
      </div>
    </div>
  );
}

function Cell21() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell14 />
    </div>
  );
}

function Status3() {
  return (
    <div className="bg-[#242320] content-stretch flex gap-[6px] h-[28px] items-center justify-center px-[8px] py-[4px] relative rounded-[30px] shrink-0" data-name="Status">
      <div aria-hidden="true" className="absolute border border-[rgba(197,154,0,0.2)] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <div className="bg-[#d9aa00] rounded-[20px] shrink-0 size-[6px]" />
      <p className="font-['Poppins:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#d9aa00] text-[12px]">Status</p>
    </div>
  );
}

function RowCell7() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Status3 />
        </div>
      </div>
    </div>
  );
}

function Cell22() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell7 />
    </div>
  );
}

function Text16() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Há 8 meses</p>
      </div>
    </div>
  );
}

function CellRowCell15() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text16 />
        </div>
      </div>
    </div>
  );
}

function Cell23() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell15 />
    </div>
  );
}

function FilesFolders3() {
  return (
    <div className="absolute inset-[5.08%_5.17%_5.21%_5.17%]" data-name="files-folders">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9333 17.9418">
        <g id="files-folders">
          <path d={svgPaths.p3b713a80} fill="var(--fill-0, white)" id="notepad-edit" />
        </g>
      </svg>
    </div>
  );
}

function IconLeft3() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon Left">
      <FilesFolders3 />
    </div>
  );
}

function CellRowCell16() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[12px] relative size-full">
          <IconLeft3 />
        </div>
      </div>
    </div>
  );
}

function Cell24() {
  return (
    <div className="content-stretch flex h-[64px] items-start relative shrink-0 w-[48px]" data-name="Cell">
      <CellRowCell16 />
    </div>
  );
}

function RowMainRecomponentizeDuplicate3() {
  return (
    <div className="content-stretch flex h-[64px] items-start overflow-clip relative shrink-0 w-full" data-name="Row / Main (recomponentize & duplicate)">
      <Cell20 />
      <Cell21 />
      <Cell22 />
      <Cell23 />
      <Cell24 />
    </div>
  );
}

function Text17() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Filipe Goes</p>
      </div>
    </div>
  );
}

function RowCell8() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <div className="relative shrink-0 size-[24px]">
            <img alt="" className="block max-w-none size-full" height="24" src={imgEllipse1} width="24" />
          </div>
          <Text17 />
        </div>
      </div>
    </div>
  );
}

function Cell25() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell8 />
    </div>
  );
}

function Text18() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Membro</p>
      </div>
    </div>
  );
}

function CellRowCell17() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text18 />
        </div>
      </div>
    </div>
  );
}

function Cell26() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell17 />
    </div>
  );
}

function Status4() {
  return (
    <div className="bg-[#242320] content-stretch flex gap-[6px] h-[28px] items-center justify-center px-[8px] py-[4px] relative rounded-[30px] shrink-0" data-name="Status">
      <div aria-hidden="true" className="absolute border border-[rgba(197,154,0,0.2)] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <div className="bg-[#d9aa00] rounded-[20px] shrink-0 size-[6px]" />
      <p className="font-['Poppins:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#d9aa00] text-[12px]">Status</p>
    </div>
  );
}

function RowCell9() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Row Cell">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] relative size-full">
          <Status4 />
        </div>
      </div>
    </div>
  );
}

function Cell27() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <RowCell9 />
    </div>
  );
}

function Text19() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Text">
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-white w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Ontem</p>
      </div>
    </div>
  );
}

function CellRowCell18() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] relative size-full">
          <Text19 />
        </div>
      </div>
    </div>
  );
}

function Cell28() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-full items-start min-h-px min-w-px relative" data-name="Cell">
      <CellRowCell18 />
    </div>
  );
}

function FilesFolders4() {
  return (
    <div className="absolute inset-[5.08%_5.17%_5.21%_5.17%]" data-name="files-folders">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9333 17.9418">
        <g id="files-folders">
          <path d={svgPaths.p3b713a80} fill="var(--fill-0, white)" id="notepad-edit" />
        </g>
      </svg>
    </div>
  );
}

function IconLeft4() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon Left">
      <FilesFolders4 />
    </div>
  );
}

function CellRowCell19() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Cell/Row Cell">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[8px] items-center justify-center px-[12px] relative size-full">
          <IconLeft4 />
        </div>
      </div>
    </div>
  );
}

function Cell29() {
  return (
    <div className="content-stretch flex h-[64px] items-start relative shrink-0 w-[48px]" data-name="Cell">
      <CellRowCell19 />
    </div>
  );
}

function RowMainRecomponentizeDuplicate4() {
  return (
    <div className="bg-[#212121] content-stretch flex h-[64px] items-start overflow-clip relative shrink-0 w-full" data-name="Row / Main (recomponentize & duplicate)">
      <Cell25 />
      <Cell26 />
      <Cell27 />
      <Cell28 />
      <Cell29 />
    </div>
  );
}

function Table() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[4px] shrink-0 w-full" data-name="Table">
      <Header />
      <RowMainRecomponentizeDuplicate />
      <RowMainRecomponentizeDuplicate1 />
      <RowMainRecomponentizeDuplicate2 />
      <RowMainRecomponentizeDuplicate3 />
      <RowMainRecomponentizeDuplicate4 />
    </div>
  );
}

function Down() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="down">
          <path clipRule="evenodd" d={svgPaths.p3c9eb80} fill="var(--fill-0, #A4A4A4)" fillRule="evenodd" id="vector" />
        </g>
      </svg>
    </div>
  );
}

function BasicInputs() {
  return (
    <div className="bg-[#313131] content-stretch flex gap-[8px] items-center p-[8px] relative rounded-[6px] shrink-0" data-name="Basic Inputs">
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <p className="font-['Poppins:Medium',sans-serif] leading-[12px] not-italic relative shrink-0 text-[#a4a4a4] text-[12px]">5</p>
      <Down />
    </div>
  );
}

function Item() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="item">
      <p className="font-['Poppins:Regular',sans-serif] leading-[12px] not-italic relative shrink-0 text-[#818181] text-[12px] tracking-[-0.12px]">Exibir</p>
      <BasicInputs />
      <p className="font-['Poppins:Regular',sans-serif] leading-[12px] not-italic relative shrink-0 text-[#818181] text-[12px] tracking-[-0.12px]">por página</p>
    </div>
  );
}

function Arrows1() {
  return (
    <div className="absolute inset-[25.33%_39.46%_25.33%_35.83%]" data-name="arrows">
      <div className="absolute inset-[-11.26%_-22.48%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.4475 10.88">
          <g id="arrows">
            <path d="M5.4475 1L1 5.44L5.4475 9.88" id="left" stroke="var(--stroke-0, #818181)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function BulkLeft() {
  return (
    <div className="overflow-clip relative shrink-0 size-[18px]" data-name="bulk_left">
      <Arrows1 />
    </div>
  );
}

function Component() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 size-[30px]" data-name="<">
      <BulkLeft />
    </div>
  );
}

function Selected() {
  return (
    <div className="bg-[#3482ff] relative rounded-[4px] shrink-0 size-[30px]" data-name="Selected">
      <p className="-translate-x-1/2 absolute font-['Poppins:SemiBold',sans-serif] leading-[14px] left-[calc(50%+0.5px)] not-italic text-[14px] text-center text-white top-[calc(50%-7px)]">2</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative rounded-[4px] shrink-0 w-[30px]">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] h-[30px] justify-center leading-[0] not-italic relative shrink-0 text-[#818181] text-[14px] text-center w-full">
        <p className="leading-[14px] whitespace-pre-wrap">4</p>
      </div>
    </div>
  );
}

function Arrows2() {
  return (
    <div className="absolute inset-[25.33%_32.04%_25.33%_43.25%]" data-name="arrows">
      <div className="absolute inset-[-11.26%_-22.48%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.4475 10.88">
          <g id="arrows">
            <path d="M1 1L5.4475 5.44L1 9.88" id="ight" stroke="var(--stroke-0, #818181)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function BulkRight() {
  return (
    <div className="overflow-clip relative shrink-0 size-[18px]" data-name="bulk_right">
      <Arrows2 />
    </div>
  );
}

function Component1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 size-[30px]" data-name=">">
      <BulkRight />
    </div>
  );
}

function Pagination() {
  return (
    <div className="content-stretch flex gap-[2px] items-center relative shrink-0" data-name="Pagination">
      <Component />
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 size-[30px] text-[#818181] text-[14px] text-center">
        <p className="leading-[14px] whitespace-pre-wrap">1</p>
      </div>
      <Selected />
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 size-[30px] text-[#818181] text-[14px] text-center">
        <p className="leading-[14px] whitespace-pre-wrap">3</p>
      </div>
      <Frame />
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 size-[30px] text-[#818181] text-[14px] text-center">
        <p className="leading-[14px] whitespace-pre-wrap">5</p>
      </div>
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 size-[30px] text-[#818181] text-[14px] text-center">
        <p className="leading-[14px] whitespace-pre-wrap">6</p>
      </div>
      <Component1 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Item />
          <Pagination />
        </div>
      </div>
    </div>
  );
}

function FullTable() {
  return (
    <div className="absolute bg-[#292929] left-[468px] rounded-[8px] top-[460px] w-[948px]" data-name="Full Table">
      <div className="content-stretch flex flex-col gap-[16px] items-start overflow-clip py-[24px] relative rounded-[inherit] w-full">
        <Frame1 />
        <Table />
        <Frame2 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#434343] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function G() {
  return (
    <div className="h-[27.81px] relative shrink-0 w-[73px]" data-name="g14">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73 27.8095">
        <g id="g14">
          <path d={svgPaths.p1dc4a100} fill="var(--fill-0, white)" id="polygon4" />
          <path d={svgPaths.p39e85800} fill="var(--fill-0, white)" id="path6" />
          <path d={svgPaths.p790c700} fill="var(--fill-0, white)" id="path8" />
          <path d={svgPaths.p2ee1e80} fill="var(--fill-0, white)" id="polygon10" />
          <path d={svgPaths.p17226170} fill="var(--fill-0, white)" id="path12" />
        </g>
      </svg>
    </div>
  );
}

function LogoBlack() {
  return (
    <div className="content-stretch flex items-center overflow-clip relative shrink-0 w-[73px]" data-name="logo-black 8">
      <G />
    </div>
  );
}

function General1() {
  return (
    <div className="absolute inset-[5.16%_5.12%_5.25%_5.29%]" data-name="general">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9172 17.9184">
        <g id="general">
          <path d={svgPaths.p31701200} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Home1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="home">
      <General1 />
    </div>
  );
}

function Home() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Home1 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Home</p>
    </div>
  );
}

function Inicio() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home />
      <Frame9 />
    </div>
  );
}

function Component2() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 2">
      <Inicio />
    </div>
  );
}

function Business() {
  return (
    <div className="absolute inset-[5.21%_5.21%_5.46%_5.21%]" data-name="business">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9167 17.8667">
        <g id="business">
          <path d={svgPaths.p838f080} fill="var(--fill-0, white)" id="graph-up" />
        </g>
      </svg>
    </div>
  );
}

function GraphUp() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="graph-up">
      <Business />
    </div>
  );
}

function Home2() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <GraphUp />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Operações</p>
    </div>
  );
}

function Inicio1() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home2 />
      <Frame10 />
    </div>
  );
}

function Component3() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 3">
      <Inicio1 />
    </div>
  );
}

function Finance1() {
  return (
    <div className="absolute inset-[10.4%_5.21%]" data-name="finance">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9167 15.84">
        <g id="finance">
          <path d={svgPaths.p345a8ef0} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p1cebdd00} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p39b1a700} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Finance() {
  return (
    <div className="absolute contents inset-[10.4%_5.21%]" data-name="finance">
      <Finance1 />
    </div>
  );
}

function Wallet() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="wallet">
      <Finance />
    </div>
  );
}

function Home3() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Wallet />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Minha carteira</p>
    </div>
  );
}

function Inicio2() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home3 />
      <Frame11 />
    </div>
  );
}

function Component4() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 4">
      <Inicio2 />
    </div>
  );
}

function General2() {
  return (
    <div className="absolute inset-[5.38%_5.27%_5.12%_5.24%]" data-name="general">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.8962 17.8999">
        <g id="general">
          <path d={svgPaths.p1010bf00} fill="var(--fill-0, white)" id="rocket" />
        </g>
      </svg>
    </div>
  );
}

function Rocket() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="rocket">
      <General2 />
    </div>
  );
}

function Home4() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Rocket />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Soluções</p>
    </div>
  );
}

function Inicio3() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home4 />
      <Frame12 />
    </div>
  );
}

function Component5() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 5">
      <Inicio3 />
    </div>
  );
}

function ItNetwork() {
  return (
    <div className="absolute inset-[5.12%_5.2%_5.12%_5.18%]" data-name="it-network">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.9228 17.9512">
        <g id="it-network">
          <path d={svgPaths.p3ba9d00} fill="var(--fill-0, white)" id="it-8" />
        </g>
      </svg>
    </div>
  );
}

function Wrench() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="wrench">
      <ItNetwork />
    </div>
  );
}

function Home5() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <Wrench />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Tools</p>
    </div>
  );
}

function Inicio4() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home5 />
      <Frame13 />
    </div>
  );
}

function Component6() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 6">
      <Inicio4 />
    </div>
  );
}

function Users() {
  return (
    <div className="absolute inset-[5.04%_7.79%]" data-name="users">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.8833 17.9832">
        <g id="users">
          <path d={svgPaths.p3a2ad900} fill="var(--fill-0, white)" id="people" />
        </g>
      </svg>
    </div>
  );
}

function People() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="people">
      <Users />
    </div>
  );
}

function Home6() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <People />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Comunidade</p>
    </div>
  );
}

function Inicio5() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home6 />
      <Frame14 />
    </div>
  );
}

function Component8() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 8">
      <Inicio5 />
    </div>
  );
}

function HelpCircle() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="help-circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_15_5997)" id="help-circle">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22540600} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10 14.1667H10.0083" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_15_5997">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Home7() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Home">
      <HelpCircle />
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.7] not-italic relative shrink-0 text-[12px] text-center text-white">Ajuda</p>
    </div>
  );
}

function Inicio6() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center relative shrink-0" data-name="Inicio">
      <Home7 />
      <Frame15 />
    </div>
  );
}

function Component7() {
  return (
    <div className="content-stretch flex flex-col h-[82px] items-center justify-center relative rounded-[4px] shrink-0 w-full" data-name="Component 7">
      <Inicio6 />
    </div>
  );
}

function Default() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-full" data-name="Default">
      <Component2 />
      <Component3 />
      <Component4 />
      <Component5 />
      <Component6 />
      <Component8 />
      <Component7 />
    </div>
  );
}

function Frame33() {
  return (
    <div className="content-stretch flex flex-col gap-[68px] items-center relative shrink-0 w-full">
      <LogoBlack />
      <Default />
    </div>
  );
}

function Menu() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[90px] h-[991px] items-center left-0 px-[8px] py-[24px] top-0 w-[120px]" data-name="Menu">
      <div aria-hidden="true" className="absolute border-[#515151] border-r border-solid inset-0 pointer-events-none" />
      <Frame33 />
    </div>
  );
}

function Component11() {
  return (
    <div className="relative shrink-0 size-[34px]" data-name="Component 13">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <path d={svgPaths.p21e0d180} fill="var(--fill-0, #FFCD39)" id="Ellipse 511" />
      </svg>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <path d={svgPaths.p21e0d180} fill="url(#paint0_linear_15_6002)" id="Ellipse 514" />
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_15_6002" x1="17" x2="35.4571" y1="0" y2="26.7143">
            <stop stopColor="#FFC709" />
            <stop offset="1" stopColor="#FD7E14" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-[2.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <g id="Ellipse 515" />
        </svg>
      </div>
      <p className="absolute font-['Poppins:Medium',sans-serif] inset-[20.62%_30.33%_20.56%_34.37%] leading-[1.7] not-italic text-[#ffc709] text-[11.657px]">IA</p>
    </div>
  );
}

function NotificationOn1() {
  return (
    <div className="absolute inset-[8.38%_10.69%_9.14%_10.66%]" data-name="notification-on">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.8756 19.7955">
        <g id="notification-on">
          <path d={svgPaths.p1df35100} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p3b5e6b80} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p31c13800} fill="var(--fill-0, white)" id="Vector_3" />
          <path d={svgPaths.pd5f100} fill="var(--fill-0, white)" id="Vector_4" />
          <path d={svgPaths.p1b141a00} fill="var(--fill-0, white)" id="Vector_5" />
        </g>
      </svg>
    </div>
  );
}

function Notification() {
  return (
    <div className="absolute contents inset-[8.38%_10.69%_9.14%_10.66%]" data-name="notification">
      <NotificationOn1 />
    </div>
  );
}

function NotificationOn() {
  return (
    <div className="absolute inset-1/4 overflow-clip" data-name="notification-on">
      <Notification />
    </div>
  );
}

function Component10() {
  return (
    <div className="col-1 ml-0 mt-0 relative row-1 size-[48px]" data-name="Component 12">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 48">
        <circle cx="24" cy="24" fill="var(--fill-0, #292929)" id="Ellipse 4" r="24" />
      </svg>
      <NotificationOn />
    </div>
  );
}

function Group() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Component10 />
      <div className="col-1 ml-[38px] mt-[6.5px] relative row-1 size-[10px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
          <ellipse cx="5" cy="5" fill="var(--fill-0, #B53939)" id="Ellipse 5" rx="5" ry="5" />
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="relative shrink-0 size-[48px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 48">
        <g id="Group 18877">
          <circle cx="24" cy="24" fill="var(--fill-0, white)" id="image" r="24" />
        </g>
      </svg>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col font-['Poppins:Medium',sans-serif] items-start leading-[1.7] not-italic relative shrink-0">
      <p className="relative shrink-0 text-[16px] text-white">Banco BS2</p>
      <p className="relative shrink-0 text-[#818181] text-[14px]">71.027.866/0001-34</p>
    </div>
  );
}

function Arrows3() {
  return (
    <div className="absolute inset-[38.5%_20.85%_28.17%_20.81%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.668 6.66734">
        <g id="arrows">
          <path d={svgPaths.p121cad00} fill="var(--fill-0, white)" id="down" />
        </g>
      </svg>
    </div>
  );
}

function Down1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="down">
      <Arrows3 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex gap-[12px] items-center justify-center relative shrink-0">
      <Group1 />
      <Frame4 />
      <Down1 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <Frame6 />
      <div className="absolute left-[37px] size-[16px] top-[31px]">
        <img alt="" className="block max-w-none size-full" height="16" src={imgEllipse7} width="16" />
      </div>
      <div className="absolute left-[9px] size-[29px] top-[12px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex gap-[32px] items-center justify-end relative shrink-0">
      <Component11 />
      <Group />
      <div className="flex h-[22px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "153.5" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[22px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 1">
                <line id="Line 62" stroke="var(--stroke-0, #515151)" x2="22" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame5 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#212121] flex-[1_0_0] min-h-px min-w-px relative">
      <div aria-hidden="true" className="absolute border-[#515151] border-b border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-end size-full">
        <div className="content-stretch flex gap-[16px] items-center justify-end px-[24px] py-[16px] relative w-full">
          <Frame8 />
        </div>
      </div>
    </div>
  );
}

function Header1() {
  return (
    <div className="absolute content-stretch flex items-center justify-end left-[118px] top-0 w-[1322px]" data-name="Header">
      <Frame7 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[-196px] top-[-13px]">
      <div className="absolute bg-gradient-to-t from-white h-[171px] left-0 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-194px_-11px] mask-size-[1468px_1102px] to-[#262626] to-[82.456%] top-0 w-[1207px]" style={{ maskImage: `url('${imgRectangle4539}')` }} />
    </div>
  );
}

function Layer() {
  return (
    <div className="absolute inset-[9.37%_5.21%_9.38%_5.21%]" data-name="Layer 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.3333 13">
        <g id="Layer 2">
          <path d={svgPaths.p23f0c840} fill="var(--fill-0, #292929)" id="Vector" />
          <path d={svgPaths.p38b79700} fill="var(--fill-0, #292929)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function CameraSolid() {
  return (
    <div className="-translate-x-1/2 absolute left-1/2 opacity-90 overflow-clip size-[16px] top-0" data-name="camera-solid">
      <Layer />
    </div>
  );
}

function ArrowRight() {
  return (
    <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-right">
      <CameraSolid />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#e3e3e3] content-stretch flex gap-[16px] items-center justify-center left-[957px] px-[12px] py-[8px] rounded-[8px] top-[112px]" data-name="Button">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[#292929] text-[12px]">{`Alterar capa do Workspace `}</p>
      <ArrowRight />
    </div>
  );
}

function Component9() {
  return (
    <div className="absolute bg-[#161616] border-2 border-[#a4a4a4] border-solid h-[162px] left-[24px] overflow-clip rounded-[10px] top-[24px] w-[1224px]" data-name="Component 10">
      <Group2 />
      <div className="absolute flex inset-[calc(-298.15%-13.93px)_calc(58.07%+0.32px)_calc(-113.67%-6.55px)_calc(-26.76%-3.07px)] items-center justify-center">
        <div className="flex-none h-[685.901px] rotate-[105.2deg] skew-x-[0.4deg] w-[677.643px]">
          <div className="relative size-full" data-name="Vector">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 678.643 686.901">
              <path d={svgPaths.p6838200} fill="url(#paint0_linear_15_9417)" fillOpacity="0.1" id="Vector" stroke="url(#paint1_radial_15_9417)" strokeMiterlimit="10" />
              <defs>
                <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_15_9417" x1="0.5" x2="678.143" y1="343.45" y2="343.45">
                  <stop stopColor="#D9D9D9" />
                  <stop offset="1" stopColor="#737373" />
                </linearGradient>
                <radialGradient cx="0" cy="0" gradientTransform="matrix(223.712 -207.442 204.944 226.438 530.002 174.001)" gradientUnits="userSpaceOnUse" id="paint1_radial_15_9417" r="1">
                  <stop offset="0.384826" stopColor="white" />
                  <stop offset="1" stopColor="#212121" />
                </radialGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute flex inset-[calc(35.19%-0.59px)_calc(-2.4%-2.1px)_calc(-213.58%-10.54px)_calc(65.12%+0.6px)] items-center justify-center">
        <div className="-rotate-90 flex-none h-[456.338px] w-[451px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-[-0.11%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 452 457.338">
                <path d={svgPaths.p38892b00} fill="url(#paint0_linear_15_9415)" fillOpacity="0.05" id="Vector" stroke="url(#paint1_radial_15_9415)" strokeMiterlimit="10" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_15_9415" x1="451.5" x2="0.5" y1="228.669" y2="228.669">
                    <stop stopColor="#D9D9D9" />
                    <stop offset="1" stopColor="#737373" />
                  </linearGradient>
                  <radialGradient cx="0" cy="0" gradientTransform="matrix(148.89 -138.014 136.399 150.652 352.906 115.933)" gradientUnits="userSpaceOnUse" id="paint1_radial_15_9415" r="1">
                    <stop offset="0.384826" stopColor="white" />
                    <stop offset="1" stopColor="#212121" />
                  </radialGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Button1 />
    </div>
  );
}

function Verificado() {
  return (
    <div className="absolute left-[263px] size-[16px] top-[233px]" data-name="verificado 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_15_6018)" id="verificado 1">
          <path d={svgPaths.p12cae680} fill="var(--fill-0, #3482FF)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_15_6018">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Layer1() {
  return (
    <div className="absolute inset-[9.37%_5.21%_9.38%_5.21%]" data-name="Layer 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.3333 13">
        <g id="Layer 2">
          <path d={svgPaths.p23f0c840} fill="var(--fill-0, #434343)" id="Vector" />
          <path d={svgPaths.p38b79700} fill="var(--fill-0, #434343)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function CameraSolid1() {
  return (
    <div className="-translate-x-1/2 absolute left-[calc(50%+1px)] opacity-90 overflow-clip size-[16px] top-[4px]" data-name="camera-solid">
      <Layer1 />
    </div>
  );
}

function Item1() {
  return (
    <div className="absolute bg-[#a4a4a4] h-[24px] left-[24px] opacity-68 rounded-bl-[8px] rounded-br-[8px] top-[266px] w-[80px]" data-name="item">
      <CameraSolid1 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="absolute bg-[#212121] h-[321px] left-[144px] overflow-clip rounded-[8px] shadow-[0px_5px_26px_8px_rgba(22,22,22,0.55)] top-[115px] w-[1272px]">
      <Component9 />
      <div className="absolute bg-[#515151] h-px left-[24px] top-[322px] w-[1208px]" data-name="Line" />
      <p className="absolute font-['Poppins:SemiBold',sans-serif] leading-[48px] left-[120px] not-italic text-[24px] text-white top-[216px]">Banco BS2</p>
      <Verificado />
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[120px] not-italic text-[14px] text-white top-[264px]">71.027.866/0001-34</p>
      <div className="absolute bg-white left-[24px] rounded-[8px] size-[80px] top-[210px]" />
      <div className="absolute left-[46px] size-[36px] top-[228px]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
      <Item1 />
    </div>
  );
}

function Arrows4() {
  return (
    <div className="absolute inset-[27.89%_27.94%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5907 10.6107">
        <g id="arrows">
          <path d={svgPaths.p23ecbb80} fill="var(--fill-0, white)" id="cross" />
        </g>
      </svg>
    </div>
  );
}

function Cross() {
  return (
    <div className="overflow-clip relative shrink-0 size-[24px]" data-name="cross">
      <Arrows4 />
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <div className="flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">
        <p className="leading-[normal]">Adicionar membro</p>
      </div>
      <Cross />
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <Frame34 />
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#a4a4a4] text-[14px] w-full">
        <p className="leading-[normal] whitespace-pre-wrap">Informe o e-mail e o tipo de permissão. Um convite será enviado por e-mail para que ele acesse o workspace.</p>
      </div>
    </div>
  );
}

function Text20() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0 w-[148px]" data-name="Text">
      <p className="font-['Poppins:SemiBold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#818181] text-[12px] w-full whitespace-pre-wrap">E-mail corporativo</p>
    </div>
  );
}

function InputText1() {
  return (
    <div className="h-[44px] relative rounded-[6px] shrink-0 w-full" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#818181] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-[16px] py-[8px] relative size-full">
          <Text20 />
        </div>
      </div>
    </div>
  );
}

function Text21() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[4px] items-start min-h-px min-w-px not-italic relative whitespace-pre-wrap" data-name="Text">
      <p className="font-['Poppins:Regular',sans-serif] leading-[10px] relative shrink-0 text-[#818181] text-[10px] tracking-[-0.3px] w-full">Permissão</p>
      <p className="font-['Poppins:SemiBold',sans-serif] h-[14px] leading-[normal] relative shrink-0 text-[12px] text-white w-full">Administrador</p>
    </div>
  );
}

function Arrows5() {
  return (
    <div className="absolute inset-[38.5%_21.31%_28.17%_20.35%]" data-name="arrows">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.668 6.66734">
        <g id="arrows">
          <path d={svgPaths.p121cad00} fill="var(--fill-0, #818181)" id="down" />
        </g>
      </svg>
    </div>
  );
}

function Down2() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="down">
      <Arrows5 />
    </div>
  );
}

function InputText2() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full" data-name="Input Text">
      <div aria-hidden="true" className="absolute border border-[#818181] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center px-[16px] py-[8px] relative w-full">
          <Text21 />
          <Down2 />
        </div>
      </div>
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex flex-col gap-[18px] items-start relative shrink-0 w-full">
      <InputText1 />
      <InputText2 />
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <Frame28 />
      <Frame29 />
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#3482ff] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center justify-center px-[24px] py-[16px] relative w-full">
          <p className="font-['Poppins:SemiBold',sans-serif] leading-[16px] not-italic relative shrink-0 text-[16px] text-white">Adicionar</p>
        </div>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Button2 />
    </div>
  );
}

function Frame31() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#212121] content-stretch flex flex-col gap-[24px] items-start left-1/2 p-[24px] rounded-[8px] top-1/2 w-[600px]">
      <Frame30 />
      <Frame32 />
    </div>
  );
}

export default function WorkspaceConfiguracoesAdicionarMembro() {
  return (
    <div className="bg-[#212121] relative size-full" data-name="Workspace > Configurações > Adicionar Membro">
      <Frame25 />
      <FullTable />
      <Menu />
      <Header1 />
      <Frame26 />
      <div className="absolute bg-[#161616] h-[1085px] left-[2px] opacity-70 top-0 w-[1438px]" />
      <Frame31 />
    </div>
  );
}