import svgPaths from "./svg-g0vm99zh1t";
import imgImage67 from "figma:asset/e867cb309f479453f096f038a8593a9a8e1eff48.png";
import imgImage from "figma:asset/9a8e3295558857dc96c9e60a2ae4f30d3cab6c73.png";

function InterfaceEssentialHomeHouse() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/Home, House">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.pd3c4230} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function ArrowsDiagramsArrow() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function BreadcrumbItem() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Breadcrumb Item">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#94a3b8] text-[14px]">Operações</p>
    </div>
  );
}

function ArrowsDiagramsArrow1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function BreadcrumbItem1() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Breadcrumb Item">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#94a3b8] text-[14px]">Consulta de viabilidade</p>
    </div>
  );
}

function ArrowsDiagramsArrow2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function BreadcrumbItem2() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Breadcrumb Item">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">BS2#001</p>
    </div>
  );
}

function BreadcrumbGroup() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Breadcrumb Group">
      <InterfaceEssentialHomeHouse />
      <ArrowsDiagramsArrow />
      <BreadcrumbItem />
      <ArrowsDiagramsArrow1 />
      <BreadcrumbItem1 />
      <ArrowsDiagramsArrow2 />
      <BreadcrumbItem2 />
    </div>
  );
}

function UserUserProfile() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="User/User,Profile">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p31cf4300} id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2bdd1260} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p18e38fe0} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[14px]">Ver perfil do Sell Side</p>
    </div>
  );
}

function ArrowsDiagramsArrow3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, #F1F5F9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function TextLink() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center overflow-clip relative rounded-[8px] shrink-0" data-name="Text Link">
      <Content />
      <ArrowsDiagramsArrow3 />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <UserUserProfile />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[16px] whitespace-pre-wrap">Informações básicas</p>
      <TextLink />
    </div>
  );
}

function Header() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="content-stretch flex flex-col items-start px-[24px] py-[16px] relative w-full">
        <Container />
      </div>
    </div>
  );
}

function LogoInsany() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[23px] left-1/2 top-[calc(50%-0.5px)] w-[36px]" data-name="logo-insany">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 23">
        <g id="logo-insany">
          <path d={svgPaths.pd893f00} fill="var(--fill-0, #FF0068)" id="Vector" />
          <path d={svgPaths.pa955600} fill="var(--fill-0, #0F172A)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Avatar() {
  return (
    <div className="bg-[#f1f5f9] overflow-clip relative rounded-[44995.504px] shadow-[0px_0px_0px_1px_#1e293b] shrink-0 size-[72px]" data-name="Avatar">
      <LogoInsany />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-1.444px_1.444px_0px_rgba(255,255,255,0.04),inset_0px_-1.444px_1.444px_0px_rgba(255,255,255,0.04)]" />
    </div>
  );
}

function VerifiedBadge() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="verified-badge">
      <div className="absolute inset-[-7.03%_-14.05%_-21.08%_-14.05%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.2154 19.2154">
          <g id="verified-badge">
            <g filter="url(#filter0_dii_1_6041)" id="Vector">
              <path clipRule="evenodd" d={svgPaths.p1c360c00} fill="var(--fill-0, #2E61FF)" fillRule="evenodd" />
              <path clipRule="evenodd" d={svgPaths.p1c360c00} fill="url(#paint0_linear_1_6041)" fillOpacity="0.2" fillRule="evenodd" />
              <path d={svgPaths.p21e6b100} stroke="var(--stroke-0, black)" strokeOpacity="0.2" strokeWidth="0.5" />
            </g>
            <g id="check-mini">
              <path d={svgPaths.p629fee0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="19.2154" id="filter0_dii_1_6041" width="19.2154" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.05385" />
              <feGaussianBlur stdDeviation="1.05385" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_6041" />
              <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_6041" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="1.05385" />
              <feGaussianBlur stdDeviation="1.05385" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.1 0" />
              <feBlend in2="shape" mode="normal" result="effect2_innerShadow_1_6041" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1.05385" />
              <feGaussianBlur stdDeviation="2.63462" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.1 0" />
              <feBlend in2="effect2_innerShadow_1_6041" mode="normal" result="effect3_innerShadow_1_6041" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_6041" x1="9.60769" x2="9.60769" y1="1.05385" y2="16.0538">
              <stop stopColor="white" />
              <stop offset="1" stopColor="white" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Frame42() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[18px]">Insany Design</p>
      <VerifiedBadge />
    </div>
  );
}

function Divider() {
  return (
    <div className="h-0 relative w-[12px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #334155)" x2="12" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px]">Non-Deal Roadshow</p>
    </div>
  );
}

function Badge() {
  return (
    <div className="bg-[rgba(255,255,255,0.08)] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content1 />
    </div>
  );
}

function Frame40() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0">
      <Frame42 />
      <div className="flex h-[12px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <Divider />
        </div>
      </div>
      <Badge />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[8px] items-start min-h-px min-w-px relative">
      <Frame40 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-w-full not-italic relative shrink-0 text-[#cbd5e1] text-[14px] w-[min-content] whitespace-pre-wrap">
        {`Somos um estúdio de design, tecnologia e inovação dedicado a potencializar a presença digital das marcas dos nossos clientes. `}
        <br aria-hidden="true" />
        Desenvolvemos soluções que elevam o seu negócio e impulsionam métricas significativas.
      </p>
    </div>
  );
}

function Text() {
  return (
    <div className="content-stretch flex gap-[24px] items-start relative shrink-0 w-full" data-name="text">
      <Avatar />
      <Frame12 />
    </div>
  );
}

function Frame24() {
  return (
    <div className="relative shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#1e293b] border-b border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start p-[24px] relative w-full">
        <Text />
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Teaser</p>
    </div>
  );
}

function Tab() {
  return (
    <div className="content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative rounded-[8px] shrink-0" data-name="Tab">
      <Content2 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[12.48%_12.48%_8.32%_12.48%]" data-name="Group">
      <div className="absolute inset-[-3.95%_-4.16%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.2562 17.0899">
          <g id="Group">
            <rect height="2.50104" id="Rectangle" rx="0.833333" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" width="15.0062" x="0.625" y="0.625" />
            <rect height="9.17049" id="Rectangle_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" width="13.3389" x="1.45868" y="3.12604" />
            <path d="M15.6312 12.2965H0.625" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
            <path d="M8.12812 12.2965V13.9639" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
            <circle cx="8.12813" cy="15.2144" id="Oval" r="1.25052" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function OfficeWorkPresentationBoard() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Office, Work/presentation-board">
      <Group />
    </div>
  );
}

function Content3() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[14px]">Investment Deck</p>
    </div>
  );
}

function Tab1() {
  return (
    <div className="bg-[#0f172a] h-[40px] relative rounded-[8px] shrink-0" data-name="Tab">
      <div className="content-stretch flex gap-[8px] h-full items-center justify-center overflow-clip px-[16px] py-[10px] relative rounded-[inherit]">
        <OfficeWorkPresentationBoard />
        <Content3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Content4() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Data Room</p>
    </div>
  );
}

function Tab2() {
  return (
    <div className="content-stretch flex gap-[8px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[10px] relative rounded-[8px] shrink-0" data-name="Tab">
      <Content4 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="bg-[#1e293b] content-stretch flex gap-[4px] items-center justify-center p-[2px] relative rounded-[8px] shrink-0">
      <Tab />
      <Tab1 />
      <Tab2 />
    </div>
  );
}

function Content5() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[14px]">Agendar conversa</p>
    </div>
  );
}

function TextLink1() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center overflow-clip relative rounded-[8px] shrink-0" data-name="Text Link">
      <Content5 />
    </div>
  );
}

function Content6() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[14px] text-white">Tenho interesse</p>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#2e61ff] content-stretch flex gap-[4px] h-[40px] items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Content6 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <TextLink1 />
      <Button />
    </div>
  );
}

function Frame15() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[24px] relative w-full">
          <Frame13 />
          <Frame14 />
        </div>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="bg-[#0f172a] relative rounded-[16px] shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[24px] items-start overflow-clip pb-[24px] relative rounded-[inherit] w-full">
        <Frame24 />
        <Frame15 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Card() {
  return (
    <div className="bg-[#1e293b] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header />
        <Frame11 />
      </div>
    </div>
  );
}

function FilesDocumentsFileText() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Files/documents-file-text">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p185c8100} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.3333 14.1667H6.66667" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M13.3333 11.25H6.66667" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M9.16667 8.33333H6.66667" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p9084218} id="Path_6" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <FilesDocumentsFileText />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[16px] whitespace-pre-wrap">Detalhes da operação</p>
    </div>
  );
}

function Header1() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start px-[24px] py-[16px] relative w-full">
          <Container1 />
        </div>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[20px] top-1/2" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="icon">
          <rect fill="var(--fill-0, #B0C9FE)" height="11.2" id="Rectangle 42429" rx="1.8" width="3.6" x="2.8" y="6" />
          <rect fill="var(--fill-0, #B0C9FE)" height="11.2" id="Rectangle 42430" rx="1.8" width="3.6" x="8.2" y="6" />
          <rect fill="var(--fill-0, #B0C9FE)" height="11.2" id="Rectangle 42431" rx="1.8" width="3.6" x="13.5996" y="6" />
          <rect fill="var(--fill-0, #2E61FF)" height="18" id="Rectangle 42432" rx="1.8" transform="rotate(90 19 15.4)" width="3.6" x="19" y="15.4" />
          <path d={svgPaths.p3f8fe600} fill="var(--fill-0, #2E61FF)" id="Rectangle 42433" />
          <circle cx="10" cy="4.5" fill="var(--fill-0, white)" id="Ellipse 21862" r="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame31() {
  return (
    <div className="bg-[#0f172a] overflow-clip relative rounded-[9999px] shadow-[0px_0px_0px_1px_rgba(52,64,84,0.04),0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)] shrink-0 size-[40px]">
      <Icon />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
    </div>
  );
}

function Item1() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="item">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#cbd5e1] text-[14px]">Volume</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px]">100 milhões</p>
    </div>
  );
}

function Item() {
  return (
    <div className="content-stretch flex gap-[20px] items-center justify-center relative shrink-0" data-name="item">
      <Frame31 />
      <Item1 />
    </div>
  );
}

function Divider1() {
  return (
    <div className="h-0 relative w-[32px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #334155)" x2="32" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[20px] top-[calc(50%+0.5px)]" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="icon">
          <path d={svgPaths.p3e45b180} fill="var(--fill-0, #B0C9FE)" id="Rectangle 42427" />
          <path d={svgPaths.p2d120200} fill="var(--fill-0, #2E61FF)" id="Rectangle 42428" />
        </g>
      </svg>
    </div>
  );
}

function Frame32() {
  return (
    <div className="bg-[#0f172a] overflow-clip relative rounded-[9999px] shadow-[0px_0px_0px_1px_rgba(52,64,84,0.04),0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)] shrink-0 size-[40px]">
      <Icon1 />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
    </div>
  );
}

function Item3() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="item">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#cbd5e1] text-[14px]">Prazo</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px]">320 meses</p>
    </div>
  );
}

function Item2() {
  return (
    <div className="content-stretch flex gap-[20px] items-center justify-center relative shrink-0" data-name="item">
      <Frame32 />
      <Item3 />
    </div>
  );
}

function Divider2() {
  return (
    <div className="h-0 relative w-[32px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #334155)" x2="32" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute h-[16.588px] left-[1.41px] top-[2px] w-[17.176px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.1762 16.5878">
        <g id="Group 1410103878">
          <g id="Vector">
            <path d={svgPaths.p9fb1e00} fill="#B0C9FE" />
            <path d={svgPaths.pb97d5c0} fill="var(--fill-0, #2E61FF)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Icon2() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-[calc(50%-0.33px)] size-[20px] top-1/2" data-name="icon">
      <Group26 />
    </div>
  );
}

function Frame33() {
  return (
    <div className="bg-[#0f172a] overflow-clip relative rounded-[9999px] shadow-[0px_0px_0px_1px_rgba(52,64,84,0.04),0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)] shrink-0 size-[40px]">
      <Icon2 />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
    </div>
  );
}

function Item5() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="item">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#cbd5e1] text-[14px]">Remuneração</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px]">IPCA + 18% a.a.</p>
    </div>
  );
}

function Item4() {
  return (
    <div className="content-stretch flex gap-[20px] items-center justify-center relative shrink-0" data-name="item">
      <Frame33 />
      <Item5 />
    </div>
  );
}

function Divider3() {
  return (
    <div className="h-0 relative w-[32px]" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #334155)" x2="32" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute left-1/2 size-[20px] top-1/2" data-name="icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="icon">
          <path d={svgPaths.p3b733500} fill="var(--fill-0, #2E61FF)" id="Ellipse 21860" />
          <path d={svgPaths.p10ba4d00} fill="var(--fill-0, #B0C9FE)" id="Ellipse 21861" />
        </g>
      </svg>
    </div>
  );
}

function Frame34() {
  return (
    <div className="bg-[#0f172a] overflow-clip relative rounded-[9999px] shadow-[0px_0px_0px_1px_rgba(52,64,84,0.04),0px_1px_1px_0.5px_rgba(52,64,84,0.04),0px_3px_3px_-1.5px_rgba(52,64,84,0.02),0px_6px_6px_-3px_rgba(52,64,84,0.04),0px_12px_12px_-6px_rgba(52,64,84,0.04),0px_24px_24px_-12px_rgba(52,64,84,0.04),0px_48px_48px_-24px_rgba(52,64,84,0.04)] shrink-0 size-[40px]">
      <Icon3 />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_-1px_1px_-0.5px_rgba(52,64,84,0.06)]" />
    </div>
  );
}

function InformationCircleSolid() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="information-circle-solid">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="information-circle-solid">
          <path clipRule="evenodd" d={svgPaths.pa8cca00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-end relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Perfil de Risco</p>
      <InformationCircleSolid />
    </div>
  );
}

function Item7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="item">
      <Frame17 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">High Yield</p>
    </div>
  );
}

function Item6() {
  return (
    <div className="content-stretch flex gap-[20px] items-center justify-center relative shrink-0" data-name="item">
      <Frame34 />
      <Item7 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <Item />
      <div className="flex h-[32px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <Divider1 />
        </div>
      </div>
      <Item2 />
      <div className="flex h-[32px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <Divider2 />
        </div>
      </div>
      <Item4 />
      <div className="flex h-[32px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <Divider3 />
        </div>
      </div>
      <Item6 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="bg-[#1e293b] relative rounded-[12px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-[24px] relative w-full">
          <Frame16 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Setor</p>
      <div className="relative shrink-0 size-[12px]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path clipRule="evenodd" d={svgPaths.p1a0b7e00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Item9() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0" data-name="item">
      <Frame21 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">Agronegócio</p>
    </div>
  );
}

function Item8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative" data-name="item">
      <Item9 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Segmento</p>
      <div className="relative shrink-0 size-[12px]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path clipRule="evenodd" d={svgPaths.p1a0b7e00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Item11() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0" data-name="item">
      <Frame23 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">Produtor Rural</p>
    </div>
  );
}

function Item10() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative" data-name="item">
      <Item11 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Finalidade</p>
      <div className="relative shrink-0 size-[12px]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path clipRule="evenodd" d={svgPaths.p1a0b7e00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Item13() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0" data-name="item">
      <Frame25 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">Investimento na produção</p>
    </div>
  );
}

function Item12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative" data-name="item">
      <Item13 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Item8 />
      <Item10 />
      <Item12 />
    </div>
  );
}

function Divider4() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Divider">
      <div className="absolute inset-[-1px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1172 1">
          <g id="Divider">
            <line id="line" stroke="var(--stroke-0, #1E293B)" x2="1172" y1="0.5" y2="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">{`Possíveis Instrumentos `}</p>
      <div className="relative shrink-0 size-[12px]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path clipRule="evenodd" d={svgPaths.p1a0b7e00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Item15() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0" data-name="item">
      <Frame27 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">CRA</p>
    </div>
  );
}

function Item14() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative" data-name="item">
      <Item15 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Estados</p>
      <div className="relative shrink-0 size-[12px]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path clipRule="evenodd" d={svgPaths.p1a0b7e00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Item17() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0" data-name="item">
      <Frame28 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">SP, BA</p>
    </div>
  );
}

function Item16() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative" data-name="item">
      <Item17 />
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[14px]">Possui rating?</p>
      <div className="relative shrink-0 size-[12px]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <path clipRule="evenodd" d={svgPaths.p1a0b7e00} fill="var(--fill-0, #475569)" fillRule="evenodd" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Item19() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0" data-name="item">
      <Frame29 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.5] not-italic relative shrink-0 text-[#f1f5f9] text-[16px]">Sim</p>
    </div>
  );
}

function Item18() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-h-px min-w-px relative" data-name="item">
      <Item19 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Item14 />
      <Item16 />
      <Item18 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="relative rounded-[24px] shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[24px] items-start pb-[16px] px-[24px] relative w-full">
        <Frame20 />
        <Divider4 />
        <Frame26 />
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[24px] items-start px-[24px] relative w-full">
        <Frame18 />
        <Frame19 />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col items-start py-[24px] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <Frame22 />
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-[#1e293b] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header1 />
        <Container2 />
      </div>
    </div>
  );
}

function ProtectionSecurityTasklistShiled() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Protection, Security/tasklist-shiled">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d="M5.83333 10H8.33333" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M5.83333 13.3333H7.5" id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <rect height="3.33333" id="Rectangle" rx="1" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" width="6.66667" x="5.83333" y="2.5" />
          <path d={svgPaths.p3138400} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2a66ec60} id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p34ecf700} fillRule="evenodd" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle_2" />
        </g>
      </svg>
    </div>
  );
}

function Content7() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#e79342] text-[12px]">482% da operação</p>
    </div>
  );
}

function Badge1() {
  return (
    <div className="bg-[#2e241b] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content7 />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <ProtectionSecurityTasklistShiled />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[16px] whitespace-pre-wrap">Garantias</p>
      <Badge1 />
    </div>
  );
}

function Header2() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start px-[24px] py-[16px] relative w-full">
          <Container3 />
        </div>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p1b647048} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p29968a80} fillRule="evenodd" id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p129ae5c0} id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p7859880} id="Path_5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MoneyWalletMoney() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Money/Wallet, Money">
      <Group1 />
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px] w-full">Carteira de recebíveis</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#cbd5e1] text-[0px] text-[14px] w-full">
        <span className="leading-[1.4]">{`Valor da garantia: `}</span>
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">R$ 30.000.000</span>
      </p>
    </div>
  );
}

function Frame4() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <MoneyWalletMoney />
          <Frame35 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[10.42%]" data-name="Group">
      <div className="absolute inset-[-3.95%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.5 20.5">
          <g id="Group">
            <circle cx="10.25" cy="10.25" id="Oval" r="9.5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.25 5.75001V6.75001" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.25 14.75V13.75" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1ca15980} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function MoneyCurrencyDollarMediunCircle() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Money/currency-dollar-mediun-circle">
      <Group2 />
    </div>
  );
}

function Frame36() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px] w-full">Imóvel rural</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#cbd5e1] text-[0px] text-[14px] w-full">
        <span className="leading-[1.4]">{`Valor da garantia: `}</span>
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">R$ 30.000.000</span>
      </p>
    </div>
  );
}

function ArrowsDiagramsArrow4() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Group">
          <g id="Group_2">
            <path d="M11.3 4.7L4.7 11.3" id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p418ba00} id="Path_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function Btn() {
  return (
    <div className="absolute bg-[#2e61ff] content-stretch flex h-[32px] items-center justify-center p-[4px] right-0 rounded-bl-[8px] rounded-tr-[8px] top-0 w-[40px]" data-name="btn">
      <ArrowsDiagramsArrow4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <MoneyCurrencyDollarMediunCircle />
          <Frame36 />
          <Btn />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#2e61ff] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_0px_0px_3px_rgba(46,97,255,0.1)]" />
    </div>
  );
}

function CarServicePartsCar() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Car, Service, Parts/Car">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d="M22 9L19.38 10" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M4.63 10L2 9" id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M18.25 14H15.75" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M8.25 14H5.75" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p17d4a800} id="Path_5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path clipRule="evenodd" d={svgPaths.p218bdd00} fillRule="evenodd" id="Path_6" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Frame37() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px] w-full">Veículos</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#cbd5e1] text-[0px] text-[14px] w-full">
        <span className="leading-[1.4]">{`Valor da garantia: `}</span>
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">R$ 30.000.000</span>
      </p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <CarServicePartsCar />
          <Frame37 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p18a86c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p2163ab00} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function SocialMediasRewardsThumbsUpLike() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Social,Medias,Rewards/Thumbs up, Like">
      <Group3 />
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px] w-full">Aval dos sócios</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[#cbd5e1] text-[0px] text-[14px] w-full">
        <span className="leading-[1.4]">{`Valor da garantia: `}</span>
        <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4]">Não informado</span>
      </p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <SocialMediasRewardsThumbsUpLike />
          <Frame38 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Container4() {
  return (
    <div className="bg-[#0f172a] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="content-stretch flex gap-[24px] items-start p-[24px] relative w-full">
        <Frame4 />
        <Frame5 />
        <Frame6 />
        <Frame7 />
        <div className="absolute left-[580px] size-[16px] top-[164px]" data-name="Vector">
          <div className="absolute inset-[-18.75%_-25%_-31.25%_-25%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0001 24.0001">
              <g filter="url(#filter0_d_5_5346)" id="Vector">
                <path d={svgPaths.p17bb8880} fill="var(--fill-0, #CBD5E1)" />
                <path d={svgPaths.p265c6800} stroke="var(--stroke-0, #0F172A)" strokeWidth="2" />
              </g>
              <defs>
                <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="24.0001" id="filter0_d_5_5346" width="24.0001" x="-2.38419e-07" y="0">
                  <feFlood floodOpacity="0" result="BackgroundImageFix" />
                  <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                  <feOffset dy="1" />
                  <feGaussianBlur stdDeviation="1" />
                  <feComposite in2="hardAlpha" operator="out" />
                  <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.0235294 0 0 0 0 0.0901961 0 0 0 0.05 0" />
                  <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_5_5346" />
                  <feBlend in="SourceGraphic" in2="effect1_dropShadow_5_5346" mode="normal" result="shape" />
                </filter>
              </defs>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-[#1e293b] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header2 />
        <Container4 />
      </div>
    </div>
  );
}

function InterfaceEssentialStarStyle() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/star-style-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p19c92f00} id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p182af00} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.peea2c00} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p350dd900} id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p1c742840} id="Path_5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_6" />
        </g>
      </svg>
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <InterfaceEssentialStarStyle />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[16px] whitespace-pre-wrap">Highlights</p>
    </div>
  );
}

function Header3() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start px-[24px] py-[16px] relative w-full">
          <Container5 />
        </div>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute inset-[12.5%_8.33%_10.42%_8.33%]" data-name="Group">
      <div className="absolute inset-[-4.05%_-3.75%_-1.35%_-3.75%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.5 19.5">
          <g id="Group">
            <path d="M0.75 18.75H20.75" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p2fa395c0} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.75 4.75H16.75" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.75 7.75H16.75" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M10.75 10.75H16.75" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p6637cc0} id="Path_6" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M15.75 18.75V14.75" id="Path_7" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M11.75 14.75V18.75" id="Path_8" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M16.75 14.75H10.75" id="Path_9" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function BuildingConstructionHotelBuilding() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Building, Construction/hotel-building-2">
      <Group4 />
    </div>
  );
}

function Content8() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] not-italic relative shrink-0 text-[#00d492] text-[12px]">Possui balanço auditado</p>
    </div>
  );
}

function Badge2() {
  return (
    <div className="bg-[#002c22] content-stretch flex h-[24px] items-center justify-center overflow-clip px-[8px] py-[6px] relative rounded-[8px] shrink-0" data-name="Badge">
      <Content8 />
    </div>
  );
}

function Frame41() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <BuildingConstructionHotelBuilding />
      <Badge2 />
    </div>
  );
}

function Frame39() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px]">Empresa</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] min-w-full relative shrink-0 text-[#cbd5e1] text-[14px] w-[min-content] whitespace-pre-wrap">
        Um time de especialistas para ajudar o seu
        <br aria-hidden="true" />
        negócio a chegar no próximo nível.
      </p>
    </div>
  );
}

function Frame8() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <Frame41 />
          <Frame39 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function FoldersFolder() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Folders/folder">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p174d7400} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame43() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px] w-full">Projeto</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#cbd5e1] text-[14px] w-full">
        Sempre trabalhando de forma ágil e com
        <br aria-hidden="true" />
        foco total nos objetivos do negócio.
      </p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <FoldersFolder />
          <Frame43 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function InterfaceEssentialSettingStyle6Big() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/setting-style-6-big">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.p35d24f80} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="12" cy="12" id="Oval" r="3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Frame44() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start not-italic relative shrink-0 w-full whitespace-pre-wrap">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f1f5f9] text-[16px] w-full">Operação</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#cbd5e1] text-[14px] w-full">
        Criando cases que se tornaram as maiores
        <br aria-hidden="true" />
        referências em seus segmentos.
      </p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[16px]">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
          <InterfaceEssentialSettingStyle6Big />
          <Frame44 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function Container6() {
  return (
    <div className="bg-[#0f172a] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="content-stretch flex gap-[24px] items-start p-[24px] relative w-full">
        <Frame8 />
        <Frame9 />
        <Frame10 />
      </div>
    </div>
  );
}

function Card3() {
  return (
    <div className="bg-[#1e293b] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header3 />
        <Container6 />
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <rect height="2.50104" id="Rectangle" rx="1" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" width="15.0062" x="2.50102" y="2.5009" />
          <rect height="9.17049" id="Rectangle_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" width="13.3389" x="3.3347" y="5.00194" />
          <path d="M17.5073 14.1724H2.50102" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.0041 14.1724V15.8398" id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="10.0041" cy="17.0903" id="Oval" r="1.25052" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_3" />
        </g>
      </svg>
    </div>
  );
}

function OfficeWorkPresentationBoard1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Office, Work/presentation-board">
      <Group5 />
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <OfficeWorkPresentationBoard1 />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[16px] whitespace-pre-wrap">Investment deck</p>
    </div>
  );
}

function Header4() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start px-[24px] py-[16px] relative w-full">
          <Container7 />
        </div>
      </div>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute contents left-[1227.67px] top-[24.87px]">
      <div className="absolute flex h-[15.948px] items-center justify-center left-[1235.64px] top-[24.87px] w-0">
        <div className="-scale-y-100 flex-none">
          <div className="h-[15.948px] relative w-0">
            <div className="absolute inset-[0_-0.66px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.329 15.948">
                <path d="M0.6645 0V15.948" id="Vector 3066" stroke="var(--stroke-0, #FAFAFA)" strokeWidth="1.329" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[1230px] size-[11.277px] top-[27.2px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-45 -scale-y-100 flex-none">
          <div className="h-[15.948px] relative w-0">
            <div className="absolute inset-[0_-0.66px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.329 15.948">
                <path d="M0.6645 0V15.948" id="Vector 3068" stroke="var(--stroke-0, #FAFAFA)" strokeWidth="1.329" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-0 items-center justify-center left-[1227.67px] top-[32.84px] w-[15.948px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-90 -scale-y-100 flex-none">
          <div className="h-[15.948px] relative w-0">
            <div className="absolute inset-[0_-0.66px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.329 15.948">
                <path d="M0.6645 0V15.948" id="Vector 3067" stroke="var(--stroke-0, #FAFAFA)" strokeWidth="1.329" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[1230px] size-[11.277px] top-[27.2px]" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "19" } as React.CSSProperties}>
        <div className="-rotate-135 -scale-y-100 flex-none">
          <div className="h-[15.948px] relative w-0">
            <div className="absolute inset-[0_-0.66px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.329 15.948">
                <path d="M0.6645 0V15.948" id="Vector 3069" stroke="var(--stroke-0, #FAFAFA)" strokeWidth="1.329" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Logo() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[32px] left-1/2 top-1/2 w-[250px]" data-name="Logo">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 250 32">
        <g id="Logo">
          <path d={svgPaths.p35e0b980} fill="var(--fill-0, #FF0074)" id="Vector" />
          <path d={svgPaths.p63248f0} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p1f780280} fill="var(--fill-0, white)" id="Vector_3" />
          <path d={svgPaths.p1a023c00} fill="var(--fill-0, white)" id="Vector_4" />
          <path d={svgPaths.p3c5f9f00} fill="var(--fill-0, white)" id="Vector_5" />
          <path d={svgPaths.p3f9f6500} fill="var(--fill-0, white)" id="Vector_6" />
          <path d={svgPaths.p3bfd8600} fill="var(--fill-0, white)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function ArrowsDiagramsArrow5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="backdrop-blur-[10px] bg-[rgba(15,23,42,0.04)] h-[32px] relative rounded-[8px]" data-name="Button">
      <div className="content-stretch flex h-full items-center justify-center overflow-clip p-[6px] relative rounded-[inherit]">
        <ArrowsDiagramsArrow5 />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_50px_100px_0px_rgba(255,255,255,0.15)]" />
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[8px] shadow-[0px_5px_10px_0px_rgba(0,0,0,0.05),0px_15px_30px_0px_rgba(0,0,0,0.05),0px_30px_60px_0px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function ArrowsDiagramsArrow6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <path d={svgPaths.p1385a000} id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute backdrop-blur-[10px] bg-[rgba(15,23,42,0.04)] h-[32px] left-[1215px] rounded-[8px] top-[209px]" data-name="Button">
      <div className="content-stretch flex h-full items-center justify-center overflow-clip p-[6px] relative rounded-[inherit]">
        <ArrowsDiagramsArrow6 />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_50px_100px_0px_rgba(255,255,255,0.15)]" />
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[8px] shadow-[0px_5px_10px_0px_rgba(0,0,0,0.05),0px_15px_30px_0px_rgba(0,0,0,0.05),0px_30px_60px_0px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function Process() {
  return (
    <div className="bg-[rgba(15,23,42,0.04)] flex-[1_0_0] h-[6px] min-h-px min-w-px relative rounded-[9999px] shadow-[0px_5px_10px_0px_rgba(0,0,0,0.05),0px_15px_30px_0px_rgba(0,0,0,0.05),0px_30px_60px_0px_rgba(0,0,0,0.1)]" data-name="process">
      <div className="absolute bg-[#2e61ff] h-[6px] left-0 rounded-[9999px] top-0 w-[17.867px]" />
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_50px_100px_0px_rgba(255,255,255,0.15)]" />
    </div>
  );
}

function Maximize() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="maximize">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="maximize">
          <path d={svgPaths.p3ef5f16f} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <path d={svgPaths.ped16c60} id="Path" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.0042 3.33472V12.2276" id="Path_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pddfb700} id="Path_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDownloadArrow() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/download-arrow">
      <Group6 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex gap-[13.333px] items-center relative shrink-0">
      <Maximize />
      <InterfaceEssentialDownloadArrow />
    </div>
  );
}

function Frame45() {
  return (
    <div className="absolute content-stretch flex gap-[24px] items-center left-[24px] overflow-clip top-[406px] w-[1220px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[12px] text-[rgba(255,255,255,0.7)]">01 / 60</p>
      <Process />
      <Frame3 />
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-[#0f172a] h-[450px] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="-translate-x-1/2 absolute h-[450px] left-1/2 top-0 w-[1268px]" data-name="image 67">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <img alt="" className="absolute h-[281.78%] left-0 max-w-none top-[-75.78%] w-full" src={imgImage67} />
          </div>
        </div>
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[1.2] left-[322.36px] not-italic text-[13.29px] text-white top-[24.97px]">{` `}</p>
        <Group25 />
        <Logo />
        <div className="absolute flex h-[32px] items-center justify-center left-[24px] top-[209px]">
          <div className="-scale-y-100 flex-none rotate-180">
            <Button1 />
          </div>
        </div>
        <Button2 />
        <Frame45 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
    </div>
  );
}

function Card4() {
  return (
    <div className="bg-[#1e293b] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header4 />
        <Container8 />
      </div>
    </div>
  );
}

function FoldersFolders() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Folders/Folders">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Group">
          <g id="Group_2">
            <path clipRule="evenodd" d={svgPaths.p3371e900} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p848be00} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p27ad1c80} id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function Content9() {
  return (
    <div className="content-stretch flex items-center justify-center px-[4px] relative shrink-0" data-name="content">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[14px]">Baixe tudo</p>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <path d={svgPaths.p2bf41600} id="Path" stroke="var(--stroke-0, #F1F5F9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.0042 3.33458V12.2275" id="Path_2" stroke="var(--stroke-0, #323232)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3ef18680} id="Path_3" stroke="var(--stroke-0, #323232)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDownloadArrow1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/download-arrow">
      <Group7 />
    </div>
  );
}

function TextLink2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center overflow-clip relative rounded-[8px] shrink-0" data-name="Text Link">
      <Content9 />
      <InterfaceEssentialDownloadArrow1 />
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex gap-[12px] h-[27px] items-center relative shrink-0 w-full" data-name="container">
      <FoldersFolders />
      <p className="flex-[1_0_0] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[16px] whitespace-pre-wrap">Data room</p>
      <TextLink2 />
    </div>
  );
}

function Header5() {
  return (
    <div className="relative rounded-[16px] shrink-0 w-full" data-name="header">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start px-[24px] py-[16px] relative w-full">
          <Container9 />
        </div>
      </div>
    </div>
  );
}

function FolderIllustration() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.pd761f00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3ed03ac0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p37261d60} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group8 />
    </div>
  );
}

function Planilha() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Cronograma físico finance</p>
          <InterfaceEssentialDots />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p165308f0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pf8d8380} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p73aad00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group9 />
    </div>
  );
}

function Planilha1() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration1 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">CRM file</p>
          <InterfaceEssentialDots1 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p2b4ed400} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p272ee812} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1e102180} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group10 />
    </div>
  );
}

function Planilha2() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration2 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">{`CV & Resume`}</p>
          <InterfaceEssentialDots2 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.pd761f00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3ed03ac0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p37261d60} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group11 />
    </div>
  );
}

function Planilha3() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration3 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Insany Deck Proposal</p>
          <InterfaceEssentialDots3 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full">
      <Planilha />
      <Planilha1 />
      <Planilha2 />
      <Planilha3 />
    </div>
  );
}

function FolderIllustration4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.pd761f00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3ed03ac0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p37261d60} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group12 />
    </div>
  );
}

function Planilha4() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration4 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">2025_Docs</p>
          <InterfaceEssentialDots4 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p165308f0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pf8d8380} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p73aad00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group13 />
    </div>
  );
}

function Planilha5() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration5 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">2024_Docs</p>
          <InterfaceEssentialDots5 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p2b4ed400} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p272ee812} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1e102180} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group14 />
    </div>
  );
}

function Planilha6() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration6 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Monthly Report</p>
          <InterfaceEssentialDots6 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.pd761f00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3ed03ac0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p37261d60} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group15 />
    </div>
  );
}

function Planilha7() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration7 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Syllabus Sample</p>
          <InterfaceEssentialDots7 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full">
      <Planilha4 />
      <Planilha5 />
      <Planilha6 />
      <Planilha7 />
    </div>
  );
}

function FolderIllustration8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.pd761f00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3ed03ac0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p37261d60} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group16 />
    </div>
  );
}

function Planilha8() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration8 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Download assets</p>
          <InterfaceEssentialDots8 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration9() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p165308f0} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pf8d8380} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p73aad00} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots9() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group17 />
    </div>
  );
}

function Planilha9() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration9 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Client Deals (2025)</p>
          <InterfaceEssentialDots9 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration10() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.p2b4ed400} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p272ee812} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p1e102180} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots10() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group18 />
    </div>
  );
}

function Planilha10() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration10 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Company list</p>
          <InterfaceEssentialDots10 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function FolderIllustration11() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="folder-illustration">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="folder-illustration">
          <g id="Vector (Stroke)">
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="var(--fill-0, #60A5FA)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p154902a0} fill="url(#paint0_linear_5_5446)" fillOpacity="0.15" fillRule="evenodd" />
            <path d={svgPaths.p2483080} stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.15" strokeWidth="0.666667" />
          </g>
          <g filter="url(#filter0_ii_5_5446)" id="Vector (Stroke)_2">
            <path d={svgPaths.pef4ff00} fill="var(--fill-0, #60A5FA)" />
            <path d={svgPaths.pef4ff00} fill="url(#paint1_linear_5_5446)" fillOpacity="0.2" />
          </g>
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="11.3822" id="filter0_ii_5_5446" width="17.16" x="1.41992" y="6.61963">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="-0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0" />
            <feBlend in2="shape" mode="normal" result="effect1_innerShadow_5_5446" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="0.666667" />
            <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
            <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect1_innerShadow_5_5446" mode="normal" result="effect2_innerShadow_5_5446" />
          </filter>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_5446" x1="9.99992" x2="9.99992" y1="1.99756" y2="18.0019">
            <stop />
            <stop offset="1" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_5_5446" x1="9.99992" x2="9.99992" y1="6.61963" y2="18.0019">
            <stop stopColor="white" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0083 20.0083">
        <g id="Group">
          <g id="Group_2">
            <path d={svgPaths.pd761f00} id="Path" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p3ed03ac0} id="Path_2" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.p37261d60} id="Path_3" stroke="var(--stroke-0, #475569)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialDots11() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Interface, Essential/dots">
      <Group19 />
    </div>
  );
}

function Planilha11() {
  return (
    <div className="bg-[#0f172a] flex-[1_0_0] min-h-px min-w-px relative rounded-[12px]" data-name="Planilha">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex gap-[12px] items-center p-[16px] relative w-full">
          <FolderIllustration11 />
          <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[1.4] min-h-px min-w-px not-italic relative text-[#f1f5f9] text-[14px] whitespace-pre-wrap">Company list</p>
          <InterfaceEssentialDots11 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[12px]" />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full">
      <Planilha8 />
      <Planilha9 />
      <Planilha10 />
      <Planilha11 />
    </div>
  );
}

function Container10() {
  return (
    <div className="bg-[#0f172a] relative rounded-[16px] shrink-0 w-full" data-name="container">
      <div aria-hidden="true" className="absolute border border-[#1e293b] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(2,6,23,0.05)]" />
      <div className="content-stretch flex flex-col gap-[24px] items-start p-[24px] relative w-full">
        <Frame />
        <Frame1 />
        <Frame2 />
      </div>
    </div>
  );
}

function Card5() {
  return (
    <div className="bg-[#1e293b] relative rounded-[16px] shrink-0 w-full" data-name="card">
      <div className="content-stretch flex flex-col items-start p-[4px] relative w-full">
        <Header5 />
        <Container10 />
      </div>
    </div>
  );
}

function WorkArea() {
  return (
    <div className="absolute bg-[#0f172a] content-stretch flex flex-col gap-[24px] items-start left-[100px] overflow-clip px-[32px] py-[24px] top-[80px] w-[1340px]" data-name="Work Area">
      <BreadcrumbGroup />
      <Card />
      <Card1 />
      <Card2 />
      <Card3 />
      <Card4 />
      <Card5 />
    </div>
  );
}

function Component() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Component 11">
      <div className="absolute inset-[-29.17%_-47.06%_-147.06%_-47.06%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46.5882 66.2941">
          <g id="Component 11">
            <circle cx="23.2941" cy="19" id="Ellipse 516" opacity="0.1" r="14.5" stroke="url(#paint0_linear_1_6126)" />
            <g filter="url(#filter0_dddddddi_1_6126)" id="Ellipse 515">
              <circle cx="23.2941" cy="19" fill="var(--fill-0, #2E61FF)" r="11.2941" />
              <circle cx="23.2941" cy="19" fill="url(#paint1_linear_1_6126)" fillOpacity="0.1" r="11.2941" />
            </g>
            <g id="Frame 427321015">
              <circle cx="18.8312" cy="1.9707" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1434" opacity="0.3" r="0.75" />
              <circle cx="10.0441" cy="3.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1435" r="0.75" />
              <circle cx="33.0441" cy="4.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1446" r="0.75" />
              <circle cx="40.0441" cy="9.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1451" opacity="0.3" r="0.75" />
              <circle cx="9.04412" cy="10.75" fill="var(--fill-0, #2E61FF)" fillOpacity="0.7" id="Ellipse 1449" opacity="0.3" r="0.75" />
            </g>
            <g id="IA">
              <path d={svgPaths.p1063c100} fill="var(--fill-0, white)" />
              <path d={svgPaths.p17307780} fill="var(--fill-0, white)" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="59.5882" id="filter0_dddddddi_1_6126" width="46.5882" x="2.98023e-07" y="6.70588">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="12" result="effect1_dropShadow_1_6126" />
              <feOffset dy="24" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="6" result="effect2_dropShadow_1_6126" />
              <feOffset dy="12" />
              <feGaussianBlur stdDeviation="6" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect1_dropShadow_1_6126" mode="normal" result="effect2_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="3" result="effect3_dropShadow_1_6126" />
              <feOffset dy="6" />
              <feGaussianBlur stdDeviation="3" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect2_dropShadow_1_6126" mode="normal" result="effect3_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="erode" radius="1.5" result="effect4_dropShadow_1_6126" />
              <feOffset dy="3" />
              <feGaussianBlur stdDeviation="1.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.02 0" />
              <feBlend in2="effect3_dropShadow_1_6126" mode="normal" result="effect4_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="0.5" result="effect5_dropShadow_1_6126" />
              <feOffset dy="1" />
              <feGaussianBlur stdDeviation="0.5" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect4_dropShadow_1_6126" mode="normal" result="effect5_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect6_dropShadow_1_6126" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0117647 0 0 0 0 0.160784 0 0 0 0 0.321569 0 0 0 0.04 0" />
              <feBlend in2="effect5_dropShadow_1_6126" mode="normal" result="effect6_dropShadow_1_6126" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="effect7_dropShadow_1_6126" />
              <feOffset />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.0588235 0 0 0 0 0.0901961 0 0 0 0 0.164706 0 0 0 1 0" />
              <feBlend in2="effect6_dropShadow_1_6126" mode="normal" result="effect7_dropShadow_1_6126" />
              <feBlend in="SourceGraphic" in2="effect7_dropShadow_1_6126" mode="normal" result="shape" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="-1" />
              <feComposite in2="hardAlpha" k2="-1" k3="1" operator="arithmetic" />
              <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.24 0" />
              <feBlend in2="shape" mode="normal" result="effect8_innerShadow_1_6126" />
            </filter>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_6126" x1="23.2941" x2="23.2941" y1="4" y2="34">
              <stop stopColor="#2E61FF" stopOpacity="0" />
              <stop offset="1" stopColor="#2E61FF" />
            </linearGradient>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_6126" x1="23.2941" x2="23.2941" y1="30.2941" y2="7.70588">
              <stop stopColor="white" stopOpacity="0" />
              <stop offset="1" stopColor="white" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#0f172a] content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <Component />
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path clipRule="evenodd" d={svgPaths.p39ce2c00} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.5 21H13.5" id="Path_3" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MusicAudioBellNotifications() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Music, Audio/Bell, Notifications">
      <Group20 />
    </div>
  );
}

function Button4() {
  return (
    <div className="bg-[#0f172a] content-stretch flex h-[40px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0" data-name="Button">
      <MusicAudioBellNotifications />
    </div>
  );
}

function CircleRedSolid() {
  return (
    <div className="absolute left-[70px] overflow-clip size-[16px] top-[6px]" data-name="circle-red-solid">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#ff6467] border border-[rgba(15,23,42,0.12)] border-solid left-1/2 rounded-[9999px] size-[8px] top-1/2" />
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="container">
      <Button3 />
      <Button4 />
      <CircleRedSolid />
    </div>
  );
}

function Logotype() {
  return (
    <div className="absolute inset-[42.65%_22.8%_42.65%_22.5%]" data-name="logotype">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.8804 5.87683">
        <g id="logotype">
          <path d={svgPaths.p1fa77d80} fill="var(--fill-0, white)" id="Vector" />
          <g id="Group">
            <path d={svgPaths.pe40ba00} fill="var(--fill-0, white)" id="Vector_2" />
            <path d={svgPaths.p1b629600} fill="var(--fill-0, white)" id="Vector_3" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Person() {
  return (
    <div className="absolute bg-[#334155] bottom-0 right-0 rounded-[9999px] size-[16px]" data-name="person">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <div className="absolute h-[64px] left-[-12px] top-[-6px] w-[35px]" data-name="image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
        </div>
        <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-gradient-to-b from-[86.008%] from-[rgba(42,56,73,0)] left-1/2 rounded-[9999px] size-[16px] to-[rgba(42,56,73,0.3)] top-1/2" data-name="filter" />
      </div>
      <div aria-hidden="true" className="absolute border border-[#0f172a] border-solid inset-[-1px] pointer-events-none rounded-[10000px]" />
    </div>
  );
}

function Avatar1() {
  return (
    <div className="bg-[#2e61ff] relative rounded-[9999px] shrink-0 size-[40px]" data-name="avatar">
      <Logotype />
      <Person />
    </div>
  );
}

function Content10() {
  return (
    <div className="content-stretch flex flex-col items-start not-italic relative shrink-0" data-name="content">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#f1f5f9] text-[14px] whitespace-nowrap">
        <p className="leading-[1.4]">Bloxs Capital Partners LTDA</p>
      </div>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.4] relative shrink-0 text-[#94a3b8] text-[12px]">41.847.533/0001-90</p>
    </div>
  );
}

function ArrowsDiagramsArrow7() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Arrows, Diagrams/Arrow">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d="M8 10L12 14L16 10" id="Path" stroke="var(--stroke-0, #94A3B8)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_2" />
        </g>
      </svg>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[12px] items-center p-[8px] relative rounded-[8px] shrink-0" data-name="container">
      <Avatar1 />
      <Content10 />
      <ArrowsDiagramsArrow7 />
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[24px] items-center justify-end min-h-px min-w-px relative">
      <Container11 />
      <div className="bg-[#1e293b] h-[24px] rounded-[9999px] shrink-0 w-[2px]" data-name="divider" />
      <Container12 />
    </div>
  );
}

function Navbar() {
  return (
    <div className="absolute h-[80px] left-[100px] top-0 w-[1340px]" data-name="Navbar">
      <div className="content-stretch flex items-center justify-between overflow-clip px-[32px] py-[16px] relative rounded-[inherit] size-full">
        <Frame30 />
      </div>
      <div aria-hidden="true" className="absolute border-[#1e293b] border-b border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Camada() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Camada_1-2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0001 24">
        <g id="Camada_1-2">
          <path d={svgPaths.p8744780} fill="var(--fill-0, #F1F5F9)" id="Vector" />
          <path d={svgPaths.p2e0a3600} fill="var(--fill-0, #2E61FF)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute content-stretch flex flex-col h-[80px] items-center justify-center left-0 px-[24px] py-[16px] top-0 w-[100px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#1e293b] border-b border-solid inset-0 pointer-events-none" />
      <Camada />
    </div>
  );
}

function InterfaceEssentialHomeClassic() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/home-classic">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Rectangle" />
          <path clipRule="evenodd" d={svgPaths.pf024880} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p32312200} fillRule="evenodd" id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <InterfaceEssentialHomeClassic />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px] text-center">Home</p>
    </div>
  );
}

function SeoSearchGraph() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="SEO/Search, Graph">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Group_2">
            <path d="M16 12.157V9H12.843" id="Path" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p1ecf540} id="Path_2" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M19 5L20 4" id="Path_3" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M20 8H21" id="Path_4" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d="M16 4V3" id="Path_5" stroke="var(--stroke-0, #2E61FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
            <path d={svgPaths.p28699a00} id="Path_6" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.28571" />
          </g>
          <g id="Path_7" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-[#1e293b] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <SeoSearchGraph />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#f1f5f9] text-[12px] text-center">Operações</p>
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <g id="Path" />
          <path d={svgPaths.p1b647048} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p29968a80} fillRule="evenodd" id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p129ae5c0} id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p7859880} id="Path_5" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function MoneyWalletMoney1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Money/Wallet, Money">
      <Group21 />
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <MoneyWalletMoney1 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px] text-center">Carteira</p>
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <path clipRule="evenodd" d={svgPaths.p30859780} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p18659d80} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p189b6c00} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path clipRule="evenodd" d={svgPaths.p2ceff7c0} fillRule="evenodd" id="Path_4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function TechnologySpaceSpaceRocket() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Technology, Space/space-rocket">
      <Group22 />
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <TechnologySpaceSpaceRocket />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px] text-center">Soluções</p>
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-4.17%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.4993 19.4993">
          <g id="Group">
            <path clipRule="evenodd" d={svgPaths.p2d1c8c80} fillRule="evenodd" id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ConstructionToolsToolsWench() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Construction, Tools/tools-wench">
      <Group23 />
    </div>
  );
}

function Button10() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <ConstructionToolsToolsWench />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px] text-center">Tools</p>
    </div>
  );
}

function UserUsers() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="User/Users">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Group">
          <path d={svgPaths.p2c68bbc0} id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <circle cx="9" cy="7" id="Oval" r="4" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe930c00} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p8cf1c80} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Rectangle" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <UserUsers />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px] text-center">Comunidade</p>
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute inset-[-0.02%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.01 24.01">
        <g id="Group">
          <circle cx="12.005" cy="12.0048" id="Oval" r="9.00375" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p24fb6800} id="Path" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p3741d600} id="Path_2" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22e8f380} id="Path_3" stroke="var(--stroke-0, #CBD5E1)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Path_4" />
        </g>
      </svg>
    </div>
  );
}

function InterfaceEssentialQuestionCircle() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Interface, Essential/question-circle">
      <Group24 />
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-[#0f172a] content-stretch flex flex-col gap-[10px] items-center justify-center overflow-clip py-[12px] relative rounded-[8px] shrink-0 w-[84px]" data-name="Button">
      <InterfaceEssentialQuestionCircle />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.4] not-italic relative shrink-0 text-[#cbd5e1] text-[12px] text-center">Ajuda</p>
    </div>
  );
}

function Main() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[14px] items-start left-[8px] top-[96px] w-[84px]" data-name="main">
      <Button6 />
      <Button7 />
      <Button8 />
      <Button9 />
      <Button10 />
      <Button11 />
      <Button12 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="bg-[#0f172a] border-[#1e293b] border-r border-solid h-[2347px] overflow-clip pointer-events-auto sticky top-0 w-[100px]" data-name="Sidebar">
      <Button5 />
      <div className="absolute bg-[#2e61ff] h-[75px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[185px] w-[3px]" data-name="state" />
      <Main />
    </div>
  );
}

export default function Component4PaginaDaOperacaoDeNdrPublicoDarkMode() {
  return (
    <div className="bg-[#0f172a] overflow-clip relative rounded-[24px] size-full" data-name="4. Página da operação de NDR | Público [Dark Mode]">
      <WorkArea />
      <Navbar />
      <div className="absolute bottom-0 h-[2347px] left-0 pointer-events-none top-0">
        <Sidebar />
      </div>
    </div>
  );
}