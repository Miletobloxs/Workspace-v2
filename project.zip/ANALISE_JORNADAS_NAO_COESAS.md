# 🎯 ANÁLISE: JORNADAS NÃO COESAS

**Data:** 19/02/2026  
**Status:** ⚠️ **DUPLICAÇÃO IDENTIFICADA**

---

## ❌ PROBLEMA: PÁGINAS DUPLICADAS

### **1. `/workspace/dashboard` - WorkspaceDashboard**
**Propósito Atual:** Dashboard geral do workspace
- ✅ Stats (operações, membros, volume, matches)
- ✅ Quick actions
- ✅ Atividades recentes
- ✅ Banner de completude

**Design:** Dark mode (#212121)

---

### **2. `/operacoes-v2` - OperationsListV2**
**Propósito Atual:** Lista de operações do SELL-SIDE
- ✅ Stats (total, volume, ativas, liquidação)
- ✅ Filtros (busca, status, tipo)
- ✅ Tabela de operações
- ✅ Gerenciamento (criar, editar, deletar)

**Design:** Dark mode (#212121)

---

### **3. `/operacoes` - OperationsList (BUY-SIDE)**
**Propósito Atual:** Marketplace de oportunidades para BUY-SIDE
- ✅ Tabs (Todos, Oferta Pública, Viabilidade)
- ✅ Cards de operações
- ✅ Filtros avançados
- ✅ Manifestar interesse / Investir

**Design:** Light mode (bg-slate-50) com Sidebar

---

## 🤔 CONFUSÃO IDENTIFICADA

### **Problema 1: Duas páginas de "Operações"**
```
/operacoes-v2    → Lista de operações (Sell-Side?)
/operacoes       → Marketplace (Buy-Side?)
```
**❌ Não está claro qual usar e quando**

### **Problema 2: Dashboard duplicado**
```
/workspace/dashboard → Dashboard genérico
/operacoes-v2        → Também tem dashboard (stats)
```
**❌ Dashboard stats aparecem em 2 lugares**

### **Problema 3: Designs diferentes**
```
/workspace/dashboard → Dark (#212121)
/operacoes-v2       → Dark (#212121)
/operacoes          → Light (bg-slate-50) + Sidebar
```
**❌ Inconsistência visual**

---

## 🎯 ARQUITETURA PROPOSTA (COESA)

### **CONCEITO:**
A Bloxs tem **2 PERSONAS** distintas com jornadas diferentes:

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  👔 SELL-SIDE (Emissor/Estruturador)           │
│     "Quero CRIAR e GERENCIAR operações"        │
│                                                 │
│  💼 BUY-SIDE (Investidor)                      │
│     "Quero ENCONTRAR e INVESTIR"               │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 📋 PROPOSTA DE ESTRUTURA

### **🏠 PÁGINA PRINCIPAL (após login):**

#### **Opção A: Rota `/home` ou `/workspace`**
**Conteúdo:** Escolha de persona (se não definido) OU Dashboard específico da persona

```tsx
if (userPersona === null) {
  // Mostrar seleção de persona
  return <PersonaSelection />
}

if (userPersona === "sell-side") {
  return <SellSideDashboard />
}

if (userPersona === "buy-side") {
  return <BuySideDashboard />
}
```

---

## 🔵 JORNADA SELL-SIDE (Emissor)

### **Dashboard:** `/workspace/dashboard` (atual WorkspaceDashboard)

**Mantém:**
- ✅ Stats (operações criadas, volume, status)
- ✅ Quick Actions:
  - Nova Operação
  - Solicitar Cotação
  - Convidar Membros
  - Configurações
- ✅ Atividades recentes

### **Operações:** `/workspace/operacoes` (renomear OperationsListV2)

**Propósito:** GERENCIAR operações que EU CRIEI
- ✅ Lista/Tabela das MINHAS operações
- ✅ Criar nova operação
- ✅ Editar operações existentes
- ✅ Ver status (ativa, liquidando, liquidada)
- ✅ Ver investidores interessados

### **Fluxo:**
```
Dashboard (visão geral)
   ↓
[Nova Operação] → /workspace/operacoes/criar
   ↓
Lista de Operações → /workspace/operacoes
   ↓
Detalhes → /workspace/operacoes/:id
```

---

## 🟢 JORNADA BUY-SIDE (Investidor)

### **Dashboard:** `/marketplace` ou `/oportunidades`

**Conteúdo:**
- ✅ Hero banner
- ✅ Tabs (Todos, Oferta Pública, Viabilidade)
- ✅ Cards de oportunidades
- ✅ Filtros (setor, volume, risco)
- ✅ Busca

**Propósito:** DESCOBRIR oportunidades de investimento

### **Operações:** MESMA PÁGINA (marketplace)

**Não precisa de página separada!**
- O marketplace JÁ É a lista de operações
- Cards já mostram tudo que o investidor precisa

### **Fluxo:**
```
Marketplace (descoberta)
   ↓
[Saiba Mais] → /marketplace/:id (detalhes)
   ↓
[Investir] → Modal ou página de investimento
```

---

## 🗺️ NOVA ESTRUTURA DE ROTAS

### **🔐 AUTH (público):**
```
/ ou /cadastro           → QuickRegister
/login                   → Login
```

### **🎭 ONBOARDING (pós-cadastro):**
```
/onboarding/persona      → Escolher Sell ou Buy
/onboarding/sell-side    → OnboardingSellSide (3 etapas)
/onboarding/buy-side     → OnboardingBuySide (3 etapas)
/onboarding/documentos   → DocumentUpload
/onboarding/dealmatch    → Dealmatch (se Buy-Side)
```

### **👔 SELL-SIDE WORKSPACE:**
```
/workspace/dashboard            → WorkspaceDashboard (stats + actions)
/workspace/operacoes            → OperationsListV2 (MINHAS operações)
/workspace/operacoes/criar      → Nova operação
/workspace/operacoes/:id        → Detalhes da operação
/workspace/configuracoes        → WorkspaceSettings
/workspace/dealmatch            → Dealmatch (configurar perfil)

/cotacao/etapa-1                → QuotationStep1
/cotacao/etapa-2-estruturacao   → QuotationStep2Estruturacao
/cotacao/etapa-3                → QuotationStep3
/cotacao/sucesso                → QuotationSuccess
```

### **💼 BUY-SIDE MARKETPLACE:**
```
/marketplace                    → OperationsList (descoberta)
/marketplace/:id                → OperationDetails (detalhes)
/marketplace/favoritos          → Operações favoritadas

/carteira                       → Carteira (investimentos)
/solucoes                       → Soluções
/tools                          → Tools
/comunidade                     → Comunidade
```

### **🔄 NAVEGAÇÃO COMPARTILHADA:**
```
/home                           → Redireciona baseado na persona
/perfil                         → Perfil do usuário
/notificacoes                   → Notificações
/ajuda                          → Central de ajuda
```

---

## 🎨 DESIGN SYSTEM UNIFICADO

### **Sell-Side (Workspace):**
```css
Background: #212121 (dark)
Accent: #3482ff (azul)
Sidebar: Não (navegação top)
```

### **Buy-Side (Marketplace):**
```css
Background: bg-slate-50 (light) / dark:bg-slate-950
Accent: #2e61ff (azul)
Sidebar: Sim (navegação lateral)
```

**DECISÃO:** Manter designs diferentes por persona é OK!
- Sell-Side = workspace/dashboard vibe (escuro)
- Buy-Side = marketplace/descoberta vibe (claro com sidebar)

---

## 📊 COMPARAÇÃO: ANTES vs DEPOIS

### **ANTES (Confuso):**
```
❌ /workspace/dashboard (genérico)
❌ /operacoes-v2 (Sell? Buy? Ambos?)
❌ /operacoes (Buy-side marketplace)
❌ Stats duplicados em 2 lugares
❌ Propósito não claro
```

### **DEPOIS (Coeso):**
```
✅ /workspace/* = SELL-SIDE (criar/gerenciar)
✅ /marketplace/* = BUY-SIDE (descobrir/investir)
✅ Cada rota tem propósito claro
✅ Zero duplicação
✅ Jornadas separadas por persona
```

---

## 🛠️ MUDANÇAS NECESSÁRIAS

### **1. Renomear Rotas:**

```tsx
// ANTES
/workspace/dashboard      → WorkspaceDashboard (genérico)
/operacoes-v2            → OperationsListV2 (confuso)
/operacoes               → OperationsList (buy-side)

// DEPOIS
/workspace/dashboard      → SellSideDashboard (específico)
/workspace/operacoes      → SellSideOperationsList (minhas ops)
/marketplace             → BuySideMarketplace (descoberta)
```

### **2. Atualizar WorkspaceDashboard:**

**Quick Action "Nova Operação":**
```tsx
// ANTES
action: () => navigate("/operacoes-v2")

// DEPOIS
action: () => navigate("/workspace/operacoes/criar")
```

### **3. Adicionar Rota de Persona:**

```tsx
// Nova rota
{
  path: "/home",
  Component: HomeRouter, // Redireciona baseado na persona
}

// HomeRouter.tsx
export function HomeRouter() {
  const { user } = useAuth();
  
  if (!user) return <Navigate to="/login" />;
  
  if (user.persona === "sell-side") {
    return <Navigate to="/workspace/dashboard" />;
  }
  
  if (user.persona === "buy-side") {
    return <Navigate to="/marketplace" />;
  }
  
  // Se não tem persona definida
  return <Navigate to="/onboarding/persona" />;
}
```

### **4. Atualizar Sidebar (Buy-Side):**

```tsx
const navigation = [
  { name: "Marketplace", href: "/marketplace", icon: SearchIcon },
  { name: "Carteira", href: "/carteira", icon: WalletIcon },
  { name: "Soluções", href: "/solucoes", icon: LayersIcon },
  { name: "Tools", href: "/tools", icon: ToolsIcon },
  { name: "Comunidade", href: "/comunidade", icon: UsersIcon },
]
```

---

## ✅ PROPOSTA FINAL

### **REMOVER:**
```
❌ /operacoes-v2 (rota confusa)
```

### **RENOMEAR:**
```
/workspace/dashboard → Manter (é Sell-Side específico)
/operacoes          → /marketplace (mais claro)
```

### **ADICIONAR:**
```
✅ /workspace/operacoes (lista Sell-Side)
✅ /workspace/operacoes/criar
✅ /home (router inteligente)
```

### **MANTER:**
```
✅ /workspace/dashboard (Sell-Side)
✅ /marketplace (Buy-Side, ex /operacoes)
✅ /carteira, /solucoes, /tools, /comunidade (Buy-Side)
```

---

## 🎯 RESULTADO ESPERADO

### **Clareza Total:**
```
👔 SELL-SIDE:
   Login → /workspace/dashboard → "Minhas Operações"
   
💼 BUY-SIDE:
   Login → /marketplace → "Oportunidades"
```

### **Zero Duplicação:**
- Dashboard único por persona
- Stats específicos do contexto
- Ações adequadas ao papel

### **Jornadas Coesas:**
- Sell-Side: CRIAR → GERENCIAR → ACOMPANHAR
- Buy-Side: DESCOBRIR → ANALISAR → INVESTIR

---

## 🤔 PRÓXIMO PASSO

**Preciso da sua aprovação:**

1. ✅ **Renomear `/operacoes` para `/marketplace`?**
2. ✅ **Remover `/operacoes-v2`?**
3. ✅ **Criar `/workspace/operacoes` (Sell-Side)?**
4. ✅ **Adicionar router inteligente `/home`?**

**Ou prefere:**
- Manter estrutura atual e apenas melhorar documentação?
- Outra proposta de arquitetura?

---

**Aguardando direcionamento para implementar a arquitetura coesa!** 🚀

---

**Criado por:** Figma Make Assistant  
**Data:** 19/02/2026  
**Status:** ⏳ Aguardando Aprovação
