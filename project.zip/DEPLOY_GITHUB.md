# 📤 Guia de Deploy para GitHub

## Como subir o código para o repositório Workspace-v2

### Opção 1: Usando o Script Automático (Recomendado) ⚡

Criamos um script que automatiza todo o processo. Siga estes passos:

1. **Abra o terminal** na pasta raiz do projeto

2. **Dê permissão de execução ao script:**
   ```bash
   chmod +x deploy.sh
   ```

3. **Execute o script:**
   ```bash
   ./deploy.sh
   ```

4. **Autentique-se** quando solicitado (se necessário):
   - Username: Miletobloxs
   - Password: Use seu Personal Access Token do GitHub (não a senha)

#### Como criar um Personal Access Token:
1. Acesse: https://github.com/settings/tokens
2. Clique em "Generate new token" → "Generate new token (classic)"
3. Dê um nome (ex: "Workspace V2")
4. Selecione os escopos: `repo` (marque todos)
5. Clique em "Generate token"
6. **Copie o token** (você só verá ele uma vez!)
7. Use esse token como senha quando o git solicitar

---

### Opção 2: Passo a Passo Manual 🔧

Se preferir fazer manualmente, siga estes comandos:

#### 1. Inicializar o Git (se ainda não foi feito)
```bash
git init
```

#### 2. Adicionar o remote do GitHub
```bash
git remote add origin https://github.com/Miletobloxs/Workspace-v2.git
```

#### 3. Adicionar todos os arquivos
```bash
git add .
```

#### 4. Criar o commit
```bash
git commit -m "feat: implementação completa do Workspace V2 da Bloxs

🎯 Funcionalidades implementadas (100%):
- ✅ Sistema de cadastro e autenticação
- ✅ Onboarding personalizado por persona (Buy-side/Sell-side)
- ✅ Workspace segmentado com dashboard personalizado
- ✅ Sistema completo de operações
- ✅ Fluxo de cotação
- ✅ Suporte total a dark mode

📊 Status: 100% funcional, zero erros"
```

#### 5. Configurar a branch principal
```bash
git branch -M main
```

#### 6. Fazer push para o GitHub
```bash
git push -u origin main
```

---

### ⚠️ Possíveis Problemas e Soluções

#### Erro: "Permission denied"
**Solução:** Você precisa autenticar. Configure o credential helper:
```bash
git config --global credential.helper store
git push -u origin main
```

#### Erro: "Repository not found"
**Solução:** Verifique se o repositório existe e se você tem acesso:
```bash
git remote -v
# Deve mostrar: https://github.com/Miletobloxs/Workspace-v2.git
```

#### Erro: "Authentication failed"
**Solução:** Use um Personal Access Token em vez da senha:
1. Crie um token em: https://github.com/settings/tokens
2. Use o token como senha quando solicitado

#### Erro: "Updates were rejected"
**Solução:** O repositório remoto tem conteúdo diferente. Force o push (cuidado!):
```bash
git push -u origin main --force
```

---

### ✅ Verificar se deu certo

Após o push, acesse:
**https://github.com/Miletobloxs/Workspace-v2**

Você deve ver:
- ✅ Todos os arquivos do projeto
- ✅ README.md formatado
- ✅ Seu commit aparecendo no histórico
- ✅ Badge "main" mostrando a branch principal

---

### 📋 O que foi preparado

Para facilitar o deploy, criamos:

1. **`.gitignore`** - Ignora arquivos desnecessários (node_modules, etc.)
2. **`README.md`** - Documentação completa e atualizada do projeto
3. **`deploy.sh`** - Script automático para deploy
4. **Este guia** - Instruções detalhadas em português

---

### 🔄 Próximos Commits

Após o primeiro push, para enviar novas alterações:

```bash
# Adicionar alterações
git add .

# Criar commit descritivo
git commit -m "feat: descrição da alteração"

# Enviar para o GitHub
git push
```

---

### 📞 Precisa de Ajuda?

Se encontrar algum problema:

1. **Verifique se o Git está instalado:**
   ```bash
   git --version
   ```

2. **Verifique se você está na pasta correta:**
   ```bash
   pwd  # Deve mostrar o caminho do projeto
   ls   # Deve mostrar os arquivos do projeto
   ```

3. **Verifique o status do Git:**
   ```bash
   git status
   ```

4. **Veja os remotes configurados:**
   ```bash
   git remote -v
   ```

---

**🎉 Boa sorte com o deploy!**
