# 🗺️ MAPA DE JORNADAS - BLOXS PLATFORM

## Visualização Completa dos Fluxos

---

## 📍 JORNADA ATUAL vs PROPOSTA

### ATUAL (Fragmentado)
```
┌─────────────────────────────────────────────────────────────┐
│                    ONBOARDING (Confuso)                      │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  1️⃣  Upload Docs          (/)                                │
│       └─ Navbar única                                        │
│       └─ Preview lado direito                                │
│       └─ Progress bar (4 steps)                              │
│                                                               │
│  2️⃣  Personalizar         (/workspace/personalizar)          │
│       └─ Navbar diferente                                    │
│       └─ Preview lado direito                                │
│       └─ Step 1 de 3                                         │
│                                                               │
│  3️⃣  Dealmatch            (/workspace/dealmatch)             │
│       └─ Mesma navbar                                        │
│       └─ Step 3 de 3 (CADÊ O STEP 2?! ⚠️)                    │
│                                                               │
│  ❓ E AGORA? Usuário não sabe para onde ir                   │
│       └─ Sem transição clara                                 │
│       └─ Sem página de sucesso                               │
│                                                               │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                 PLATAFORMA (Múltiplas Entradas)              │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  /operacoes                                                  │
│  /operacoes/gerenciar                                        │
│  /operacoes/:id                                              │
│  /workspace/configuracoes                                    │
│  /home, /carteira, /solucoes... (todas vão para /operacoes) │
│                                                               │
│  Problema: Sem hierarquia clara                             │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### PROPOSTA (Estruturado)
```
┌──────────────────────────────────────────────────────────────────────┐
│                   JORNADA COMPLETA - USUÁRIO NOVO                     │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🎯 OBJETIVO: Onboarding → Primeiro Valor em < 5min                  │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  FASE 1: AUTENTICAÇÃO                                        │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  1. /login                                                   │    │
│  │     └─ Email + Senha                                         │    │
│  │     └─ "Esqueci senha"                                       │    │
│  │     └─ "Criar conta" → vai para /registro                   │    │
│  │                                                               │    │
│  │  2. /registro                                                │    │
│  │     └─ Dados básicos (Nome, Email, Senha)                   │    │
│  │     └─ Verificação de email                                 │    │
│  │     └─ Após verificado → /onboarding/bem-vindo              │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  FASE 2: ONBOARDING GUIADO (Layout dedicado)                │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  1. /onboarding/bem-vindo                                    │    │
│  │     └─ Video explicativo (30s)                               │    │
│  │     └─ "O que você pode fazer na Bloxs"                     │    │
│  │     └─ CTA: "Começar" → /onboarding/documentos              │    │
│  │                                                               │    │
│  │  2. /onboarding/documentos (Step 1/5) ⚪⚪⚪⚪⚪              │    │
│  │     └─ Upload: Frente, Verso, Comprovante                   │    │
│  │     └─ Preview em tempo real                                 │    │
│  │     └─ Validação automática                                  │    │
│  │     └─ "Pular por enquanto" (draft)                         │    │
│  │     └─ CTA: "Próximo" → /onboarding/empresa                 │    │
│  │                                                               │    │
│  │  3. /onboarding/empresa (Step 2/5) ⚫⚪⚪⚪⚪                 │    │
│  │     └─ Nome da empresa                                       │    │
│  │     └─ CNPJ (com validação)                                  │    │
│  │     └─ Setor de atuação                                      │    │
│  │     └─ Tipo (Buy Side / Sell Side)                          │    │
│  │     └─ CTA: "Próximo" → /onboarding/personalizar            │    │
│  │                                                               │    │
│  │  4. /onboarding/personalizar (Step 3/5) ⚫⚫⚪⚪⚪            │    │
│  │     └─ Logo do workspace                                     │    │
│  │     └─ Foto de capa                                          │    │
│  │     └─ Descrição (200 chars)                                 │    │
│  │     └─ Preview ao vivo                                       │    │
│  │     └─ CTA: "Próximo" → /onboarding/dealmatch               │    │
│  │                                                               │    │
│  │  5. /onboarding/dealmatch (Step 4/5) ⚫⚫⚫⚪⚪               │    │
│  │     └─ Interesses de investimento                            │    │
│  │     └─ Perfil de risco                                       │    │
│  │     └─ Localização preferida                                 │    │
│  │     └─ Requisitos específicos                                │    │
│  │     └─ CTA: "Próximo" → /onboarding/convites                │    │
│  │                                                               │    │
│  │  6. /onboarding/convites (Step 5/5) ⚫⚫⚫⚫⚪                │    │
│  │     └─ "Convide sua equipe" (opcional)                      │    │
│  │     └─ Lista de emails                                       │    │
│  │     └─ Definir permissões                                    │    │
│  │     └─ "Pular por enquanto"                                 │    │
│  │     └─ CTA: "Finalizar" → /onboarding/sucesso               │    │
│  │                                                               │    │
│  │  7. /onboarding/sucesso (Step 5/5) ⚫⚫⚫⚫⚫                 │    │
│  │     └─ 🎉 "Bem-vindo à Bloxs!"                             │    │
│  │     └─ Tour rápido (opcional)                                │    │
│  │     └─ Atalhos principais                                    │    │
│  │     └─ CTA: "Explorar plataforma" → /dashboard              │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  FASE 3: PRIMEIRO VALOR                                      │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  /dashboard (Página inicial pós-onboarding)                 │    │
│  │     └─ Widget: "Operações recomendadas para você" (3)       │    │
│  │     └─ Widget: "Complete seu perfil" (checklist)            │    │
│  │     └─ Widget: "Convide membros" (se ainda não convidou)   │    │
│  │     └─ Widget: "Atividades recentes"                         │    │
│  │     └─ CTA primário: "Explorar operações"                   │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                        │
└──────────────────────────────────────────────────────────────────────┘


┌──────────────────────────────────────────────────────────────────────┐
│                JORNADA PRINCIPAL - USUÁRIO EXISTENTE                  │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🎯 OBJETIVO: Encontrar → Avaliar → Agir em < 2min                   │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  HUB PRINCIPAL: /dashboard                                   │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Sidebar sempre visível:                                     │    │
│  │  ├─ 🏠 Dashboard                                             │    │
│  │  ├─ 🔄 Operações ────┐                                       │    │
│  │  ├─ 💼 Carteira      │ Menu principal                        │    │
│  │  ├─ 🚀 Soluções      │                                       │    │
│  │  ├─ 🔧 Tools         │                                       │    │
│  │  ├─ 👥 Comunidade    │                                       │    │
│  │  └─ ❓ Ajuda ────────┘                                       │    │
│  │                                                               │    │
│  │  Header:                                                      │    │
│  │  ├─ 🔍 Busca global (Cmd+K)                                 │    │
│  │  ├─ 🔔 Notificações (badge de contador)                     │    │
│  │  └─ 👤 Workspace menu (dropdown)                            │    │
│  │                                                               │    │
│  │  Conteúdo do Dashboard:                                      │    │
│  │  ├─ Cards de métricas (4 colunas)                           │    │
│  │  ├─ Gráfico de atividade                                     │    │
│  │  ├─ Lista de operações recentes                              │    │
│  │  └─ Atividades da equipe                                     │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  EXPLORAR OPERAÇÕES: /operacoes                              │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Ações principais:                                           │    │
│  │  ├─ Filtrar (modal lateral)                                 │    │
│  │  ├─ Buscar (campo de texto)                                 │    │
│  │  ├─ Ordenar (dropdown)                                       │    │
│  │  └─ Visualizar (grid/lista)                                 │    │
│  │                                                               │    │
│  │  Tabs:                                                        │    │
│  │  ├─ Todas (default)                                          │    │
│  │  ├─ Oferta Pública                                           │    │
│  │  ├─ Consulta de Viabilidade ⭐                              │    │
│  │  └─ Favoritas ❤️                                            │    │
│  │                                                               │    │
│  │  Grid de cards (3 colunas):                                 │    │
│  │  └─ Card da operação                                         │    │
│  │      ├─ Avatar do Sell Side                                  │    │
│  │      ├─ Título + Badges                                      │    │
│  │      ├─ Métricas (Volume, Prazo, Remuneração)               │    │
│  │      ├─ Botão: "Saiba mais" → /operacoes/:id               │    │
│  │      └─ Ícone: ❤️ Favoritar                                 │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  DETALHES DA OPERAÇÃO: /operacoes/:id                       │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Breadcrumb: Dashboard > Operações > Detalhes               │    │
│  │                                                               │    │
│  │  Hero Section:                                                │    │
│  │  ├─ Avatar + Nome da empresa                                 │    │
│  │  ├─ Tipo de operação (badge)                                 │    │
│  │  ├─ Descrição                                                 │    │
│  │  └─ CTAs: [Agendar conversa] [Tenho interesse]              │    │
│  │                                                               │    │
│  │  Tabs de conteúdo:                                           │    │
│  │  ├─ 📄 Teaser (default)                                     │    │
│  │  │   ├─ Informações básicas                                  │    │
│  │  │   ├─ Detalhes da operação (grid)                         │    │
│  │  │   ├─ Garantias (cards)                                    │    │
│  │  │   └─ Highlights                                           │    │
│  │  │                                                            │    │
│  │  ├─ 📊 Investment Deck                                      │    │
│  │  │   └─ Visualizador de slides                               │    │
│  │  │       ├─ Navegação (< >)                                  │    │
│  │  │       ├─ Fullscreen                                       │    │
│  │  │       ├─ Download                                         │    │
│  │  │       └─ Contador (01/40)                                 │    │
│  │  │                                                            │    │
│  │  └─ 📁 Data Room                                            │    │
│  │      └─ Grid de arquivos                                     │    │
│  │          ├─ Preview                                           │    │
│  │          ├─ Download individual                               │    │
│  │          └─ Baixar tudo                                       │    │
│  │                                                               │    │
│  │  Sidebar direita:                                            │    │
│  │  └─ Atividades recentes                                      │    │
│  │      ├─ Quem acessou                                         │    │
│  │      ├─ Downloads                                             │    │
│  │      └─ Interesses manifestados                              │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  AÇÃO: "Tenho interesse" → Modal                            │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  1. Modal de confirmação abre                                │    │
│  │  2. Formulário rápido:                                       │    │
│  │     ├─ Volume de interesse (R$)                              │    │
│  │     ├─ Prazo desejado (meses)                                │    │
│  │     ├─ Comentário opcional (texto)                           │    │
│  │     └─ Anexar documentos (opcional)                          │    │
│  │                                                               │    │
│  │  3. CTAs:                                                     │    │
│  │     ├─ "Cancelar"                                            │    │
│  │     └─ "Enviar interesse" → Success toast                   │    │
│  │                                                               │    │
│  │  4. Após envio:                                              │    │
│  │     ├─ Toast: "✅ Interesse enviado com sucesso!"           │    │
│  │     ├─ Badge "Interesse manifestado" aparece na operação    │    │
│  │     └─ Notificação enviada ao Sell Side                     │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                        │
└──────────────────────────────────────────────────────────────────────┘


┌──────────────────────────────────────────────────────────────────────┐
│              JORNADA DE GERENCIAMENTO - SELL SIDE                     │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🎯 OBJETIVO: Listar → Gerenciar → Acompanhar Resultados             │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  MINHAS OPERAÇÕES: /operacoes/gerenciar                     │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Header:                                                      │    │
│  │  └─ Botão: "➕ Listar nova operação" (destaque)            │    │
│  │                                                               │    │
│  │  Overview (4 cards):                                         │    │
│  │  ├─ Em consulta de viabilidade                               │    │
│  │  │   └─ R$ 1.2M | -3 deals | Progress bar                   │    │
│  │  ├─ Buy Sides engajados                                      │    │
│  │  │   └─ 24 instituições | Avatars empilhados                │    │
│  │  ├─ Concluídos                                               │    │
│  │  │   └─ R$ 10M | 5 deals | Gráfico de pizza                 │    │
│  │  └─ Tempo médio das operações                                │    │
│  │      └─ 12 dias | Mini bar chart                             │    │
│  │                                                               │    │
│  │  Gráfico:                                                     │    │
│  │  └─ Acessos nos últimos 30 dias                              │    │
│  │      └─ Line chart interativo (Recharts)                     │    │
│  │                                                               │    │
│  │  Tabela de operações:                                        │    │
│  │  ├─ Tabs: Em andamento | Encerradas | Rascunhos             │    │
│  │  ├─ Colunas:                                                  │    │
│  │  │   ├─ Operação (ID + Nome)                                 │    │
│  │  │   ├─ Volume                                               │    │
│  │  │   ├─ Setor                                                │    │
│  │  │   ├─ Status (badge colorido)                              │    │
│  │  │   ├─ Data de publicação                                   │    │
│  │  │   └─ Ações (⋮ menu)                                       │    │
│  │  ├─ Ações em linha:                                          │    │
│  │  │   ├─ Editar                                               │    │
│  │  │   ├─ Ver detalhes                                         │    │
│  │  │   ├─ Pausar/Retomar                                       │    │
│  │  │   ├─ Encerrar                                             │    │
│  │  │   └─ Excluir (com confirmação)                            │    │
│  │  └─ Paginação: 1 de 6                                        │    │
│  │                                                               │    │
│  │  Sidebar direita:                                            │    │
│  │  └─ 🕐 Histórico recente                                    │    │
│  │      ├─ XP Asset solicitou acesso                            │    │
│  │      ├─ BTG baixou investment deck                           │    │
│  │      ├─ Bradesco manifestou interesse                        │    │
│  │      └─ Itaú baixou Data Room                                │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  CRIAR OPERAÇÃO: /operacoes/nova (Wizard)                   │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Step 1/4: Informações básicas                               │    │
│  │  ├─ Nome da operação                                         │    │
│  │  ├─ Tipo (dropdown)                                          │    │
│  │  ├─ Setor                                                     │    │
│  │  └─ Descrição curta                                          │    │
│  │                                                               │    │
│  │  Step 2/4: Detalhes financeiros                              │    │
│  │  ├─ Volume (R$)                                              │    │
│  │  ├─ Prazo (meses)                                            │    │
│  │  ├─ Remuneração                                              │    │
│  │  ├─ Perfil de risco                                          │    │
│  │  └─ Possíveis instrumentos                                   │    │
│  │                                                               │    │
│  │  Step 3/4: Garantias                                         │    │
│  │  └─ Adicionar garantias (repeater)                           │    │
│  │      ├─ Tipo                                                  │    │
│  │      ├─ Valor                                                │    │
│  │      └─ Status                                               │    │
│  │                                                               │    │
│  │  Step 4/4: Documentos                                        │    │
│  │  ├─ Upload Teaser (PDF)                                      │    │
│  │  ├─ Upload Investment Deck (PDF/PPT)                         │    │
│  │  └─ Upload Data Room (múltiplos)                             │    │
│  │                                                               │    │
│  │  Opções finais:                                              │    │
│  │  ├─ [Salvar como rascunho]                                  │    │
│  │  └─ [Publicar operação] → Success + Redirect                │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                        │
└──────────────────────────────────────────────────────────────────────┘


┌──────────────────────────────���───────────────────────────────────────┐
│           JORNADA DE CONFIGURAÇÕES - ADMIN DO WORKSPACE               │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🎯 OBJETIVO: Gerenciar → Configurar → Controlar                     │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  CONFIGURAÇÕES: /workspace/configuracoes                     │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Acesso via:                                                  │    │
│  │  ├─ Dropdown do workspace (header)                           │    │
│  │  └─ Opção "⚙️ Configurações"                                │    │
│  │                                                               │    │
│  │  Layout:                                                      │    │
│  │  ├─ Sidebar esquerda (navegação vertical)                   │    │
│  │  │   ├─ 🏢 Dados da empresa                                 │    │
│  │  │   ├─ 👥 Membros (ativo)                                  │    │
│  │  │   ├─ 🎯 Dealmatch                                        │    │
│  │  │   ├─ 🔒 Segurança                                        │    │
│  │  │   ├─ 💳 Planos & Pagamento                              │    │
│  │  │   └─ 📊 Analytics                                        │    │
│  │  │                                                            │    │
│  │  └─ Conteúdo principal (área grande)                        │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                            ⬇                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  MEMBROS: /workspace/configuracoes/membros                   │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Header da empresa:                                          │    │
│  │  ├─ Banner editável                                          │    │
│  │  ├─ Logo grande (120x120) com badge verificado              │    │
│  │  ├─ Nome + CNPJ                                              │    │
│  │  └─ Botão editar                                             │    │
│  │                                                               │    │
│  │  Seção: Membros do workspace                                 │    │
│  │  ├─ Botão: "➕ Adicionar membros"                           │    │
│  │  ├─ Campo de busca                                           │    │
│  │  └─ Tabela:                                                  │    │
│  │      ├─ Membro (avatar + nome)                               │    │
│  │      ├─ Permissão (Dono/Admin/Membro/Visualizador)          │    │
│  │      ├─ Status (Ativo/Desativado)                            │    │
│  │      ├─ Último acesso                                        │    │
│  │      └─ Ações (✏️ Editar)                                   │    │
│  │                                                               │    │
│  │  Seção: Solicitações de acesso                               │    │
│  │  ├─ Campo de busca                                           │    │
│  │  └─ Tabela:                                                  │    │
│  │      ├─ Solicitante (avatar + nome)                          │    │
│  │      ├─ Status (Pendente/Aceito/Rejeitado)                  │    │
│  │      ├─ Data de solicitação                                  │    │
│  │      ├─ Decisor (quem aceitou/rejeitou)                     │    │
│  │      └─ Ações:                                               │    │
│  │          ├─ [Gerenciar] → Modal                              │    │
│  │          │   ├─ Ver perfil do solicitante                    │    │
│  │          │   ├─ Definir permissão                            │    │
│  │          │   └─ [Aceitar] ou [Rejeitar]                     │    │
│  │          └─ Após ação → Toast de confirmação                │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                        │
└──────────────────────────────────────────────────────────────────────┘


┌──────────────────────────────────────────────────────────────────────┐
│                    JORNADA DE BUSCA UNIVERSAL                         │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🎯 OBJETIVO: Encontrar Qualquer Coisa em < 3 segundos               │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  BUSCA GLOBAL: Cmd+K (⌘K ou Ctrl+K)                         │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Modal centralizado (overlay):                               │    │
│  │  ├─ Campo de busca com foco automático                      │    │
│  │  ├─ Placeholder: "Buscar operações, membros, arquivos..."   │    │
│  │  └─ Ícone: 🔍                                               │    │
│  │                                                               │    │
│  │  Resultados agrupados:                                       │    │
│  │                                                               │    │
│  │  📄 Operações (3 resultados)                                │    │
│  │  ├─ BS2#001 - Neialy Lima                                   │    │
│  │  ├─ BS2#002 - Caio Paixão                                   │    │
│  │  └─ Ver todos resultados (12) →                             │    │
│  │                                                               │    │
│  │  👥 Membros (2 resultados)                                  │    │
│  │  ├─ Lucas Ayres                                              │    │
│  │  └─ Jessica Mota                                             │    │
│  │                                                               │    │
│  │  📁 Arquivos (4 resultados)                                 │    │
│  │  ├─ Investment_Deck_BS2.pdf                                  │    │
│  │  ├─ Teaser_Operacao.pdf                                      │    │
│  │  ├─ Cronograma_Fisico.xlsx                                   │    │
│  │  └─ Ver todos arquivos (24) →                               │    │
│  │                                                               │    │
│  │  ⚡ Ações rápidas                                            │    │
│  │  ├─ Nova operação                                            │    │
│  │  ├─ Adicionar membro                                         │    │
│  │  ├─ Configurações                                            │    │
│  │  └─ Ajuda                                                     │    │
│  │                                                               │    │
│  │  Footer:                                                      │    │
│  │  └─ Dicas: ↑↓ navegar | Enter selecionar | Esc fechar      │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                        │
└──────────────────────────────────────────────────────────────────────┘


┌──────────────────────────────────────────────────────────────────────┐
│                    JORNADA DE NOTIFICAÇÕES                            │
├──────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🎯 OBJETIVO: Manter Usuário Informado e Engajado                    │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  CENTRO DE NOTIFICAÇÕES: Ícone 🔔 no Header                │    │
│  ├─────────────────────────────────────────────────────────────┤    │
│  │                                                               │    │
│  │  Badge: Contador de não-lidas (vermelho)                    │    │
│  │                                                               │    │
│  │  Ao clicar → Dropdown (400px):                              │    │
│  │                                                               │    │
│  │  Header:                                                      │    │
│  │  ├─ "Notificações"                                           │    │
│  │  └─ "Marcar todas como lidas"                               │    │
│  │                                                               │    │
│  │  Tabs:                                                        │    │
│  │  ├─ Todas                                                     │    │
│  │  ├─ Menções                                                   │    │
│  │  └─ Não lidas (badge: 3)                                     │    │
│  │                                                               │    │
│  │  Lista de notificações:                                      │    │
│  │                                                               │    │
│  │  [•] Novo interesse em BS2#001                              │    │
│  │      ├─ XP Asset manifestou interesse                        │    │
│  │      ├─ Há 5 minutos                                         │    │
│  │      └─ [Ver detalhes]                                       │    │
│  │                                                               │    │
│  │  [•] Solicitação de acesso pendente                         │    │
│  │      ├─ Caio Paixão solicitou acesso ao workspace          │    │
│  │      ├─ Há 1 hora                                            │    │
│  │      └─ [Gerenciar]                                          │    │
│  │                                                               │    │
│  │  [ ] Documento baixado                                       │    │
│  │      ├─ BTG Pactual baixou Investment Deck                  │    │
│  │      ├─ Há 3 horas                                           │    │
│  │      └─ [Ver atividade]                                      │    │
│  │                                                               │    │
│  │  Footer:                                                      │    │
│  │  └─ "Ver todas notificações" →                              │    │
│  │                                                               │    │
│  │  Configurações de notificação:                               │    │
│  │  ├─ Email                                                     │    │
│  │  ├─ Push (navegador)                                         │    │
│  │  └─ In-app (sempre ativo)                                   │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                        │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 MATRIZ DE DECISÃO - NAVEGAÇÃO

| De/Para | Dashboard | Operações | Detalhes | Gerenciar | Config | Onboard |
|---------|-----------|-----------|----------|-----------|--------|---------|
| **Dashboard** | - | Click sidebar | Card CTA | Click tab | Dropdown | - |
| **Operações** | Sidebar | - | "Saiba mais" | Tab/Sidebar | Dropdown | - |
| **Detalhes** | Breadcrumb | Breadcrumb | - | Via ops | Dropdown | - |
| **Gerenciar** | Sidebar | Sidebar | Table row | - | Dropdown | - |
| **Config** | Sidebar | Sidebar | - | - | - | - |
| **Onboard** | CTA final | - | - | - | - | Linear |

---

## 🔄 ESTADOS E TRANSIÇÕES

```
ESTADOS DA OPERAÇÃO:
Rascunho → Publicada → Ativa → Pausada → Encerrada → Arquivada
            ↓
    Pode ir direto para Pausada ou Encerrada

PERMISSÕES DE USUÁRIO:
Dono → Pode tudo
Admin → Pode gerenciar membros e operações
Membro → Pode ver e interagir com operações
Visualizador → Só leitura

FLUXO DE ACESSO:
Solicitação → Pendente → (Aceito → Ativo) OU (Rejeitado → Arquivado)
```

---

## 📱 RESPONSIVIDADE - BREAKPOINTS

```
Mobile (< 768px):
├─ Sidebar vira bottom navigation
├─ Tabelas viram cards empilhados
├─ Modais são full-screen
├─ Grid de 1 coluna
└─ Navegação por swipe

Tablet (768px - 1023px):
├─ Sidebar colapsável
├─ Grid de 2 colunas
├─ Tabelas com scroll horizontal
└─ Modais com largura máxima

Desktop (> 1024px):
├─ Layout completo
├─ Grid de 3 colunas
├─ Todas as features visíveis
└─ Sidebar sempre expandida
```

---

Criado em: 18/02/2026  
Versão: 1.0  
Status: 🟢 Em revisão
